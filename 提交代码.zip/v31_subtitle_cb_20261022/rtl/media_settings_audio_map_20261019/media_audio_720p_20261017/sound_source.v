module sound_source  (
    input  wire               clk,
    input  wire               rst,
    input  wire               trigger,
    input  wire [1:0]         sound_id,

    output wire signed [23:0] pcm_sample,
    output wire               pcm_valid
);
    // sound_id remains a compatibility port; every UI action uses one click.
    ui_click_sound #(.CLK_HZ(75000000)) u_click (
        .clk(clk),.rst(rst),.trigger(trigger),
        .pcm_sample(pcm_sample),.pcm_valid(pcm_valid));

endmodule
