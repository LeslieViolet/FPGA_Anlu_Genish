// Part 7: leased frame-range reader in the clk_pixel domain.
// Part 8 implements the CDC FIFOs and physical SDRAM adapter behind mem_*.
`timescale 1ns/1ps
`default_nettype none
module zhen_duqu (
    input wire clk,
    input wire rst,
    input wire disp_valid,
    input wire disp_buffer_sel,
    input wire [15:0] disp_index,
    input wire [1:0] disp_physical_slot,
    input wire [15:0] disp_width,
    input wire [15:0] disp_height,
    input wire disp_previous_valid,
    input wire disp_previous_sel,
    input wire read_req,
    output reg read_ack,
    input wire read_buffer_sel,
    input wire [31:0] read_start_addr,
    input wire [31:0] read_length,
    output wire read_pixel_valid,
    input wire read_pixel_ready,
    output wire [23:0] read_pixel_data,
    output wire read_pixel_last,
    output wire read_done,
    input wire read_done_ready,
    output reg [3:0] read_status,
    input wire read_cancel_req,
    output reg read_cancel_ack,
    output wire mem_read_valid,
    input wire mem_read_ready,
    output wire [20:0] mem_read_addr,
    input wire mem_read_data_valid,
    output wire mem_read_data_ready,
    input wire [31:0] mem_read_data,
    output wire mem_read_cancel_req,
    input wire mem_read_cancel_done,
    input wire memory_fault,
    output wire display_reads_idle,
    output reg reset_required
);
    localparam [1:0] IDLE=2'd0, ACTIVE=2'd1,
                     CANCEL_DRAIN=2'd2, DONE=2'd3;
    wire [32:0] FRAME_WORDS=33'd921600;
    wire [20:0] SLOT_WORDS=21'd921600;

    reg [1:0] state;
    reg req_seen;
    reg buffer_reg;
    reg [1:0] physical_slot_reg;
    reg last_disp_token;
    reg [1:0] last_disp_slot, previous_disp_slot;
    reg [31:0] start_reg, length_reg;
    reg [31:0] issued_count, returned_count;
    reg pixel_valid_reg, pixel_last_reg;
    reg [23:0] pixel_data_reg;

    wire lease_ok = (disp_valid && read_buffer_sel==disp_buffer_sel) ||
                    (disp_previous_valid && read_buffer_sel==disp_previous_sel);
    wire descriptor_ok = disp_width==(16'd1280) &&
                         disp_height==(16'd720) &&
                         disp_index < 16'd16 &&
                         disp_physical_slot<2;
    wire [32:0] range_end = {1'b0,read_start_addr}+{1'b0,read_length};
    wire range_ok = read_length!=0 && range_end<=FRAME_WORDS;
    wire [32:0] next_offset = {1'b0,start_reg}+{1'b0,issued_count};
    wire [20:0] slot_base = physical_slot_reg[0] ? 21'd921600 : 21'd0;
    wire mem_request_take = mem_read_valid && mem_read_ready;
    wire mem_data_take = mem_read_data_valid && mem_read_data_ready;
    wire pixel_take = read_pixel_valid && read_pixel_ready;

    assign mem_read_valid = !rst && state==ACTIVE &&
                            issued_count<length_reg &&
                            !read_cancel_req && !memory_fault;
    assign mem_read_addr = slot_base+next_offset[20:0];
    // During cancellation, consume and discard irrevocable read responses
    // until Part 8 confirms that its command and data paths are empty.
    assign mem_read_data_ready = !rst &&
        ((state==ACTIVE && (!pixel_valid_reg || read_pixel_ready) &&
          !read_cancel_req && !memory_fault) || state==CANCEL_DRAIN);
    assign mem_read_cancel_req = !rst && state==CANCEL_DRAIN;
    assign read_pixel_valid = !rst && state==ACTIVE && pixel_valid_reg &&
                              !read_cancel_req && !memory_fault;
    assign read_pixel_data = pixel_data_reg;
    assign read_pixel_last = read_pixel_valid && pixel_last_reg;
    assign read_done = !rst && state==DONE;
    assign display_reads_idle = !rst && state==IDLE && !pixel_valid_reg;

    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=IDLE; req_seen<=0; buffer_reg<=0; physical_slot_reg<=0;
            last_disp_token<=0; last_disp_slot<=0; previous_disp_slot<=0;
            start_reg<=0;
            length_reg<=0; issued_count<=0; returned_count<=0;
            pixel_valid_reg<=0; pixel_last_reg<=0; pixel_data_reg<=0;
            read_ack<=0; read_status<=0; read_cancel_ack<=0;
            reset_required<=0;
        end else begin
            // The display token changes only when a committed image is viewed.
            // Keep the prior physical image for the optional previous-frame lease.
            if(disp_valid && disp_buffer_sel != last_disp_token) begin
                previous_disp_slot <= last_disp_slot;
                last_disp_token <= disp_buffer_sel;
                last_disp_slot <= disp_physical_slot;
            end else if(disp_valid) begin
                last_disp_slot <= disp_physical_slot;
            end
            read_ack<=0;
            read_cancel_ack<=0;
            if(!read_req) req_seen<=0;
            if(memory_fault) reset_required<=1;
            case(state)
                IDLE: begin
                    pixel_valid_reg<=0;
                    if(read_req && !req_seen) begin
                        req_seen<=1; read_ack<=1;
                        buffer_reg<=read_buffer_sel;
                        physical_slot_reg <= (disp_valid &&
                            read_buffer_sel == disp_buffer_sel) ?
                            disp_physical_slot : previous_disp_slot;
                        start_reg<=read_start_addr; length_reg<=read_length;
                        issued_count<=0; returned_count<=0; read_status<=0;
                        if(memory_fault || reset_required) begin
                            read_status<=4'd4; state<=DONE;
                        end else if(!lease_ok || !descriptor_ok) begin
                            read_status<=4'd1; state<=DONE;
                        end else if(!range_ok) begin
                            read_status<=4'd2; state<=DONE;
                        end else state<=ACTIVE;
                    end
                end
                ACTIVE: begin
                    if(memory_fault) begin
                        read_status<=4'd4; pixel_valid_reg<=0;
                        state<=CANCEL_DRAIN;
                    end else if(read_cancel_req) begin
                        read_status<=4'd3; pixel_valid_reg<=0;
                        state<=CANCEL_DRAIN;
                    end else begin
                        if(mem_request_take) issued_count<=issued_count+1'b1;
                        if(pixel_take && !mem_data_take) pixel_valid_reg<=0;
                        if(mem_data_take) begin
                            returned_count<=returned_count+1'b1;
                            pixel_data_reg<=mem_read_data[31:8];
                            pixel_last_reg<=returned_count==length_reg-1'b1;
                            pixel_valid_reg<=1;
                        end
                        if(pixel_take && pixel_last_reg) begin
                            pixel_valid_reg<=0; read_status<=4'd0;
                            state<=DONE;
                        end
                    end
                end
                CANCEL_DRAIN: begin
                    pixel_valid_reg<=0;
                    if(mem_data_take) returned_count<=returned_count+1'b1;
                    if(mem_read_cancel_done) begin
                        if(read_status==4'd3) read_cancel_ack<=1;
                        state<=DONE;
                    end
                end
                DONE: begin
                    pixel_valid_reg<=0;
                    if(read_done_ready) state<=IDLE;
                end
                default: begin
                    state<=DONE; read_status<=4'd4; pixel_valid_reg<=0;
                    reset_required<=1;
                end
            endcase
        end
    end
endmodule
`default_nettype wire
