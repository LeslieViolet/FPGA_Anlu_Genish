// Parts 2/3/4 with an exclusive shared Part 1 reader port.
// Scan wins simultaneous requests. Owner retained through load result handshake.
`default_nettype none
module sucai_jiazai_tongdao #(
    parameter KEEP_CATALOG=0,
    parameter [31:0] IO_TIMEOUT_CYCLES=32'd200000000
)(
    input wire clk, rst, input wire rst_catalog,
    input wire scan_valid,
    output wire scan_ready,
    input wire [31:0] scan_first_lba, scan_last_lba,
    output wire scan_done,
    output wire [3:0] scan_status,
    output wire [4:0] asset_count,
    input wire load_valid,
    output wire load_ready,
    input wire [3:0] load_id,
    input wire cancel,
    output wire busy, reset_required,
    output wire result_valid,
    input wire result_ready,
    output wire [3:0] result_code, reader_error_code,
    output wire [15:0] result_index,
    output wire frame_valid,
    input wire frame_ready,
    output wire [15:0] frame_width, frame_height, frame_index,
    output wire frame_bottom_up,
    output wire pixel_valid,
    input wire pixel_ready,
    output wire [23:0] pixel_rgb,
    output wire [15:0] pixel_x, pixel_y,
    output wire pixel_last,
    input wire card_ready, reader_busy,
    output wire read_valid,
    input wire read_ready,
    output wire [31:0] read_lba,
    input wire [7:0] data,
    input wire data_valid, data_last,
    output wire data_ready,
    input wire reader_done, reader_error,
    input wire [3:0] read_error_code
);

    localparam [1:0] FREE=0, SCAN=1, LOAD=2, LOCKED=3;
    reg [1:0] owner;
    wire catalog_rst=KEEP_CATALOG ? rst_catalog : rst;
    wire s_ready,s_busy,s_req,s_data_ready,s_result;
    wire l_ready,l_req,l_data_ready,l_reset,map_open_ready,map_busy;
    wire [31:0] s_lba,l_lba,asset_cluster,asset_length;
    wire [31:0] fat_lba,data_lba,max_cluster;
    wire [32:0] volume_end;
    wire [7:0] cluster_sectors;
    wire query_valid;
    wire [3:0] cat_code,load_error;
    reg scan_done_reg;reg [3:0] scan_status_reg;
    wire available=!rst && owner==FREE && !reader_busy && !l_reset;
    assign scan_ready=available && s_ready;
    assign scan_done=scan_done_reg;
    assign scan_status=scan_status_reg;
    assign load_ready=available && !scan_valid && scan_done && scan_status==0 &&
                      card_ready && l_ready && map_open_ready;
    assign busy=!rst && (owner==SCAN || owner==LOAD);
    assign reset_required=owner==LOCKED || l_reset || (scan_done && scan_status>=3);
    assign reader_error_code=(owner==SCAN || (scan_done && scan_status>=3)) ? cat_code : load_error;
    wire m_req,m_ready,m_dvalid,m_last,m_done,m_error,m_data_ready;
    wire [31:0] m_lba;
    wire [7:0] m_data;
    assign read_valid=owner==SCAN ? s_req : owner==LOAD ? m_req : 1'b0;
    assign read_lba=owner==SCAN ? s_lba : m_lba;
    assign data_ready=owner==SCAN ? s_data_ready : owner==LOAD ? m_data_ready : 1'b1;
    always @(posedge clk or posedge catalog_rst)begin
      if(catalog_rst)begin scan_done_reg<=0;scan_status_reg<=0;end
      else if(scan_valid && scan_ready)begin scan_done_reg<=0;scan_status_reg<=0;end
      else if(s_result)begin
        scan_done_reg<=1;
        scan_status_reg<=cat_code==0?4'd0:cat_code==2?4'd1:4'd3;
      end
    end
    always @(posedge clk or posedge rst)begin
      if(rst)owner<=FREE;
      else case(owner)
       FREE:if(scan_valid && scan_ready)owner<=SCAN;
            else if(load_valid && load_ready)owner<=LOAD;
       SCAN:if(scan_done && !s_busy)owner<=scan_status>=3?LOCKED:FREE;
       LOAD:if(result_valid && result_ready)owner<=l_reset?LOCKED:FREE;
       LOCKED:owner<=LOCKED;
      endcase
    end
    fat32_picture_catalog #(.TIMEOUT_CYCLES(IO_TIMEOUT_CYCLES)) u_picture_catalog(
      .clk(clk),.rst(catalog_rst),.abort(1'b0),
      .start_valid(scan_valid && scan_ready),.start_ready(s_ready),
      .read_valid(s_req),.read_ready(read_ready && owner==SCAN),.read_lba(s_lba),
      .data(data),.data_valid(data_valid && owner==SCAN),.data_ready(s_data_ready),
      .data_last(data_last),.read_done(reader_done && owner==SCAN),
      .read_error(reader_error && owner==SCAN),.result_valid(s_result),.result_ready(1'b1),
      .result_code(cat_code),.file_first_cluster(),.file_size(),.partition_lba(),
      .fat_start_lba(fat_lba),.data_start_lba(data_lba),.max_cluster(max_cluster),
      .volume_end_lba(volume_end),.sectors_per_cluster(cluster_sectors),.busy(s_busy),
      .query_id(load_id),.query_valid(query_valid),.query_cluster(asset_cluster),
      .query_size(asset_length),.asset_count(asset_count),.wallpaper_present());
    fat32_image_sector_bridge #(.TIMEOUT_CYCLES(IO_TIMEOUT_CYCLES)) u_image_file_bridge(
      .clk(clk),.rst(rst),.abort((cancel && owner==LOAD) || (result_valid && result_ready)),
      .open_valid(load_valid && load_ready && query_valid),.open_ready(map_open_ready),
      .file_first_cluster(asset_cluster),.file_length(asset_length),
      .fat_start_lba(fat_lba),.data_start_lba(data_lba),.max_cluster(max_cluster),
      .volume_end_lba(volume_end),.sectors_per_cluster(cluster_sectors),
      .client_valid(l_req && owner==LOAD),.client_ready(m_ready),
      .client_data(m_data),.client_data_valid(m_dvalid),.client_data_ready(l_data_ready),
      .client_data_last(m_last),.client_done(m_done),.client_error(m_error),.busy(map_busy),
      .read_valid(m_req),.read_ready(read_ready && owner==LOAD),.read_lba(m_lba),
      .data(data),.data_valid(data_valid && owner==LOAD),.data_last(data_last),
      .data_ready(m_data_ready),.reader_done(reader_done && owner==LOAD),
      .reader_error(reader_error && owner==LOAD));
    tuxiang_jiazai #(.IO_TIMEOUT_CYCLES(IO_TIMEOUT_CYCLES),.TRUST_HEADER_OFFSET(1)) u_tuxiang_jiazai(
      .clk(clk),.rst(rst),.load_valid(load_valid && load_ready),.load_ready(l_ready),
      .descriptor_valid(query_valid),.asset_lba(32'd0),.asset_length(asset_length),
      .asset_offset(32'd0),.asset_index({12'd0,load_id}),.cancel(cancel && owner==LOAD),
      .busy(),.reset_required(l_reset),.result_valid(result_valid),.result_ready(result_ready && owner==LOAD),
      .result_code(result_code),.result_index(result_index),.reader_error_code(load_error),
      .frame_valid(frame_valid),.frame_ready(frame_ready),.frame_width(frame_width),
      .frame_height(frame_height),.frame_index(frame_index),.frame_bottom_up(frame_bottom_up),
      .pixel_valid(pixel_valid),.pixel_ready(pixel_ready),.pixel_rgb(pixel_rgb),
      .pixel_x(pixel_x),.pixel_y(pixel_y),.pixel_last(pixel_last),
      .card_ready(card_ready),.reader_busy(reader_busy || map_busy),.read_valid(l_req),
      .read_ready(m_ready && owner==LOAD),.read_lba(l_lba),.data(m_data),
      .data_valid(m_dvalid && owner==LOAD),.data_last(m_last),.data_ready(l_data_ready),
      .reader_done(m_done && owner==LOAD),.reader_error(m_error && owner==LOAD),
      .read_error_code(m_error?4'd3:read_error_code));
endmodule
`default_nettype wire
