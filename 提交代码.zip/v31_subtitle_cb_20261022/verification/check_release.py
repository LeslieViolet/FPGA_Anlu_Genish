from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
for rel,expected in manifest.items():
    p=root/rel;assert p.is_file(),p
    assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,'Changed: '+str(p)
status=json.loads((root/'release_status.json').read_text(encoding='utf-8'))
project=root/'project/media_audio_720p_20261017.al';tree=ET.parse(project)
assert tree.findtext('TOP_MODULE/MODULE')=='top_720p'
active=0
for f in tree.findall('Source_Files/Verilog/File'):
    assert (project.parent/f.get('Path')).resolve().is_file()
    attrs={x.get('Name'):x.get('Val') for x in f.findall('FileInfo/Attr')}
    if attrs.get('AutoExcluded')!='true' and attrs.get('UsedInSyn')=='true':
        assert attrs['UsedInP&R']=='true';active+=1
assert active==101
print('SUBTITLE_CB_RELEASE_CURRENT',json.dumps(status['metrics']),status['timing'])
