`default_nettype none

// Remote-only production input layer. Board-key ports/parameters are
// retained for source compatibility and intentionally have no consumers.
module control_input #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer DEBOUNCE_MS = 20
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       key_next_n,
    input  wire       key_auto_n,
    input  wire       key_aux_n,
    input  wire       ir_event_valid,
    input  wire [3:0] ir_event_code,
    input  wire       ir_event_repeat,
    input  wire       ir_digit_valid,
    input  wire [3:0] ir_digit_code,
    output reg        ui_event_valid,
    output reg  [3:0] ui_event_code,
    output reg        ui_event_repeat,
    output reg        ui_event_source,
    output reg        ui_digit_valid,
    output reg  [3:0] ui_digit_code
);

localparam [3:0] EVT_NONE     = 4'd0;
localparam [3:0] EVT_UP       = 4'd1;
localparam [3:0] EVT_DOWN     = 4'd2;
localparam [3:0] EVT_LEFT     = 4'd3;
localparam [3:0] EVT_RIGHT    = 4'd4;
localparam [3:0] EVT_OK       = 4'd5;
localparam [3:0] EVT_BACK     = 4'd6;
localparam [3:0] EVT_SETTINGS = 4'd7;
localparam [3:0] EVT_FUNCTION = 4'd8;
localparam [3:0] EVT_PLAY     = 4'd9;

// Register remote transactions once, preserving the original event/digit
// priority, latency and source tag. No board-key debounce hardware remains.
always @(posedge clk or posedge rst) begin
    if (rst) begin
        ui_event_valid  <= 1'b0;
        ui_event_code   <= EVT_NONE;
        ui_event_repeat <= 1'b0;
        ui_event_source <= 1'b0;
        ui_digit_valid <= 1'b0;
        ui_digit_code  <= 4'd0;
    end else begin
        ui_event_valid  <= 1'b0;
        ui_event_code   <= EVT_NONE;
        ui_event_repeat <= 1'b0;
        ui_event_source <= 1'b0;
        ui_digit_valid <= 1'b0;
        ui_digit_code  <= 4'd0;
        if (ir_event_valid) begin
            ui_event_valid  <= 1'b1;
            ui_event_code   <= ir_event_code;
            ui_event_repeat <= ir_event_repeat;
            ui_event_source <= 1'b1;
        end else if (ir_digit_valid) begin
            ui_digit_valid <= 1'b1;
            ui_digit_code  <= ir_digit_code;
        end
    end
end
endmodule

`default_nettype wire
