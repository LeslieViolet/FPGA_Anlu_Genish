`default_nettype none
// Canonical PCM WAV profile: fmt16/data44, 48kHz, signed16 mono or stereo.
// Input bytes MUST be committed after sector CRC succeeds, not provisional SPI.
module audio_wav_stream #(
 parameter integer BYTE_TIMEOUT_CYCLES=250000000
)(
 input wire clk,rst,abort,
 input wire open_valid,output wire open_ready,input wire [31:0] file_length,
 input wire byte_valid,output wire byte_ready,input wire [7:0] byte_data,input wire byte_last,
 output reg sample_valid,input wire sample_ready,
 output reg signed [15:0] pcm_left,pcm_right,output reg sample_last,
 output reg opened,done,error,output reg [3:0] error_code,
 output reg [31:0] sample_count,output reg stereo
);
 localparam [2:0] IDLE=0,HEADER=1,CHECK=2,PCM=3,FINISHED=4,FAILED=5,VERIFY=6;
 // SWUG106 p39: keep the explicit compact state encoding for this small parser.
 (* fsm_encoding="sequential" *) reg [2:0] state;
 reg [5:0] header_pos;
 localparam TIMEOUT_W=BYTE_TIMEOUT_CYCLES<2?1:$clog2(BYTE_TIMEOUT_CYCLES);
 reg [31:0] length_latched,remaining,header_riff_size,header_data_size;
 reg [TIMEOUT_W-1:0] timeout_count;
 reg profile_error;
 reg [1:0] sample_byte;reg [7:0] low_byte;
 reg length_ok,header_stereo;
 wire take_byte=byte_valid&&byte_ready;
 wire take_sample=sample_valid&&sample_ready;
 assign open_ready=!rst&&!abort&&(state==IDLE||state==FINISHED||state==FAILED)&&!sample_valid;
 assign byte_ready=!rst&&!abort&&((state==HEADER)||((state==PCM)&&!sample_valid));
 // Fixed profile bytes are checked in flight. Only two lengths are retained.
 function [7:0] expected_header_byte(input [5:0] p,input two_channels);
  begin case(p)
   0:expected_header_byte="R";1:expected_header_byte="I";2,3:expected_header_byte="F";
   8:expected_header_byte="W";9:expected_header_byte="A";10:expected_header_byte="V";11:expected_header_byte="E";
   12:expected_header_byte="f";13:expected_header_byte="m";14:expected_header_byte="t";15:expected_header_byte=" ";
   16,34:expected_header_byte=16;20:expected_header_byte=1;
   24:expected_header_byte=8'h80;25:expected_header_byte=8'hbb;
   29:expected_header_byte=two_channels?8'hee:8'h77;
   30:expected_header_byte=two_channels?8'h02:8'h01;
   32:expected_header_byte=two_channels?8'h04:8'h02;
   36:expected_header_byte="d";37,39:expected_header_byte="a";38:expected_header_byte="t";
   default:expected_header_byte=0;
  endcase end
 endfunction
 wire open_fire=open_valid&&open_ready;
 // Counter starts at zero and cannot advance past the terminal value.
 wire input_timeout=byte_ready&&!byte_valid&&(BYTE_TIMEOUT_CYCLES==0||timeout_count==BYTE_TIMEOUT_CYCLES-1);
 reg [2:0] next_state;reg [3:0] failure_code;
 // State transition logic has a single state-register driver, independent of data.
 always @* begin
  next_state=state;failure_code=0;
  if(abort)next_state=IDLE;
  else if(open_fire)begin
   if(file_length<46)begin next_state=FAILED;failure_code=1;end
   else next_state=HEADER;
  end else begin
   case(state)
    HEADER:if(take_byte)begin
     if(byte_last)begin next_state=FAILED;failure_code=1;end
     else if(header_pos==43)next_state=CHECK;
    end
    CHECK:next_state=VERIFY;
    VERIFY:begin
     if(profile_error)begin next_state=FAILED;failure_code=2;end
     else if(!length_ok)begin next_state=FAILED;failure_code=1;end
     else next_state=PCM;
    end
    PCM:begin
     if(take_byte&&byte_last!=(remaining==1))begin next_state=FAILED;failure_code=3;end
     else if(take_sample&&sample_last)next_state=FINISHED;
    end
    default:begin end
   endcase
   if(input_timeout)begin next_state=FAILED;failure_code=4;end
  end
 end
 always @(posedge clk or posedge rst)
  if(rst)state<=IDLE;else state<=next_state;
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   header_pos<=0;length_latched<=0;remaining<=0;
   sample_byte<=0;low_byte<=0;sample_valid<=0;pcm_left<=0;pcm_right<=0;
   sample_last<=0;opened<=0;done<=0;error<=0;error_code<=0;sample_count<=0;stereo<=0;timeout_count<=0;
   length_ok<=0;header_stereo<=0;
   header_riff_size<=0;header_data_size<=0;profile_error<=0;
  end else begin
   done<=0;
   if(abort)begin
    sample_valid<=0;sample_last<=0;opened<=0;error<=0;error_code<=0;timeout_count<=0;
    sample_byte<=0;sample_count<=0;
   end else if(open_fire)begin
    header_pos<=0;length_latched<=file_length;sample_valid<=0;
    profile_error<=0;header_riff_size<=0;header_data_size<=0;header_stereo<=0;
    opened<=0;error<=0;error_code<=0;sample_last<=0;sample_byte<=0;sample_count<=0;stereo<=0;timeout_count<=0;
    if(failure_code!=0)begin error<=1;error_code<=failure_code;end
   end else if(failure_code!=0)begin
    error<=1;error_code<=failure_code;sample_valid<=0;sample_last<=0;opened<=0;
   end else begin
    if(take_sample)begin
     // A <=4GiB signed16 WAV contains fewer than 2^31 mono samples.
     sample_valid<=0;sample_count<={1'b0,sample_count[30:0]+31'd1};
     if(sample_last)begin done<=1;opened<=0;end
    end
    if(take_byte)begin timeout_count<=0;end
    else if(byte_ready)begin
     timeout_count<=timeout_count+1'b1;
    end else timeout_count<=0;
    case(state)
     HEADER:if(take_byte)begin
      if(header_pos>=4&&header_pos<=7)header_riff_size<={byte_data,header_riff_size[31:8]};
      else if(header_pos>=40)header_data_size<={byte_data,header_data_size[31:8]};
      else if(header_pos==22)begin
       header_stereo<=byte_data==2;
       if(byte_data!=1&&byte_data!=2)profile_error<=1;
      end else if(byte_data!=expected_header_byte(header_pos,header_stereo))profile_error<=1;
      if(header_pos!=43)header_pos<=header_pos+1'b1;
     end
     CHECK:begin
      length_ok<=header_riff_size==length_latched-8&&header_data_size==length_latched-44&&header_data_size!=0&&
         (header_stereo?(header_data_size&3)==0:(header_data_size&1)==0);
      remaining<=header_data_size;
     end
     VERIFY:begin
      stereo<=header_stereo;opened<=1;
     end
     PCM:if(take_byte)begin
      begin
       remaining<=remaining-1'b1;
       sample_byte<=sample_byte==(stereo?2'd3:2'd1)?2'd0:sample_byte+2'd1;
       case(sample_byte)
        0:begin low_byte<=byte_data;end
        1:begin
         // Use the output register as the left-half holding register while invalid.
         pcm_left<={byte_data,low_byte};
         if(!stereo)begin pcm_right<={byte_data,low_byte};sample_valid<=1;sample_last<=remaining==1;end
        end
        2:begin low_byte<=byte_data;end
        3:begin pcm_right<={byte_data,low_byte};sample_valid<=1;sample_last<=remaining==1;end
       endcase
      end
     end
    endcase
   end
  end
 end
endmodule
`default_nettype wire
