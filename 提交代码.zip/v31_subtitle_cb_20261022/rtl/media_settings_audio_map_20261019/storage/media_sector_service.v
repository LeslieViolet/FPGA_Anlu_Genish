`default_nettype none
// One physical reader. All control/quiescence inputs belong to clk.
module media_sector_service #(
 parameter integer POWER_UP_CYCLES=1000000,
 parameter [15:0] INIT_HALF_PERIOD=16'd125,DATA_HALF_PERIOD=16'd2,
 parameter [31:0] SWITCH_TIMEOUT_CYCLES=32'd250000000,
 parameter integer STOP_TIMEOUT_BYTES=65535
)(
 input wire clk,rst,
 input wire mode_valid,output wire mode_ready,input wire requested_mode,
 output reg active_mode,output reg mode_result_valid,input wire mode_result_ready,
 output reg [1:0] mode_result_code,output wire switching,output reg reset_required,
 input wire [1:0] clients_idle,client_cancel_supported,
 input wire memory_drained,display_reads_retired,external_fault,
 input wire [1:0] client_read_valid,output wire [1:0] client_read_ready,
 input wire [63:0] client_lba,input wire [31:0] client_blocks,
 output wire [7:0] client_data,output wire [1:0] client_data_valid,client_data_last,
 input wire [1:0] client_data_ready,
 output wire [1:0] client_block_done,client_busy,client_card_ready,client_cancel,
 output reg [1:0] client_done,client_error,output reg [7:0] client_error_code,
 output wire tf_cs_n,tf_sclk,tf_mosi,input wire tf_miso
);
 localparam integer SWITCH_TIMER_BITS =
     SWITCH_TIMEOUT_CYCLES <= 1 ? 1 : $clog2(SWITCH_TIMEOUT_CYCLES);
 reg transaction_active,transaction_owner,transaction_cancelled;
 reg [3:0] cancel_code;
 reg mode_pending,target_mode;
 reg [SWITCH_TIMER_BITS-1:0] switch_timer;
 wire reader_ready,reader_busy,reader_card_ready,reader_done,reader_error;
 wire reader_valid,reader_last,reader_block_done;
 wire [7:0] reader_data;
 wire [3:0] reader_error_code;
 wire reader_data_ready;
 assign mode_ready=!rst && !mode_pending && !mode_result_valid && !reset_required && !external_fault &&
                   (requested_mode==active_mode || clients_idle[active_mode] || client_cancel_supported[active_mode]);
 wire mode_fire=mode_valid && mode_ready;
 wire switch_start=mode_fire && requested_mode!=active_mode;
 assign switching=mode_pending;
 wire can_issue=!rst && !transaction_active && !mode_pending && !mode_result_valid &&
                !mode_fire && !reset_required && !external_fault;
 wire read_valid=can_issue && client_read_valid[active_mode];
 wire read_fire=read_valid && reader_ready;
 assign client_read_ready[0]=can_issue && !active_mode && reader_ready;
 assign client_read_ready[1]=can_issue &&  active_mode && reader_ready;
 wire draining=mode_pending || transaction_cancelled || switch_start || reset_required || external_fault;
 assign client_data=reader_data;
 assign client_data_valid[0]=!rst && transaction_active && !transaction_owner && !draining && reader_valid;
 assign client_data_valid[1]=!rst && transaction_active &&  transaction_owner && !draining && reader_valid;
 assign client_data_last=client_data_valid & {2{reader_last}};
 assign client_block_done[0]=!rst && transaction_active && !transaction_owner && !draining && reader_block_done;
 assign client_block_done[1]=!rst && transaction_active &&  transaction_owner && !draining && reader_block_done;
 assign reader_data_ready=transaction_active && (draining || client_data_ready[transaction_owner]);
 assign client_busy=transaction_active ? (transaction_owner ? 2'b10 : 2'b01) : 2'b00;
 // Physical availability is distinct from read-request admission.
 wire available=reader_card_ready && !reset_required && !external_fault && !rst;
 assign client_card_ready=available ? (active_mode ? 2'b10 : 2'b01) : 2'b00;
 assign client_cancel=(mode_pending || switch_start || reset_required || external_fault) && !rst ?
                      (active_mode ? 2'b10 : 2'b01) : 2'b00;
 wire terminal=transaction_active && !reader_busy && tf_cs_n && !reader_valid && (reader_done || reader_error);
 wire timed_out=SWITCH_TIMEOUT_CYCLES==0 || switch_timer>=SWITCH_TIMEOUT_CYCLES-1'b1;
 tf_spi_burst_reader #(.POWER_UP_CYCLES(POWER_UP_CYCLES),
  .INIT_HALF_PERIOD(INIT_HALF_PERIOD),.DATA_HALF_PERIOD(DATA_HALF_PERIOD),
  .STOP_TIMEOUT_BYTES(STOP_TIMEOUT_BYTES)) u_reader (
  .clk(clk),.rst(rst),.read_valid(read_valid),.read_ready(reader_ready),
  .read_lba(active_mode ? client_lba[63:32] : client_lba[31:0]),
  .read_blocks(active_mode ? client_blocks[31:16] : client_blocks[15:0]),
  .block_done(reader_block_done),.blocks_completed(),.transaction_cycles(),.payload_bytes(),
  .data(reader_data),.data_valid(reader_valid),.data_ready(reader_data_ready),.data_last(reader_last),
  .busy(reader_busy),.card_ready(reader_card_ready),.done(reader_done),.error(reader_error),
  .error_code(reader_error_code),.tf_cs_n(tf_cs_n),.tf_sclk(tf_sclk),.tf_mosi(tf_mosi),.tf_miso(tf_miso));
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   active_mode<=0;mode_pending<=0;target_mode<=0;switch_timer<=0;
   mode_result_valid<=0;mode_result_code<=0;reset_required<=0;
   transaction_active<=0;transaction_owner<=0;transaction_cancelled<=0;cancel_code<=0;
   client_done<=0;client_error<=0;client_error_code<=0;
  end else begin
   client_done<=0;client_error<=0;
   if(mode_result_valid && mode_result_ready)mode_result_valid<=0;
   if(read_fire)begin
    transaction_active<=1;transaction_owner<=active_mode;
    transaction_cancelled<=0;cancel_code<=0;
    if(active_mode)client_error_code[7:4]<=0;else client_error_code[3:0]<=0;
   end
   if(mode_fire)begin
    switch_timer<=0;
    if(requested_mode==active_mode)begin mode_result_valid<=1;mode_result_code<=0;end
    else begin
     mode_pending<=1;target_mode<=requested_mode;
     if(transaction_active)begin transaction_cancelled<=1;cancel_code<=4'd12;end
    end
   end
   if(terminal)begin
    transaction_active<=0;
    if(reader_error || transaction_cancelled || switch_start || external_fault)begin
     client_error[transaction_owner]<=1;
     if(transaction_owner)client_error_code[7:4]<=reader_error ? reader_error_code :
       (external_fault ? 4'd13 : (switch_start ? 4'd12 : cancel_code));
     else client_error_code[3:0]<=reader_error ? reader_error_code :
       (external_fault ? 4'd13 : (switch_start ? 4'd12 : cancel_code));
    end else client_done[transaction_owner]<=1;
   end
   if(mode_pending && !reset_required)begin
    if(!transaction_active && !reader_busy && reader_ready && tf_cs_n && !reader_valid && !reader_error && !external_fault &&
       &clients_idle && memory_drained && display_reads_retired)begin
     active_mode<=target_mode;mode_pending<=0;mode_result_valid<=1;mode_result_code<=0;
    end else if(timed_out)begin
     mode_pending<=0;mode_result_valid<=1;mode_result_code<=1;reset_required<=1;
     transaction_cancelled<=1;cancel_code<=4'd14;
    end else switch_timer<=switch_timer+1'b1;
   end
   // Reader errors can be asserted before CMD12 cleanup; never hand off early.
   if(!reset_required && reader_error && !reader_busy && tf_cs_n &&
      (mode_pending || switch_start || !reader_card_ready))begin
    reset_required<=1;transaction_cancelled<=1;
    if(mode_pending || switch_start)begin
     mode_pending<=0;mode_result_valid<=1;mode_result_code<=2;
    end
   end
   if(external_fault && !reset_required)begin
    reset_required<=1;transaction_cancelled<=1;cancel_code<=4'd13;
    if(mode_pending || mode_fire)begin mode_pending<=0;mode_result_valid<=1;mode_result_code<=3;end
   end
  end
 end
endmodule
`default_nettype wire
