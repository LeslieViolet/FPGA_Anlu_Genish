// Per-channel 0..16/16 fade. OSD is drawn after this stage and stays legible.
`default_nettype none
module baseline_transition_fade (
    input  wire [23:0] rgb_in,
    input  wire [4:0]  level,
    output wire [23:0] rgb_out
);
    wire [4:0] safe_level = level > 5'd16 ? 5'd16 : level;
    wire [12:0] r = rgb_in[23:16] * safe_level;
    wire [12:0] g = rgb_in[15:8]  * safe_level;
    wire [12:0] b = rgb_in[7:0]   * safe_level;
    assign rgb_out = {r[11:4], g[11:4], b[11:4]};
endmodule
`default_nettype wire
