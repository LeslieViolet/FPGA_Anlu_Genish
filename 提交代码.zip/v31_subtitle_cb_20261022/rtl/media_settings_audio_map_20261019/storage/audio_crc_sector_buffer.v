`default_nettype none
// One 512-byte SD sector. The producer's finish_ok must mean CRC was checked.
// Every provisional byte stays private until the complete sector is approved.
module audio_crc_sector_buffer(
 input wire clk,rst,abort,
 input wire start_valid,output wire start_ready,
 input wire [9:0] valid_bytes,input wire file_last,
 input wire provisional_valid,output wire provisional_ready,
 input wire [7:0] provisional_data,input wire provisional_last,
 input wire finish_valid,finish_ok,
 output wire byte_valid,input wire byte_ready,
 output reg [7:0] byte_data,output wire byte_last,
 output reg done,error,output reg [2:0] error_code
);
 localparam [1:0] IDLE=0,FILL=1,FETCH=2,PRESENT=3;
 reg [1:0] state;
 // SWUG106 §4.2.6 and §5.6.13: dedicated synchronous read/write processes.
 (* ram_style="bram_9k" *) reg [7:0] sector_ram[0:511];
 reg [9:0] written,bytes_latched;
 reg [8:0] rd_addr;
 reg last_latched,bad_frame;
 wire input_fire=provisional_valid&&provisional_ready;
 wire last_input=input_fire&&written==10'd511;
 wire input_bad=input_fire&&(provisional_last!=(written==10'd511));
 assign start_ready=!rst&&!abort&&state==IDLE;
 assign provisional_ready=!rst&&!abort&&state==FILL&&written<10'd512;
 assign byte_valid=!rst&&!abort&&state==PRESENT;
 assign byte_last=byte_valid&&last_latched&&({1'b0,rd_addr}+10'd1==bytes_latched);
 always @(posedge clk)begin
  if(!rst&&!abort&&state==FILL&&input_fire)
   sector_ram[written[8:0]]<=provisional_data;
  if(!rst&&!abort&&state==FETCH)
   byte_data<=sector_ram[rd_addr];
 end
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   state<=IDLE;written<=0;bytes_latched<=0;rd_addr<=0;
   last_latched<=0;bad_frame<=0;
   done<=0;error<=0;error_code<=0;
  end else begin
   done<=0;
   if(abort)begin
    state<=IDLE;written<=0;rd_addr<=0;bad_frame<=0;
    error<=0;error_code<=0;
   end else case(state)
    IDLE:if(start_valid&&start_ready)begin
     error<=0;error_code<=0;written<=0;rd_addr<=0;bad_frame<=0;
     bytes_latched<=valid_bytes;last_latched<=file_last;
     if(valid_bytes==0||valid_bytes>10'd512)begin
      error<=1;error_code<=3'd1;
     end else state<=FILL;
    end
    FILL:begin
     if(input_fire)begin
      written<=written+10'd1;
      if(input_bad)bad_frame<=1;
     end
     if(finish_valid)begin
      if(!finish_ok)begin error<=1;error_code<=3'd3;state<=IDLE;end
      else if((written!=10'd512&&!last_input)||bad_frame||input_bad)begin
       error<=1;error_code<=3'd2;state<=IDLE;
      end else begin rd_addr<=0;state<=FETCH;end
     end
    end
    FETCH:state<=PRESENT;
    PRESENT:if(byte_ready)begin
     if({1'b0,rd_addr}+10'd1==bytes_latched)begin state<=IDLE;done<=1;end
     else begin rd_addr<=rd_addr+9'd1;state<=FETCH;end
    end
   endcase
  end
 end
endmodule
`default_nettype wire
