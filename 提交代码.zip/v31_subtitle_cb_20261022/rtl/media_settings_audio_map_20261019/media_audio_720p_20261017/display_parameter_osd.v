`default_nettype none
// Glyph descriptors only: the compositor reuses its one synchronous font ROM.
// All inputs belong to the pixel domain and correspond to the same pixel.
module display_parameter_osd #(parameter FRAME_WIDTH=1280) (
input wire [10:0] x,y,
    input wire enabled,valid,editing,parameters_valid,parameters_pending,
    input wire [3:0] brightness_applied,contrast_applied,
    output wire panel_hit,border_hit,
    output wire [23:0] status_color,
    output reg text_valid,
    output reg [6:0] glyph,
    output wire [3:0] glyph_row,glyph_col
);
wire [10:0] active_width=FRAME_WIDTH;
    wire [10:0] LEFT=active_width-176;
    // 160x64 panel, 16 pixels from the upper and right display edges.
    assign panel_hit=enabled && valid && x>=LEFT && x<LEFT+160 && y>=16 && y<80;
    assign border_hit=panel_hit && (x==LEFT || x==LEFT+159 || y==16 || y==79);
    assign status_color=parameters_pending ? 24'hffcc40 :
                        editing ? 24'h35e5ff : 24'h50e080;
    wire [10:0] dx=x-(LEFT+8),dy=y-24;
    assign glyph_row=dy[3:0];
    assign glyph_col=dx[3:0];
    wire text_area=panel_hit && y>=24 && y<72;
    wire [1:0] line_number=dy[5:4];
    wire [3:0] digit=line_number==0 ? brightness_applied : contrast_applied;
    always @* begin
        text_valid=1'b0;
        glyph=7'd127; // unused blank glyph
        if(text_area) begin
            if(x>=LEFT+8 && x<LEFT+56) begin
                case(line_number)
                    0:case(dx[5:4])
                        0:begin text_valid=1;glyph=57;end // 亮
                        1:begin text_valid=1;glyph=58;end // 度
                        default:begin end
                    endcase
                    1:begin
                        text_valid=1;
                        case(dx[5:4])
                            0:glyph=59; // 对
                            1:glyph=60; // 比
                            default:glyph=58; // 度
                        endcase
                    end
                    2:case(dx[5:4])
                        0:begin text_valid=editing||parameters_pending;glyph=23;end
                        1:begin text_valid=editing||parameters_pending;glyph=24;end
                        default:begin end
                    endcase // Show editing/pending only; no persistent OK label.
                    default:begin end
                endcase
            end else if(line_number<2 && x>=LEFT+104 && x<LEFT+120) begin
                text_valid=1;
                glyph=parameters_valid && digit<=9 ? 7'd82+digit : 7'd92;
            end
        end
    end
endmodule
`default_nettype wire
