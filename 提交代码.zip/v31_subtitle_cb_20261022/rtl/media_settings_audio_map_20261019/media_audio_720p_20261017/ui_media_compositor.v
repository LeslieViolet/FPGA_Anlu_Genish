`default_nettype none
// 固定720p合成器：颜色表1拍、描述符1拍、共享字体1拍、输出1拍。
// RGB/valid/SOF/EOL始终一起延迟，关闭叠加也保持相同延迟。
module ui_media_compositor #(parameter FRAME_WIDTH=1280,FRAME_HEIGHT=720)(
 input wire clk_pixel,rst_pixel,enabled,input wire [95:0] ui_status_payload_pixel,
 input wire bgm_visualizer_enable,input wire [3:0] bgm_level_left,bgm_level_right,
 input wire [10:0] x,y,input wire [23:0] rgb_in,
 input wire user_in,last_in,valid_in,wallpaper_valid,
 output reg axis_tx_user,axis_tx_valid,axis_tx_last,output reg [23:0] axis_tx_data
);
 wire [23:0] adjusted;
 wire [10:0] px,py;
 wire u,l,v,w,parameters_valid,parameters_pending;
 wire [3:0] brightness_applied,contrast_applied;
 ui_color_lut #(.COORD_WIDTH(11),.PIPELINED_BUILD(1)) u_color(
 .clk(clk_pixel),.rst(rst_pixel),
 .brightness(enabled?ui_status_payload_pixel[30:27]:4'd5),
 .contrast(enabled?ui_status_payload_pixel[13:10]:4'd5),
 .rgb_in(rgb_in),.rgb_out(adjusted),.x_in(x),.y_in(y),.x_out(px),.y_out(py),
 .user_in(user_in),.last_in(last_in),.valid_in(valid_in),
 .user_out(u),.last_out(l),.valid_out(v),.wallpaper_in(wallpaper_valid),.wallpaper_out(w),
 .brightness_applied(brightness_applied),.contrast_applied(contrast_applied),
 .parameters_valid(parameters_valid),.parameters_pending(parameters_pending));
 wire hit,text;
 wire [3:0] palette,row,col,text_palette;
 wire [6:0] glyph;
 wire [9:0] text_address;
 ui_settings_renderer #(.SYNC_TEXT(1)) u_renderer(.enabled(enabled),.video_active(v && px<FRAME_WIDTH && py<FRAME_HEIGHT),
 .x(px),.y(py),.status(ui_status_payload_pixel),.overlay_hit(hit),.palette(palette),
 .font_valid(text),.font_glyph(glyph),.font_row(row),.font_col(col),.font_palette(text_palette),
 .text_address(text_address));
 wire subtitle_enabled=enabled && ui_status_payload_pixel[63:60]==4'd2 &&
                       ui_status_payload_pixel[77];
 wire subtitle_text;
 wire [8:0] subtitle_address;
 wire [3:0] subtitle_col;
 wire [1:0] subtitle_palette;
 promo_marquee_renderer #(.FRAME_WIDTH(FRAME_WIDTH)) u_promo_marquee(
 .clk(clk_pixel),.rst(rst_pixel),.enabled(subtitle_enabled),
 .x(px),.y(py),.user_in(u),.valid_in(v),
 .font_valid(subtitle_text),.font_address(subtitle_address),
 .font_col(subtitle_col),.font_palette(subtitle_palette));
 reg [8:0] subtitle_address_q;
 reg [3:0] subtitle_col_q,subtitle_col_f;
 reg [1:0] subtitle_palette_q;
 reg subtitle_q,subtitle_f;
 reg [23:0] subtitle_color_f;
 wire [31:0] subtitle_bits;
 wire [15:0] subtitle_ink=subtitle_bits[15:0];
 wire [15:0] subtitle_outline=subtitle_bits[31:16];
 promo_subtitle_font_rom u_promo_font(.clk(clk_pixel),.address(subtitle_address_q),.bits(subtitle_bits));
 always @(posedge clk_pixel)begin
  subtitle_address_q<=subtitle_address;subtitle_col_q<=subtitle_col;
  subtitle_palette_q<=subtitle_palette;subtitle_col_f<=subtitle_col_q;
  case(subtitle_palette_q)
   1:subtitle_color_f<=24'hffd166;
   2:subtitle_color_f<=24'hffb6a2;
   default:subtitle_color_f<=24'hfff7e8;
  endcase
 end
 always @(posedge clk_pixel or posedge rst_pixel)
  if(rst_pixel)begin subtitle_q<=0;subtitle_f<=0;end
  else begin subtitle_q<=subtitle_text;subtitle_f<=subtitle_q;end
 function [23:0] color;
  input [3:0] code;
  begin case(code)
   1:color=24'hffffff;2:color=24'h35e5ff;3:color=24'h174f78;
   4:color=24'h202c5c;5:color=24'h28e0b8;6:color=24'h111936;
   9:color=24'h0b1125;10:color=24'h126aa0;
   12:color=24'hef476f;13:color=24'hffd166;15:color=24'h29345d;
   default:color=24'h000000;
  endcase end
 endfunction
 reg [23:0] rgb_q;
 reg [3:0] palette_q,text_palette_q,col_q,row_q;
 reg [6:0] direct_glyph_q;
 reg lookup_q;
 wire [6:0] mapped_glyph_q;
 wire [6:0] glyph_q=lookup_q?mapped_glyph_q:direct_glyph_q;
 ui_settings_text_sync_rom u_text_map(.clk(clk_pixel),.address(text_address),.glyph(mapped_glyph_q));
 reg hit_q,text_q,u_q,l_q,v_q;
 always @(posedge clk_pixel)begin
  rgb_q<=adjusted;palette_q<=palette;text_palette_q<=text_palette;
  col_q<=col;row_q<=row;direct_glyph_q<=glyph;
  lookup_q<=text_address!=10'h3ff;
 end
 always @(posedge clk_pixel or posedge rst_pixel)
  if(rst_pixel)begin hit_q<=0;text_q<=0;u_q<=0;l_q<=0;v_q<=0;end
  else begin hit_q<=hit;text_q<=text;u_q<=u;l_q<=l;v_q<=v;end
 wire [15:0] font_bits;
 ui_font16_sync_rom u_shared_ui_font(.clk(clk_pixel),.glyph_id(glyph_q),.row(row_q),.bits(font_bits));
 reg [23:0] base_f,color_f;
 reg [3:0] col_f;
 reg text_f,u_f,l_f,v_f;
 always @(posedge clk_pixel)begin
  base_f<=hit_q?color(palette_q):rgb_q;color_f<=color(text_palette_q);col_f<=col_q;
 end
 always @(posedge clk_pixel or posedge rst_pixel)
  if(rst_pixel)begin text_f<=0;u_f<=0;l_f<=0;v_f<=0;end
  else begin text_f<=text_q;u_f<=u_q;l_f<=l_q;v_f<=v_q;end
 always @(posedge clk_pixel or posedge rst_pixel)
  if(rst_pixel)begin axis_tx_data<=0;axis_tx_valid<=0;axis_tx_user<=0;axis_tx_last<=0;end
  else begin
   if(subtitle_f && subtitle_ink[~subtitle_col_f]) axis_tx_data<=subtitle_color_f;
   else if(subtitle_f && subtitle_outline[~subtitle_col_f]) axis_tx_data<=24'h302337;
   else axis_tx_data<=text_f && font_bits[15-col_f]?color_f:base_f;
   axis_tx_valid<=v_f;axis_tx_user<=u_f;axis_tx_last<=l_f;
 end
endmodule

`default_nettype wire
