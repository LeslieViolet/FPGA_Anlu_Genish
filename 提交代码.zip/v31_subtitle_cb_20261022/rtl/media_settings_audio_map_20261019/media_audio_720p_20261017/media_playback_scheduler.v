// Temporary A/B integration controller used until A supplies the final UI.
// It debounces KEY2/KEY4, loads asset 0 after catalog scan, advances through
// the discovered assets on KEY2, and toggles five-second autoplay on KEY4.
`timescale 1ns/1ps
`default_nettype none
module media_playback_scheduler #(
    parameter integer CLK_FREQ_HZ = 50000000,
    parameter integer AUTO_SECONDS = 5,
    parameter integer DEBOUNCE_MS = 20
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       key_next_n,
    input  wire       key_auto_n,
    input  wire       catalog_done,
    input  wire       catalog_ok,
    input  wire [4:0] asset_count,
    input  wire       storage_ready,
    output reg        request_valid,
    input  wire       request_ready,
    output reg  [3:0] request_id,
    input  wire       result_valid,
    input  wire [3:0] result_code,
    output reg        auto_enabled,
    output reg  [3:0] current_id,
    output wire       load_active,
    output reg        request_started
);
    localparam integer AUTO_CYCLES = CLK_FREQ_HZ * AUTO_SECONDS;

    wire next_press;
    wire auto_press;
    key_press_debounce #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ), .DEBOUNCE_MS(DEBOUNCE_MS)
    ) u_next_debounce (
        .clk(clk), .rst(rst), .button_n(key_next_n), .press_pulse(next_press)
    );
    key_press_debounce #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ), .DEBOUNCE_MS(DEBOUNCE_MS)
    ) u_auto_debounce (
        .clk(clk), .rst(rst), .button_n(key_auto_n), .press_pulse(auto_press)
    );

    reg        initial_requested;
    reg        first_loaded;
    reg        inflight;
    reg [3:0]  inflight_id;
    reg        next_pending;
    reg [31:0] auto_count;

    assign load_active = request_valid || inflight;

    function [3:0] next_index;
        input [3:0] current;
        input [4:0] count;
        begin
            if (count <= 1)
                next_index = 4'd0;
            else if ({1'b0,current} + 1'b1 >= count)
                next_index = 4'd0;
            else
                next_index = current + 1'b1;
        end
    endfunction

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            request_valid    <= 1'b0;
            request_id       <= 4'd0;
            auto_enabled     <= 1'b0;
            current_id       <= 4'd0;
            initial_requested<= 1'b0;
            first_loaded     <= 1'b0;
            inflight         <= 1'b0;
            inflight_id      <= 4'd0;
            next_pending     <= 1'b0;
            auto_count       <= 32'd0;
            request_started  <= 1'b0;
        end else begin
            if (!catalog_done || !catalog_ok || asset_count == 0) begin
                request_valid     <= 1'b0;
                auto_enabled      <= 1'b0;
                initial_requested <= 1'b0;
                first_loaded      <= 1'b0;
                inflight          <= 1'b0;
                next_pending      <= 1'b0;
                auto_count        <= 32'd0;
                request_started   <= 1'b0;
            end else begin
                if (auto_press && asset_count > 1) begin
                    auto_enabled <= ~auto_enabled;
                    auto_count <= 32'd0;
                end

                if (next_press && first_loaded)
                    next_pending <= 1'b1;

                if (auto_enabled && first_loaded && !load_active && asset_count > 1) begin
                    if (auto_count >= AUTO_CYCLES-1) begin
                        auto_count <= 32'd0;
                        next_pending <= 1'b1;
                    end else begin
                        auto_count <= auto_count + 1'b1;
                    end
                end else if (!auto_enabled || !first_loaded || load_active) begin
                    auto_count <= 32'd0;
                end

                if (!initial_requested && storage_ready && !request_valid && !inflight) begin
                    request_valid <= 1'b1;
                    request_id <= 4'd0;
                    initial_requested <= 1'b1;
                end else if (next_pending && storage_ready && !request_valid && !inflight) begin
                    request_valid <= 1'b1;
                    request_id <= next_index(current_id, asset_count);
                    next_pending <= 1'b0;
                end

                if (request_valid && request_ready) begin
                    request_valid <= 1'b0;
                    inflight <= 1'b1;
                    inflight_id <= request_id;
                    request_started <= 1'b1;
                end

                if (result_valid && inflight) begin
                    inflight <= 1'b0;
                    if (result_code == 0) begin
                        current_id <= inflight_id;
                        first_loaded <= 1'b1;
                    end
                end
            end
        end
    end
endmodule

module key_press_debounce #(
    parameter integer CLK_FREQ_HZ = 50000000,
    parameter integer DEBOUNCE_MS = 20
)(
    input  wire clk,
    input  wire rst,
    input  wire button_n,
    output reg  press_pulse
);
    localparam integer DEBOUNCE_CYCLES = (CLK_FREQ_HZ/1000)*DEBOUNCE_MS;
    (* async_reg = "true" *) reg sync0, sync1;
    reg stable;
    reg [31:0] count;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            sync0 <= 1'b1;
            sync1 <= 1'b1;
            stable <= 1'b1;
            count <= 32'd0;
            press_pulse <= 1'b0;
        end else begin
            sync0 <= button_n;
            sync1 <= sync0;
            press_pulse <= 1'b0;
            if (sync1 == stable) begin
                count <= 32'd0;
            end else if (count >= DEBOUNCE_CYCLES-1) begin
                if (stable && !sync1)
                    press_pulse <= 1'b1;
                stable <= sync1;
                count <= 32'd0;
            end else begin
                count <= count + 1'b1;
            end
        end
    end
endmodule
`default_nettype wire
