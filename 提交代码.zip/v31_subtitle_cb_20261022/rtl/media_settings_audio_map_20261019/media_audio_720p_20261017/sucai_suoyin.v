// Controlled-media catalog, Verilog-2001. All ports are in clk's domain.
// Sector-aligned, physically contiguous BMP files only; NOT a FAT reader.
// A FAT32 boot-sector probe skips the reserved/FAT metadata region before the
// original BMP scan. Unsupported cards fall back to the original LBA scan.
`default_nettype none
module sucai_suoyin #(
    parameter [31:0] STALL_TIMEOUT_CYCLES = 32'd200000000,
    // Once at least one image is indexed, stop after this many consecutive
    // non-header sectors.  This avoids scanning the whole 64 MiB window when
    // a card contains fewer than four images.
    parameter [31:0] POST_ASSET_GAP_SECTORS = 32'd4096
)(
    input wire clk,
    input wire rst,
    input wire scan_valid,
    output wire scan_ready,
    input wire [31:0] scan_first_lba,
    input wire [31:0] scan_last_lba,  // inclusive; also bounds file extents
    output wire scan_busy,
    output reg scan_done,           // held until next scan or reset
    output reg [3:0] scan_status,   // 0=OK,1=empty,2=range,3=IO,4=protocol,5=timeout,6=card
    output reg [3:0] reader_error_code,
    output reg [4:0] asset_count,   // 0..16; query only after successful scan
    output reg [31:0] rejected_count,
    output reg [31:0] current_lba,
    input wire [3:0] query_id,
    output reg query_valid,
    output reg [31:0] asset_start_lba,
    output reg [31:0] asset_byte_length,
    output reg [31:0] asset_pixel_offset,
    output reg [15:0] asset_width,
    output reg [15:0] asset_height,
    output reg asset_bottom_up,

    // Connect these to Part 1 tf_shanqu_duqu. One outstanding read only.
    input wire card_ready,
    output wire read_valid,
    input wire read_ready,
    output wire [31:0] read_lba,
    input wire [7:0] data,
    input wire data_valid,
    output wire data_ready,
    input wire data_last,
    input wire reader_done,
    input wire reader_error,
    input wire [3:0] read_error_code
);
    localparam [3:0] IDLE=4'd0, WAIT_CARD=4'd1, ISSUE=4'd2,
                     RECEIVE=4'd3, CHECK=4'd4, COMPLETE=4'd5, FATAL=4'd6,
                     VALIDATE=4'd7, CALC_END=4'd8, RECORD=4'd9;
    // Keep the public timeout parameters 32-bit, but size counters to the
    // configured ranges so unused high bits do not build wide comparators.
    localparam integer STALL_COUNT_WIDTH =
        STALL_TIMEOUT_CYCLES <= 1 ? 1 : $clog2(STALL_TIMEOUT_CYCLES);
    localparam integer POST_GAP_WIDTH =
        POST_ASSET_GAP_SECTORS <= 1 ? 1 : $clog2(POST_ASSET_GAP_SECTORS);
    reg [3:0] state;
    reg [31:0] last_lba;
    reg [STALL_COUNT_WIDTH-1:0] stall_count;
    reg [POST_GAP_WIDTH-1:0] post_asset_gap;
    reg [31:0] pixel_bytes_reg;
    reg [32:0] sector_span_reg, next_file_lba_reg, pixel_end_reg;
    reg [40:0] bpb_root_start_reg;
    reg [9:0] byte_count; // represents 512 without wrapping
    reg [431:0] header_bytes; // byte n at [8*n +: 8], only first 54 bytes
    reg [1:0] probe_mode; // 0=BMP scan, 1=sector-0 MBR/PBR, 2=partition PBR
    reg [7:0] partition_type;
    reg [31:0] partition_start;
    reg [15:0] sector_signature;
    reg [31:0] lba_table [0:15];
    reg [31:0] length_table [0:15];
    reg [31:0] offset_table [0:15];
    reg [15:0] width_table [0:15];
    reg [15:0] height_table [0:15];
    integer i;

    wire start_scan = scan_valid && scan_ready;
    wire timed_out = (STALL_TIMEOUT_CYCLES == 0) ||
                     (stall_count >= STALL_TIMEOUT_CYCLES - 1'b1);
    wire byte_fire = data_valid && data_ready;
    wire bad_byte = byte_fire && ((byte_count >= 10'd512) ||
                                 (data_last != (byte_count == 10'd511)));
    wire [10:0] received_total = {1'b0,byte_count} + (byte_fire ? 11'd1 : 11'd0);

    // Fields in a BMP header are little endian. The packed register's layout
    // makes a contiguous field slice have the correct numeric value.
    wire [31:0] file_bytes = header_bytes[47:16];       // bfSize @2
    wire [31:0] pixel_offset = header_bytes[111:80];    // bfOffBits @10
    wire [31:0] dib_bytes = header_bytes[143:112];      // biSize @14
    wire [31:0] bmp_width = header_bytes[175:144];      // biWidth @18
    wire [31:0] bmp_height = header_bytes[207:176];     // biHeight @22
    wire [15:0] planes = header_bytes[223:208];
    wire [15:0] bit_depth = header_bytes[239:224];
    wire [31:0] compression = header_bytes[271:240];
    wire [31:0] image_bytes = header_bytes[303:272];
    wire [31:0] colors_used = header_bytes[399:368];
    wire signature_ok = header_bytes[15:0] == 16'h4d42;
    wire [15:0] bpb_sector_bytes = header_bytes[103:88];
    wire [7:0] bpb_cluster_sectors = header_bytes[111:104];
    wire [15:0] bpb_reserved = header_bytes[127:112];
    wire [7:0] bpb_fat_count = header_bytes[135:128];
    wire [31:0] bpb_fat_sectors = header_bytes[319:288];
    wire [31:0] bpb_root_cluster = header_bytes[383:352];
    wire bpb_ok = sector_signature == 16'haa55 &&
                  bpb_sector_bytes == 16'd512 &&
                  bpb_cluster_sectors != 0 &&
                  (bpb_cluster_sectors & (bpb_cluster_sectors - 1'b1)) == 0 &&
                  bpb_reserved != 0 &&
                  (bpb_fat_count == 1 || bpb_fat_count == 2) &&
                  bpb_fat_sectors != 0 && bpb_root_cluster >= 2;
    wire [40:0] bpb_fat_span = bpb_fat_count == 2 ?
                               {8'd0,bpb_fat_sectors,1'b0} :
                               {9'd0,bpb_fat_sectors};
    wire [40:0] bpb_data_start = {9'd0,current_lba} +
                                  {25'd0,bpb_reserved} + bpb_fat_span;
    wire [40:0] bpb_root_start = bpb_data_start +
        (({9'd0,bpb_root_cluster} - 41'd2) * {33'd0,bpb_cluster_sectors});
    wire fat32_mbr_ok = sector_signature == 16'haa55 &&
        (partition_type == 8'h0b || partition_type == 8'h0c) &&
        partition_start > scan_first_lba && partition_start <= last_lba;

    // 33-bit math prevents wrapped file sizes / LBAs from passing the checks.
    // BMP rows are padded to a four-byte boundary, even at odd widths.
    wire [31:0] raw_row_bytes = {16'd0,bmp_width[15:0]} +
                                ({16'd0,bmp_width[15:0]} << 1);
    wire [31:0] padded_row_bytes = (raw_row_bytes + 32'd3) &
                                   32'hfffffffc;
    wire [31:0] pixel_bytes = padded_row_bytes * bmp_height[15:0];
    wire [32:0] pixel_end = {1'b0,pixel_offset} + {1'b0,pixel_bytes_reg};
    wire [32:0] rounded_file = {1'b0,file_bytes} + 33'd511;
    wire [32:0] sector_span = rounded_file >> 9;
    wire [32:0] range_end = {1'b0,last_lba} + 33'd1;
    wire header_ok = signature_ok &&
                     (header_bytes[79:48] == 32'd0) && // reserved fields
                     (dib_bytes == 32'd40) &&          // BITMAPINFOHEADER
                     (bmp_width >= 32'd1) && (bmp_width <= 32'd2048) &&
                     (bmp_height >= 32'd1) && (bmp_height <= 32'd1536) &&
                     (planes == 16'd1) && (bit_depth == 16'd24) &&
                     (compression == 32'd0) && (colors_used == 32'd0) &&
                     ((image_bytes == 0) || (image_bytes == pixel_bytes_reg)) &&
                     (pixel_offset >= 32'd54) &&
                     (pixel_end_reg <= {1'b0,file_bytes}) &&
                     (sector_span_reg != 0) && (next_file_lba_reg <= range_end);

    assign scan_ready = !rst && ((state == IDLE) || (state == COMPLETE));
    assign scan_busy = !rst && ((state == WAIT_CARD) || (state == ISSUE) ||
                               (state == RECEIVE) || (state == CHECK) ||
                               (state == VALIDATE) || (state == CALC_END) ||
                               (state == RECORD));
    assign read_valid = !rst && (state == ISSUE) && card_ready;
    assign read_lba = current_lba;
    // Always drain the selected reader, including after a fatal timeout.
    // FATAL cannot rescan before a coordinated reset of both modules.
    assign data_ready = !rst;

    // Tables have no reset. A query is allowed only after a successful scan,
    // and query_id < asset_count proves that RECORD wrote this entry.
    // Reset/count invalidation still forces invalid-query outputs to zero.
    // Single-clock write + asynchronous read infers compact distributed RAM,
    // instead of 2048 resettable flip-flops and a large read multiplexor.
    always @(posedge clk)begin
        if(!rst && state==RECORD)begin
            lba_table[asset_count[3:0]]<=current_lba;
            length_table[asset_count[3:0]]<=file_bytes;
            offset_table[asset_count[3:0]]<=pixel_offset;
            width_table[asset_count[3:0]]<=bmp_width[15:0];
            height_table[asset_count[3:0]]<=bmp_height[15:0];
        end
    end

    always @* begin
        query_valid = 1'b0;
        asset_start_lba = 32'd0;
        asset_byte_length = 32'd0;
        asset_pixel_offset = 32'd0;
        asset_width = 16'd0;
        asset_height = 16'd0;
        asset_bottom_up = 1'b0;
        if (!rst && !start_scan && scan_done && (scan_status == 0) &&
            ({1'b0,query_id} < asset_count)) begin
            query_valid = 1'b1;
            asset_start_lba = lba_table[query_id];
            asset_byte_length = length_table[query_id];
            asset_pixel_offset = offset_table[query_id];
            asset_width = width_table[query_id];
            asset_height = height_table[query_id];
            asset_bottom_up = 1'b1;
        end
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= IDLE;
            scan_done <= 1'b0;
            scan_status <= 4'd0;
            reader_error_code <= 4'd0;
            asset_count <= 5'd0;
            rejected_count <= 32'd0;
            current_lba <= 32'd0;
            last_lba <= 32'd0;
            stall_count <= 32'd0;
            post_asset_gap <= 32'd0;
            pixel_bytes_reg <= 32'd0;
            sector_span_reg <= 33'd0;
            next_file_lba_reg <= 33'd0;
            pixel_end_reg <= 33'd0;
            bpb_root_start_reg <= 41'd0;
            byte_count <= 10'd0;
            header_bytes <= 432'd0;
            probe_mode <= 2'd0;
            partition_type <= 8'd0;
            partition_start <= 32'd0;
            sector_signature <= 16'd0;

        end else begin
            case (state)
                IDLE, COMPLETE: begin
                    if (start_scan) begin
                        scan_done <= 1'b0;
                        scan_status <= 4'd0;
                        reader_error_code <= 4'd0;
                        asset_count <= 5'd0;
                        rejected_count <= 32'd0;
                        current_lba <= scan_first_lba;
                        probe_mode <= 2'd1;
                        last_lba <= scan_last_lba;
                        stall_count <= 32'd0;
                        post_asset_gap <= 32'd0;
                        if (scan_first_lba > scan_last_lba) begin
                            scan_status <= 4'd2;
                            scan_done <= 1'b1;
                            state <= COMPLETE;
                        end else state <= WAIT_CARD;
                    end
                end
                WAIT_CARD: begin
                    if (reader_error) begin
                        reader_error_code <= read_error_code;
                        scan_status <= 4'd3;
                        scan_done <= 1'b1;
                        asset_count <= 5'd0;
                        state <= FATAL;
                    end else if (card_ready) begin
                        stall_count <= 32'd0;
                        state <= ISSUE;
                    end else if (timed_out) begin
                        scan_status <= 4'd5;
                        scan_done <= 1'b1;
                        asset_count <= 5'd0;
                        state <= FATAL;
                    end else stall_count <= stall_count + 1'b1;
                end
                ISSUE: begin
                    if (!card_ready) begin
                        scan_status <= 4'd6;
                        scan_done <= 1'b1;
                        asset_count <= 5'd0;
                        state <= FATAL;
                    end else if (read_valid && read_ready) begin
                        byte_count <= 10'd0;
                        header_bytes <= 432'd0;
                        partition_type <= 8'd0;
                        partition_start <= 32'd0;
                        sector_signature <= 16'd0;
                        stall_count <= 32'd0;
                        state <= RECEIVE;
                    end else if (timed_out) begin
                        scan_status <= 4'd5;
                        scan_done <= 1'b1;
                        asset_count <= 5'd0;
                        state <= FATAL;
                    end else stall_count <= stall_count + 1'b1;
                end
                RECEIVE: begin
                    if (reader_error || !card_ready) begin
                        reader_error_code <= read_error_code;
                        scan_status <= reader_error ? 4'd3 : 4'd6;
                        scan_done <= 1'b1;
                        asset_count <= 5'd0;
                        state <= FATAL;
                    end else if (bad_byte || (reader_done && received_total != 11'd512)) begin
                        scan_status <= 4'd4;
                        scan_done <= 1'b1;
                        asset_count <= 5'd0;
                        state <= FATAL;
                    end else begin
                        if (byte_fire) begin
                            if (byte_count < 10'd54)
                                header_bytes[byte_count[5:0]*8 +: 8] <= data;
                            case(byte_count)
                                10'd450: partition_type <= data;
                                10'd454: partition_start[7:0] <= data;
                                10'd455: partition_start[15:8] <= data;
                                10'd456: partition_start[23:16] <= data;
                                10'd457: partition_start[31:24] <= data;
                                10'd510: sector_signature[7:0] <= data;
                                10'd511: sector_signature[15:8] <= data;
                                default: begin end
                            endcase
                            byte_count <= byte_count + 1'b1;
                        end
                        // Part 1 emits done ONLY after reading and checking CRC.
                        // A header must never be registered on data_last alone.
                        if (reader_done) begin
                            stall_count <= 32'd0;
                            state <= CHECK;
                        end else if (byte_fire) stall_count <= 32'd0;
                        else if (timed_out) begin
                            scan_status <= 4'd5;
                            scan_done <= 1'b1;
                            asset_count <= 5'd0;
                            state <= FATAL;
                        end else stall_count <= stall_count + 1'b1;
                    end
                end
                CHECK: begin
                    // Break the BMP size multiplier/adder from the catalogue
                    // write-enable path. One extra 50 MHz cycle per header.
                    pixel_bytes_reg <= pixel_bytes;
                    sector_span_reg <= sector_span;
                    // The FAT32 root-cluster calculation also contains a
                    // multiply; register it before the LBA select path.
                    bpb_root_start_reg <= bpb_root_start;
                    state <= CALC_END;
                end
                CALC_END: begin
                    // Separate the rounded file length, end-address adders
                    // and catalogue write enable. Keep 33-bit overflow checks.
                    next_file_lba_reg <= {1'b0,current_lba} + sector_span_reg;
                    pixel_end_reg <= pixel_end;
                    state <= VALIDATE;
                end
                VALIDATE: begin
                    if(probe_mode != 0) begin
                        if(bpb_ok && bpb_root_start_reg <= {9'd0,last_lba}) begin
                            // Superfloppy PBR or MBR-selected partition PBR.
                            current_lba <= bpb_root_start_reg[31:0];
                            probe_mode <= 2'd0;
                            state <= ISSUE;
                        end else if(probe_mode == 2'd1 && fat32_mbr_ok) begin
                            current_lba <= partition_start;
                            probe_mode <= 2'd2;
                            state <= ISSUE;
                        end else begin
                            // Preserve the former raw-sector behavior.
                            current_lba <= scan_first_lba;
                            probe_mode <= 2'd0;
                            state <= ISSUE;
                        end
                    end else if (header_ok) begin
                        // The validated header remains stable until RECORD.
                        // Isolate the common table enable from header checks.
                        state <= RECORD;
                    end else begin
                        if (signature_ok && rejected_count != 32'hffffffff)
                            rejected_count <= rejected_count + 1'b1;
                        if ((asset_count != 0) &&
                            ((POST_ASSET_GAP_SECTORS == 0) ||
                             (post_asset_gap >= POST_ASSET_GAP_SECTORS - 1'b1))) begin
                            scan_status <= 4'd0;
                            scan_done <= 1'b1;
                            state <= COMPLETE;
                        end else if (current_lba == last_lba) begin
                            scan_status <= (asset_count == 0) ? 4'd1 : 4'd0;
                            scan_done <= 1'b1;
                            state <= COMPLETE;
                        end else begin
                            if (asset_count != 0)
                                post_asset_gap <= post_asset_gap + 1'b1;
                            current_lba <= current_lba + 1'b1;
                            state <= ISSUE;
                        end
                    end
                end
                RECORD: begin
                    post_asset_gap <= 32'd0;

                    asset_count <= asset_count + 1'b1;
                    if ((asset_count == 5'd15) || (next_file_lba_reg >= range_end)) begin
                        scan_status <= 4'd0;
                        scan_done <= 1'b1;
                        state <= COMPLETE;
                    end else begin
                        // Skip this complete contiguous file, including padding.
                        current_lba <= next_file_lba_reg[31:0];
                        state <= ISSUE;
                    end
                end
                // Late bytes/done cannot create a new asset or a new read.
                FATAL: state <= FATAL;
                default: begin
                    state <= FATAL;
                    scan_done <= 1'b1;
                    scan_status <= 4'd4;
                    asset_count <= 5'd0;
                end
            endcase
        end
    end
endmodule
`default_nettype wire
