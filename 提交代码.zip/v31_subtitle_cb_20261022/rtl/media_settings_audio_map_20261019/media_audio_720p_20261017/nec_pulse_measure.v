`default_nettype none

// 红外脉宽测量模块。
// HX1838输出空闲为高电平、接收到38 kHz载波时输出低电平。
// 外部输入先经过两级同步，再测量每一段稳定高/低电平持续的时钟数。
module nec_pulse_measure #(
    parameter integer COUNTER_WIDTH = 20,   // 脉宽计数器位宽；20位最大约20.97 ms（50 MHz）
    parameter         IDLE_LEVEL    = 1'b1  // HX1838空闲电平，默认高电平
)(
    input  wire                    clk,         // 50 MHz系统时钟
    input  wire                    rst,         // 高电平有效复位
    input  wire                    ir_rx_async, // 来自HX1838的异步原始输入
    output reg                     edge_valid,  // 一段电平刚结束，输出数据有效一周期
    output reg                     pulse_level, // 刚结束的电平：0=低，1=高
    output reg                     level_now,   // 两级同步后的当前输入电平，供调试观察
    output reg [COUNTER_WIDTH-1:0] pulse_ticks, // 刚结束的电平持续时钟周期数
    output reg                     overflow     // 有效低脉冲持续过长导致计数器溢出
);

    // 计数器能够表示的最大值，例如20位时为20'hFFFFF。
    localparam [COUNTER_WIDTH-1:0] MAX_TICKS = {COUNTER_WIDTH{1'b1}};

    reg ir_meta; // 两级同步器第一级，只用于吸收亚稳态
    reg ir_sync; // 两级同步器第二级，后续逻辑只使用该信号
    reg level_d; // 当前正在计时的电平
    reg [COUNTER_WIDTH-1:0] run_ticks; // 当前电平已经持续的时钟周期数,前面的代表可变的位宽

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            ir_meta    <= 1'b1;
            ir_sync    <= 1'b1;
            level_d    <= 1'b1;
            run_ticks  <= {{(COUNTER_WIDTH-1){1'b0}}, 1'b1};
            edge_valid <= 1'b0;
            pulse_level<= 1'b1;
            level_now  <= 1'b1;
            pulse_ticks<= {COUNTER_WIDTH{1'b0}};
            overflow   <= 1'b0;
        end else begin
            // 两级同步：不用ir_rx_async驱动计数器或状态机。
            ir_meta <= ir_rx_async;
            ir_sync <= ir_meta;
            level_now <= ir_sync;

            // 事件型输出默认清零，因此只保持一个时钟周期。
            edge_valid <= 1'b0;
            overflow   <= 1'b0;

            if (ir_sync == level_d) begin
                if (run_ticks != MAX_TICKS) begin
                    run_ticks <= run_ticks + {{(COUNTER_WIDTH-1){1'b0}}, 1'b1};
                    end 
                else begin
                    // 空闲高电平可能无限长，不算错误；只有有效低脉冲过长才报溢出。
                    overflow <= (level_d != IDLE_LEVEL);
                    end
                end 
            else begin
                // 电平发生变化：记录刚结束的旧电平及其持续时间，
                // 然后从1开始测量新的电平。
                edge_valid  <= 1'b1;
                pulse_level <= level_d;
                pulse_ticks <= run_ticks;
                level_d     <= ir_sync;
                run_ticks   <= {{(COUNTER_WIDTH-1){1'b0}}, 1'b1};
            end
        end
    end
endmodule

`default_nettype wire
