`timescale 1ns/1ps
module tb_subtitle_font;
 reg clk=0;always #5 clk=~clk;
 reg [8:0] address=0;wire [31:0] bits;
 reg [15:0] raw[0:511];
 integer n,x,dy,dx,rr,cc,base,foreground,outline,near_on;
 reg [31:0] expected;
 promo_subtitle_font_rom dut(.*);
 initial begin
  $readmemh("subtitle_ink.hex",raw);
  for(n=0;n<512;n=n+1)begin
   foreground=raw[n];outline=0;base=n&1023&(~15);
   for(x=0;x<16;x=x+1)begin
    near_on=0;
    for(dy=-1;dy<=1;dy=dy+1)for(dx=-1;dx<=1;dx=dx+1)begin
     rr=(n%16)+dy;cc=x+dx;
     if(rr>=0&&rr<16&&cc>=0&&cc<16)near_on=near_on|((raw[base+rr]>>(15-cc))&1);
    end
    if(near_on&&!((foreground>>(15-x))&1))outline=outline|(1<<(15-x));
   end
   expected={16'(outline),16'(foreground)};
   @(negedge clk);address=n;
   @(posedge clk);#1;
   if(bits!==expected)$fatal(1,"font address %0d got %h want %h",n,bits,expected);
   if((bits[31:16]&bits[15:0])!=0)$fatal(1,"outline overlaps foreground");
  end
  $display("SUBTITLE_FONT_PASS 512_addresses independent_outline_compare");$finish;
 end
 initial begin #100000;$fatal(1,"font timeout");end
endmodule
