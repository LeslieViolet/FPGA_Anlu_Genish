set run_dir {D:/FPGA/work/sim/v31_subtitle_cb_20261022/physical_seed1_v4_area_routable}
import_device eagle_s20.db -package EG4S20BG256
set sources {
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/changkuai_duqu_hd.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/liucheng_jishu_zhenduan.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/sdram_dizhi_jiaoyan.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/sdram_guanfang_yuanma.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/soft_fifo.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/spi_zijie_shoufa.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/tf_shanqu_duqu.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/sucai_suoyin.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/bmp_jiexi.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/tuxiang_jiazai.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/sucai_jiazai_tongdao.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/tuxiang_jiazai_dingceng.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/xie_dizhi_yingshe.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/zhen_xieru.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/zhen_xieru_dingceng.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/shuang_huanchong.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/shuang_huanchong_dingceng.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/zhen_duqu.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/zhen_duqu_dingceng.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/guanfang_yibu_fifo.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/sdram_kongzhiqi_fengzhuang.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/sdram_shipeiqi.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/clock_reset_subsystem.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/framebuffer_subsystem.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/bc_frame_fetch_for_video_pipe.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/av_output_subsystem.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/audio_acr.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/audio_engine.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/audio_transport.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/gain_mute.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/note_sequencer.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/sound_source.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/tone_generator.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/brightness_adjust.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/contrast_adjust.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/video_pipe.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/video_rgb_to_axis.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/video_timing.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/hdmi_1_4b_transmitter_core_wrapper.enc.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/hdmi_phy_warpper.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/lane_lvds_10_1.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/top.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/top_720p.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/transition_fade.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/bmp_nearest_scaler.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/transition_effect.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/video_pll_hd.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_media_input_subsystem.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_media_control_subsystem.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_snapshot_mailbox.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_font16_sync_rom.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_color_lut.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_home_renderer.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_browser_renderer.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_settings_renderer.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ir_input_subsystem.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ir_gesture.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/nec_pulse_measure.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/nec_decoder.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ir_keymap.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/control_input.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_shell.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/media_control_adapter.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_media_compositor.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/display_parameter_osd.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/hdmi_resolution_tx.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/alpha_blend_quarters.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/rich_osd_mask_rom.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/rich_picture_osd.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/axis_osd_coordinates.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/axis_media_stream_delay4.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/osd_uptime.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/audio_ui_policy.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/audio_board_shared_reader.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/ui_media/audio_level_overlay.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_peak_meter.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_wav_stream.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_crc_sector_buffer.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_pcm_output.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_slideshow_core.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/fat32_bgm_locator.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/fat32_file_sector_walker.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_bgm_file_session.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_bgm_player.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_image_sector_arbiter.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/tf_spi_burst_reader.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/media_sector_service.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/audio_slideshow_storage.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/fat32_picture_catalog.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/storage/fat32_image_sector_bridge.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_canvas_map.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_click_sound.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/ui_audio_click_mix.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/spectrum/audio_spectrum_coeff_rom.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/spectrum/fft64_audio_analyzer.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/spectrum/audio_spectrum_overlay.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/spectrum/audio_spectrum_axis_overlay.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/spectrum/audio_spectrum_delay4.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/software_reset_hold.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/promo_marquee_renderer.v}
{D:/FPGA/work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019/media_audio_720p_20261017/promo_subtitle_font_rom.v}
}
read_hdl -file [join $sources " "] -top top_720p
read_adc [file join {D:/FPGA/work/td_project_subtitle_cb_20261022} banzi.adc]
read_sdc [file join {D:/FPGA/work/td_project_subtitle_cb_20261022} shizhong_static_720p.sdc]
cd $run_dir
optimize_rtl
set_param gate pack_seq_in_io off
set_param gate map_mode area_prior
set_param gate pack_effort high
optimize_gate -packarea "$run_dir/synthesis.area"
read_sdc [file join {D:/FPGA/work/td_project_subtitle_cb_20261022} software_reset_entry.sdc]
read_sdc [file join {D:/FPGA/work/td_project_subtitle_cb_20261022} end_pixel_reset_entry.sdc]
source [file join {D:/FPGA/work/verification/v31_subtitle_cb_20261022} apply_v27_timing_exceptions.tcl]
export_db "$run_dir/gate.db"
read_sdc [file join {D:/FPGA/work/verification/v31_subtitle_cb_20261022} implementation_guardband.sdc]
read_adc [file join {D:/FPGA/work/td_project_subtitle_cb_20261022} capture_location.adc]
legalize_phy_inst
set_param place fix_hold high
set_param place seed 1
set_param place pack_mode adaptive_pin_density
place
source [file join {D:/FPGA/work/verification/v31_subtitle_cb_20261022} audit_end_pixel_release_physical.tcl]
export_db "$run_dir/placed.db"
set_param route effort routability
set_param route post_route_opt ultra
route
fix_hold
export_db "$run_dir/implementation.db"
puts SUBTITLE_CB_IMPLEMENTATION_READY
exit
