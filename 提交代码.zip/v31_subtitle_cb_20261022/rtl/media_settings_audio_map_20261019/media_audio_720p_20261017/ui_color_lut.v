`default_nettype none
// Atomic frame-boundary commit of three identical tone tables.
// No RAM reset/initialization: only a fully written table may be displayed.
module ui_color_lut #(parameter COORD_WIDTH=10, PIPELINED_BUILD=0) (
    input wire clk, input wire rst,
    input wire [3:0] brightness, input wire [3:0] contrast,
    input wire [23:0] rgb_in,
    input wire [COORD_WIDTH-1:0] x_in, input wire [COORD_WIDTH-1:0] y_in,
    input wire user_in, input wire last_in, input wire valid_in,
    input wire wallpaper_in,
    output wire [23:0] rgb_out,
    output reg [COORD_WIDTH-1:0] x_out, output reg [COORD_WIDTH-1:0] y_out,
    output reg user_out, output reg last_out, output reg valid_out,
    output reg wallpaper_out,
    output wire [3:0] brightness_applied, contrast_applied,
    output wire parameters_valid, parameters_pending
);
    reg [7:0] red_table [0:511];
    reg [7:0] green_table [0:511];
    reg [7:0] blue_table [0:511];
    reg [7:0] red_q, green_q, blue_q;
    reg active_bank, table_valid, output_table_valid;
    reg busy, pending, draining;
    reg [7:0] write_index;
    reg [3:0] build_brightness, build_contrast;
    reg [3:0] active_brightness, active_contrast;
    wire commit = pending && user_in && valid_in;
    wire read_bank = commit ? ~active_bank : active_bank;
    wire [8:0] write_address = {~active_bank, write_index};
    // These describe the table used by rgb_out, never an uncommitted request.
    assign brightness_applied = active_brightness;
    assign contrast_applied = active_contrast;
    assign parameters_valid = output_table_valid;
    assign parameters_pending = !table_valid || busy || draining || pending ||
        brightness != active_brightness || contrast != active_contrast;

    function [7:0] transfer_value;
        input [7:0] channel;
        input [3:0] bright, contr;
        // All 16 encoded brightness/contrast values fit these exact bounds:
        // pre-clamp v=-60..375; d=-256..254; final v=-128..382.
        // Avoid 32-bit integer carry chains and a brightness DSP at 75MHz.
        reg signed [9:0] v, d;
        reg signed [7:0] offset;
        integer legacy_v, legacy_d;
        begin
          if (!PIPELINED_BUILD) begin
            // The 25MHz build retains the DSP-based mapping that fits MSlices.
            // This branch is removed at elaboration in the 75MHz HD build.
            legacy_v = channel + ($signed({1'b0, bright}) - 5) * 12;
            if (legacy_v < 0) legacy_v = 0; else if (legacy_v > 255) legacy_v = 255;
            legacy_d = legacy_v - 128;
            case (contr)
                0: legacy_d = legacy_d >>> 2;
                1,2: legacy_d = legacy_d >>> 1;
                3,4: legacy_d = legacy_d - (legacy_d >>> 2);
                5: legacy_d = legacy_d;
                6,7: legacy_d = legacy_d + (legacy_d >>> 2);
                8: legacy_d = legacy_d + (legacy_d >>> 1);
                default: legacy_d = legacy_d <<< 1;
            endcase
            legacy_v = 128 + legacy_d;
            if (legacy_v < 0) transfer_value = 0;
            else if (legacy_v > 255) transfer_value = 255;
            else transfer_value = legacy_v[7:0];
          end else begin
            case(bright)
                0:offset=-8'sd60; 1:offset=-8'sd48; 2:offset=-8'sd36;
                3:offset=-8'sd24; 4:offset=-8'sd12; 5:offset=8'sd0;
                6:offset=8'sd12; 7:offset=8'sd24; 8:offset=8'sd36;
                9:offset=8'sd48; 10:offset=8'sd60; 11:offset=8'sd72;
                12:offset=8'sd84; 13:offset=8'sd96; 14:offset=8'sd108;
                default:offset=8'sd120;
            endcase
            v = $signed({2'b0,channel}) + offset;
            if (v < 10'sd0) v = 10'sd0; else if (v > 10'sd255) v = 10'sd255;
            d = v - 10'sd128;
            case (contr)
                0: d = d >>> 2;
                1,2: d = d >>> 1;
                3,4: d = d - (d >>> 2);
                5: d = d;
                6,7: d = d + (d >>> 2);
                8: d = d + (d >>> 1);
                default: d = d <<< 1;
            endcase
            v = 10'sd128 + d;
            if (v < 10'sd0) transfer_value = 0;
            else if (v > 10'sd255) transfer_value = 255;
            else transfer_value = v[7:0];
          end
        end
    endfunction
    wire [7:0] write_value;
    wire [8:0] ram_write_address;
    wire ram_write_enable, build_finished;
    generate if (!PIPELINED_BUILD) begin: sd_table_math
        assign write_value = transfer_value(write_index, build_brightness, build_contrast);
        assign ram_write_address = write_address;
        assign ram_write_enable = busy && !rst;
        assign build_finished = busy && write_index == 255;
    end else begin: hd_table_math
        // Three registered arithmetic stages; address/valid travel together.
        reg [2:0] stage_valid;
        reg [8:0] address0,address1,address2;
        reg signed [9:0] raw_brightness,contrast_delta;
        reg [7:0] clipped_brightness;
        function signed [7:0] brightness_offset;
            input [3:0] value;
            begin case(value)
                0:brightness_offset=-8'sd60; 1:brightness_offset=-8'sd48;
                2:brightness_offset=-8'sd36; 3:brightness_offset=-8'sd24;
                4:brightness_offset=-8'sd12; 5:brightness_offset=8'sd0;
                6:brightness_offset=8'sd12; 7:brightness_offset=8'sd24;
                8:brightness_offset=8'sd36; 9:brightness_offset=8'sd48;
                10:brightness_offset=8'sd60; 11:brightness_offset=8'sd72;
                12:brightness_offset=8'sd84; 13:brightness_offset=8'sd96;
                14:brightness_offset=8'sd108; default:brightness_offset=8'sd120;
            endcase end
        endfunction
        function signed [9:0] contrast_value;
            input [7:0] value; input [3:0] setting;
            reg signed [9:0] d;
            begin
                d=$signed({2'b0,value})-10'sd128;
                case(setting)
                    0:d=d>>>2; 1,2:d=d>>>1; 3,4:d=d-(d>>>2);
                    5:d=d; 6,7:d=d+(d>>>2); 8:d=d+(d>>>1);
                    default:d=d<<<1;
                endcase
                contrast_value=d;
            end
        endfunction
        wire signed [9:0] final_value=contrast_delta+10'sd128;
        always @(posedge clk or posedge rst) begin
            if(rst) stage_valid<=0;
            else stage_valid<={stage_valid[1:0],busy};
        end
        always @(posedge clk) begin
            if(busy && !rst) begin
                raw_brightness<=$signed({2'b0,write_index})+brightness_offset(build_brightness);
                address0<=write_address;
            end
            if(stage_valid[0]) begin
                clipped_brightness<=raw_brightness<0 ? 8'd0 : raw_brightness>255 ? 8'd255 : raw_brightness[7:0];
                address1<=address0;
            end
            if(stage_valid[1]) begin
                contrast_delta<=contrast_value(clipped_brightness,build_contrast);
                address2<=address1;
            end
        end
        assign write_value=final_value<0 ? 8'd0 : final_value>255 ? 8'd255 : final_value[7:0];
        assign ram_write_address=address2;
        assign ram_write_enable=stage_valid[2] && !rst;
        assign build_finished=ram_write_enable && address2[7:0]==255;
    end endgenerate

    // Synchronous simple-dual-port RAM template.  Read and write banks differ.
    always @(posedge clk) begin
        if (ram_write_enable) begin
            red_table[ram_write_address] <= write_value;
            green_table[ram_write_address] <= write_value;
            blue_table[ram_write_address] <= write_value;
        end
        red_q <= red_table[{read_bank,rgb_in[23:16]}];
        green_q <= green_table[{read_bank,rgb_in[15:8]}];
        blue_q <= blue_table[{read_bank,rgb_in[7:0]}];
    end
    assign rgb_out = output_table_valid ? {red_q,green_q,blue_q} : 24'h000000;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            active_bank <= 0; table_valid <= 0; output_table_valid <= 0;
            busy <= 0; pending <= 0; draining <= 0; write_index <= 0;
            build_brightness <= 5; build_contrast <= 5;
            active_brightness <= 5; active_contrast <= 5;
            x_out <= 0; y_out <= 0; user_out <= 0; last_out <= 0;
            valid_out <= 0; wallpaper_out <= 0;
        end else begin
            x_out <= x_in; y_out <= y_in; user_out <= user_in;
            last_out <= last_in; valid_out <= valid_in; wallpaper_out <= wallpaper_in;
            output_table_valid <= table_valid || commit;
            if (busy) begin
                if (write_index == 255) begin
                    busy <= 0;
                    if(!PIPELINED_BUILD) pending <= 1;
                    else draining <= 1;
                end
                else write_index <= write_index + 1'b1;
            end else if (draining) begin
                if(build_finished) begin draining <= 0; pending <= 1; end
            end else if (pending) begin
                if (commit) begin
                    active_bank <= ~active_bank; table_valid <= 1;
                    active_brightness <= build_brightness;
                    active_contrast <= build_contrast;
                    pending <= 0;
                end
            end else if (!table_valid || brightness != active_brightness || contrast != active_contrast) begin
                build_brightness <= brightness; build_contrast <= contrast;
                write_index <= 0; busy <= 1;
            end
        end
    end
endmodule
`default_nettype wire
