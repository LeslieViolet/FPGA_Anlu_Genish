`default_nettype none
// Converts a mounted FAT32 file into one-sector audio descriptors. Metadata and
// audio transactions must share a single external physical reader/arbiter.
module fat32_file_sector_walker #(
 parameter integer TIMEOUT_CYCLES=250000000,
 parameter integer MAX_CHAIN_CLUSTERS=65535,
 parameter integer LATCH_GEOMETRY=0
)(
 input wire clk,rst,abort,
 input wire open_valid,output wire open_ready,
 input wire [31:0] file_first_cluster,file_length,fat_start_lba,data_start_lba,max_cluster,
 input wire [32:0] volume_end_lba,input wire [7:0] sectors_per_cluster,
 output wire sector_valid,input wire sector_ready,output wire [31:0] sector_lba,
 output wire [9:0] sector_valid_bytes,output wire sector_file_last,
 input wire sector_done,sector_error,
 output wire meta_read_valid,input wire meta_read_ready,output wire [31:0] meta_read_lba,
 input wire [7:0] meta_data,input wire meta_data_valid,output wire meta_data_ready,
 input wire meta_data_last,meta_done,meta_error,
 output reg result_valid,input wire result_ready,output reg [3:0] result_code,
 output wire file_read_done,output wire busy
);
 localparam [3:0] IDLE=0,ADDRESS=1,AUDIO_REQ=2,AUDIO_WAIT=3,
    FAT_REQ=4,FAT_READ=5,FAT_WAIT=6,FAT_APPLY=7,RESULT=8,
    ADDRESS_SHIFT=9,ADDRESS_FINAL=10;
 localparam integer CHAIN_BITS=$clog2(MAX_CHAIN_CLUSTERS+1);
 localparam integer TIMEOUT_BITS=TIMEOUT_CYCLES>1?$clog2(TIMEOUT_CYCLES):1;
 reg [3:0] state;
 reg [31:0] remaining;
 reg [27:0] cluster,cycle_anchor;
 wire [31:0] fat_base,data_base;
 wire [27:0] max_valid_cluster;
 wire [32:0] volume_end;
 reg [6:0] last_sector,cluster_sector;
 reg [2:0] cfg_shift;
 reg [TIMEOUT_BITS-1:0] wait_count;
 reg [CHAIN_BITS-1:0] chain_count;
 reg [31:0] request_lba;
 reg [34:0] shift_work;
 reg [2:0] shift_left;
 reg [8:0] meta_count;
 reg [8:0] fat_offset;
 reg [27:0] fat_value;
 reg framing_error;
 function [2:0] spc_log2(input [7:0] value);
  begin case(value)
   2:spc_log2=1;4:spc_log2=2;8:spc_log2=3;16:spc_log2=4;
   32:spc_log2=5;64:spc_log2=6;128:spc_log2=7;default:spc_log2=0;
  endcase end
 endfunction
 wire spc_ok=sectors_per_cluster!=0&&
           (sectors_per_cluster&(sectors_per_cluster-1'b1))==0;
 wire open_ok=file_length!=0&&spc_ok&&file_first_cluster>=2&&file_first_cluster<=max_cluster&&
     max_cluster<32'h0ffffff0&&data_start_lba<volume_end_lba&&
     fat_start_lba<data_start_lba&&volume_end_lba<=33'h100000000;
 // In shared mode the parent owns a stable mounted-volume snapshot throughout
 // this file transaction. Callers without that guarantee must enable latching.
 generate if(LATCH_GEOMETRY)begin:held_geometry
  reg [31:0] held_fat,held_data;
  reg [27:0] held_max;
  reg [32:0] held_end;
  always @(posedge clk or posedge rst)begin
   if(rst)begin held_fat<=0;held_data<=0;held_max<=0;held_end<=0;end
   else if(open_valid&&open_ready&&open_ok)begin
    held_fat<=fat_start_lba;held_data<=data_start_lba;held_max<=max_cluster[27:0];held_end<=volume_end_lba;
   end
  end
  assign fat_base=held_fat;assign data_base=held_data;assign max_valid_cluster=held_max;assign volume_end=held_end;
 end else begin:shared_geometry
  assign fat_base=fat_start_lba;assign data_base=data_start_lba;
  assign max_valid_cluster=max_cluster[27:0];assign volume_end=volume_end_lba;
 end endgenerate
 wire [32:0] lba_calc={1'b0,data_base}+{1'b0,shift_work[31:0]}+cluster_sector;
 wire [32:0] fat_lba_calc={1'b0,fat_base}+{12'd0,cluster[27:7]};
 wire [27:0] next_cluster=fat_value;
 wire invalid_next=next_cluster<2||next_cluster>max_valid_cluster||
     next_cluster>=32'h0ffffff0||next_cluster==cluster||next_cluster==cycle_anchor||
     chain_count>=MAX_CHAIN_CLUSTERS;
 wire waiting=state==AUDIO_WAIT||state==FAT_REQ||state==FAT_READ||state==FAT_WAIT;
 wire progress=(meta_read_valid&&meta_read_ready)||(meta_data_valid&&meta_data_ready)||
     meta_done||meta_error||sector_done||sector_error;
 wire timeout_hit=TIMEOUT_CYCLES==0||wait_count>=TIMEOUT_CYCLES-1;
 assign open_ready=state==IDLE&&!rst&&!abort;
 assign sector_valid=state==AUDIO_REQ&&!rst&&!abort;
 assign sector_valid_bytes=remaining>=512?10'd512:remaining[9:0];
 assign sector_file_last=remaining<=512;
 assign meta_read_valid=state==FAT_REQ&&!rst&&!abort;
 assign meta_data_ready=state==FAT_READ&&!rst&&!abort;
 assign file_read_done=result_valid&&result_code==0;
 assign busy=state!=IDLE&&state!=RESULT;
 assign sector_lba=request_lba;
 assign meta_read_lba=request_lba;
 wire [CHAIN_BITS:0] next_chain_count={1'b0,chain_count}+1'b1;
 wire next_checkpoint=(next_chain_count&(next_chain_count-1'b1))==0;
 task finish_result(input [3:0] code);
  begin result_valid<=1;result_code<=code;state<=RESULT;end
 endtask
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   state<=IDLE;result_valid<=0;result_code<=0;request_lba<=0;
   cluster<=0;remaining<=0;
   last_sector<=0;cfg_shift<=0;cluster_sector<=0;wait_count<=0;chain_count<=0;
   cycle_anchor<=0;
   shift_work<=0;shift_left<=0;
   meta_count<=0;fat_offset<=0;fat_value<=0;framing_error<=0;
  end else if(abort)begin
   state<=IDLE;result_valid<=0;result_code<=0;wait_count<=0;remaining<=0;
  end else begin
   if(waiting)begin
    if(progress)wait_count<=0;
    else if(!timeout_hit)wait_count<=wait_count+1'b1;
   end else wait_count<=0;
   if(waiting&&timeout_hit&&!progress)finish_result(4'd6);
   else case(state)
    IDLE:if(open_valid)begin
     result_valid<=0;result_code<=0;
     if(!open_ok)finish_result(4'd1);
     else begin
      cluster<=file_first_cluster[27:0];remaining<=file_length;
      last_sector<=sectors_per_cluster-1'b1;cfg_shift<=spc_log2(sectors_per_cluster);cluster_sector<=0;
      cycle_anchor<=file_first_cluster[27:0];chain_count<=1;
      state<=ADDRESS;
     end
    end
    ADDRESS:begin shift_work<={7'd0,cluster}-35'd2;shift_left<=cfg_shift;state<=ADDRESS_SHIFT;end
    ADDRESS_SHIFT:begin
     if(shift_left!=0)begin shift_work<=shift_work<<1;shift_left<=shift_left-1'b1;end
     else state<=ADDRESS_FINAL;
    end
    ADDRESS_FINAL:begin
     if(shift_work[34:32]!=0||lba_calc[32]||lba_calc>=volume_end)finish_result(4'd2);
     else begin request_lba<=lba_calc[31:0];state<=AUDIO_REQ;end
    end
    AUDIO_REQ:if(sector_ready)begin state<=AUDIO_WAIT;wait_count<=0;end
    AUDIO_WAIT:begin
     if(sector_error)finish_result(4'd5);
     else if(sector_done)begin
      if(remaining<=512)begin remaining<=0;finish_result(4'd0);end
      else begin
       remaining<=remaining-32'd512;
       if(cluster_sector!=last_sector)begin cluster_sector<=cluster_sector+1'b1;state<=ADDRESS;end
       else if(fat_lba_calc[32]||fat_lba_calc>=data_base)finish_result(4'd2);
       else begin
        request_lba<=fat_lba_calc[31:0];fat_offset<={cluster[6:0],2'b00};
        state<=FAT_REQ;wait_count<=0;
       end
      end
     end
    end
    FAT_REQ:if(meta_read_ready)begin
     meta_count<=0;fat_value<=0;framing_error<=0;state<=FAT_READ;wait_count<=0;
    end
    FAT_READ:begin
     if(meta_error)finish_result(4'd5);
     else if(meta_done)finish_result(4'd4);
     else if(meta_data_valid)begin
      if(meta_data_last!=(meta_count==511))framing_error<=1;
      if(meta_count==fat_offset)fat_value[7:0]<=meta_data;
      if(meta_count==fat_offset+10'd1)fat_value[15:8]<=meta_data;
      if(meta_count==fat_offset+10'd2)fat_value[23:16]<=meta_data;
      if(meta_count==fat_offset+10'd3)fat_value[27:24]<=meta_data[3:0];
      if(meta_count==511)state<=FAT_WAIT;else meta_count<=meta_count+1'b1;
     end
    end
    FAT_WAIT:begin
     if(meta_data_valid)framing_error<=1;
     if(meta_error)finish_result(4'd5);
     else if(meta_done)begin
      if(framing_error||meta_data_valid)finish_result(4'd4);
      else state<=FAT_APPLY;
     end
    end
    FAT_APPLY:begin
     if(invalid_next)finish_result(4'd3);
     else begin
      cluster<=next_cluster;cluster_sector<=0;chain_count<=chain_count+1'b1;
      if(next_checkpoint)cycle_anchor<=next_cluster;
      state<=ADDRESS;
     end
    end
    RESULT:if(result_ready)begin result_valid<=0;state<=IDLE;end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
