module audio_engine  (
    input  wire        clk,
    input  wire        rst,
    input  wire        trigger,
    input  wire [1:0]  sound_id,
    input  wire        mute,
    input  wire [1:0]  volume,

    output wire        audio_valid,
    output wire [23:0] audio_left_data,
    output wire [23:0] audio_right_data,
    output wire        acr_valid,
    output wire [19:0] acr_cts,
    output wire [19:0] acr_n
);
    localparam active_hd = 1'b1;

    wire signed [23:0] source_pcm;
    wire               source_valid;
    wire signed [23:0] adjusted_pcm;
    wire               adjusted_valid;

    sound_source  u_sound_source (
        
        .clk        (clk),
        .rst        (rst),
        .trigger    (trigger),
        .sound_id   (sound_id),
        .pcm_sample (source_pcm),
        .pcm_valid  (source_valid)
    );

    gain_mute u_gain_mute (
        .pcm_in        (source_pcm),
        .pcm_valid_in  (source_valid),
        .mute          (mute),
        .volume        (volume),
        .pcm_out       (adjusted_pcm),
        .pcm_valid_out (adjusted_valid)
    );

    audio_transport  u_audio_transport (
        
        .clk              (clk),
        .rst              (rst),
        .pcm_in           (adjusted_pcm),
        .pcm_valid_in     (adjusted_valid),
        .audio_valid      (audio_valid),
        .audio_left_data  (audio_left_data),
        .audio_right_data (audio_right_data)
    );

    audio_acr #(
        .ACR_N (20'd6144)
    ) u_audio_acr (
        .clk         (clk),
        .rst         (rst),
        .audio_valid (audio_valid),
        .acr_valid   (acr_valid),
        .acr_cts     (acr_cts),
        .acr_n       (acr_n)
    );

endmodule
