module audio_transport  (
    input  wire               clk,
    input  wire               rst,
    input  wire signed [23:0] pcm_in,
    input  wire               pcm_valid_in,

    output reg                audio_valid,
    output reg  [23:0]        audio_left_data,
    output reg  [23:0]        audio_right_data
);
    localparam active_hd = 1'b1;

    wire [26:0] CLK_HZ         = 27'd75000000;
    localparam [26:0] SAMPLE_RATE_HZ = 27'd48000;

    // 分数累加器使25 MHz时钟在长期平均下精确产生48 kHz采样脉冲。
    reg [26:0] sample_accumulator;

    always @(posedge clk) begin
        if (rst) begin
            sample_accumulator <= 27'd0;
            audio_valid        <= 1'b0;
            audio_left_data    <= 24'd0;
            audio_right_data   <= 24'd0;
        end
        else begin
            audio_valid <= 1'b0;

            if (sample_accumulator >= CLK_HZ - SAMPLE_RATE_HZ) begin
                sample_accumulator <= sample_accumulator
                                      + SAMPLE_RATE_HZ - CLK_HZ;
                audio_valid <= 1'b1;

                // 第一版左右声道播放相同的提示音。
                if (pcm_valid_in) begin
                    audio_left_data  <= pcm_in;
                    audio_right_data <= pcm_in;
                end
                else begin
                    audio_left_data  <= 24'd0;
                    audio_right_data <= 24'd0;
                end
            end
            else begin
                sample_accumulator <= sample_accumulator + SAMPLE_RATE_HZ;
            end
        end
    end

endmodule
