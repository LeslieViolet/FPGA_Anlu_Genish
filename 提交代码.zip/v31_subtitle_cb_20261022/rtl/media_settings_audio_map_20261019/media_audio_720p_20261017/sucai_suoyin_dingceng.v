// Part 1 + Part 2 integration wrapper. Instantiate this ONCE under B.
// clk must be 100 MHz with the default Part 1 timing parameters.
`default_nettype none
module sucai_suoyin_dingceng (
    input wire clk,
    input wire rst,
    input wire scan_valid,
    output wire scan_ready,
    input wire [31:0] scan_first_lba,
    input wire [31:0] scan_last_lba,
    output wire scan_busy,
    output wire scan_done,
    output wire [3:0] scan_status,
    output wire [3:0] reader_error_code,
    output wire [4:0] asset_count,
    output wire [31:0] rejected_count,
    output wire [31:0] current_lba,
    input wire [3:0] query_id,
    output wire query_valid,
    output wire [31:0] asset_start_lba,
    output wire [31:0] asset_byte_length,
    output wire [31:0] asset_pixel_offset,
    output wire [15:0] asset_width,
    output wire [15:0] asset_height,
    output wire asset_bottom_up,
    output wire card_ready,
    output wire tf_cs_n,
    output wire tf_sclk,
    output wire tf_mosi,
    input wire tf_miso
);
    wire read_valid, read_ready;
    wire [31:0] read_lba;
    wire [7:0] data;
    wire data_valid, data_ready, data_last;
    wire reader_done, reader_error;
    wire [3:0] read_error_code;

    tf_shanqu_duqu u_tf_shanqu_duqu (
        .clk(clk), .rst(rst),
        .read_valid(read_valid), .read_ready(read_ready), .read_lba(read_lba),
        .data(data), .data_valid(data_valid), .data_ready(data_ready),
        .data_last(data_last), .busy(), .card_ready(card_ready),
        .done(reader_done), .error(reader_error), .error_code(read_error_code),
        .tf_cs_n(tf_cs_n), .tf_sclk(tf_sclk), .tf_mosi(tf_mosi), .tf_miso(tf_miso)
    );

    sucai_suoyin u_sucai_suoyin (
        .clk(clk), .rst(rst),
        .scan_valid(scan_valid), .scan_ready(scan_ready),
        .scan_first_lba(scan_first_lba), .scan_last_lba(scan_last_lba),
        .scan_busy(scan_busy), .scan_done(scan_done), .scan_status(scan_status),
        .reader_error_code(reader_error_code), .asset_count(asset_count),
        .rejected_count(rejected_count), .current_lba(current_lba),
        .query_id(query_id), .query_valid(query_valid),
        .asset_start_lba(asset_start_lba), .asset_byte_length(asset_byte_length),
        .asset_pixel_offset(asset_pixel_offset), .asset_width(asset_width),
        .asset_height(asset_height), .asset_bottom_up(asset_bottom_up),
        .card_ready(card_ready), .read_valid(read_valid), .read_ready(read_ready),
        .read_lba(read_lba), .data(data), .data_valid(data_valid),
        .data_ready(data_ready), .data_last(data_last),
        .reader_done(reader_done), .reader_error(reader_error),
        .read_error_code(read_error_code)
    );
endmodule
`default_nettype wire
