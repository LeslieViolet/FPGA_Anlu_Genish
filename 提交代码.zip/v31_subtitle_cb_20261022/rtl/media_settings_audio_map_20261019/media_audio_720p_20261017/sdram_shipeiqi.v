// Part 8: write/read CDC, arbitration, cancellation drain and APUG011 adapter.
`timescale 1ns/1ps
`default_nettype none
module sdram_shipeiqi #(
    parameter FULL_WRITE_GROUP=1,
    parameter READ_CHECK_WORDS=921600,
    parameter DIAGNOSTICS=1
)(
    input  wire        clk_write,
    input  wire        rst_write,
    input  wire        mem_write_valid,
    output wire        mem_write_ready,
    input  wire [20:0] mem_write_addr,
    input  wire [31:0] mem_write_data,
    input  wire        mem_flush_req,
    output wire        mem_flush_done,

    input  wire        clk_read,
    input  wire        rst_read,
    input  wire        mem_read_valid,
    output wire        mem_read_ready,
    input  wire [20:0] mem_read_addr,
    output wire        mem_read_data_valid,
    input  wire        mem_read_data_ready,
    output wire [31:0] mem_read_data,
    input  wire        mem_read_cancel_req,
    output wire        mem_read_cancel_done,

    input  wire        clk_mem,
    input  wire        clk_mem_sft,
    input  wire        rst_mem,
    output wire        memory_ready,
    output wire        memory_fault,
    output wire [7:0]  memory_diag,
    output wire [3:0]  read_request_diag,
    output wire [3:0]  native_write_crc,
    output wire [6:0]  alignment_match,
    output wire [3:0]  alignment_status,
    output wire [3:0]  native_read_addr_diag,
    output wire [3:0]  native_access_diag
);
    localparam [20:0] USED_WORDS = 21'd1843200;
    localparam FIFO_ADDR_WIDTH = 9;
    localparam [9:0] RESPONSE_HEADROOM = 10'd16;

    wire write_fifo_reset = rst_write | rst_mem;
    wire read_fifo_reset  = rst_read | rst_mem;

    wire write_addr_ok = mem_write_addr < USED_WORDS;
    wire read_addr_ok = mem_read_addr < USED_WORDS;

    // Controller status is synchronized separately into each producer domain.
    wire controller_init_done;
    wire controller_refresh_active;
    wire controller_busy;
    wire [31:0] controller_read_data;
    wire batch_fault;
    reg first_flush_seen;
    (* async_reg = "true" *) reg [1:0] init_sync_write;
    (* async_reg = "true" *) reg [1:0] init_sync_read;

    // Write request FIFO: clk_write -> clk_mem, {word address, data}.
    wire [52:0] write_fifo_out;
    wire write_fifo_full, write_fifo_afull, write_fifo_empty;
    wire write_fifo_aempty, write_fifo_valid;
    wire write_fifo_overflow, write_fifo_underflow;
    wire [FIFO_ADDR_WIDTH:0] write_fifo_wr_usedw, write_fifo_rd_usedw;
    wire write_fifo_we;
    wire write_fifo_re;

    // Read command FIFO: clk_read -> clk_mem, one word address per entry.
    wire [20:0] read_cmd_fifo_out;
    wire read_cmd_fifo_full, read_cmd_fifo_afull, read_cmd_fifo_empty;
    wire read_cmd_fifo_aempty, read_cmd_fifo_valid;
    wire read_cmd_fifo_overflow, read_cmd_fifo_underflow;
    wire [FIFO_ADDR_WIDTH:0] read_cmd_fifo_wr_usedw, read_cmd_fifo_rd_usedw;
    wire read_cmd_fifo_we;
    wire read_cmd_fifo_re;

    // Read response FIFO: clk_mem -> clk_read.
    wire [31:0] read_rsp_fifo_out;
    wire read_rsp_fifo_full, read_rsp_fifo_afull, read_rsp_fifo_empty;
    wire read_rsp_fifo_aempty, read_rsp_fifo_valid;
    wire read_rsp_fifo_overflow, read_rsp_fifo_underflow;
    wire [FIFO_ADDR_WIDTH:0] read_rsp_fifo_wr_usedw, read_rsp_fifo_rd_usedw;
    wire read_rsp_fifo_we;
    wire read_rsp_fifo_re;

    reg fault_write;
    reg fault_read;
    reg fault_mem;
    // The sticky aggregate is a status crossing, never combinationally gate
    // another domain's ready/valid with it. Local faults still stop immediately.
    (* async_reg = "true" *) reg [1:0] fault_write_sync;
    (* async_reg = "true" *) reg [1:0] fault_read_sync;
    wire write_fault_local = fault_write | fault_write_sync[1];
    wire read_fault_local = fault_read | fault_read_sync[1];
    assign memory_fault = fault_write | fault_read | fault_mem | batch_fault;
    assign memory_ready = init_sync_write[1] && !write_fault_local;

    always @(posedge clk_write or posedge rst_write) begin
        if(rst_write) fault_write_sync<=0;
        else fault_write_sync<={fault_write_sync[0],memory_fault};
    end
    always @(posedge clk_read or posedge rst_read) begin
        if(rst_read) fault_read_sync<=0;
        else fault_read_sync<={fault_read_sync[0],memory_fault};
    end

    always @(posedge clk_write or posedge rst_write) begin
        if(rst_write) begin
            init_sync_write<=0;
            fault_write<=0;
        end else begin
            init_sync_write<={init_sync_write[0],controller_init_done};
            if((mem_write_valid && !write_addr_ok) || write_fifo_overflow)
                fault_write<=1;
        end
    end

    always @(posedge clk_read or posedge rst_read) begin
        if(rst_read) begin
            init_sync_read<=0;
            fault_read<=0;
        end else begin
            init_sync_read<={init_sync_read[0],controller_init_done};
            if((mem_read_valid && !read_addr_ok) || read_cmd_fifo_overflow ||
               read_rsp_fifo_underflow)
                fault_read<=1;
        end
    end

    assign mem_write_ready = !rst_write && init_sync_write[1] &&
        !write_fault_local && write_addr_ok && !mem_flush_req && !write_fifo_full;
    assign write_fifo_we = mem_write_valid && mem_write_ready;

    assign mem_read_ready = !rst_read && init_sync_read[1] &&
        !read_fault_local && read_addr_ok && !mem_read_cancel_req &&
        !read_cmd_fifo_full;
    assign read_cmd_fifo_we = mem_read_valid && mem_read_ready;

    guanfang_yibu_fifo #(.DATA_WIDTH(53), .ADDR_WIDTH(FIFO_ADDR_WIDTH),
        .ALMOST_FULL_LEVEL(496), .ALMOST_EMPTY_LEVEL(4)) u_write_fifo (
        .rst(write_fifo_reset), .wr_clk(clk_write), .wr_en(write_fifo_we),
        .wr_data({mem_write_addr,mem_write_data}), .full(write_fifo_full),
        .almost_full(write_fifo_afull), .wr_usedw(write_fifo_wr_usedw),
        .overflow(write_fifo_overflow), .rd_clk(clk_mem), .rd_en(write_fifo_re),
        .rd_data(write_fifo_out), .empty(write_fifo_empty),
        .almost_empty(write_fifo_aempty), .valid(write_fifo_valid),
        .rd_usedw(write_fifo_rd_usedw), .underflow(write_fifo_underflow)
    );

    guanfang_yibu_fifo #(.DATA_WIDTH(21), .ADDR_WIDTH(FIFO_ADDR_WIDTH),
        .ALMOST_FULL_LEVEL(496), .ALMOST_EMPTY_LEVEL(4)) u_read_cmd_fifo (
        .rst(read_fifo_reset), .wr_clk(clk_read), .wr_en(read_cmd_fifo_we),
        .wr_data(mem_read_addr), .full(read_cmd_fifo_full),
        .almost_full(read_cmd_fifo_afull), .wr_usedw(read_cmd_fifo_wr_usedw),
        .overflow(read_cmd_fifo_overflow), .rd_clk(clk_mem), .rd_en(read_cmd_fifo_re),
        .rd_data(read_cmd_fifo_out), .empty(read_cmd_fifo_empty),
        .almost_empty(read_cmd_fifo_aempty), .valid(read_cmd_fifo_valid),
        .rd_usedw(read_cmd_fifo_rd_usedw), .underflow(read_cmd_fifo_underflow)
    );

    guanfang_yibu_fifo #(.DATA_WIDTH(32), .ADDR_WIDTH(FIFO_ADDR_WIDTH),
        .ALMOST_FULL_LEVEL(496), .ALMOST_EMPTY_LEVEL(4)) u_read_rsp_fifo (
        .rst(read_fifo_reset), .wr_clk(clk_mem), .wr_en(read_rsp_fifo_we),
        .wr_data(controller_read_data), .full(read_rsp_fifo_full),
        .almost_full(read_rsp_fifo_afull), .wr_usedw(read_rsp_fifo_wr_usedw),
        .overflow(read_rsp_fifo_overflow), .rd_clk(clk_read), .rd_en(read_rsp_fifo_re),
        .rd_data(read_rsp_fifo_out), .empty(read_rsp_fifo_empty),
        .almost_empty(read_rsp_fifo_aempty), .valid(read_rsp_fifo_valid),
        .rd_usedw(read_rsp_fifo_rd_usedw), .underflow(read_rsp_fifo_underflow)
    );

    // Flush request crosses as a held level. Completion is also held until the
    // request is released, avoiding pulse loss between unrelated clocks.
    (* async_reg = "true" *) reg [1:0] flush_req_sync;
    (* async_reg = "true" *) reg [1:0] flush_done_sync;
    reg flush_done_mem;
    reg [6:0] flush_quiet_count;
    assign mem_flush_done = mem_flush_req && flush_done_sync[1] && !write_fault_local;

    always @(posedge clk_write or posedge rst_write) begin
        if(rst_write) flush_done_sync<=0;
        else flush_done_sync<={flush_done_sync[0],flush_done_mem};
    end

    // Read cancellation crosses to clk_mem. Commands already queued are
    // discarded and controller returns already in flight are dropped.
    (* async_reg = "true" *) reg [1:0] cancel_req_sync;
    (* async_reg = "true" *) reg [1:0] cancel_drained_sync;
    reg cancel_active_mem;
    wire cancel_drained_mem;
    assign mem_read_cancel_done = mem_read_cancel_req &&
        cancel_drained_sync[1] && read_rsp_fifo_empty;
    assign mem_read_data_valid = !rst_read && !mem_read_cancel_req &&
        read_rsp_fifo_valid && !read_rsp_fifo_empty && !read_fault_local;
    assign mem_read_data = read_rsp_fifo_out;
    assign read_rsp_fifo_re = read_rsp_fifo_valid && !read_rsp_fifo_empty &&
        (mem_read_cancel_req || mem_read_data_ready);

    always @(posedge clk_read or posedge rst_read) begin
        if(rst_read) cancel_drained_sync<=0;
        else cancel_drained_sync<={cancel_drained_sync[0],cancel_drained_mem};
    end

    // APUG011 addresses are interpreted as aligned groups of four words.
    // Collect a group before issuing it. Never arbitrate within a group.
    // FULL_WRITE_GROUP waits across source gaps; flush/address jump still seal
    // partial groups using DM=1111. Unused read words are dropped by tags.
    reg prefer_read;
    reg [1:0] quantum_count;
    reg [5:0] read_outstanding;
    wire controller_read_valid;
    wire [31:0] controller_raw_read_data;

    reg [18:0] wr_base, rd_base;
    reg [3:0] wr_mask, rd_mask;
    reg [1:0] wr_last, rd_last;
    reg wr_sealed, rd_sealed;
    reg [4:0] wr_wait, rd_wait;
    reg [31:0] wr_words [0:3];
    reg active, active_read;
    reg [1:0] beat;
    reg [18:0] txn_base;
    reg [3:0] txn_mask;
    reg [31:0] txn_words [0:3];

    // Tags correspond to ALL native reads, including padded/dropped words.
    // 16 maximum in flight, 32 ring entries; preserve the producer's order.
    reg keep_tag [0:31];
    reg [4:0] tag_wr, tag_rd;
    wire returned_requested = read_outstanding!=0 && keep_tag[tag_rd];
    wire response_room = !read_rsp_fifo_afull && !read_rsp_fifo_full &&
                         read_outstanding <=
                         ((active && active_read) ? 6'd11 : 6'd12);
    wire engine_available = !active || beat==2'd3;

    // The display reader works in 128-word batches.  Once a complete batch of
    // commands is queued, give it priority over starting the next four-word
    // write group.  A batch is much shorter than the time needed by the
    // 25 MHz pixel side to consume 128 pixels, so the gaps between batches are
    // still available to the TF/BMP writer.  Requiring write_fifo_empty here
    // used to starve display reads for the whole duration of an image load:
    // C's 640-word prefill showed the first line, then underflowed to black.
    wire batch_pop, batch_put, batch_rd, batch_busy, batch_cancel_done;
    wire batch_valid;
    wire [20:0] batch_addr;
    // A complete read batch reserves the next group boundary even while a
    // write is active.  Launch eligibility alone cannot arbitrate beat three:
    // it requires !active, which remains false when writes chain every group.
    wire read_batch_pending = controller_init_done && first_flush_seen && !batch_busy &&
        // Flush drains the write producer; it must not suspend an unrelated
        // leased display read. Native write/read mutual exclusion is enforced
        // by !active/!batch_busy, and the flush barrier still checks write drain.
        !cancel_req_sync[1] && !cancel_active_mem &&
        read_cmd_fifo_valid && !read_cmd_fifo_empty &&
        read_cmd_fifo_rd_usedw >= 10'd128 &&
        read_rsp_fifo_wr_usedw <= 10'd384 && !read_rsp_fifo_full;
    wire batch_start_request = read_batch_pending &&
        !controller_refresh_active && !controller_busy && !active;

    wire can_write = controller_init_done && !controller_refresh_active && !controller_busy &&
                     wr_sealed && !flush_done_mem && !batch_busy &&
                     !read_batch_pending;
    wire can_read = 1'b0 && controller_init_done && !controller_refresh_active &&
                    rd_sealed && response_room && !cancel_active_mem &&
                    !cancel_req_sync[1] && !flush_req_sync[1];
    wire start_write = engine_available && can_write &&
                       (flush_req_sync[1] || !can_read || !prefer_read);
    wire start_read = engine_available && can_read && !start_write;
    // APUG011 BUSY includes its command/data pipeline after the last app beat.
    // Restarting a discontinuous group during that tail can leave SDR_DQ high-Z
    // on a physical WRITE. Check again at beat zero, since BUSY can assert after
    // scheduling. Once begun, all four beats must remain consecutive.
    wire issue_write = active && !active_read &&
                       (beat!=0 || (!controller_refresh_active && !controller_busy));
    wire issue_read = active && active_read &&
                      (beat!=0 || !controller_refresh_active);

    wire wr_head_valid = write_fifo_valid && !write_fifo_empty;
    wire rd_head_valid = read_cmd_fifo_valid && !read_cmd_fifo_empty;
    wire wr_same_group = wr_mask==0 ||
        (write_fifo_out[52:34]==wr_base && write_fifo_out[33:32]>wr_last);
    wire rd_same_group = rd_mask==0 ||
        (read_cmd_fifo_out[20:2]==rd_base && read_cmd_fifo_out[1:0]>rd_last);
    assign write_fifo_re = controller_init_done && !wr_sealed &&
        !start_write && wr_head_valid && wr_same_group;
    assign read_cmd_fifo_re=batch_pop;
    assign read_rsp_fifo_we=batch_put;
    assign cancel_drained_mem=batch_cancel_done;


    assign controller_read_valid=1'b0;
    generate begin : g_hd_stream
    changkuai_duqu_hd #(.USED_WORDS(USED_WORDS)) u_batch (
        .clk(clk_mem),.rst(rst_mem),
        .enable(batch_start_request),
        .refresh(controller_refresh_active),.cancel(cancel_req_sync[1] || cancel_active_mem),
        .cmd_valid(read_cmd_fifo_valid),.cmd_empty(read_cmd_fifo_empty),
        .cmd_count(read_cmd_fifo_rd_usedw),.rsp_count(read_rsp_fifo_wr_usedw),
        .cmd_addr(read_cmd_fifo_out),.native_valid(batch_valid),.rsp_full(read_rsp_fifo_full),
        .cmd_pop(batch_pop),.rd(batch_rd),.put(batch_put),.busy(batch_busy),
        .cancel_done(batch_cancel_done),.addr(batch_addr),.fault(batch_fault)
    );
    end endgenerate
    sdram_kongzhiqi_fengzhuang u_sdram (
        .clk_mem(clk_mem), .clk_mem_sft(clk_mem_sft), .rst_mem(rst_mem),
        .app_wr_en(issue_write), .app_wr_addr({txn_base,beat}),
        .app_wr_dm(txn_mask[beat] ? 4'b0000 : 4'b1111),
        .app_wr_data(txn_words[beat]),
        .app_rd_en(batch_rd), .app_rd_addr(batch_addr),
        .app_rd_data_valid(batch_valid),
        .app_rd_data(controller_read_data), .raw_read_data(controller_raw_read_data),
        .init_done(controller_init_done),
        .refresh_active(controller_refresh_active),
        .controller_busy(controller_busy)
    );

    always @(posedge clk_mem or posedge rst_mem) begin
        if(rst_mem) first_flush_seen<=0;
        else if(flush_done_mem) first_flush_seen<=1;
    end

generate if(DIAGNOSTICS) begin : g_diagnostics
    // First-frame address probe: compare native useful reads against the
    // buffer selected by the first actual useful native write.
    sdram_dizhi_jiaoyan #(.FRAME_WORDS(921600)) u_native_address (
    
        .clk(clk_mem),.rst(rst_mem),
        .write_take(issue_write && txn_mask[beat]),.write_addr({txn_base,beat}),
        .read_take(batch_rd),.read_addr(batch_addr),
        .flags(native_read_addr_diag)
    );
    reg full_groups_only, masked_write_seen, refresh_overlap_seen;
    reg read_before_flush_seen;
    assign native_access_diag={masked_write_seen,refresh_overlap_seen,
                               read_before_flush_seen,full_groups_only};
    always @(posedge clk_mem or posedge rst_mem) begin
        if(rst_mem) begin
            full_groups_only<=1;masked_write_seen<=0;refresh_overlap_seen<=0;
            read_before_flush_seen<=0;
        end else begin
            if(issue_write && txn_mask!=4'b1111) full_groups_only<=0;
            if(issue_write && !txn_mask[beat]) masked_write_seen<=1;
            if((issue_write || batch_rd) && controller_refresh_active)
                refresh_overlap_seen<=1;
            if(batch_rd && !first_flush_seen) read_before_flush_seen<=1;
        end
    end

    // The eight parallel known-pattern CRC probes are historical lab tools.
    // Runtime mode retains the general frame_integrity_probe below, along with
    // address, FIFO, refresh, timeout and underrun checks. Inactive legacy flags
    // stay zero (not "passed") to avoid consuming the space for the second TX.
    begin:legacy_pattern_crc
    sdram_duiqi_jiaoyan #(.FRAME_WIDTH(1280),
                           .FRAME_HEIGHT(720)) u_alignment_crc (
    
        .clk(clk_mem),.rst(rst_mem),
        .write_take(issue_write && txn_mask[beat]),
        .write_rgb(txn_words[beat][31:8]),.write_addr({txn_base,beat}),
        .read_take(read_rsp_fifo_we),.raw_rgb(controller_raw_read_data[31:8]),
        .native_write_crc(native_write_crc),.alignment_match(alignment_match),
        .alignment_status(alignment_status)
    );

    end
    // Observation only: no diagnostic result gates functional handshakes.
    wire native_return_stuck, refresh_stuck;
    liucheng_jishu_zhenduan #(.STALL_CYCLES(4096)) u_native_diag (
        .clk(clk_mem),.rst(rst_mem),.count_take(read_rsp_fifo_we),
        .progress(batch_valid),
        .wait_for_event(read_outstanding!=0),
        .milestones(memory_diag[7:4]),.stalled(native_return_stuck)
    );
    liucheng_jishu_zhenduan #(.STALL_CYCLES(4096)) u_refresh_diag (
        .clk(clk_mem),.rst(rst_mem),.count_take(1'b0),
        .progress(1'b0),.wait_for_event(controller_refresh_active),
        .milestones(),.stalled(refresh_stuck)
    );
    // Compare source writes with complete display reads, independently of
    // service latency. This is observational and never gates the data path.
    frame_integrity_probe #(.WIDTH(1280),
        .HEIGHT(720)) u_frame_integrity (
    
    
        .write_clk(clk_write),.write_rst(rst_write),
        .write_take(write_fifo_we),.write_addr(mem_write_addr),
        .write_data(mem_write_data),.read_clk(clk_read),.read_rst(rst_read),
        .request_take(read_cmd_fifo_we),.request_addr(mem_read_addr),
        .data_take(mem_read_data_valid && mem_read_data_ready),
        .read_data(mem_read_data),.cancel(mem_read_cancel_req),
        .flags(memory_diag[3:0]));
    liucheng_jishu_zhenduan u_request_diag (
        .clk(clk_read),.rst(rst_read),.count_take(read_cmd_fifo_we),
        .progress(1'b0),.wait_for_event(1'b0),
        .milestones(read_request_diag),.stalled()
    );
end else begin : g_no_diagnostics
    assign memory_diag=0;
    assign read_request_diag=0;
    assign native_write_crc=0;
    assign alignment_match=0;
    assign alignment_status=0;
    assign native_read_addr_diag=0;
    assign native_access_diag=0;
end endgenerate

    integer k;
    always @(posedge clk_mem or posedge rst_mem) begin
        if(rst_mem) begin
            flush_req_sync<=0; flush_done_mem<=0; flush_quiet_count<=0;
            cancel_req_sync<=0; cancel_active_mem<=0;
            prefer_read<=1; quantum_count<=0; read_outstanding<=0;
            fault_mem<=0;
            wr_base<=0; rd_base<=0; wr_mask<=0; rd_mask<=0;
            wr_last<=0; rd_last<=0; wr_sealed<=0; rd_sealed<=0;
            wr_wait<=0; rd_wait<=0; active<=0; active_read<=0; beat<=0;
            txn_base<=0; txn_mask<=0; tag_wr<=0; tag_rd<=0;
            for(k=0;k<4;k=k+1) begin wr_words[k]<=0; txn_words[k]<=0; end
            for(k=0;k<32;k=k+1) keep_tag[k]<=0;
        end else begin
            flush_req_sync<={flush_req_sync[0],mem_flush_req};
            cancel_req_sync<={cancel_req_sync[0],mem_read_cancel_req};
            if(cancel_req_sync[1]) cancel_active_mem<=1;
            else if(cancel_active_mem) cancel_active_mem<=0;

            // Collect in address order. A jump, duplicate or backwards address
            // seals the previous group; the next request remains in the FIFO.
            if(start_write) begin
                wr_mask<=0; wr_sealed<=0; wr_wait<=0;
            end else if(write_fifo_re) begin
                wr_base<=write_fifo_out[52:34];
                wr_words[write_fifo_out[33:32]]<=write_fifo_out[31:0];
                wr_mask<=wr_mask | (4'b0001 << write_fifo_out[33:32]);
                wr_last<=write_fifo_out[33:32]; wr_wait<=0;
                if(write_fifo_out[33:32]==2'd3) wr_sealed<=1;
            end else if(wr_mask!=0 && !wr_sealed) begin
                if((wr_head_valid && !wr_same_group) ||
                   (!FULL_WRITE_GROUP && wr_wait==5'd15) ||
                   (flush_req_sync[1] && write_fifo_empty)) wr_sealed<=1;
                else wr_wait<=wr_wait+1'b1;
            end

            if(cancel_active_mem || cancel_req_sync[1]) begin
                rd_mask<=0; rd_sealed<=0; rd_wait<=0;
            end else if(start_read) begin
                rd_mask<=0; rd_sealed<=0; rd_wait<=0;
            end else if(read_cmd_fifo_re) begin
                rd_base<=read_cmd_fifo_out[20:2];
                rd_mask<=rd_mask | (4'b0001 << read_cmd_fifo_out[1:0]);
                rd_last<=read_cmd_fifo_out[1:0]; rd_wait<=0;
                if(read_cmd_fifo_out[1:0]==2'd3) rd_sealed<=1;
            end else if(rd_mask!=0 && !rd_sealed) begin
                if((rd_head_valid && !rd_same_group) || rd_wait==5'd15)
                    rd_sealed<=1;
                else rd_wait<=rd_wait+1'b1;
            end

            // Snapshot a complete group, while collectors prepare the next one.
            // An already started group is always finished, including on cancel.
            if(start_write || start_read) begin
                active<=1; active_read<=start_read; beat<=0;
                txn_base<=start_read ? rd_base : wr_base;
                txn_mask<=start_read ? rd_mask : wr_mask;
                if(start_write)
                    for(k=0;k<4;k=k+1) txn_words[k]<=wr_words[k];
                if(quantum_count==2'd3) begin
                    quantum_count<=0; prefer_read<=~prefer_read;
                end else quantum_count<=quantum_count+1'b1;
            end else if(issue_write || issue_read) begin
                if(beat==2'd3) active<=0;
                else beat<=beat+1'b1;
            end

            if(issue_read) begin
                keep_tag[tag_wr]<=txn_mask[beat];
                tag_wr<=tag_wr+1'b1;
            end
            if(controller_read_valid) tag_rd<=tag_rd+1'b1;
            case({issue_read,controller_read_valid})
                2'b10: read_outstanding<=read_outstanding+1'b1;
                2'b01: begin
                    if(read_outstanding==0) fault_mem<=1;
                    else read_outstanding<=read_outstanding-1'b1;
                end
                default: read_outstanding<=read_outstanding;
            endcase

            if(!flush_req_sync[1]) begin
                flush_done_mem<=0; flush_quiet_count<=0;
            end else if(!flush_done_mem) begin
                if(write_fifo_empty && wr_mask==0 && !issue_write &&
                   !active && !start_write && !controller_refresh_active && !controller_busy) begin
                    if(flush_quiet_count==7'd63) flush_done_mem<=1;
                    else flush_quiet_count<=flush_quiet_count+1'b1;
                end else flush_quiet_count<=0;
            end

            if(write_fifo_underflow || read_cmd_fifo_underflow ||
               read_rsp_fifo_overflow ||
               (controller_read_valid && returned_requested &&
                !cancel_active_mem && read_rsp_fifo_full))
                fault_mem<=1;
        end
    end
endmodule

// Diagnostic sum is modulo 2^32 and independent of row order. A matching
// sum is evidence, not a proof against every possible corruption/collision.
// Expected sums are captured only at a leased full-frame read request. The
// existing flush/commit handshake holds the completed write payload stable
// and forbids rewriting that physical slot during its display lease.
module frame_integrity_probe #(parameter WIDTH=1280,HEIGHT=720)(
    input wire write_clk,write_rst,write_take,
    input wire [20:0] write_addr,input wire [31:0] write_data,
    input wire read_clk,read_rst,request_take,
    input wire [20:0] request_addr,input wire data_take,input wire [31:0] read_data,
    input wire cancel,output wire [3:0] flags);
    wire [21:0] WORDS=WIDTH*HEIGHT;
    wire [21:0] READ_WORDS=WIDTH*HEIGHT;
    wire [11:0] frame_width=WIDTH;
    reg [31:0] signature[0:3];
    reg [3:0] signature_valid;
    reg [31:0] write_sum;
    reg [20:0] write_count;
    reg [1:0] write_slot;
    reg write_sequence_fault;
    wire [1:0] ws=write_addr<WORDS ? 0 : write_addr<2*WORDS ? 1 :
                     write_addr<3*WORDS ? 2 : 3;
    wire [20:0] woff=write_addr-ws*WORDS;
    wire [1:0] rs=request_addr<READ_WORDS ? 0 : request_addr<2*READ_WORDS ? 1 :
                     request_addr<3*READ_WORDS ? 2 : 3;
    wire [20:0] roff=request_addr-rs*READ_WORDS;
    integer i;
    always @(posedge write_clk or posedge write_rst) begin
        if(write_rst) begin
            signature_valid<=0;write_sum<=0;write_count<=0;write_slot<=0;
            write_sequence_fault<=0;
            for(i=0;i<4;i=i+1) signature[i]<=0;
        end else if(write_take) begin
            // Production ingress is bottom-up: last raster row arrives first.
            if(woff==WORDS-frame_width) begin
                signature_valid[ws]<=0;
                write_sum<=write_data;write_count<=1;write_slot<=ws;
            end else begin
                write_sum<=write_sum+write_data;
                write_count<=write_count+1'b1;
                if(write_count==0 || write_slot!=ws) write_sequence_fault<=1;
                if(write_count==WORDS-1) begin
                    signature[ws]<=write_sum+write_data;
                    signature_valid[ws]<=1;
                end
            end
        end
    end
    (* async_reg="true" *) reg [3:0] signature_valid_meta,signature_valid_sync;
    reg [3:0] signature_local_valid;
    reg [31:0] signature_pixel[0:3];
    integer signature_number;
    always @(posedge read_clk or posedge read_rst)begin
        if(read_rst)begin
            signature_valid_meta<=0;signature_valid_sync<=0;signature_local_valid<=0;
            for(signature_number=0;signature_number<4;signature_number=signature_number+1)
                signature_pixel[signature_number]<=0;
        end else begin
            signature_valid_meta<=signature_valid;
            signature_valid_sync<=signature_valid_meta;
            for(signature_number=0;signature_number<4;signature_number=signature_number+1)begin
                if(!signature_valid_sync[signature_number])signature_local_valid[signature_number]<=0;
                else if(!signature_local_valid[signature_number])begin
                    signature_pixel[signature_number]<=signature[signature_number];
                    signature_local_valid[signature_number]<=1;
                end
            end
        end
    end
    reg reading, expected_valid, mismatch, missing_baseline, checked;
    reg [31:0] expected_sum,read_sum;
    reg [20:0] read_count;
    (* async_reg="true" *) reg [1:0] write_fault_sync;
    assign flags={write_fault_sync[1],missing_baseline,mismatch,checked};
    always @(posedge read_clk or posedge read_rst) begin
        if(read_rst) begin
            reading<=0;expected_valid<=0;expected_sum<=0;
            read_sum<=0;read_count<=0;mismatch<=0;missing_baseline<=0;
            checked<=0;write_fault_sync<=0;
        end else begin
            write_fault_sync<={write_fault_sync[0],write_sequence_fault};
            if(cancel) reading<=0;
            else begin
                if(request_take && roff==0) begin
                    reading<=1;read_count<=0;read_sum<=0;
                    expected_sum<=signature_pixel[rs];
                    expected_valid<=signature_local_valid[rs];
                    if(!signature_local_valid[rs]) missing_baseline<=1;
                end
                if(data_take && reading) begin
                    read_sum<=read_sum+read_data;
                    read_count<=read_count+1'b1;
                    if(read_count==READ_WORDS-1) begin
                        reading<=0;
                        if(expected_valid) begin
                            checked<=1;
                            if(read_sum+read_data!=expected_sum) mismatch<=1;
                        end
                    end
                end
            end
        end
    end
endmodule
`default_nettype wire
