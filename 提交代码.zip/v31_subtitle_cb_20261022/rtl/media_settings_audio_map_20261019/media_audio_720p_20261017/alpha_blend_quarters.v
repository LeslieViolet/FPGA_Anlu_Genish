// Alpha in exact quarters. Every intermediate channel is ten bits:
// max numerator = 4*255+2 = 1022; no truncation or multiplier is needed.
`default_nettype none
module alpha_blend_quarters #(
    parameter integer ALPHA = 3
) (
    input  wire [23:0] background_rgb,
    input  wire [23:0] foreground_rgb,
    output wire [23:0] mixed_rgb
);
    genvar channel;
    generate for (channel=0; channel<3; channel=channel+1) begin : g_channel
        wire [7:0] bg = background_rgb[channel*8 +: 8];
        wire [7:0] fg = foreground_rgb[channel*8 +: 8];
        if (ALPHA==0) begin : g_zero
            assign mixed_rgb[channel*8 +: 8] = bg;
        end else if (ALPHA==4) begin : g_full
            assign mixed_rgb[channel*8 +: 8] = fg;
        end else if (ALPHA==2) begin : g_half
            wire [8:0] numerator = {1'b0,bg}+{1'b0,fg}+9'd1;
            assign mixed_rgb[channel*8 +: 8] = numerator[8:1];
        end else if (ALPHA==1) begin : g_quarter
            wire [9:0] numerator = {1'b0,bg,1'b0}+{2'b0,bg}
                                 +{2'b0,fg}+10'd2;
            assign mixed_rgb[channel*8 +: 8] = numerator[9:2];
        end else begin : g_three_quarters
            wire [9:0] numerator = {2'b0,bg}+{1'b0,fg,1'b0}
                                 +{2'b0,fg}+10'd2;
            assign mixed_rgb[channel*8 +: 8] = numerator[9:2];
        end
    end endgenerate
endmodule
`default_nettype wire
