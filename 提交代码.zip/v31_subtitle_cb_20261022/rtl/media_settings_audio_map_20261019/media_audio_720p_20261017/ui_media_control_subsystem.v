`default_nettype none
// Unified control front-end for the teammate media baseline.
// The NEC/UI side runs in clk_sys; media request/result signals are bridged
// to the teammate A/B contract in clk_sd by media_control_adapter.
module ui_media_control_subsystem #(
    parameter integer DEMO_IMAGES = 0,
    parameter integer CLK_SYS_HZ = 50000000,
    parameter integer CLK_SD_HZ = 50000000,
    parameter integer AUTO_SECONDS = 5
)(
    input wire clk_sys, input wire rst_sys,
    input wire clk_sd, input wire rst_sd,
    input wire key_next_n, input wire key_auto_n, input wire key_aux_n,
    input wire ir_rx_async,
    input wire card_offline_sd,input wire catalog_done_sd, input wire catalog_ok_sd,
    input wire [4:0] asset_count_sd, input wire storage_ready_sd,
    input wire media_request_ready_sd,
    input wire media_result_valid_sd, input wire [3:0] media_result_code_sd,
    output wire media_request_valid_sd, output wire [3:0] media_request_id_sd,
    output wire media_request_cancel_sd, output wire media_request_started_sd,
    output wire catalog_ready_sys, output wire [4:0] asset_count_sys,
    output wire [3:0] current_id_sys, output wire auto_enabled_sys,
    output wire media_busy_sys, output wire result_valid_sys,
    output wire [3:0] result_code_sys,
    output wire [3:0] ui_state, output wire [15:0] browser_index,
    output wire [1:0] home_focus, output wire [1:0] launch_mode,
    output wire [3:0] brightness_level, output wire [3:0] zoom_level,
    output wire [1:0] rotation_mode,
    output wire [2:0] settings_page, output wire [2:0] settings_focus,
    output wire [3:0] bgm_map_picture,output wire [1:0] bgm_map_track,current_bgm_track,
    output wire [3:0] volume_level, output wire mute_enabled,
    output wire [3:0] contrast_level, output wire [3:0] auto_interval_code,
    output wire [1:0] transition_mode, output wire osd_enabled,
    output wire audio_visualizer_enabled,output wire subtitle_enabled,
    output wire slideshow_auto,output wire audio_enabled,
    output wire playback_rate_valid, output wire [1:0] playback_rate_code,
    output wire settings_numeric_edit, output wire player_playing, output wire ir_hold_active, output wire ui_fault,
    output wire ir_debug_event_valid, output wire [7:0] ir_debug_command,
    output wire ir_debug_fault, output wire ir_debug_edge_valid,
    output wire [3:0] edit_value, output wire [1:0] settings_feedback,
    output wire confirm_active, confirm_yes, software_reset_req,
    output reg ui_click_toggle
);
    wire ir_rx_sync_level, raw_ir_event_valid, raw_ir_event_repeat;
    wire ir_digit_valid, ir_event_fault;
    wire [3:0] raw_ir_event_code, ir_digit_code;
    wire ir_event_valid, ir_hold_start, ir_hold_release;
    wire [3:0] ir_event_code, ir_hold_code;
    wire ui_event_valid, ui_event_repeat, ui_event_source, ui_digit_valid;
    wire [3:0] ui_event_code, ui_digit_code;
    wire media_open_req, media_next_req, media_prev_req, media_play_toggle;
    wire settings_enter, transform_enter, pip_select_req, pip_move_mode;
    wire brightness_inc, brightness_dec, zoom_inc, zoom_dec, rotate_cw, rotate_ccw;
    wire file_select_digit_valid, settings_digit_valid;
    wire [3:0] file_select_digit, settings_digit;
    wire sys_cmd_busy, auto_enabled_sd;
    wire [4:0] actual_asset_count_sys;
    (* async_reg="true" *) reg [1:0] card_offline_sync;
    always @(posedge clk_sys or posedge rst_sys)
        if(rst_sys)card_offline_sync<=0;else card_offline_sync<={card_offline_sync[0],card_offline_sd};
    assign asset_count_sys=DEMO_IMAGES?5'd3:actual_asset_count_sys;
    // This trial has no wallpaper/home page; resource zero stays reserved but
    // is never requested before the first slideshow image.
    wire home_active_sys = 1'b0;

    // One UI action, one click. NEC repeats do not become repeated clicks;
    // a directional hold contributes its single normalized hold_start event.
    always @(posedge clk_sys or posedge rst_sys)
        if(rst_sys)ui_click_toggle<=1'b0;
        else if((ui_event_valid && !ui_event_repeat) || ui_digit_valid || ir_hold_start)
            ui_click_toggle<=~ui_click_toggle;

    ir_input_subsystem u_ir_input (
        .clk(clk_sys), .rst(rst_sys), .ir_rx_async(ir_rx_async),
        .ir_rx_sync_level(ir_rx_sync_level), .ir_event_valid(raw_ir_event_valid),
        .ir_event_code(raw_ir_event_code), .ir_event_repeat(raw_ir_event_repeat),
        .ir_digit_valid(ir_digit_valid), .ir_digit_code(ir_digit_code),
        .ir_fault(ir_event_fault), .debug_event_valid(ir_debug_event_valid),
        .debug_command(ir_debug_command), .debug_fault(ir_debug_fault),
        .debug_edge_valid(ir_debug_edge_valid)
    );

    ir_gesture #(.CLOCK_HZ(CLK_SYS_HZ)) u_ir_gesture (
        .clk(clk_sys), .rst(rst_sys),
        .raw_event_valid(raw_ir_event_valid),
        .raw_event_code(raw_ir_event_code),
        .raw_event_repeat(raw_ir_event_repeat),
        .tap_valid(ir_event_valid), .tap_code(ir_event_code),
        .hold_start(ir_hold_start), .hold_active(ir_hold_active),
        .hold_release(ir_hold_release), .hold_code(ir_hold_code)
    );

    control_input #(.CLK_HZ(CLK_SYS_HZ)) u_control_input (
        .clk(clk_sys), .rst(rst_sys), .key_next_n(key_next_n),
        .key_auto_n(key_auto_n), .key_aux_n(key_aux_n),
        .ir_event_valid(ir_event_valid), .ir_event_code(ir_event_code),
        .ir_event_repeat(1'b0), .ir_digit_valid(ir_digit_valid),
        .ir_digit_code(ir_digit_code), .ui_event_valid(ui_event_valid),
        .ui_event_code(ui_event_code), .ui_event_repeat(ui_event_repeat),
        .ui_event_source(ui_event_source), .ui_digit_valid(ui_digit_valid),
        .ui_digit_code(ui_digit_code)
    );

    ui_shell #(.DEMO_IMAGES(DEMO_IMAGES),.CLK_HZ(CLK_SYS_HZ)) u_ui_shell (
    .media_offline(card_offline_sync[1]),
        .clk(clk_sys), .rst(rst_sys), .event_valid(ui_event_valid),
        .event_code(ui_event_code), .event_repeat(ui_event_repeat),
        .event_source(ui_event_source), .digit_valid(ui_digit_valid),
        .digit_code(ui_digit_code), .hold_start(ir_hold_start),
        .hold_release(ir_hold_release), .hold_code(ir_hold_code),
        .asset_count(asset_count_sys), .current_picture(current_id_sys), .media_busy(media_busy_sys),
        .edit_value(edit_value), .settings_feedback(settings_feedback),
        .confirm_active(confirm_active), .confirm_yes(confirm_yes), .software_reset_req(software_reset_req),
        .ui_state(ui_state), .home_focus(home_focus), .launch_mode(launch_mode),
        .media_open_req(media_open_req), .media_next_req(media_next_req),
        .media_prev_req(media_prev_req), .media_play_toggle(media_play_toggle),
        .settings_enter(settings_enter), .transform_enter(transform_enter),
        .pip_select_req(pip_select_req), .pip_move_mode(pip_move_mode),
        .brightness_inc(brightness_inc), .brightness_dec(brightness_dec),
        .zoom_inc(zoom_inc), .zoom_dec(zoom_dec), .rotate_cw(rotate_cw),
        .rotate_ccw(rotate_ccw), .file_select_digit_valid(file_select_digit_valid),
        .file_select_digit(file_select_digit), .settings_digit_valid(settings_digit_valid),
        .settings_digit(settings_digit), .browser_index(browser_index),
        .brightness_level(brightness_level), .zoom_level(zoom_level),
        .rotation_mode(rotation_mode), .playback_rate_valid(playback_rate_valid),
        .playback_rate_code(playback_rate_code), .settings_page(settings_page),
        .settings_focus(settings_focus), .volume_level(volume_level),
        .bgm_map_picture(bgm_map_picture),.bgm_map_track(bgm_map_track),.current_bgm_track(current_bgm_track),
        .mute_enabled(mute_enabled), .contrast_level(contrast_level),
        .auto_interval_code(auto_interval_code), .transition_mode(transition_mode),
        .osd_enabled(osd_enabled), .audio_visualizer_enabled(audio_visualizer_enabled),
        .subtitle_enabled(subtitle_enabled),
        .slideshow_auto(slideshow_auto),.audio_enabled(audio_enabled),
        .settings_numeric_edit(settings_numeric_edit), .player_playing(player_playing), .ui_fault(ui_fault)
    );

    media_control_adapter #(.CLK_SD_HZ(CLK_SD_HZ), .AUTO_SECONDS(AUTO_SECONDS)) u_media_adapter (
        .clk_sys(clk_sys), .rst_sys(rst_sys), .clk_sd(clk_sd), .rst_sd(rst_sd),
        .media_open_req(media_open_req), .media_next_req(media_next_req),
        .media_prev_req(media_prev_req), .media_play_toggle(media_play_toggle),
        .browser_index(browser_index), .home_active_sys(home_active_sys),
        .autoplay_run_sys(ui_state==4'd2 && launch_mode==1 && slideshow_auto && player_playing),
        .auto_interval_sys(auto_interval_code),
        .sys_cmd_busy(sys_cmd_busy),
        .catalog_done_sd(catalog_done_sd), .catalog_ok_sd(catalog_ok_sd),
        .asset_count_sd(asset_count_sd), .storage_ready_sd(storage_ready_sd),
        .catalog_ready_sys(catalog_ready_sys), .asset_count_sys(actual_asset_count_sys),
        .current_id_sys(current_id_sys), .auto_enabled_sys(auto_enabled_sys),
        .media_busy_sys(media_busy_sys), .result_valid_sys(result_valid_sys),
        .result_code_sys(result_code_sys),
        .media_request_valid_sd(media_request_valid_sd),
        .media_request_ready_sd(media_request_ready_sd),
        .media_request_id_sd(media_request_id_sd),
        .media_result_valid_sd(media_result_valid_sd),
        .media_result_code_sd(media_result_code_sd),
        .media_request_cancel_sd(media_request_cancel_sd),
        .media_request_started_sd(media_request_started_sd),
        .auto_enabled_sd(auto_enabled_sd)
    );
endmodule
`default_nettype wire
