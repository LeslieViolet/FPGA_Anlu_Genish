`timescale 1ns/1ps
module tb_subtitle_motion;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,enabled=1,user_in=0,valid_in=0;
 reg [10:0] x=0,y=0;
 wire font_valid;wire [8:0] font_address;wire [3:0] font_col;wire [1:0] font_palette;
 promo_marquee_renderer dut(.*);
 integer phrase=0,stage=0,left_edge=960,count=0,width=224,word_left,glyph_base;
 integer step,xx,yy,rel,expected_address,expected_color,transitions=0,holds=0,seen=0;
 bit expected_valid,advance;
 task sample;
  begin
   #1;word_left=left_edge+(phrase==0?64:phrase==2?32:0);rel=x-word_left;
   expected_valid=enabled&&valid_in&&x>=320&&x<960&&y>=24&&y<56&&rel>=0&&rel<width;
   if(font_valid!==expected_valid)$fatal(1,"mask step=%0d x=%0d y=%0d left=%0d",step,x,y,left_edge);
   if(expected_valid)begin
    glyph_base=phrase==0?0:phrase==1?7:18;
    expected_address=glyph_base*16+(rel/32)*16+(y-24)/2;
    if(font_address!==9'(expected_address)||font_col!==4'((rel%32)/2))$fatal(1,"descriptor mismatch");
    expected_color=0;
    if(phrase==1)begin if(rel/32<6)expected_color=1;else if(rel/32>=7)expected_color=2;end
    if(font_palette!==2'(expected_color))$fatal(1,"palette mismatch");
    seen=seen+1;
   end
  end
 endtask
 initial begin
  repeat(3)@(negedge clk);rst=0;
  for(step=0;step<1450;step=step+1)begin
   enabled=step%61!=17;valid_in=step%47!=11;user_in=step%43!=13;x=0;y=0;
   advance=enabled&&valid_in&&user_in;
   if(advance)begin
    case(stage)
     0:begin left_edge=left_edge-4;if(left_edge==464)begin stage=1;count=0;end end
     1:begin holds=holds+1;if(count==119)begin stage=2;left_edge=left_edge-4;end else count=count+1;end
     2:begin
      if(left_edge+352==320)begin
       phrase=(phrase+1)%3;width=phrase==0?224:phrase==1?352:288;
       stage=0;left_edge=960;transitions=transitions+1;
      end else left_edge=left_edge-4;
     end
    endcase
   end
   @(posedge clk);#1;
   if(dut.phrase_id!==2'(phrase)||dut.phase!==2'(stage)||dut.scroll_offset!==11'((-left_edge)&2047))$fatal(1,"state mismatch step %0d",step);
   @(negedge clk);user_in=0;valid_in=1;
   for(yy=23;yy<=56;yy=yy+8)begin
    y=yy;for(xx=0;xx<1280;xx=xx+31)begin x=xx;sample();end
   end
   y=55;x=959;sample();x=960;sample();
   y=622;x=640;sample();y=24;x=1008;sample();
   @(negedge clk);
  end
  if(transitions<3||holds<360||seen<10000)$fatal(1,"coverage incomplete");
  $display("SUBTITLE_MOTION_PASS frames=1450 phrases=%0d hold_samples=%0d glyph_checks=%0d",transitions,holds,seen);$finish;
 end
 initial begin #10000000;$fatal(1,"motion timeout");end
endmodule
