set_clock_uncertainty -setup 0.500 [get_clocks *]
