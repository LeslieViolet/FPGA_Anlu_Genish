`default_nettype none
`timescale 1ns/1ps
module axis_media_stream_delay4 (
    input wire clk,input wire rst,
    input wire user_in,input wire last_in,input wire valid_in,input wire [23:0] rgb_in,
    output reg user_out,output reg last_out,output reg valid_out,output reg [23:0] rgb_out
);
    reg [23:0] rgb_s1,rgb_s2,rgb_s3;
    reg user_s1,user_s2,user_s3;
    reg last_s1,last_s2,last_s3;
    reg valid_s1,valid_s2,valid_s3;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            rgb_s1<=0;rgb_s2<=0;rgb_s3<=0;
            user_s1<=0;user_s2<=0;user_s3<=0;
            last_s1<=0;last_s2<=0;last_s3<=0;
            valid_s1<=0;valid_s2<=0;valid_s3<=0;
            user_out<=0;last_out<=0;valid_out<=0;rgb_out<=0;
        end else begin
            rgb_s1<=rgb_in;rgb_s2<=rgb_s1;rgb_s3<=rgb_s2;
            user_s1<=user_in;user_s2<=user_s1;user_s3<=user_s2;
            last_s1<=last_in;last_s2<=last_s1;last_s3<=last_s2;
            valid_s1<=valid_in;valid_s2<=valid_s1;valid_s3<=valid_s2;
            user_out<=user_s3;last_out<=last_s3;valid_out<=valid_s3;rgb_out<=rgb_s3;
        end
    end
endmodule
`default_nettype wire
