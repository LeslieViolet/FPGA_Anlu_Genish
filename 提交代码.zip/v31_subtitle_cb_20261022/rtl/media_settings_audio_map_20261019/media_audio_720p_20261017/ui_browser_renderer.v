`default_nettype none
// Opaque 640x480 TF catalog page.  It is intentionally independent from the
// framebuffer so a slow card or an incomplete frame can never stall HDMI.
module ui_browser_renderer #(parameter EXTERNAL_FONT = 10'd0, parameter FAST_DIGITS=0, parameter integer DEMO_IMAGES=0) (
    input  wire [9:0]  x,
    input  wire [9:0]  y,
    input  wire        video_active,
    input  wire        browser_enable,
    input  wire [3:0]  selected_index,
    input  wire [4:0]  asset_count,
    input  wire [3:0]  current_id,
    input  wire        tf_ready,
    input  wire        media_busy,
    input  wire [23:0] pixel_in,
    output reg  [23:0] pixel_out,
    input wire [15:0] font_bits_in,
    output wire [6:0] font_glyph_out,
    output wire [3:0] font_row_out,
    output wire [3:0] font_col_out,
    output wire font_valid_out,
    output wire [23:0] font_color_out
);
// Constant coordinate comparisons as a Boolean prefix tree.
    // For constant boundary bits this maps to LUT logic, not long carry chains.
    function automatic coord_ge;
        input [9:0] coordinate;
        input [9:0] boundary;
        integer k;
        reg ge;
        begin
            ge=1'b1;
            for(k=0;k<10;k=k+1)
                if(boundary[k]) ge=coordinate[k]&ge;
                else ge=coordinate[k]|ge;
            coord_ge=ge;
        end
    endfunction

    function automatic draw_ge;
        input [9:0] coordinate,boundary;
        begin draw_ge=FAST_DIGITS?coord_ge(coordinate,boundary):(coordinate>=boundary);end
    endfunction
    reg glyph_valid;
    reg [6:0] glyph_id;
    reg [3:0] glyph_row, glyph_col;
    wire [15:0] glyph_bits;
    wire glyph_on = glyph_valid && glyph_bits[10'd15-glyph_col];
    reg [2:0] gi; integer grow; reg [9:0] gy;
    integer prow; reg [9:0] py;
    wire [3:0] page_base=selected_index<6 ? 4'd0 : selected_index<12 ? 4'd6 : 4'd12;

    // Keep catalog arithmetic at the actual index width. The visible page has
    // six rows and the 16-item UI index never needs a 32-bit integer adder.
    function [4:0] absolute_item_index;
        input [3:0] base_index;
        input [2:0] visible_row;
        begin absolute_item_index={1'b0,base_index}+{2'b00,visible_row}; end
    endfunction

    assign font_glyph_out = glyph_id;
    assign font_row_out = glyph_row;
    assign font_col_out=glyph_col;
    assign font_valid_out=glyph_valid && video_active && browser_enable;
    assign font_color_out=24'hffffff;
    generate if (EXTERNAL_FONT == 10'd2) begin : font_descriptor
        assign glyph_bits=16'd0;
    end else if (EXTERNAL_FONT) begin : shared_font
        assign glyph_bits = font_bits_in;
    end else begin : local_font
        ui_font16_rom u_font(.glyph_id(glyph_id), .row(glyph_row), .bits(glyph_bits));
    end endgenerate

// Every text span is bounded to at most seven 18-pixel cells.
    function [2:0] cell18;
        input [9:0] delta;
        begin cell18 = (~coord_ge(delta,10'd18))  ?  3'd0  :  (~coord_ge(delta,10'd36))  ?  3'd1  : 
            (~coord_ge(delta,10'd54))  ?  3'd2  :  (~coord_ge(delta,10'd72))  ?  3'd3  : 
            (~coord_ge(delta,10'd90))  ?  3'd4  :  (~coord_ge(delta,10'd108))  ?  3'd5  :  3'd6; end
    endfunction
    localparam [511:0] COL18_TABLE=512'h1010fedcba987654321010fedcba987654321010fedcba987654321010fedcba987654321010fedcba987654321010fedcba987654321010fedcba9876543210;
    function [3:0] col18;
        input [9:0] delta;
        reg [9:0] remainder;
        begin
            if(FAST_DIGITS)begin
                if(!coord_ge(delta,10'd126)) col18=COL18_TABLE[{delta[6:0],2'b00} +:4];
                else col18=delta[3:0]-4'd12;
            end else begin remainder = delta - cell18(delta)*10'd18; col18=remainder[3:0];end
        end
    endfunction
// The 3x5 digit is only evaluated within an 18x25 pixel rectangle.
    function [1:0] digit_x;
        input [9:0] delta;
        begin digit_x = (~coord_ge(delta,10'd6))  ?  2'd0  :  (~coord_ge(delta,10'd12))  ?  2'd1  :  2'd2; end
    endfunction
    function [2:0] digit_y;
        input [9:0] delta;
        begin digit_y = (~coord_ge(delta,10'd5))  ?  3'd0  :  (~coord_ge(delta,10'd10))  ?  3'd1  : 
            (~coord_ge(delta,10'd15))  ?  3'd2  :  (~coord_ge(delta,10'd20))  ?  3'd3  :  3'd4; end
    endfunction

    // A compact 3x5 digit used for file numbers and the catalog count.
    function digit_dot;
        input [3:0] d;
        input [1:0] cx;
        input [2:0] cy;
        reg [14:0] p; reg [2:0] row_bits;
        begin
            case(d)
                10'd0:p=15'b111101101101111; 10'd1:p=15'b010110010010111;
                10'd2:p=15'b111001111100111; 10'd3:p=15'b111001111001111;
                10'd4:p=15'b101101111001001; 10'd5:p=15'b111100111001111;
                10'd6:p=15'b111100111101111; 10'd7:p=15'b111001001001001;
                10'd8:p=15'b111101111101111; default:p=15'b111101111001111;
            endcase
            if(FAST_DIGITS) begin
                case(cy)
                    0:row_bits=p[14:12];1:row_bits=p[11:9];2:row_bits=p[8:6];
                    3:row_bits=p[5:3];default:row_bits=p[2:0];
                endcase
                digit_dot=cx==0?row_bits[2]:cx==1?row_bits[1]:row_bits[0];
            end else digit_dot = p[10'd14-(cy*10'd3+cx)];
        end
    endfunction

    function number_dot;
        input [4:0] number;
        input [9:0] dx,dy;
        reg [3:0] ones; reg [1:0] cx;
        begin
            ones=number>=10 ? number-10 : number;
            // number_dot is consumed only inside bounded 18x25 rectangles.
            // Low five coordinate bits suffice; avoid ten-bit subtract/compare chains.
            if(FAST_DIGITS) begin
                if(number>=10)begin
                    cx=!coord_ge({5'd0,dx[4:0]},10'd9)?
                       (!coord_ge({5'd0,dx[4:0]},10'd3)?0:!coord_ge({5'd0,dx[4:0]},10'd6)?1:2):
                       (!coord_ge({5'd0,dx[4:0]},10'd12)?0:!coord_ge({5'd0,dx[4:0]},10'd15)?1:2);
                    number_dot=digit_dot(!coord_ge({5'd0,dx[4:0]},10'd9)?4'd1:ones,cx,digit_y({5'd0,dy[4:0]}));
                end else number_dot=digit_dot(ones,digit_x({5'd0,dx[4:0]}),digit_y({5'd0,dy[4:0]}));
            end else begin
            if(number>=10) begin
                cx=dx<9 ? (dx<3 ? 0 : dx<6 ? 1 : 2) :
                          (dx<12 ? 0 : dx<15 ? 1 : 2);
                number_dot=digit_dot(dx<9 ? 4'd1 : ones,cx,digit_y(dy));
            end
            else number_dot=digit_dot(ones,digit_x(dx),digit_y(dy));
            end
        end
    endfunction
    always @* begin
        gi=0;gy=0; glyph_valid=1'b0; glyph_id=6'd0; glyph_row=4'd0; glyph_col=4'd0;
        // Title: 浏览TF卡文件 (glyphs 5..11)
        if (coord_ge(y,10'd20) && (~coord_ge(y,10'd36)) && coord_ge(x,10'd24) && (~coord_ge(x,10'd150))) begin
            gi=cell18(x-10'd24);
            if (gi<(DEMO_IMAGES?4:7)) begin glyph_valid=1'b1; glyph_id=DEMO_IMAGES?((gi<2)?75+gi:10+gi):10'd5+gi; glyph_row=y-10'd20; glyph_col=col18(x-10'd24); end
        end
        // Each available row says 图片.
        for (grow=10'd0; grow<10'd6; grow=grow+10'd1) begin
            gy=10'd88+grow*10'd50;
            if (absolute_item_index(page_base,grow[2:0])<asset_count && draw_ge(y,gy+10'd14) && !draw_ge(y,gy+10'd30) && coord_ge(x,10'd82) && (~coord_ge(x,10'd118))) begin
                gi=cell18(x-10'd82);
                if (gi<10'd2) begin glyph_valid=1'b1; glyph_id=10'd12+gi; glyph_row=y-(gy+10'd14); glyph_col=col18(x-10'd82); end
            end
        end
        // Detail label 图片.
        if (coord_ge(y,10'd306) && (~coord_ge(y,10'd322)) && coord_ge(x,10'd424) && (~coord_ge(x,10'd460))) begin
            gi=cell18(x-10'd424);
            if (gi<10'd2) begin glyph_valid=1'b1; glyph_id=10'd12+gi; glyph_row=y-10'd306; glyph_col=col18(x-10'd424); end
        end
        // Footer: 选择  OK确认  *返回  0主页
        if (coord_ge(y,10'd446) && (~coord_ge(y,10'd462)) && coord_ge(x,10'd76) && (~coord_ge(x,10'd112))) begin
            gi=cell18(x-10'd76); if(gi<10'd2) begin glyph_valid=10'd1;glyph_id=10'd31+gi;glyph_row=y-10'd446;glyph_col=col18(x-10'd76);end
        end else if (coord_ge(y,10'd446) && (~coord_ge(y,10'd462)) && coord_ge(x,10'd198) && (~coord_ge(x,10'd270))) begin
            gi=cell18(x-10'd198); if(gi<10'd4) begin glyph_valid=10'd1;glyph_id=10'd33+gi;glyph_row=y-10'd446;glyph_col=col18(x-10'd198);end
        end else if (coord_ge(y,10'd446) && (~coord_ge(y,10'd462)) && coord_ge(x,10'd354) && (~coord_ge(x,10'd408))) begin
            gi=cell18(x-10'd354); if(gi<10'd3) begin glyph_valid=10'd1;glyph_id=10'd37+gi;glyph_row=y-10'd446;glyph_col=col18(x-10'd354);end
        end else if (coord_ge(y,10'd446) && (~coord_ge(y,10'd462)) && coord_ge(x,10'd486) && (~coord_ge(x,10'd540))) begin
            gi=cell18(x-10'd486); if(gi<10'd3) begin glyph_valid=10'd1;glyph_id=(gi==0)?7'd81:(10'd40+gi);glyph_row=y-10'd446;glyph_col=col18(x-10'd486);end
        end
    end

    always @* begin
        py=0;
        if (!video_active) pixel_out=24'h000000;
        else if (!browser_enable) pixel_out=pixel_in;
        else begin
            // Dark blue opaque canvas.
            pixel_out = ((~coord_ge(y,10'd56)))  ?  24'h111936  :  (coord_ge(y,10'd424)  ?  24'h10172f  :  24'h0b1125);
            // Header underline and TF status.
            if (coord_ge(y,10'd54) && (~coord_ge(y,10'd56))) pixel_out=24'h16cbea;
            if (coord_ge(x,10'd582) && (~coord_ge(x,10'd594)) && coord_ge(y,10'd22) && (~coord_ge(y,10'd34)))
                pixel_out=tf_ready  ?  24'h28e0b8  :  24'hef476f;
            // Left list panel and six bounded rows.
            if (coord_ge(x,10'd24) && (~coord_ge(x,10'd304)) && coord_ge(y,10'd76) && (~coord_ge(y,10'd398))) pixel_out=24'h151f3f;
            for (prow=10'd0; prow<10'd6; prow=prow+10'd1) begin
                py=10'd88+prow*10'd50;
                if (coord_ge(x,10'd36) && (~coord_ge(x,10'd292)) && draw_ge(y,py) && !draw_ge(y,py+10'd42)) begin
                    if (absolute_item_index(page_base,prow[2:0])>=asset_count) pixel_out=24'h11182d;
                    else if (absolute_item_index(page_base,prow[2:0])=={1'b0,selected_index}) pixel_out=24'h126aa0;
                    else pixel_out=24'h25305b;
                    if (absolute_item_index(page_base,prow[2:0])<asset_count && absolute_item_index(page_base,prow[2:0])=={1'b0,current_id} && coord_ge(x,10'd42) && (~coord_ge(x,10'd48)))
                        pixel_out=24'h28e0b8;
                    if (absolute_item_index(page_base,prow[2:0])<asset_count && coord_ge(x,10'd58) && (~coord_ge(x,10'd76)) && draw_ge(y,py+10'd9) && !draw_ge(y,py+10'd34) &&
                        number_dot(absolute_item_index(page_base,prow[2:0])+5'd1,x-10'd58,y-(py+10'd9)))
                        pixel_out=24'hffffff;
                end
            end
            // Cyan selection border.
            py=10'd88+(selected_index-page_base)*10'd50;
            if(FAST_DIGITS)begin
                for(prow=0;prow<6;prow=prow+1)begin
                    if(selected_index<asset_count && {1'b0,selected_index}==absolute_item_index(page_base,prow[2:0]) &&
                       coord_ge(x,10'd34) && !coord_ge(x,10'd294) &&
                       coord_ge(y,10'd86+prow*10'd50) && !coord_ge(y,10'd132+prow*10'd50) &&
                       (!coord_ge(x,10'd38)||coord_ge(x,10'd290)||
                        !coord_ge(y,10'd90+prow*10'd50)||coord_ge(y,10'd128+prow*10'd50)))pixel_out=24'h35e5ff;
                end
            end else begin
            if (selected_index<asset_count && coord_ge(x,10'd34) && (~coord_ge(x,10'd294)) && y>=py-10'd2 && y<py+10'd44 &&
                ((~coord_ge(x,10'd38)) || coord_ge(x,10'd290) || y<py+10'd2 || y>=py+10'd40)) pixel_out=24'h35e5ff;
            end
            // Right detail panel and generic image icon.
            if (coord_ge(x,10'd320) && (~coord_ge(x,10'd616)) && coord_ge(y,10'd76) && (~coord_ge(y,10'd398))) pixel_out=24'h151f3f;
            if (coord_ge(x,10'd382) && (~coord_ge(x,10'd554)) && coord_ge(y,10'd126) && (~coord_ge(y,10'd274))) begin
                pixel_out=24'h26325f;
                if ((~coord_ge(x,10'd388)) || coord_ge(x,10'd548) || (~coord_ge(y,10'd132)) || coord_ge(y,10'd268)) pixel_out=24'h93a7ff;
                if ((coord_ge(y,10'd215) && (~coord_ge(y,10'd260))) && (coord_ge(x,10'd397) && (~coord_ge(x,10'd540))) &&
                    ((x-10'd396)<(y-10'd214)*10'd2 || (10'd540-x)<(y-10'd214)*10'd2)) pixel_out=24'h6374cf;
                if (coord_ge(x,10'd510) && (~coord_ge(x,10'd530)) && coord_ge(y,10'd148) && (~coord_ge(y,10'd168))) pixel_out=24'hffd166;
            end
            // Selected number and total count.
            if (selected_index<asset_count && coord_ge(x,10'd472) && (~coord_ge(x,10'd490)) && coord_ge(y,10'd302) && (~coord_ge(y,10'd327)) &&
                number_dot({1'b0,selected_index}+5'd1,x-10'd472,y-10'd302)) pixel_out=24'hffffff;
            if (coord_ge(x,10'd574) && (~coord_ge(x,10'd592)) && coord_ge(y,10'd372) && (~coord_ge(y,10'd397)) &&
                number_dot(asset_count,x-10'd574,y-10'd372)) pixel_out=24'h8fa8ff;
            if (media_busy && coord_ge(x,10'd340) && (~coord_ge(x,10'd352)) && coord_ge(y,10'd372) && (~coord_ge(y,10'd384))) pixel_out=24'hffd166;
            // Up/down triangles in the footer.
            if (coord_ge(x,10'd42) && (~coord_ge(x,10'd58)) && coord_ge(y,10'd440) && (~coord_ge(y,10'd468)) &&
                (((~coord_ge(y,10'd454)) && (x-10'd42)>=10'd7-((y-10'd440)/10'd2) && (x-10'd42)<=10'd8+((y-10'd440)/10'd2)) ||
                 (coord_ge(y,10'd454) && (x-10'd42)>=((y-10'd454)/10'd2) && (x-10'd42)<=10'd15-((y-10'd454)/10'd2))))
                pixel_out=24'hffffff;
            if (glyph_on) pixel_out=24'hffffff;
        end
    end
endmodule
`default_nettype wire


