`default_nettype none
// Pixel-clock combinational overlay for the existing 640x480 UI canvas.
// Levels must be the post-volume/post-mute levels from audio_pcm_output.
module audio_level_overlay(
 input wire enabled,video_active,
 input wire [9:0] x,y,input wire [3:0] level_left,level_right,
 input wire [23:0] pixel_in,output reg [23:0] pixel_out
);
 // Eight 16-pixel segments reuse coordinate bits, avoiding pixel multipliers.
 wire bar_y=y>=10'd380&&y<10'd392;
 wire l_bg=x[9:7]==3'd1&&bar_y;
 wire r_bg=x[9:7]==3'd3&&bar_y;
 wire l_fill=l_bg&&{1'b0,x[6:4]}<level_left;
 wire r_fill=r_bg&&{1'b0,x[6:4]}<level_right;
 always @*begin
  pixel_out=pixel_in;
  if(enabled&&video_active)begin
   if(l_bg||r_bg)pixel_out=24'h172343;
   if(l_fill)pixel_out=24'h35e5ff;
   if(r_fill)pixel_out=24'h9d8cff;
  end
 end
endmodule
`default_nettype wire
