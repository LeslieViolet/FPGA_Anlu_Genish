`default_nettype none
// Full-raster 1280x720 -> existing logical 640x480 layout, with no frame RAM.
// For y in 0..719, floor(y*683/1024) equals floor(2*y/3) exactly.
module ui_canvas_map(
 input wire [10:0] x,y,
 output wire [9:0] logical_x,logical_y,
 output wire active
);
 wire [20:0] y_product=( {10'd0,y} << 9 ) + ( {10'd0,y} << 7 ) +
     ( {10'd0,y} << 5 ) + ( {10'd0,y} << 3 ) + ( {10'd0,y} << 1 ) + {10'd0,y};
 assign logical_x=x[10:1];
 assign logical_y=y_product[19:10];
 assign active=x<1280 && y<720;
endmodule
`default_nettype wire
