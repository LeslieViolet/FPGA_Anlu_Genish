`default_nettype none

module hdmi_resolution_tx#(
    parameter DEVICE            = "EG", //"EF2","EF3","EF4","SF1","SF2","EG","PH1A","PH1P","DR1","PH2A"

    parameter HTOTAL            = 2200,
    parameter HSA               = 44,
    parameter HFP               = 88,
    parameter HBP               = 148,
    parameter HACTIVE           = 1920,
    parameter VTOTAL            = 1125,
    parameter VSA               = 5,
    parameter VFP               = 4,
    parameter VBP               = 36,
    parameter VACTIVE           = 1080,

    parameter VIDEO_TPG         = "Enable",
    parameter VIDEO_FORMAT      = "RGB",
    parameter VIDEO_VIC         = 16,

    parameter AUDIO_SAMPLE_RATE = "48K",

    parameter IIC_SCL_DIV       = 125
)(
    input wire       I_pixel_clk,
    input wire       I_rst,

    /*
        edid read interface 
    */
    input wire       I_edid_read_trig,
    output wire      O_edid_read_valid,
    output wire[7:0] O_edid_read_data,

    /*
        video interface 
    */
    input wire       I_axis_s_user,
    input wire       I_axis_s_valid,
    input wire       I_axis_s_last,
    input wire[23:0] I_axis_s_data,
    output wire      O_axis_s_ready,

    /*
        audio interface 
    */
    input wire       I_audio_valid,     
    input wire[23:0] I_audio_left_data, 
    input wire[23:0] I_audio_right_data,

    /*
        audio regenaration interface
    */
    input wire       I_acr_valid,
    input wire[19:0] I_acr_cts,
    input wire[19:0] I_acr_n,

    /*
        status signal
    */
    output wire      O_video_locked,

    /*
        DDC channel interface
    */
    output wire      O_ddc_scl,
    inout wire       IO_ddc_sda,

    /*
        tmds data interface 
    */
    output wire[9:0] O_ch0_tmds_data,
    output wire[9:0] O_ch1_tmds_data,
    output wire[9:0] O_ch2_tmds_data,
    output wire[9:0] O_clk_tmds_data
);


localparam CORE_COUNT=1;
wire [0:0] ready_bus,locked_bus,scl_bus,edid_valid_bus;
wire [7:0] edid_data_bus[0:0];
wire [9:0] ch0_bus[0:0],ch1_bus[0:0],ch2_bus[0:0],clk_bus[0:0];
genvar i;
generate for(i=0;i<CORE_COUNT;i=i+1)begin:timing_core
    hdmi_1_4b_transmitter_core_wrapper #(
        .DEVICE(DEVICE),
        .HTOTAL(HTOTAL),
        .HSA(HSA),.HFP(HFP),
        .HBP(HBP),.HACTIVE(HACTIVE),
        .VTOTAL(VTOTAL),
        .VSA(VSA),.VFP(VFP),
        .VBP(VBP),.VACTIVE(VACTIVE),
        .VIDEO_TPG(VIDEO_TPG),.VIDEO_FORMAT(VIDEO_FORMAT),.VIDEO_VIC(VIDEO_VIC),
        .AUDIO_SAMPLE_RATE(AUDIO_SAMPLE_RATE),.IIC_SCL_DIV(IIC_SCL_DIV)
    ) u_core (
        .I_pixel_clk(I_pixel_clk),.I_rst(I_rst),
        .I_edid_read_trig(I_edid_read_trig && i==0),
        .O_edid_read_valid(edid_valid_bus[i]),.O_edid_read_data(edid_data_bus[i]),
        .I_axis_s_user(I_axis_s_user),.I_axis_s_valid(I_axis_s_valid),
        .I_axis_s_last(I_axis_s_last),.I_axis_s_data(I_axis_s_data),.O_axis_s_ready(ready_bus[i]),
        .I_audio_valid(I_audio_valid),.I_audio_left_data(I_audio_left_data),.I_audio_right_data(I_audio_right_data),
        .I_acr_valid(I_acr_valid),.I_acr_cts(I_acr_cts),.I_acr_n(I_acr_n),
        .O_video_locked(locked_bus[i]),.O_ddc_scl(scl_bus[i]),.IO_ddc_sda(IO_ddc_sda),
        .O_ch0_tmds_data(ch0_bus[i]),.O_ch1_tmds_data(ch1_bus[i]),
        .O_ch2_tmds_data(ch2_bus[i]),.O_clk_tmds_data(clk_bus[i]));
end endgenerate
assign O_axis_s_ready=ready_bus[0];assign O_video_locked=locked_bus[0];
assign O_ddc_scl=scl_bus[0];assign O_edid_read_valid=edid_valid_bus[0];
assign O_edid_read_data=edid_data_bus[0];
generate begin:static_tmds
    assign O_ch0_tmds_data=ch0_bus[0];assign O_ch1_tmds_data=ch1_bus[0];
    assign O_ch2_tmds_data=ch2_bus[0];assign O_clk_tmds_data=clk_bus[0];
end endgenerate
endmodule
`default_nettype wire
