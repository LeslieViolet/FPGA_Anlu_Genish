`default_nettype none
// Read-only FAT32 locator for MEDIA/BGM.WAV or MEDIA/BGM1..3.WAV.
// One CRC-checked 512-byte sector transaction may be active at a time.
module fat32_bgm_locator #(
 parameter integer TIMEOUT_CYCLES=250000000,
 parameter integer MAX_CHAIN_CLUSTERS=65535
)(
 input wire clk,input wire rst,input wire abort,
 input wire start_valid,input wire [1:0] track_select,output wire start_ready,
 output wire read_valid,input wire read_ready,output reg [31:0] read_lba,
 input wire [7:0] data,input wire data_valid,output wire data_ready,input wire data_last,
 input wire read_done,input wire read_error,
 output reg result_valid,input wire result_ready,output reg [3:0] result_code,
 output reg [31:0] file_first_cluster,output reg [31:0] file_size,
 output reg [31:0] partition_lba,output reg [31:0] fat_start_lba,
 output reg [31:0] data_start_lba,output reg [7:0] sectors_per_cluster,
 output reg [31:0] max_cluster,output reg [32:0] volume_end_lba,
 output wire busy
);
 localparam [3:0] IDLE=0,ISSUE=1,RECEIVE=2,WAIT_DONE=3,RESULT=4,ADDRESS=5,
    MOUNT_SHIFT=6,MOUNT_CHECK=7,ADDRESS_SHIFT=8,ADDRESS_FINAL=9,
    MOUNT_SPAN=10,MOUNT_VALIDATE=11,MOUNT_CALC=12,
    MOUNT_ACTIVE=13,MOUNT_DATA=14,MOUNT_END=15;
 localparam integer CHAIN_BITS=$clog2(MAX_CHAIN_CLUSTERS+1);
 localparam integer TIMEOUT_BITS=TIMEOUT_CYCLES<=1?1:$clog2(TIMEOUT_CYCLES);
 localparam [1:0] K_BOOT0=0,K_PBR=1,K_DIR=2,K_FAT=3;
 reg [3:0] state;
 reg [1:0] sector_kind;
 reg [9:0] byte_count;
 reg payload_complete,framing_error;
 reg [TIMEOUT_BITS-1:0] wait_count;
 reg entry_name_match;
 reg [7:0] entry_attr;
 reg [31:0] entry_cluster;
 reg [23:0] entry_size_low;
 reg [7:0] bpb_spc,bpb_nfats,mbr_type;
 reg [15:0] bpb_bps,bpb_reserved,signature,bpb_flags;
 reg bpb_legacy_nonzero;
 reg [31:0] bpb_fat_size,bpb_root,bpb_total,mbr_start,mbr_length,partition_length;
 reg dir_target; // 0 MEDIA directory in root, 1 BGM.WAV in MEDIA
 reg [1:0] track_latched;
 reg [31:0] dir_cluster;
 reg [7:0] dir_sector;
 reg [CHAIN_BITS-1:0] chain_count;
 reg [31:0] shift_work;
 reg [2:0] shift_left;
 reg dir_found,dir_end;
 reg [31:0] found_cluster,found_size;
 reg [8:0] fat_offset;
 reg [31:0] fat_value;
 reg mount_overhead_overflow;

 wire progress=(read_valid&&read_ready)||(data_valid&&data_ready)||read_done||read_error;
 assign start_ready=state==IDLE&&!rst&&!abort;
 assign read_valid=state==ISSUE&&!rst&&!abort;
 assign data_ready=state==RECEIVE&&!rst&&!abort;
 assign busy=state!=IDLE && state!=RESULT;
 wire timeout_hit=TIMEOUT_CYCLES==0 || wait_count>=TIMEOUT_CYCLES-1;
 wire spc_ok=bpb_spc==1||bpb_spc==2||bpb_spc==4||bpb_spc==8||
             bpb_spc==16||bpb_spc==32||bpb_spc==64||bpb_spc==128;
 function [2:0] spc_log2(input [7:0] spc);
  begin case(spc)
   2:spc_log2=1;4:spc_log2=2;8:spc_log2=3;16:spc_log2=4;
   32:spc_log2=5;64:spc_log2=6;128:spc_log2=7;default:spc_log2=0;
  endcase end
 endfunction
 function [7:0] expected_short_name_byte(input [4:0] pos,input target,input [1:0] track);
  begin
   case(pos)
    0:expected_short_name_byte=target?"B":"M";
    1:expected_short_name_byte=target?"G":"E";
    2:expected_short_name_byte=target?"M":"D";
    3:expected_short_name_byte=target?((track==2'd1)?"1":(track==2'd2)?"2":(track==2'd3)?"3":" "):"I";
    4:expected_short_name_byte=target?" ":"A";
    8:expected_short_name_byte=target?"W":" ";
    9:expected_short_name_byte=target?"A":" ";
    10:expected_short_name_byte=target?"V":" ";
    default:expected_short_name_byte=" ";
   endcase
  end
 endfunction
 wire [31:0] fat_next=fat_value & 32'h0fffffff;
 wire [2:0] bpb_shift=spc_log2(bpb_spc),cluster_shift=spc_log2(sectors_per_cluster);
 wire [33:0] fat_span=bpb_nfats==2?{1'd0,bpb_fat_size,1'b0}:{2'd0,bpb_fat_size};
 wire [33:0] overhead={18'd0,bpb_reserved}+fat_span;
 // Before MOUNT_CALC, shift_work holds the already checked FAT overhead.
 // Afterwards the same register becomes the cluster-count/address shifter.
 wire [31:0] data_sectors=bpb_total-shift_work;
 wire [38:0] fat_entries={bpb_fat_size,7'd0};
 wire bpb_ok=signature==16'haa55 && bpb_bps==16'd512 && spc_ok &&
             bpb_reserved!=0 && (bpb_nfats==1||bpb_nfats==2) &&
             bpb_fat_size!=0 && bpb_root>=2 && bpb_total!=0 &&
             !bpb_legacy_nonzero &&
             (!bpb_flags[7] || bpb_flags[3:0]<bpb_nfats) &&
             !mount_overhead_overflow && bpb_total>shift_work &&
             (partition_length==0 || bpb_total<=partition_length);
 wire mbr_ok=signature==16'haa55 && (mbr_type==8'h0b||mbr_type==8'h0c) && mbr_start!=0 && mbr_length!=0;
 // One mount adder is shared over four cycles; every intermediate is checked.
 wire [31:0] mount_left=state==MOUNT_ACTIVE ? fat_start_lba : partition_lba;
 reg [31:0] mount_right;
 always @*begin
  case(state)
   MOUNT_CALC:mount_right={16'd0,bpb_reserved};
   MOUNT_ACTIVE:mount_right=(bpb_flags[7]&&bpb_flags[3:0]==1)?bpb_fat_size:32'd0;
   MOUNT_DATA:mount_right=shift_work;
   default:mount_right=bpb_total;
  endcase
 end
 wire [32:0] mount_sum={1'd0,mount_left}+{1'd0,mount_right};
 wire [32:0] partition_end_calc={1'd0,mbr_start}+{1'd0,mbr_length};
 // Shared shift register computes the mount's cluster count and later the
 // directory cluster offsets in a bounded number of cycles (at most seven).
 // Validated power-of-two SPC makes these bitfields disjoint.
 wire [31:0] cluster_offset=shift_work | {24'd0,dir_sector};
 wire [32:0] cluster_lba_calc={1'd0,data_start_lba}+{1'd0,cluster_offset};
 wire [32:0] fat_lba_calc={1'd0,fat_start_lba}+{8'd0,dir_cluster[31:7]};
 wire fat_eoc=fat_next>=32'h0ffffff8;
 wire fat_invalid=fat_next<2 || fat_next==32'h0ffffff7 ||
                  (fat_next>=32'h0ffffff0 && !fat_eoc) || fat_next==dir_cluster || fat_next>max_cluster;
 wire [4:0] entry_pos=byte_count[4:0];
 wire entry_lfn=entry_attr==8'h0f;
 wire entry_volume=entry_attr[3];
 wire entry_directory=entry_attr[4];
 wire [31:0] entry_size_with_data={data,entry_size_low};

 task finish_result;
  input [3:0] code;
  begin result_code<=code;result_valid<=1;state<=RESULT;end
 endtask
 task issue_sector;
  input [1:0] kind; input [31:0] lba;
  begin sector_kind<=kind;read_lba<=lba;state<=ISSUE;wait_count<=0;end
 endtask
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   state<=IDLE;sector_kind<=0;read_lba<=0;byte_count<=0;payload_complete<=0;framing_error<=0;wait_count<=0;
   result_valid<=0;result_code<=0;file_first_cluster<=0;file_size<=0;
   partition_lba<=0;fat_start_lba<=0;data_start_lba<=0;sectors_per_cluster<=0;max_cluster<=0;volume_end_lba<=0;
   bpb_spc<=0;bpb_nfats<=0;mbr_type<=0;bpb_bps<=0;bpb_reserved<=0;signature<=0;
   bpb_fat_size<=0;bpb_root<=0;bpb_total<=0;mbr_start<=0;mbr_length<=0;partition_length<=0;
   bpb_legacy_nonzero<=0;bpb_flags<=0;
   dir_target<=0;track_latched<=2'd1;dir_cluster<=0;dir_sector<=0;chain_count<=0;dir_found<=0;dir_end<=0;
   found_cluster<=0;found_size<=0;fat_offset<=0;fat_value<=0;
   entry_name_match<=0;entry_attr<=0;entry_cluster<=0;entry_size_low<=0;
   shift_work<=0;shift_left<=0;
   mount_overhead_overflow<=0;
  end else if(abort)begin
   state<=IDLE;result_valid<=0;result_code<=0;wait_count<=0;payload_complete<=0;framing_error<=0;
  end else begin
   if(state==RESULT && result_valid && result_ready)begin state<=IDLE;result_valid<=0;end
   if(state!=IDLE && state!=RESULT)begin
    if(progress)wait_count<=0;else if(!timeout_hit)wait_count<=wait_count+1'b1;
    if(timeout_hit&&!progress)finish_result(4'd7);
   end
   case(state)
    IDLE:if(start_valid)begin
     result_valid<=0;result_code<=0;file_first_cluster<=0;file_size<=0;
     partition_lba<=0;fat_start_lba<=0;data_start_lba<=0;sectors_per_cluster<=0;partition_length<=0;max_cluster<=0;volume_end_lba<=0;
     track_latched<=track_select;
     issue_sector(K_BOOT0,32'd0);
    end
    ISSUE:if(read_ready)begin
     state<=RECEIVE;byte_count<=0;payload_complete<=0;framing_error<=0;
     // Complete CRC-checked sectors overwrite all fixed BPB fields.
     // Only accumulators need per-sector clearing; partial sectors fail.
     bpb_legacy_nonzero<=0;bpb_flags<=0;
     dir_found<=0;dir_end<=0;fat_value<=0;entry_name_match<=0;
    end
    RECEIVE:begin
     if(read_error)finish_result(4'd6);
     else if(read_done)finish_result(4'd5);
     else if(data_valid)begin
      if(byte_count>=10'd512)framing_error<=1;
      if(data_last!=(byte_count==10'd511))framing_error<=1;
      if(sector_kind==K_BOOT0||sector_kind==K_PBR)begin
       case(byte_count)
        11:bpb_bps[7:0]<=data;12:bpb_bps[15:8]<=data;13:bpb_spc<=data;
        14:bpb_reserved[7:0]<=data;15:bpb_reserved[15:8]<=data;16:bpb_nfats<=data;
        17,18,19,20,22,23,42,43:bpb_legacy_nonzero<=bpb_legacy_nonzero || (|data);
        32:bpb_total[7:0]<=data;33:bpb_total[15:8]<=data;34:bpb_total[23:16]<=data;35:bpb_total[31:24]<=data;
        36:bpb_fat_size[7:0]<=data;37:bpb_fat_size[15:8]<=data;38:bpb_fat_size[23:16]<=data;39:bpb_fat_size[31:24]<=data;
        40:bpb_flags[7:0]<=data;41:bpb_flags[15:8]<=data;
        44:bpb_root[7:0]<=data;45:bpb_root[15:8]<=data;46:bpb_root[23:16]<=data;47:bpb_root[31:24]<=data;
        450:mbr_type<=data;454:mbr_start[7:0]<=data;455:mbr_start[15:8]<=data;
        456:mbr_start[23:16]<=data;457:mbr_start[31:24]<=data;
        458:mbr_length[7:0]<=data;459:mbr_length[15:8]<=data;460:mbr_length[23:16]<=data;461:mbr_length[31:24]<=data;
        510:signature[7:0]<=data;511:signature[15:8]<=data;
        default:begin end
       endcase
      end else if(sector_kind==K_DIR)begin
       if(entry_pos<11)begin
        if(entry_pos==0)entry_name_match<=data==expected_short_name_byte(entry_pos,dir_target,track_latched);
        else entry_name_match<=entry_name_match&&
             (data==expected_short_name_byte(entry_pos,dir_target,track_latched));
       end
       case(entry_pos)
        11:entry_attr<=data;
        20:entry_cluster[23:16]<=data;21:entry_cluster[31:24]<=data;
        26:entry_cluster[7:0]<=data;27:entry_cluster[15:8]<=data;
        28:entry_size_low[7:0]<=data;29:entry_size_low[15:8]<=data;30:entry_size_low[23:16]<=data;
        default:begin end
       endcase
       if(entry_pos==0 && data==0)dir_end<=1;
       if(entry_pos==31 && !dir_found && !dir_end && !entry_lfn && !entry_volume)begin
        if(!dir_target && entry_name_match && entry_directory)begin
         dir_found<=1;found_cluster<=entry_cluster;found_size<=0;
        end else if(dir_target && entry_name_match && !entry_directory)begin
         dir_found<=1;found_cluster<=entry_cluster;found_size<=entry_size_with_data;
        end
       end
      end else begin
       if(byte_count==fat_offset)fat_value[7:0]<=data;
       if(byte_count==fat_offset+1'b1)fat_value[15:8]<=data;
       if(byte_count==fat_offset+2'd2)fat_value[23:16]<=data;
       if(byte_count==fat_offset+2'd3)fat_value[31:24]<=data;
      end
      if(byte_count==10'd511)begin payload_complete<=1;state<=WAIT_DONE;end
      else byte_count<=byte_count+1'b1;
     end
    end
    WAIT_DONE:begin
     if(data_valid)framing_error<=1;
     if(read_error)finish_result(4'd6);
     else if(read_done)begin
      if(!payload_complete||framing_error||data_valid)finish_result(4'd5);
      else if(sector_kind==K_BOOT0)begin
       state<=MOUNT_SPAN;
      end else if(sector_kind==K_PBR)begin
       state<=MOUNT_SPAN;
      end else if(sector_kind==K_DIR)begin
       if(dir_found)begin
        if(found_cluster<2||found_cluster>max_cluster||(dir_target&&found_size<45))finish_result(4'd4);
        else if(!dir_target)begin
         dir_target<=1;dir_cluster<=found_cluster;dir_sector<=0;chain_count<=0;
         state<=ADDRESS;
        end else begin
         file_first_cluster<=found_cluster;file_size<=found_size;finish_result(4'd0);
        end
       end else if(dir_end)finish_result(dir_target?4'd3:4'd2);
       else if(dir_sector+1'b1<sectors_per_cluster)begin
        dir_sector<=dir_sector+1'b1;
        state<=ADDRESS;
       end else begin
        fat_offset<={dir_cluster[6:0],2'b00};
        if(fat_lba_calc[32]!=0)finish_result(4'd8);
        else issue_sector(K_FAT,fat_lba_calc[31:0]);
       end
      end else begin
       if(fat_eoc)finish_result(dir_target?4'd3:4'd2);
       else if(fat_invalid||chain_count>=MAX_CHAIN_CLUSTERS-1)finish_result(4'd4);
       else begin
        dir_cluster<=fat_next;dir_sector<=0;chain_count<=chain_count+1'b1;
        state<=ADDRESS;
       end
      end
     end
    end
    RESULT:begin end
    MOUNT_SPAN:begin
     // Preserve all 34 bits logically: a high bit makes total32 > overhead34
     // impossible. Reuse the idle shifter for the remaining 32 bits instead
     // of adding another wide register or repeating the adder in VALIDATE.
     shift_work<=overhead[31:0];
     mount_overhead_overflow<=|overhead[33:32];
     state<=MOUNT_VALIDATE;
    end
    MOUNT_VALIDATE:begin
     if(bpb_ok)begin
      if(sector_kind==K_BOOT0)partition_lba<=0;
      state<=MOUNT_CALC;
     end else if(sector_kind==K_BOOT0 && mbr_ok)begin
      if(partition_end_calc>33'h100000000)finish_result(4'd8);
      else begin partition_lba<=mbr_start;partition_length<=mbr_length;issue_sector(K_PBR,mbr_start);end
     end else finish_result(4'd1);
    end
    MOUNT_CALC:begin
     if(mount_sum[32])finish_result(4'd8);
     else begin fat_start_lba<=mount_sum[31:0];state<=MOUNT_ACTIVE;end
    end
    MOUNT_ACTIVE:begin
     if(mount_sum[32])finish_result(4'd8);
     else begin fat_start_lba<=mount_sum[31:0];state<=MOUNT_DATA;end
    end
    MOUNT_DATA:begin
     if(mount_sum[32])finish_result(4'd8);
     else begin data_start_lba<=mount_sum[31:0];state<=MOUNT_END;end
    end
    MOUNT_END:begin
     if(mount_sum>33'h100000000)finish_result(4'd8);
     else begin
      sectors_per_cluster<=bpb_spc;volume_end_lba<=mount_sum;
      dir_target<=0;dir_cluster<=bpb_root;dir_sector<=0;chain_count<=0;
      shift_work<=data_sectors;shift_left<=bpb_shift;state<=MOUNT_SHIFT;
     end
    end
    MOUNT_SHIFT:begin
     if(shift_left!=0)begin shift_work<=shift_work>>1;shift_left<=shift_left-1'b1;end
     else state<=MOUNT_CHECK;
    end
    MOUNT_CHECK:begin
     if(shift_work<65525||shift_work>=32'h0fffffee||fat_entries<{7'd0,shift_work}+2||bpb_root>shift_work+1)finish_result(4'd1);
     else begin max_cluster<=shift_work+1'b1;state<=ADDRESS;end
    end
    ADDRESS:begin
     shift_work<=dir_cluster-32'd2;shift_left<=cluster_shift;state<=ADDRESS_SHIFT;
    end
    ADDRESS_SHIFT:begin
     if(shift_left!=0)begin shift_work<=shift_work<<1;shift_left<=shift_left-1'b1;end
     else state<=ADDRESS_FINAL;
    end
    ADDRESS_FINAL:begin
     if(cluster_lba_calc[32]||cluster_lba_calc>=volume_end_lba)finish_result(4'd8);
     else issue_sector(K_DIR,cluster_lba_calc[31:0]);
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
