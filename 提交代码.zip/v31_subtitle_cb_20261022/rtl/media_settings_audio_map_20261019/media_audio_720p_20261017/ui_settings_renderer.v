`default_nettype none
// 720p设置/HUD共用一个描述符绘制器；不保存图像，不增加字体ROM。
// 组合输出由compositor寄存，再同步读字体。条宽是9的整数倍，0空9满。
module ui_settings_renderer #(parameter SYNC_TEXT=0)(
 input wire enabled,video_active,input wire [10:0] x,y,
 input wire [95:0] status,
 output reg overlay_hit,output reg [3:0] palette,
 output reg font_valid,output reg [6:0] font_glyph,
 output reg [3:0] font_row,font_col,output reg [3:0] font_palette,
 output reg [9:0] text_address
);
 wire settings=enabled && status[63:60]==9;
 wire hud=enabled && status[63:60]==2 && status[15];
 wire [2:0] page=status[26:24],focus=status[23:21];
 wire [1:0] parent=status[58:57],feedback=status[87:86];
 wire editing=status[0],confirm=status[85],confirm_yes=status[84];
 wire [3:0] draft=status[95:92];
 wire panel=x[10:6]>=5'd5  && x[10:6]<5'd15  && y[10:7]>=4'd1  && y[10:6]<5'd9 ;
 wire [10:0] tx=x-384,by=y-224,bx=x-368,hx=x-1024;
 wire [10:0] footer_x=x-352,popup_x=x-480;
wire [2:0] row_id=by[8:6];
 wire [2:0] active_parent=page==0?{1'b0,parent}:page==5?3'd1:page-3'd1;
wire row_exists=((page==1 || page==2) && row_id<4) || (page==3 && row_id<5) || (page==4 && row_id<2) || (page==5 && row_id<2);
 reg [3:0] row_value,bar_value;
 reg row_switch;
wire row_selected=row_id==focus;
 wire [4:0] bar_end=5'd17+{1'b0,bar_value}; // 9*32=288px
 wire row_named_value=(page==1&&row_id==3)||(page==2&&row_id==3)||(page==5&&row_id==1);
 wire [10:0] value_x=x-11'd848;
 wire [1:0] value_char=value_x[5:4];
 wire [1:0] hud_row=y[6:5];
 reg [3:0] hud_value;
 wire [6:0] hud_end=7'd69+{3'd0,hud_value}; // 9*16=144px





function [6:0] text_glyph; input [9:0] address; begin case(address)
10'd32:text_glyph=7'd12;
10'd33:text_glyph=7'd13;
10'd34:text_glyph=7'd31;
10'd35:text_glyph=7'd32;
10'd40:text_glyph=7'd49;
10'd41:text_glyph=7'd50;
10'd42:text_glyph=7'd111;
10'd48:text_glyph=7'd61;
10'd49:text_glyph=7'd62;
10'd50:text_glyph=7'd21;
10'd51:text_glyph=7'd22;
10'd56:text_glyph=7'd63;
10'd57:text_glyph=7'd64;
10'd64:text_glyph=7'd44;
10'd65:text_glyph=7'd55;
10'd72:text_glyph=7'd56;
10'd73:text_glyph=7'd44;
10'd80:text_glyph=7'd44;
10'd81:text_glyph=7'd94;
10'd88:text_glyph=7'd12;
10'd89:text_glyph=7'd13;
10'd90:text_glyph=7'd93;
10'd91:text_glyph=7'd94;
10'd96:text_glyph=7'd57;
10'd97:text_glyph=7'd58;
10'd104:text_glyph=7'd59;
10'd105:text_glyph=7'd60;
10'd106:text_glyph=7'd58;
10'd112:text_glyph=7'd95;
10'd113:text_glyph=7'd96;
10'd114:text_glyph=7'd97;
10'd115:text_glyph=7'd98;
10'd116:text_glyph=7'd99;
10'd120:text_glyph=7'd44;
10'd121:text_glyph=7'd20;
10'd122:text_glyph=7'd112;
10'd128:text_glyph=7'd67;
10'd129:text_glyph=7'd68;
10'd130:text_glyph=7'd69;
10'd131:text_glyph=7'd36;
10'd132:text_glyph=7'd23;
10'd133:text_glyph=7'd78;
10'd136:text_glyph=7'd77;
10'd137:text_glyph=7'd78;
10'd138:text_glyph=7'd53;
10'd139:text_glyph=7'd54;
10'd160:text_glyph=7'd12;
10'd161:text_glyph=7'd13;
10'd168:text_glyph=7'd93;
10'd169:text_glyph=7'd94;
10'd216:text_glyph=7'd44;
10'd217:text_glyph=7'd20;
10'd218:text_glyph=7'd112;
10'd256:text_glyph=7'd21;
10'd257:text_glyph=7'd22;
10'd258:text_glyph=7'd93;
10'd259:text_glyph=7'd94;
10'd260:text_glyph=7'd113;
10'd261:text_glyph=7'd114;
10'd262:text_glyph=7'd53;
10'd263:text_glyph=7'd54;
10'd320:text_glyph=7'd12;
10'd321:text_glyph=7'd13;
10'd328:text_glyph=7'd93;
10'd329:text_glyph=7'd94;
10'd512:text_glyph=7'd33;
10'd513:text_glyph=7'd34;
10'd514:text_glyph=7'd35;
10'd515:text_glyph=7'd36;
10'd517:text_glyph=7'd37;
10'd518:text_glyph=7'd38;
10'd519:text_glyph=7'd39;
10'd521:text_glyph=7'd40;
10'd522:text_glyph=7'd66;
10'd523:text_glyph=7'd117;
10'd544:text_glyph=7'd100;
10'd545:text_glyph=7'd101;
10'd546:text_glyph=7'd3;
10'd548:text_glyph=7'd33;
10'd549:text_glyph=7'd34;
10'd550:text_glyph=7'd102;
10'd551:text_glyph=7'd103;
10'd553:text_glyph=7'd37;
10'd554:text_glyph=7'd105;
10'd555:text_glyph=7'd106;
10'd576:text_glyph=7'd104;
10'd577:text_glyph=7'd102;
10'd578:text_glyph=7'd103;
10'd608:text_glyph=7'd104;
10'd609:text_glyph=7'd105;
10'd610:text_glyph=7'd106;
10'd640:text_glyph=7'd108;
10'd641:text_glyph=7'd77;
10'd642:text_glyph=7'd76;
10'd672:text_glyph=7'd35;
10'd673:text_glyph=7'd36;
10'd674:text_glyph=7'd109;
10'd675:text_glyph=7'd110;
10'd704:text_glyph=7'd105;
10'd705:text_glyph=7'd106;
10'd736:text_glyph=7'd35;
10'd737:text_glyph=7'd36;
10'd768:text_glyph=7'd57;
10'd769:text_glyph=7'd58;
10'd772:text_glyph=7'd59;
10'd773:text_glyph=7'd60;
10'd774:text_glyph=7'd58;
10'd776:text_glyph=7'd44;
10'd777:text_glyph=7'd55;
10'd864:text_glyph=7'd8;
10'd865:text_glyph=7'd9;
default:text_glyph=7'd127;endcase end endfunction
 always @* begin
  row_value=0;row_switch=0;
  case(page)
   1:case(row_id)
    0:row_value=status[76:73]+4'd1;
    1:row_value=status[91:88];
    2:begin row_value={3'b0,status[2]};row_switch=1;end
    3:row_value={2'b0,status[7:6]};
   endcase
   2:case(row_id)
    0:row_value=status[20:17];
    1:begin row_value={3'b0,status[16]};row_switch=1;end
    2:begin row_value={3'b0,status[1]};row_switch=1;end
    3:row_value=0;
   endcase
   3:case(row_id)
    0:row_value=status[30:27];1:row_value=status[13:10];
    2:begin row_value={3'b0,status[15]};row_switch=1;end
    3:begin row_value={3'b0,status[14]};row_switch=1;end
    4:begin row_value={3'b0,status[77]};row_switch=1;end
    default:row_value=0;
   endcase
   5:case(row_id)
    0:row_value=status[83:80];
    1:row_value={2'b00,status[79:78]};
    default:row_value=0;
   endcase
   default:row_value=0;
  endcase
  if(editing && row_selected)row_value=draft;
  bar_value=row_switch?(row_value==0?4'd0:4'd9):(row_value>9?4'd9:row_value);
  case(hud_row)
   0:hud_value=status[30:27];1:hud_value=status[13:10];default:hud_value=status[20:17];
  endcase
  if(hud_value>9)hud_value=9;
  text_address=10'h3ff;overlay_hit=0;palette=0;font_valid=0;font_glyph=127;
  font_row=y[3:0];font_col=x[3:0];font_palette=1;
  if(video_active && settings && panel)begin
   overlay_hit=1;palette=9;
   if(x[10:2]<9'd81  || x[10:2]>=9'd239  || y[10:2]<9'd33  || y[10:2]>=9'd143 )palette=3;
   // 四个母目录水平排列，子目录保留当前母目录高亮。
   if(y[10:5]>=6'd5  && y[10:4]<7'd13  && x[10:7]>=4'd3  && x[10:7]<4'd7 )begin
    palette=({1'b0,tx[8:7]}==active_parent)?10:6;
    if(y[10:4]>=7'd11  && y[10:6]<5'd3  && tx[6:0]>=48 && tx[6:0]<80)begin
     font_valid=1;text_address={2'd1,5'd0,tx[8:7],~tx[4]};
    end
   end
   if(page!=0 && y[10:5]>=6'd7  && y[10:5]<6'd17  && x[10:5]>=6'd11  && x[10:5]<6'd29  && row_exists)begin
    palette=row_selected?4:6;
    if(row_selected && (x[10:2]<9'd89  || x[10:2]>=9'd231  || by[5:0]<2 || by[5:0]>=62))
     palette=editing?13:2;
     if(by[5:4]==1 && x[10:4]>=7'd23  && x[10:4]<7'd31 )begin
      if(page==3 && row_id==4)begin
       if(bx[6:4]<2)begin
        font_valid=1;text_address={9'd432,bx[4]};
       end
      end else begin
       font_valid=1;text_address={2'd0,{page,row_id[1:0],bx[6:4]}};
      end
    end
    if(page!=4)begin
     if(!row_named_value && by[5:0]>=40 && by[5:0]<48 && x[10:5]>=6'd17  && x[10:6]<5'd13 )
      palette=x[10:5]<bar_end?(editing && row_selected?13:5):15;
     if(by[5:4]==1 && x[10:4]>=7'd53  && x[10:4]<7'd57 )begin
      if(row_named_value)begin
       if((page==1&&row_id==3&&value_char<(row_value==3?3:2))||
          (page==2&&row_id==3&&value_char<2)||
          (page==5&&row_id==1&&value_char<(row_value==0?2:3)))begin
        font_valid=1;
        if(page==1)begin
         case(row_value)
          0:font_glyph=value_char==0?7'd118:7'd119;
          1:font_glyph=value_char==0?7'd120:7'd121;
          2:font_glyph=value_char==0?7'd122:7'd121;
          default:case(value_char)0:font_glyph=7'd123;1:font_glyph=7'd124;default:font_glyph=7'd125;endcase
         endcase
        end else if(page==2)begin
         font_glyph=value_char==0?7'd115:7'd116;
        end else begin
         case(row_value)
          0:font_glyph=value_char==0?7'd56:7'd44;
          1:case(value_char)0:font_glyph=7'd44;1:font_glyph=7'd94;default:font_glyph=7'd83;endcase
          default:case(value_char)0:font_glyph=7'd44;1:font_glyph=7'd94;default:font_glyph=7'd82+{2'b00,row_value};endcase
         endcase
        end
       end
      end else if(x[10:4]==7'd53)begin
       font_valid=1;font_glyph=row_switch?(row_value!=0?7'd65:7'd66):(7'd82+row_value);
      end
      font_palette=editing && row_selected?13:1;
     end
    end
   end
   if(y[10:4]>=7'd35  && y[10:5]<6'd18  && x[10:5]>=6'd11  && x[10:5]<6'd27 )begin
    font_valid=1;font_col=x[3:0];
    text_address={2'd2,{feedback==1?3'd2:feedback==2?3'd3:feedback==3?3'd4:editing?3'd1:3'd0,footer_x[8:4]}};
    font_palette=feedback==1?5:feedback==3?12:editing?13:1;
   end
   // 危险操作的独立确认窗口，初始取消，右键选择确认。
   if(confirm && x[10:6]>=5'd7  && x[10:6]<5'd13  && y[10:8]>=3'd1  && y[10:6]<5'd7 )begin
    palette=6;font_valid=0;
    if(x[10:2]<9'd113  || x[10:2]>=9'd207  || y[10:2]<9'd65  || y[10:2]>=9'd111 )palette=13;
    if(y[10:5]>=6'd9  && y[10:4]<7'd19  && x[10:5]>=6'd15  && x[10:5]<6'd19 )begin
     font_valid=1;text_address={2'd0,{3'd4,focus[1:0],popup_x[6:4]}};
    end
    if(y[10:4]>=7'd21  && y[10:5]<6'd11  && x[10:5]>=6'd15  && x[10:5]<6'd19 )begin
     font_valid=1;text_address={2'd2,{3'd5,2'd0,popup_x[6:4]}};
    end
    if(y[10:3]>=8'd47  && y[10:3]<8'd53  && x[10:5]>=6'd15  && x[10:5]<6'd25 )begin
     palette=(x[10:7]<4'd5 ?!confirm_yes:confirm_yes)?10:4;
     if(y[10:3]>=8'd49  && y[10:3]<8'd51  && ((x[10:4]>=7'd33  && x[10:4]<7'd35 )||(x[10:4]>=7'd43  && x[10:4]<7'd45 )))begin
      font_valid=1;font_row=y-11'd392;
      text_address={2'd2,{x[10:7]<4'd5 ?3'd6:3'd7,4'd0,~x[4]}};
     end
    end
   end
  end else if(video_active && hud && x[10:4]>=7'd63  && x[10:8]<3'd5  && y[10:3]<8'd13 )begin
   overlay_hit=1;palette=9;
   if(y<11'd2  || x<11'd1010  || y>=11'd102 )palette=3;
   if(hud_row<3)begin
    if(y[4:0]>=8 && y[4:0]<24)begin
     font_row=y[3:0]-4'd8;
     if(x[10:10]>=1'd1  && x[10:6]<5'd17 )begin font_valid=1;text_address={2'd3,4'd0,hud_row,hx[5:4]};end
     if(x[10:5]>=6'd39  && x[10:4]<7'd79 )begin font_valid=1;font_glyph=7'd82+hud_value;end
    end
    if(y[4:0]>=26 && y[4:0]<30 && x[10:4]>=7'd69  && x[10:5]<6'd39 )palette=x[10:4]<hud_end?5:15;
   end
  end
  if(!SYNC_TEXT && text_address!=10'h3ff)font_glyph=text_glyph(text_address);
 end
endmodule
`default_nettype wire

// 字符编号表1024x7，使用描述符原有的一拍；不增加像素总延迟。
module ui_settings_text_sync_rom(input wire clk,input wire [9:0] address,
 output reg [6:0] glyph);
reg [6:0] map[0:1023]; integer i;
initial begin
 for(i=0;i<1024;i=i+1)map[i]=7'd127;
map[832]=7'd0;map[833]=7'd1;map[834]=7'd2;map[835]=7'd64;
map[836]=7'd91;map[837]=7'd10;map[838]=7'd87;map[839]=7'd4;
map[840]=7'd11;map[841]=7'd5;map[842]=7'd6;map[843]=7'd7;map[844]=7'd6;
map[864]=7'd8;map[865]=7'd9;
map[32]=7'd12;
map[33]=7'd13;
map[34]=7'd31;
map[35]=7'd32;
map[40]=7'd49;
map[41]=7'd50;
map[42]=7'd111;
map[48]=7'd61;
map[49]=7'd62;
map[50]=7'd21;
map[51]=7'd22;
map[56]=7'd63;
map[57]=7'd64;
map[64]=7'd44;
map[65]=7'd55;
map[72]=7'd56;
map[73]=7'd44;
map[80]=7'd44;
map[81]=7'd94;
map[88]=7'd12;
map[89]=7'd13;
map[90]=7'd93;
map[91]=7'd94;
map[96]=7'd57;
map[97]=7'd58;
map[104]=7'd59;
map[105]=7'd60;
map[106]=7'd58;
map[112]=7'd95;
map[113]=7'd96;
map[114]=7'd97;
map[115]=7'd98;
map[116]=7'd99;
map[120]=7'd44;
map[121]=7'd20;
map[122]=7'd112;
map[128]=7'd67;
map[129]=7'd68;
map[130]=7'd69;
map[131]=7'd36;
map[132]=7'd23;
map[133]=7'd78;
map[136]=7'd77;
map[137]=7'd78;
map[138]=7'd53;
map[139]=7'd54;
map[160]=7'd12;
map[161]=7'd13;
map[168]=7'd93;
map[169]=7'd94;
map[216]=7'd44;
map[217]=7'd20;
map[218]=7'd112;
map[256]=7'd21;
map[257]=7'd22;
map[258]=7'd93;
map[259]=7'd94;
map[260]=7'd113;
map[261]=7'd114;
map[262]=7'd53;
map[263]=7'd54;
map[320]=7'd12;
map[321]=7'd13;
map[328]=7'd93;
map[329]=7'd94;
map[512]=7'd33;
map[513]=7'd34;
map[514]=7'd35;
map[515]=7'd36;
map[517]=7'd37;
map[518]=7'd38;
map[519]=7'd39;
map[521]=7'd40;
map[522]=7'd66;
map[523]=7'd117;
map[544]=7'd100;
map[545]=7'd101;
map[546]=7'd3;
map[548]=7'd33;
map[549]=7'd34;
map[550]=7'd102;
map[551]=7'd103;
map[553]=7'd37;
map[554]=7'd105;
map[555]=7'd106;
map[576]=7'd104;
map[577]=7'd102;
map[578]=7'd103;
map[608]=7'd104;
map[609]=7'd105;
map[610]=7'd106;
map[640]=7'd108;
map[641]=7'd77;
map[642]=7'd76;
map[672]=7'd35;
map[673]=7'd36;
map[674]=7'd109;
map[675]=7'd110;
map[704]=7'd105;
map[705]=7'd106;
map[736]=7'd35;
map[737]=7'd36;
map[768]=7'd57;
map[769]=7'd58;
map[772]=7'd59;
map[773]=7'd60;
map[774]=7'd58;
map[776]=7'd44;
map[777]=7'd55;
end
always @(posedge clk)glyph<=map[address];
endmodule
