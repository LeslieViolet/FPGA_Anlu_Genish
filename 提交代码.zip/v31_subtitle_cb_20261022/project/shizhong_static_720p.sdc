# Static 1280x720 entry: no runtime resolution clock mux or mode-control CDC.
# Keep the board reference and derive all clocks from the instantiated PLLs.
create_clock -name clk_50m -period 20.000 [get_ports {clk_50m}]
derive_clocks

# PCM uses the same checked Soft FIFO wrapper as SDRAM. Bound only the
# Gray-pointer first-stage crossings; second stages and functional logic
# retain normal timing checks. Neither clock domain is globally excepted.
set_max_delay -datapath_only 8.000 -to [get_regs {*u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/u_pcm_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/u_pcm_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*]}]
set_false_path -hold -to [get_regs {*u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/u_pcm_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/u_pcm_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*]}]
set_max_skew -to [get_regs {*u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/u_pcm_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/u_pcm_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*]}] 5.000

# One-bit session request, finite-file marker and end-of-playback toggle.
set_max_delay -datapath_only 8.000 -to [get_regs {*u_tf_audio_reader/session_sync[0] *u_tf_audio_reader/u_shared_storage/u_player/end_sync[0] *u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/file_end_sync[0]}]
set_false_path -hold -to [get_regs {*u_tf_audio_reader/session_sync[0] *u_tf_audio_reader/u_shared_storage/u_player/end_sync[0] *u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/file_end_sync[0]}]

# Asynchronous FIFO first-stage synchronizers. Bound routing and bus skew;
# functional and second-stage paths remain timed.
set_max_delay -datapath_only 8.000 -to [get_regs {*u_b/u_sdram_shipeiqi/u_read_cmd_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_read_cmd_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*] *u_b/u_sdram_shipeiqi/u_write_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_write_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*]}]
set_false_path -hold -to [get_regs {*u_b/u_sdram_shipeiqi/u_read_cmd_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_read_cmd_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*] *u_b/u_sdram_shipeiqi/u_write_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_write_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*]}]
set_max_skew -to [get_regs {*u_b/u_sdram_shipeiqi/u_read_cmd_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_read_cmd_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*] *u_b/u_sdram_shipeiqi/u_write_fifo/u_fifo/cdc$cross_inst/sync_r1_r[*] *u_b/u_sdram_shipeiqi/u_write_fifo/u_fifo/cdc$cross_inst/sync_r1_w[*]}] 5.000
set_max_delay -datapath_only 8.000 -to [get_regs {*u_b/u_sdram_shipeiqi/init_sync_write[0] *u_b/u_sdram_shipeiqi/init_sync_read[0] *u_b/u_sdram_shipeiqi/flush_req_sync[0] *u_b/u_sdram_shipeiqi/flush_done_sync[0] *u_b/u_sdram_shipeiqi/cancel_req_sync[0] *u_b/u_sdram_shipeiqi/cancel_drained_sync[0] *u_b/u_sdram_shipeiqi/fault_write_sync[0] *u_b/u_sdram_shipeiqi/fault_read_sync[0]}]
set_false_path -hold -to [get_regs {*u_b/u_sdram_shipeiqi/init_sync_write[0] *u_b/u_sdram_shipeiqi/init_sync_read[0] *u_b/u_sdram_shipeiqi/flush_req_sync[0] *u_b/u_sdram_shipeiqi/flush_done_sync[0] *u_b/u_sdram_shipeiqi/cancel_req_sync[0] *u_b/u_sdram_shipeiqi/cancel_drained_sync[0] *u_b/u_sdram_shipeiqi/fault_write_sync[0] *u_b/u_sdram_shipeiqi/fault_read_sync[0]}]
set_max_skew -to [get_regs {*u_b/u_sdram_shipeiqi/init_sync_write[0] *u_b/u_sdram_shipeiqi/init_sync_read[0] *u_b/u_sdram_shipeiqi/flush_req_sync[0] *u_b/u_sdram_shipeiqi/flush_done_sync[0] *u_b/u_sdram_shipeiqi/cancel_req_sync[0] *u_b/u_sdram_shipeiqi/cancel_drained_sync[0] *u_b/u_sdram_shipeiqi/fault_write_sync[0] *u_b/u_sdram_shipeiqi/fault_read_sync[0]}] 5.000
set_max_delay -datapath_only 8.000 -to [get_regs {*u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_ack_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_toggle_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_slot_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_toggle_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_buffer_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_ack_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_index_sync1[*] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_generation_sync1[*]}]
set_false_path -hold -to [get_regs {*u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_ack_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_toggle_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_slot_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_toggle_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_buffer_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_ack_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_index_sync1[*] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_generation_sync1[*]}]
set_max_skew -to [get_regs {*u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_ack_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_toggle_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_slot_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_toggle_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_buffer_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/release_ack_sync[0] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_index_sync1[*] *u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_shuang_huanchong/commit_generation_sync1[*]}] 5.000
set_max_delay -datapath_only 8.000 -to [get_regs {*u_b/u_zhen_duqu_dingceng/memory_fault_write_sync[0] *u_b/u_zhen_duqu_dingceng/memory_fault_read_sync[0]}]
set_false_path -hold -to [get_regs {*u_b/u_zhen_duqu_dingceng/memory_fault_write_sync[0] *u_b/u_zhen_duqu_dingceng/memory_fault_read_sync[0]}]
set_max_skew -to [get_regs {*u_b/u_zhen_duqu_dingceng/memory_fault_write_sync[0] *u_b/u_zhen_duqu_dingceng/memory_fault_read_sync[0]}] 5.000

# Asynchronous assertion into explicit reset-release chains only.
set_false_path -from [get_regs {*u_k/release_sd[2] *u_k/release_mem[2] *u_k/release_pixel[2]}] -to [get_regs {*u_b/u_sdram_shipeiqi/u_write_fifo/wr_release[*] *u_b/u_sdram_shipeiqi/u_write_fifo/rd_release[*] *u_b/u_sdram_shipeiqi/u_read_cmd_fifo/wr_release[*] *u_b/u_sdram_shipeiqi/u_read_cmd_fifo/rd_release[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/wr_release[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/rd_release[*] *u_c/u_bc_tuxiang_tongdao/u_yuqu_fifo/wr_release[*] *u_c/u_bc_tuxiang_tongdao/u_yuqu_fifo/rd_release[*]}]

# HDMI serial lane consumes each TMDS word on its fifth serial edge. This is
# the documented, timed load phase, not a false path.
set_multicycle_path -setup -from [get_regs {*u_c/u_hdmi_tx/*u_hdmi_tx_controller_wrapper/u0_hdmi_tmds_encode/O_tmds_code_data* *u_c/u_hdmi_tx/*u_hdmi_tx_controller_wrapper/u1_hdmi_tmds_encode/O_tmds_code_data* *u_c/u_hdmi_tx/*u_hdmi_tx_controller_wrapper/u2_hdmi_tmds_encode/O_tmds_code_data* *u_c/u_hdmi_tx/registered_tmds_select*symbols*}] -to [get_regs {*u_c/u_hdmi_phy/u0_lane_lvds_8_1/S_shift_data[*] *u_c/u_hdmi_phy/u1_lane_lvds_8_1/S_shift_data[*] *u_c/u_hdmi_phy/u2_lane_lvds_8_1/S_shift_data[*] *u_c/u_hdmi_phy/u3_lane_lvds_8_1/S_shift_data[*]}] 5
set_multicycle_path -hold -end -from [get_regs {*u_c/u_hdmi_tx/*u_hdmi_tx_controller_wrapper/u0_hdmi_tmds_encode/O_tmds_code_data* *u_c/u_hdmi_tx/*u_hdmi_tx_controller_wrapper/u1_hdmi_tmds_encode/O_tmds_code_data* *u_c/u_hdmi_tx/*u_hdmi_tx_controller_wrapper/u2_hdmi_tmds_encode/O_tmds_code_data* *u_c/u_hdmi_tx/registered_tmds_select*symbols*}] -to [get_regs {*u_c/u_hdmi_phy/u0_lane_lvds_8_1/S_shift_data[*] *u_c/u_hdmi_phy/u1_lane_lvds_8_1/S_shift_data[*] *u_c/u_hdmi_phy/u2_lane_lvds_8_1/S_shift_data[*] *u_c/u_hdmi_phy/u3_lane_lvds_8_1/S_shift_data[*]}] 4

# Stable-payload UI mailbox: only metastability entry stages are excepted.
set_max_delay -datapath_only 8.000 -to [get_regs {*u_a/u_ui_status_mailbox/req_sync1 *u_a/u_ui_status_mailbox/ack_sync1}]
set_false_path -hold -to [get_regs {*u_a/u_ui_status_mailbox/req_sync1 *u_a/u_ui_status_mailbox/ack_sync1}]
set_max_delay -datapath_only 8.000 -from [get_regs {*u_a/u_ui_status_mailbox/payload_hold[*]}] -to [get_regs {*u_a/u_ui_status_mailbox/dst_payload[*]}]
set_false_path -hold -from [get_regs {*u_a/u_ui_status_mailbox/payload_hold[*]}] -to [get_regs {*u_a/u_ui_status_mailbox/dst_payload[*]}]
set_max_skew -from [get_regs {*u_a/u_ui_status_mailbox/payload_hold[*]}] -to [get_regs {*u_a/u_ui_status_mailbox/dst_payload[*]}] 5.000

# Two-bit track selection uses the same acknowledged stable-payload mailbox.
# audio_control_last_pixel may be merged with payload_hold during mapping.
set_max_delay -datapath_only 8.000 -to [get_regs {*u_tf_audio_reader/u_audio_control_mailbox/req_sync1 *u_tf_audio_reader/u_audio_control_mailbox/ack_sync1}]
set_false_path -hold -to [get_regs {*u_tf_audio_reader/u_audio_control_mailbox/req_sync1 *u_tf_audio_reader/u_audio_control_mailbox/ack_sync1}]
set_max_delay -datapath_only 8.000 -from [get_regs {*u_tf_audio_reader/u_audio_control_mailbox/payload_hold[*] *u_tf_audio_reader/audio_control_last_pixel[*]}] -to [get_regs {*u_tf_audio_reader/u_audio_control_mailbox/dst_payload[*]}]
set_false_path -hold -from [get_regs {*u_tf_audio_reader/u_audio_control_mailbox/payload_hold[*] *u_tf_audio_reader/audio_control_last_pixel[*]}] -to [get_regs {*u_tf_audio_reader/u_audio_control_mailbox/dst_payload[*]}]
set_max_skew -from [get_regs {*u_tf_audio_reader/u_audio_control_mailbox/payload_hold[*] *u_tf_audio_reader/audio_control_last_pixel[*]}] -to [get_regs {*u_tf_audio_reader/u_audio_control_mailbox/dst_payload[*]}] 5.000

# Media-removal reset and card-offline CDC.
set_false_path -from [get_regs {*u_b/removal_reset}] -to [get_regs {*u_b/media_release_mem[*] *u_b/media_release_pixel[*]}]
set_max_delay -datapath_only 8.000 -to [get_regs {*u_a/u_ui_media/card_offline_sync[0]}]
set_false_path -hold -to [get_regs {*u_a/u_ui_media/card_offline_sync[0]}]
set_false_path -from [get_regs {*u_b/media_release_mem[2] *u_b/media_release_pixel[2] *u_b/removal_reset}] -to [get_regs {*u_b/u_sdram_shipeiqi/u_write_fifo/wr_release[*] *u_b/u_sdram_shipeiqi/u_write_fifo/rd_release[*] *u_b/u_sdram_shipeiqi/u_read_cmd_fifo/wr_release[*] *u_b/u_sdram_shipeiqi/u_read_cmd_fifo/rd_release[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/wr_release[*] *u_b/u_sdram_shipeiqi/u_read_rsp_fifo/rd_release[*]}]

# No uptime/subtitle mailbox is instantiated in this static production profile.

# PCM session clear is asynchronously asserted into this explicit4-stage
# reset-release chain. Only its asynchronous SR entry pins are excepted.
# D/Q shift paths and downstream functional logic remain timed.
set_false_path -to [get_pins {*u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/pixel_release*.sr}]
