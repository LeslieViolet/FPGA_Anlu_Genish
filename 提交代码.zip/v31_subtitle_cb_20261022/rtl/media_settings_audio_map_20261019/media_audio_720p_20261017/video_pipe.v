module video_pipe #(
    parameter FRAME_WIDTH = 1280,
    parameter FRAME_HEIGHT = 720,
    parameter H_FRONT = 110,
    parameter H_SYNC = 40,
    parameter H_BACK = 220,
    parameter V_FRONT = 5,
    parameter V_SYNC = 5,
    parameter V_BACK = 20,
    parameter PIPELINED = 0
) (
    input  wire        clk,
    input  wire        rst,
    input  wire [23:0] frame_rgb,
    input  wire [4:0]  fade_level,
    input  wire [1:0]  transition_style,
    output wire [10:0] h_count,
    output wire [10:0] v_count,
    output wire        axis_user,
    output wire        axis_valid,
    output wire        axis_last,
    output wire [10:0] axis_x_out, axis_y_out,
    output wire [23:0] axis_data
);
    wire [11:0] active_height = FRAME_HEIGHT;
    wire [11:0] active_width = FRAME_WIDTH;
    wire active_hd = (FRAME_WIDTH>640);

    wire [11:0] active_htotal = FRAME_WIDTH+H_FRONT+H_SYNC+H_BACK;
    wire [11:0] active_vtotal = FRAME_HEIGHT+V_FRONT+V_SYNC+V_BACK;
    wire [10:0] pixel_x;
    wire [10:0] pixel_y;
    wire        hsync;
    wire        vsync;
    wire        de;
    wire [23:0] selected_rgb;
    wire [23:0] processed_rgb;
    wire [23:0] faded_rgb;
    wire [23:0] osd_rgb;
    wire [23:0] scroll_rgb;
    wire [10:0] effect_x, effect_y, overlay_x, overlay_y;
    wire [10:0] osd_x, osd_y, scroll_x, scroll_y, axis_x, axis_y;
    wire effect_de, overlay_de, osd_de, scroll_de, axis_de;
    wire [23:0] effect_input, overlay_input, osd_input, scroll_input, axis_rgb;
    // At 75 MHz the complete source/filter/fade/OSD chain exceeds one cycle.
    // In HD only, register RGB and its coordinate/DE sidebands together at
    // each boundary. The verified SD mode remains a zero-latency path.
    generate if (PIPELINED) begin : g_hd_pipeline
        reg [10:0] x1,y1,x2,y2,x2a,y2a,x3,y3,x4,y4,x5,y5;
        reg de1,de2,de2a,de3,de4,de5;
        reg [23:0] rgb1,rgb2,rgb2a,rgb3,rgb4,rgb5;
        always @(posedge clk or posedge rst) begin
            if (rst) begin
                x1<=0; y1<=0; de1<=0; rgb1<=0;
                x2<=0; y2<=0; de2<=0; rgb2<=0;
                x2a<=0; y2a<=0; de2a<=0; rgb2a<=0;
                x3<=0; y3<=0; de3<=0; rgb3<=0;
                x4<=0; y4<=0; de4<=0; rgb4<=0;
                x5<=0; y5<=0; de5<=0; rgb5<=0;
            end else begin
                x1<=pixel_x; y1<=pixel_y; de1<=de; rgb1<=selected_rgb;
                x2<=x1; y2<=y1; de2<=de1; rgb2<=processed_rgb;
                x2a<=x2; y2a<=y2; de2a<=de2; rgb2a<=rgb2;
                x3<=x2a; y3<=y2a; de3<=de2a; rgb3<=faded_rgb;
                x4<=x3; y4<=y3; de4<=de3; rgb4<=osd_rgb;
                x5<=x4; y5<=y4;
                de5<=de4; rgb5<=scroll_rgb;
            end
        end
        assign effect_x=x1; assign effect_y=y1; assign effect_de=de1;
        assign effect_input=rgb1;
        assign overlay_x=x2a; assign overlay_y=y2a; assign overlay_de=de2a;
        assign overlay_input=rgb2a;
        assign osd_x=x3; assign osd_y=y3; assign osd_de=de3;
        assign osd_input=rgb3;
        assign scroll_x=x4; assign scroll_y=y4; assign scroll_de=de4;
        assign scroll_input=rgb4;
        assign axis_x=x5; assign axis_y=y5; assign axis_de=de5;
        assign axis_rgb=rgb5;
    end else begin : g_sd_direct
        assign effect_x=pixel_x; assign effect_y=pixel_y; assign effect_de=de;
        assign effect_input=selected_rgb;
        assign overlay_x=pixel_x; assign overlay_y=pixel_y; assign overlay_de=de;
        assign overlay_input=processed_rgb;
        assign osd_x=pixel_x; assign osd_y=pixel_y; assign osd_de=de;
        assign osd_input=faded_rgb;
        assign scroll_x=pixel_x; assign scroll_y=pixel_y; assign scroll_de=de;
        assign scroll_input=osd_rgb;
        assign axis_x=pixel_x; assign axis_y=pixel_y; assign axis_de=de;
        assign axis_rgb=scroll_rgb;
    end endgenerate

    video_timing #(
        .H_ACTIVE(FRAME_WIDTH), .H_FRONT(H_FRONT), .H_SYNC(H_SYNC),
        .H_BACK(H_BACK), .V_ACTIVE(FRAME_HEIGHT), .V_FRONT(V_FRONT),
        .V_SYNC(V_SYNC), .V_BACK(V_BACK)
    ) u_video_timing (
        
        .clk     (clk),
        .rst     (rst),
        .h_count (h_count),
        .v_count (v_count),
        .x       (pixel_x),
        .y       (pixel_y),
        .hs      (hsync),
        .vs      (vsync),
        .de      (de)
    );

    // Equivalent to the old source=media, effect=off production path.
    assign selected_rgb=de ? frame_rgb : 24'd0;
    assign processed_rgb=effect_input;
    transition_effect #(.FRAME_WIDTH(FRAME_WIDTH),
        .FRAME_HEIGHT(FRAME_HEIGHT)) u_transition_effect (
        
        .x(overlay_x), .y(overlay_y),
        .rgb_in(overlay_input), .level(fade_level),
        .style(transition_style), .rgb_out(faded_rgb)
    );
    assign osd_rgb=osd_input;
    assign scroll_rgb=scroll_input;
    assign axis_x_out=axis_x;
    assign axis_y_out=axis_y;

    video_rgb_to_axis #(.FRAME_WIDTH(FRAME_WIDTH)) u_video_rgb_to_axis (
        
        .clk        (clk),
        .rst        (rst),
        .x          (axis_x),
        .y          (axis_y),
        .de         (axis_de),
        .rgb_in     (axis_rgb),
        .axis_user  (axis_user),
        .axis_valid (axis_valid),
        .axis_last  (axis_last),
        .axis_data  (axis_data)
    );

endmodule
