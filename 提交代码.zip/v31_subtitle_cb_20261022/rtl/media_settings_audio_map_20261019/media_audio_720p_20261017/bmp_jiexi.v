// Part 3: bounded, uncompressed 24-bit BMP byte stream to RGB888.
// Verilog-2001. All ports use clk. Pixels are provisional until result_code=0.
`default_nettype none
module bmp_jiexi #(parameter TRUST_HEADER_OFFSET=0) (
    input wire clk,
    input wire rst,
    input wire start_valid,
    output wire start_ready,
    input wire [31:0] file_length,
    input wire [31:0] file_pixel_offset,
    input wire [15:0] file_index,
    input wire [7:0] byte_data,
    input wire byte_valid,
    output wire byte_ready,
    input wire byte_last,       // Last FILE byte, not last byte of a sector.
    input wire source_error,   // Immediate error, including late sector CRC failure.
    input wire abort,
    input wire finish_valid,   // Loader confirms all requested reads/CRCs succeeded.
    output wire finish_ready,
    output wire frame_valid,
    input wire frame_ready,
    output wire [15:0] frame_width,
    output wire [15:0] frame_height,
    output wire frame_bottom_up,
    output wire [15:0] frame_index,
    output reg pixel_valid,
    input wire pixel_ready,
    output reg [23:0] pixel_rgb,
    output reg [15:0] pixel_x,
    output reg [15:0] pixel_y,   // Top-origin coordinates.
    output reg pixel_last,
    output wire busy,
    output wire result_valid,
    input wire result_ready,
    output reg [3:0] result_code, // 0 success,1 format/index,2 stream length,3 IO,4 abort
    output wire [15:0] result_index
);
    localparam [3:0] IDLE=0, HEADER=1, CHECK=2, DESCRIPTOR=3,
                     SKIP=4, PIXELS=5, TAIL=6, FINISH=7, RESULT=8,
                     ROW_PAD=9, CALC_STRIDE=10, CALC_BYTES=11, CALC_EXTENT=12;
    reg [3:0] state;
    // Only three BMP fields need to survive the header phase. Check the
    // fixed-format fields as bytes arrive instead of building a 432-bit
    // register with a variable byte write port.
    reg [31:0] header_length, header_offset, image_bytes;
    reg [15:0] source_width, source_height;
    reg [31:0] row_stride_reg, pixel_bytes;
    reg [32:0] pixel_end_reg;
    reg header_fields_ok;
    reg [31:0] source_pixels_reg, last_source_index;
    reg header_bad;
    reg [31:0] length_reg, offset_reg, position;
    reg [15:0] index_reg, x, row;
    reg [21:0] pixel_count;
    reg [1:0] component;
    reg [1:0] padding_remaining;
    reg [7:0] blue, green;
    wire active = (state != IDLE) && (state != RESULT);
    wire [31:0] source_pixels = {16'd0,source_width} * {16'd0,source_height};
    wire [31:0] row_bytes = {16'd0,source_width} +
                            ({16'd0,source_width} << 1);
    wire [31:0] row_stride = (row_bytes + 32'd3) & 32'hfffffffc;
    wire [1:0] row_padding = 2'd0-row_bytes[1:0];
    wire [32:0] pixel_end = {1'b0,header_offset} + {1'b0,pixel_bytes};
    wire dimensions_ok = source_width!=0 && source_width<=16'd2048 &&
                         source_height!=0 && source_height<=16'd1536;
    wire final_source_pixel = {10'd0,pixel_count} == last_source_index;
    wire header_fields_match = !header_bad &&
        dimensions_ok && (image_bytes == 0 || image_bytes == pixel_bytes) &&
        header_offset >= 54 &&
        header_length == length_reg && (TRUST_HEADER_OFFSET || header_offset == offset_reg);
    wire header_ok = header_fields_ok && pixel_end_reg <= {1'b0,header_length};

    assign start_ready = !rst && state == IDLE;
    assign byte_ready = !rst && !abort && !source_error &&
        ((state == HEADER) || (state == SKIP) || (state == TAIL) ||
         (state == ROW_PAD) ||
         ((state == PIXELS) && !pixel_valid));
    assign frame_valid = !rst && !abort && !source_error && state == DESCRIPTOR;
    assign frame_width = source_width;
    assign frame_height = source_height;
    assign frame_bottom_up = 1'b1;
    assign frame_index = index_reg;
    assign finish_ready = !rst && !abort && !source_error &&
                          state == FINISH && !pixel_valid;
    assign busy = !rst && active;
    assign result_valid = !rst && state == RESULT;
    assign result_index = index_reg;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= IDLE;
            header_length <= 0; header_offset <= 0;
            image_bytes <= 0; header_bad <= 0;
            source_width <= 0; source_height <= 0;
            row_stride_reg <= 0; pixel_bytes <= 0;
            pixel_end_reg <= 0; header_fields_ok <= 0;
            source_pixels_reg <= 0; last_source_index <= 0;
            length_reg <= 0; offset_reg <= 0; position <= 0; index_reg <= 0;
            x <= 0; row <= 0; pixel_count <= 0; component <= 0;
            padding_remaining <= 0;
            blue <= 0; green <= 0;
            pixel_valid <= 0; pixel_rgb <= 0; pixel_x <= 0; pixel_y <= 0;
            pixel_last <= 0; result_code <= 0;
        end else begin
            if (pixel_valid && pixel_ready) begin
                pixel_valid <= 0;
                pixel_last <= 0;
            end
            // Cancellation explicitly invalidates any outstanding provisional pixel.
            if (active && (source_error || abort)) begin
                state <= RESULT;
                result_code <= source_error ? 4'd3 : 4'd4;
                pixel_valid <= 0;
                pixel_last <= 0;
            end else if (byte_valid && byte_ready &&
                         (byte_last != (position == length_reg - 1'b1))) begin
                state <= RESULT; result_code <= 4'd2;
                pixel_valid <= 0; pixel_last <= 0;
            end else begin
                case (state)
                    IDLE: if (start_valid && start_ready) begin
                        length_reg <= file_length; offset_reg <= file_pixel_offset;
                        index_reg <= file_index; position <= 0;
                        header_length <= 0; header_offset <= 0;
                        image_bytes <= 0; header_bad <= 0;
                        source_width <= 0; source_height <= 0;
                        x <= 0; row <= 0; pixel_count <= 0; component <= 0;
                        padding_remaining <= 0;
                        pixel_valid <= 0; pixel_last <= 0; result_code <= 0;
                        if (file_length < 54) begin
                            state <= RESULT; result_code <= 4'd2;
                        end else state <= HEADER;
                    end
                    HEADER: if (byte_valid && byte_ready) begin
                        case (position[5:0])
                            6'd2: header_length[7:0] <= byte_data;
                            6'd3: header_length[15:8] <= byte_data;
                            6'd4: header_length[23:16] <= byte_data;
                            6'd5: header_length[31:24] <= byte_data;
                            6'd10: header_offset[7:0] <= byte_data;
                            6'd11: header_offset[15:8] <= byte_data;
                            6'd12: header_offset[23:16] <= byte_data;
                            6'd13: header_offset[31:24] <= byte_data;
                            6'd34: image_bytes[7:0] <= byte_data;
                            6'd35: image_bytes[15:8] <= byte_data;
                            6'd36: image_bytes[23:16] <= byte_data;
                            6'd37: image_bytes[31:24] <= byte_data;
                            6'd18: source_width[7:0] <= byte_data;
                            6'd19: source_width[15:8] <= byte_data;
                            6'd22: source_height[7:0] <= byte_data;
                            6'd23: source_height[15:8] <= byte_data;
                            6'd0: if (byte_data != 8'h42) header_bad <= 1'b1;
                            6'd1: if (byte_data != 8'h4d) header_bad <= 1'b1;
                            6'd14: if (byte_data != 8'd40) header_bad <= 1'b1;
                            6'd26: if (byte_data != 8'h01) header_bad <= 1'b1;
                            6'd28: if (byte_data != 8'h18) header_bad <= 1'b1;
                            6'd6, 6'd7, 6'd8, 6'd9,
                            6'd15, 6'd16, 6'd17,
                            6'd20, 6'd21, 6'd24, 6'd25,
                            6'd27, 6'd29,
                            6'd30, 6'd31, 6'd32, 6'd33,
                            6'd46, 6'd47, 6'd48, 6'd49:
                                if (byte_data != 8'd0) header_bad <= 1'b1;
                            default: begin end
                        endcase
                        position <= position + 1'b1;
                        if (position == 53) state <= CALC_STRIDE;
                    end
                    // Split stride rounding, multiplication and extent checks
                    // across clocks. BYTE_READY stays low while validating.
                    CALC_STRIDE: begin
                        row_stride_reg <= row_stride;
                        source_pixels_reg <= source_pixels;
                        state <= CALC_BYTES;
                    end
                    CALC_BYTES: begin
                        pixel_bytes <= row_stride_reg * {16'd0,source_height};
                        // Dimensions are stable after HEADER. Precompute this
                        // boundary once, not a multiply/subtract per pixel.
                        last_source_index <= source_pixels_reg - 32'd1;
                        state <= CALC_EXTENT;
                    end
                    CALC_EXTENT: begin
                        // Separate the 33-bit end-address addition from the
                        // bounds comparison; preserve carry for overflow rejection.
                        pixel_end_reg <= pixel_end;
                        header_fields_ok <= header_fields_match;
                        if(TRUST_HEADER_OFFSET)offset_reg<=header_offset;
                        state <= CHECK;
                    end
                    CHECK: begin
                        if (header_ok) state <= DESCRIPTOR;
                        else begin state <= RESULT; result_code <= 4'd1; end
                    end
                    DESCRIPTOR: if (frame_valid && frame_ready)
                        state <= (position == offset_reg) ? PIXELS : SKIP;
                    SKIP: if (byte_valid && byte_ready) begin
                        position <= position + 1'b1;
                        if (position + 1'b1 == offset_reg) state <= PIXELS;
                    end
                    PIXELS: if (byte_valid && byte_ready) begin
                        position <= position + 1'b1;
                        case (component)
                            0: begin blue <= byte_data; component <= 1; end
                            1: begin green <= byte_data; component <= 2; end
                            2: begin
                                component <= 0;
                                pixel_rgb <= {byte_data,green,blue};
                                pixel_x <= x; pixel_y <= source_height - 1'b1 - row;
                                pixel_valid <= 1;
                                pixel_last <= final_source_pixel;
                                pixel_count <= pixel_count + 1'b1;
                                if (x == source_width-1'b1) begin
                                    x <= 0; row <= row + 1'b1;
                                    if (row_padding!=0) begin
                                        padding_remaining <= row_padding;
                                        state <= ROW_PAD;
                                    end else if (final_source_pixel)
                                        state <= byte_last ? FINISH : TAIL;
                                end else x <= x + 1'b1;
                            end
                            default: begin state <= RESULT; result_code <= 4'd1; end
                        endcase
                    end
                    ROW_PAD: if (byte_valid && byte_ready) begin
                        position <= position + 1'b1;
                        padding_remaining <= padding_remaining - 1'b1;
                        if (padding_remaining == 2'd1) begin
                            if ({10'd0,pixel_count} == source_pixels)
                                state <= byte_last ? FINISH : TAIL;
                            else state <= PIXELS;
                        end
                    end
                    TAIL: if (byte_valid && byte_ready) begin
                        position <= position + 1'b1;
                        if (byte_last) state <= FINISH;
                    end
                    FINISH: if (finish_valid && finish_ready) begin
                        state <= RESULT; result_code <= 0;
                    end
                    RESULT: if (result_valid && result_ready) state <= IDLE;
                    default: begin state <= RESULT; result_code <= 4'd1; end
                endcase
            end
        end
    end
endmodule
`default_nettype wire
