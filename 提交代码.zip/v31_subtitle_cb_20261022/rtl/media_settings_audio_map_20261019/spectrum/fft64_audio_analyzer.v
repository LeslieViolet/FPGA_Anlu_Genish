`default_nettype none
// 64 real samples, decimated Hann window, in-place radix-2 DIT.
// One shared signed multiplier. PCM and all controls belong to clk's domain.
// Nominal input: 48kHz enables at 25MHz or75MHz, not a held-high valid level.
module fft64_audio_analyzer(
    input wire clk,rst,audio_running,sample_valid,
    input wire signed [15:0] sample_data,
    output reg [127:0] levels,
    output reg levels_valid,overrun,
    output wire busy,
    output reg bin_valid,
    output reg [7:0] bin_index,
    output reg signed [15:0] bin_real,bin_imag
);
    localparam [4:0] IDLE=0,LD_REQ=1,LD_OP=2,LD_WAIT=3,LD_WRITE=4,
        RA=5,RB=6,OP0=7,OP1=8,OP2=9,OP3=10,PRODUCTS=11,
        SUM=12,SCALE=13,WA=14,WB=15,SCAN_REQ=16,SCAN_EVAL=17,
        SCAN_UPDATE=18,DONE=19,SCAN_MAG=20,SCAN_LOG=21;
    reg [4:0] state;
    reg [7:0] capture_index,load_index,a_addr,b_addr,half_span,twiddle_step;
    reg [6:0] butterfly,twiddle_index;
    reg [3:0] stage;
    reg [7:0] scan_index,scan_height;
    reg [3:0] scan_band;
    reg [3:0] peak_band;
    reg [7:0] band_peak;
    reg [15:0] abs_real_q,abs_imag_q;
    reg [16:0] magnitude_q;
    reg [127:0] work_levels;
    reg signed [15:0] ar,ai,br,bi,wr,wi,mul_a,mul_b;
    reg signed [31:0] mul_result,p0,p1,p2;
    reg signed [32:0] tr,ti;
    reg signed [17:0] tr_scaled,ti_scaled;
    // TD SWUG106 section 4.2.6: keep these synchronous memories in BRAM
    // rather than using the nearly full slice array for distributed RAM.
    (* ram_style="bram_9k" *) reg [15:0] capture_mem[0:63];
    (* ram_style="bram_9k" *) reg [31:0] fft_mem[0:63];
    reg [15:0] capture_q;
    reg [31:0] fft_q;
    reg [5:0] fft_addr; // 64 entries: expose exactly six address bits to RAM inference.
    reg [31:0] fft_din;
    reg fft_we;
    reg [8:0] coeff_addr;
    wire signed [15:0] coeff_q;
    wire capture_take=sample_valid&&audio_running&&!rst;
    wire capture_full=capture_take&&capture_index==8'd63;
    // Abort instead of publishing a frame if an invalid too-fast source can
    // overwrite capture data before its windowed copy has consumed it.
    wire load_collision=capture_take&&state>=LD_REQ&&state<=LD_WRITE&&capture_index>=load_index;
    assign busy=state!=IDLE;

    audio_spectrum_coeff_rom u_coeff(.clk(clk),.addr(coeff_addr),.data(coeff_q));
    function [7:0] bit_reverse;
        input [7:0] value;
        begin bit_reverse={2'b0,value[0],value[1],value[2],value[3],value[4],value[5]};end
    endfunction

    // Sixteen bands from the 32 positive-frequency bins of the 64-point FFT.
    function [3:0] band_of_scan;
        input [7:0] index;
        begin
            if (index <= 1) band_of_scan=0;
            else if (index <= 2) band_of_scan=1;
            else if (index <= 3) band_of_scan=2;
            else if (index <= 4) band_of_scan=3;
            else if (index <= 5) band_of_scan=4;
            else if (index <= 6) band_of_scan=5;
            else if (index <= 7) band_of_scan=6;
            else if (index <= 8) band_of_scan=7;
            else if (index <= 9) band_of_scan=8;
            else if (index <= 10) band_of_scan=9;
            else if (index <= 12) band_of_scan=10;
            else if (index <= 14) band_of_scan=11;
            else if (index <= 17) band_of_scan=12;
            else if (index <= 21) band_of_scan=13;
            else if (index <= 26) band_of_scan=14;
            else band_of_scan=15;
        end
    endfunction
    function [15:0] saturate16;
        input signed [18:0] value;
        begin
            if(value>19'sd32767)saturate16=16'h7fff;
            else if(value< -19'sd32768)saturate16=16'h8000;
            else saturate16=value[15:0];
        end
    endfunction
    wire signed [18:0] ar_plus=$signed({{3{ar[15]}},ar})+$signed({tr_scaled[17],tr_scaled});
    wire signed [18:0] ai_plus=$signed({{3{ai[15]}},ai})+$signed({ti_scaled[17],ti_scaled});
    wire signed [18:0] ar_minus=$signed({{3{ar[15]}},ar})-$signed({tr_scaled[17],tr_scaled});
    wire signed [18:0] ai_minus=$signed({{3{ai[15]}},ai})-$signed({ti_scaled[17],ti_scaled});
    wire signed [18:0] window_scaled=$signed(mul_result)>>>15;
    wire [15:0] abs_real=fft_q[31]?(~fft_q[31:16]+16'd1):fft_q[31:16];
    wire [15:0] abs_imag=fft_q[15]?(~fft_q[15:0]+16'd1):fft_q[15:0];
    wire [16:0] magnitude={1'b0,abs_real}+{1'b0,abs_imag};
    // Log2-like height: three fractional bits, fixed noise floor, cap96.
    // L1 magnitude avoids a square root/multiplier; not calibrated dB/SPL.
    function [7:0] magnitude_height;
        input [16:0] value;
        integer k;
        reg [7:0] h;
        begin
            h=0;
            for(k=3;k<=16;k=k+1)
                if(value[k])h=(k-3)*8+((value>>(k-3))&7);
            magnitude_height=h>96?8'd96:h;
        end
    endfunction

    // No RAM reset: every FFT location is written before its first read.
    always @(posedge clk) begin
        // Both counters stay in 0..63. Wider algorithm counters must not
        // create out-of-range read/write decoders around the physical RAM.
        if(capture_take)capture_mem[capture_index[5:0]]<=sample_data;
        capture_q<=capture_mem[load_index[5:0]];
        if(fft_we&&!load_collision)fft_mem[fft_addr]<=fft_din;
        fft_q<=fft_mem[fft_addr];
        mul_result<=$signed(mul_a)*$signed(mul_b);
    end
    // This scratch bank is never observable until DONE. IDLE clears it before
    // every transform, so an asynchronous reset only adds reset-tree fanout.
    always @(posedge clk) begin
        if (!rst) begin
            if (!audio_running) work_levels <= 0;
            else if (!load_collision) begin
                if (state == IDLE && capture_full) work_levels <= 0;
                else if (state == SCAN_UPDATE && scan_band != peak_band)
                    work_levels <= {band_peak,work_levels[127:8]};
            end
        end
    end
    always @* begin
        coeff_addr={1'b0,load_index[5:0],2'b0};
        fft_addr=0;fft_din=0;fft_we=0;
        case(state)
            LD_WRITE:begin fft_addr=bit_reverse(load_index);fft_din={saturate16(window_scaled),16'd0};fft_we=1;end
            RA:begin fft_addr=a_addr;coeff_addr=9'd256+{1'b0,twiddle_index,1'b0};end
            RB:begin fft_addr=b_addr;coeff_addr=9'd384+{1'b0,twiddle_index,1'b0};end
            WA:begin fft_addr=a_addr;fft_din={saturate16(ar_plus>>>1),saturate16(ai_plus>>>1)};fft_we=1;end
            WB:begin fft_addr=b_addr;fft_din={saturate16(ar_minus>>>1),saturate16(ai_minus>>>1)};fft_we=1;end
            SCAN_REQ:fft_addr=scan_index;
            default:begin end
        endcase
    end
    always @(posedge clk or posedge rst) begin
        if(rst)capture_index<=0;
        else if(!audio_running)capture_index<=0;
        else if(capture_take)capture_index<=capture_index==63?8'd0:capture_index+1'b1;
    end
    always @(posedge clk or posedge rst) begin
        if(rst)begin
            state<=IDLE;load_index<=0;a_addr<=0;b_addr<=1;half_span<=1;twiddle_step<=64;
            butterfly<=0;twiddle_index<=0;stage<=1;scan_index<=1;scan_height<=0;scan_band<=0;
            peak_band<=0;band_peak<=0;abs_real_q<=0;abs_imag_q<=0;magnitude_q<=0;
            levels<=0;levels_valid<=0;overrun<=0;
            ar<=0;ai<=0;br<=0;bi<=0;wr<=0;wi<=0;mul_a<=0;mul_b<=0;
            p0<=0;p1<=0;p2<=0;tr<=0;ti<=0;tr_scaled<=0;ti_scaled<=0;
            bin_valid<=0;bin_index<=0;bin_real<=0;bin_imag<=0;
        end else begin
            levels_valid<=0;bin_valid<=0;
            if(!audio_running)begin
                state<=IDLE;levels<=0;overrun<=0;
            end else if(load_collision)begin
                state<=IDLE;overrun<=1;
            end else begin
                if(capture_full&&state!=IDLE)overrun<=1;
                case(state)
                    IDLE:if(capture_full)begin load_index<=0;peak_band<=0;band_peak<=0;state<=LD_REQ;end
                    LD_REQ:state<=LD_OP;
                    LD_OP:begin mul_a<=capture_q;mul_b<=coeff_q;state<=LD_WAIT;end
                    LD_WAIT:state<=LD_WRITE;
                    LD_WRITE:if(load_index==63)begin
                        stage<=1;half_span<=1;twiddle_step<=64;twiddle_index<=0;
                        butterfly<=0;a_addr<=0;b_addr<=1;state<=RA;
                    end else begin load_index<=load_index+1'b1;state<=LD_REQ;end
                    RA:state<=RB;
                    RB:begin ar<=fft_q[31:16];ai<=fft_q[15:0];wr<=coeff_q;state<=OP0;end
                    OP0:begin
                        br<=fft_q[31:16];bi<=fft_q[15:0];wi<=coeff_q;
                        mul_a<=fft_q[31:16];mul_b<=wr;state<=OP1;
                    end
                    OP1:begin mul_a<=bi;mul_b<=wi;state<=OP2;end
                    OP2:begin p0<=mul_result;mul_a<=br;mul_b<=wi;state<=OP3;end
                    OP3:begin p1<=mul_result;mul_a<=bi;mul_b<=wr;state<=PRODUCTS;end
                    PRODUCTS:begin p2<=mul_result;state<=SUM;end
                    SUM:begin
                        tr<=$signed({p0[31],p0})-$signed({p1[31],p1});
                        ti<=$signed({p2[31],p2})+$signed({mul_result[31],mul_result});state<=SCALE;
                    end
                    SCALE:begin tr_scaled<=tr>>>15;ti_scaled<=ti>>>15;state<=WA;end
                    WA:state<=WB;
                    WB:begin
                        if(butterfly==31)begin
                            if(stage==6)begin scan_index<=1;state<=SCAN_REQ;end
                            else begin
                                stage<=stage+1'b1;half_span<=half_span<<1;twiddle_step<=twiddle_step>>1;
                                a_addr<=0;b_addr<=half_span<<1;twiddle_index<=0;butterfly<=0;state<=RA;
                            end
                        end else begin
                            butterfly<=butterfly+1'b1;
                            if((a_addr&(half_span-1'b1))==half_span-1'b1)begin
                                a_addr<=b_addr+1'b1;b_addr<=b_addr+1'b1+half_span;twiddle_index<=0;
                            end else begin
                                a_addr<=a_addr+1'b1;b_addr<=b_addr+1'b1;twiddle_index<=twiddle_index+twiddle_step;
                            end
                            state<=RA;
                        end
                    end
                    SCAN_REQ:state<=SCAN_EVAL;
                    SCAN_EVAL:begin
                        abs_real_q<=abs_real;abs_imag_q<=abs_imag;
                        bin_valid<=1;bin_index<=scan_index;bin_real<=fft_q[31:16];bin_imag<=fft_q[15:0];state<=SCAN_MAG;
                    end
                    SCAN_MAG:begin magnitude_q<={1'b0,abs_real_q}+{1'b0,abs_imag_q};state<=SCAN_LOG;end
                    SCAN_LOG:begin scan_height<=magnitude_height(magnitude_q);
                        scan_band<=band_of_scan(scan_index);state<=SCAN_UPDATE;end
                    SCAN_UPDATE:begin
                        // Bands are monotonic; shift one completed band at a boundary.
                        if(scan_band!=peak_band)begin
                            peak_band<=scan_band;band_peak<=scan_height;
                        end else if(scan_height>band_peak)band_peak<=scan_height;
                        if(scan_index==32)state<=DONE;
                        else begin scan_index<=scan_index+1'b1;state<=SCAN_REQ;end
                    end
                    DONE:begin levels<={band_peak,work_levels[127:8]};levels_valid<=1;state<=IDLE;end
                    default:state<=IDLE;
                endcase
            end
        end
    end
endmodule
`default_nettype wire
