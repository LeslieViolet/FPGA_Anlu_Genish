// Thin wrapper around Anlogic Soft FIFO 3.0.
// Production builds use the encrypted vendor core. B_FANGZHEN selects the
// explicitly simulation-only model used by this part's self-checking testbench.
`timescale 1ns/1ps
`default_nettype none
module guanfang_yibu_fifo #(
    parameter DATA_WIDTH = 32,
    parameter MEMORY_TYPE = 0,
    parameter ADDR_WIDTH = 9,
    parameter ALMOST_FULL_LEVEL = 496,
    parameter ALMOST_EMPTY_LEVEL = 4
)(
    input  wire                  rst,
    input  wire                  wr_clk,
    input  wire                  wr_en,
    input  wire [DATA_WIDTH-1:0] wr_data,
    output wire                  full,
    output wire                  almost_full,
    output wire [ADDR_WIDTH:0]   wr_usedw,
    output wire                  overflow,
    input  wire                  rd_clk,
    input  wire                  rd_en,
    output wire [DATA_WIDTH-1:0] rd_data,
    output wire                  empty,
    output wire                  almost_empty,
    output wire                  valid,
    output wire [ADDR_WIDTH:0]   rd_usedw,
    output wire                  underflow
);
    // Explicit, auditable async-assert / synchronous-release reset per domain.
    // Do not drive a domain's core reset directly from the other domain's reset.
    (* async_reg = "true" *) reg [3:0] wr_release, rd_release;
    always @(posedge wr_clk or posedge rst) begin
        if(rst) wr_release<=4'b1111;
        else wr_release<={wr_release[2:0],1'b0};
    end
    always @(posedge rd_clk or posedge rst) begin
        if(rst) rd_release<=4'b1111;
        else rd_release<={rd_release[2:0],1'b0};
    end
    wire core_full, core_empty, core_valid;
    wire core_we = wr_en && !wr_release[3];
    wire core_re = rd_en && !rd_release[3];
    assign full = core_full || wr_release[3];
    assign empty = core_empty || rd_release[3];
    assign valid = core_valid && !rd_release[3];
`ifdef B_FANGZHEN
    fangzhen_yibu_fifo #(
        .DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(ADDR_WIDTH),
        .ALMOST_FULL_LEVEL(ALMOST_FULL_LEVEL),
        .ALMOST_EMPTY_LEVEL(ALMOST_EMPTY_LEVEL)
    ) u_fifo (
        .rst(rst), .wr_clk(wr_clk), .wr_en(core_we), .wr_data(wr_data),
        .full(core_full), .almost_full(almost_full), .wr_usedw(wr_usedw),
        .overflow(overflow), .rd_clk(rd_clk), .rd_en(core_re),
        .rd_data(rd_data), .empty(core_empty), .almost_empty(almost_empty),
        .valid(core_valid), .rd_usedw(rd_usedw), .underflow(underflow)
    );
`else
    wire wr_success;
    wire wr_rst_done;
    wire rd_rst_done;
    soft_fifo #(
        .COMMON_CLK_EN(0),
        .MEMORY_TYPE(MEMORY_TYPE),
        .RST_TYPE(1),
        .DATA_WIDTH_W(DATA_WIDTH),
        .ADDR_WIDTH_W(ADDR_WIDTH),
        .DATA_WIDTH_R(DATA_WIDTH),
        .ADDR_WIDTH_R(ADDR_WIDTH),
        .DOUT_INITVAL({DATA_WIDTH{1'b0}}),
        .OUTREG_EN(0),
        .SHOW_AHEAD_EN(1),
        .AL_FULL_NUM(ALMOST_FULL_LEVEL),
        .AL_EMPTY_NUM(ALMOST_EMPTY_LEVEL),
        .RDUSEDW_WIDTH(ADDR_WIDTH+1),
        .WRUSEDW_WIDTH(ADDR_WIDTH+1),
        .ASYNC_RST_SYNC_RELS(0),
        .SYNC_STAGE(2)
    ) u_fifo (
        .rst(1'b0), .srst(1'b0), .wrst(wr_release[3]), .rrst(rd_release[3]),
        .clk(1'b0), .clkw(wr_clk), .clkr(rd_clk),
        .di(wr_data), .we(core_we), .re(core_re), .dout(rd_data),
        .empty_flag(core_empty), .aempty(almost_empty),
        .full_flag(core_full), .afull(almost_full), .valid(core_valid),
        .overflow(overflow), .underflow(underflow),
        .wr_success(wr_success), .rdusedw(rd_usedw), .wrusedw(wr_usedw),
        .wr_rst_done(wr_rst_done), .rd_rst_done(rd_rst_done)
    );
`endif
endmodule
`default_nettype wire

