`timescale 1ns/1ps
module tb_subtitle_pixels;
 reg clk_pixel=0,rst_pixel=1,enabled=1;always #5 clk_pixel=~clk_pixel;
 reg [95:0] ui_status_payload_pixel=0;
 wire [95:0] baseline_status=ui_status_payload_pixel&~(96'd1<<77);
 reg bgm_visualizer_enable=0;reg [3:0] bgm_level_left=0,bgm_level_right=0;
 reg [10:0] x=0,y=0;reg [23:0] rgb_in=0;
 reg user_in=0,last_in=0,valid_in=0,wallpaper_valid=0;
 wire axis_tx_user,axis_tx_last,axis_tx_valid;wire [23:0] axis_tx_data;
 wire old_user,old_last,old_valid;wire [23:0] old_rgb;
 ui_media_compositor dut(.*);
 baseline_ui_media_compositor baseline(.clk_pixel(clk_pixel),.rst_pixel(rst_pixel),.enabled(enabled),
 .ui_status_payload_pixel(baseline_status),.bgm_visualizer_enable(1'b0),.bgm_level_left(4'd0),.bgm_level_right(4'd0),
 .x(x),.y(y),.rgb_in(rgb_in),.user_in(user_in),.last_in(last_in),.valid_in(valid_in),.wallpaper_valid(wallpaper_valid),
 .axis_tx_user(old_user),.axis_tx_last(old_last),.axis_tx_valid(old_valid),.axis_tx_data(old_rgb));
 reg [15:0] raw[0:511];
 reg [2:0] tuple[0:3];reg mask[0:3];reg [23:0] color[0:3];
 integer phrase=0,left_edge=528,width=224,xx,yy,rel,cell_index,row_index,col_index,addr;
 integer ddx,ddy,near_on,rr,cc,base,fg,palette,glyph_base;
 integer checks=0,ink_checks=0,outline_checks=0,background_checks=0,fd=0;
 reg running=0;
 initial $readmemh("subtitle_ink.hex",raw);
 always @(posedge clk_pixel)begin
  for(integer z=3;z>0;z--)begin tuple[z]=tuple[z-1];mask[z]=mask[z-1];color[z]=color[z-1];end
  tuple[0]={user_in,last_in,valid_in};mask[0]=0;color[0]=0;
  rel=x-left_edge;
  if(enabled&&ui_status_payload_pixel[77]&&ui_status_payload_pixel[63:60]==2&&valid_in&&x>=320&&x<960&&y>=24&&y<56&&rel>=0&&rel<width)begin
   cell_index=rel/32;row_index=(y-24)/2;col_index=(rel%32)/2;
   glyph_base=phrase==0?0:phrase==1?7:18;
   addr=(glyph_base+cell_index)*16+row_index;fg=raw[addr][15-col_index];near_on=0;
   for(ddy=-1;ddy<=1;ddy=ddy+1)for(ddx=-1;ddx<=1;ddx=ddx+1)begin
    rr=row_index+ddy;cc=col_index+ddx;
    if(rr>=0&&rr<16&&cc>=0&&cc<16)near_on=near_on|raw[(glyph_base+cell_index)*16+rr][15-cc];
   end
   if(fg)begin
    mask[0]=1;color[0]=24'hfff7e8;
    if(phrase==1)begin if(cell_index<6)color[0]=24'hffd166;else if(cell_index>=7)color[0]=24'hffb6a2;end
    ink_checks=ink_checks+1;
   end else if(near_on)begin mask[0]=1;color[0]=24'h302337;outline_checks=outline_checks+1;end
  end
  #1;
  if(running)begin
   if({axis_tx_user,axis_tx_last,axis_tx_valid}!==tuple[3])$fatal(1,"four-cycle tuple mismatch");
   if({axis_tx_user,axis_tx_last,axis_tx_valid}!=={old_user,old_last,old_valid})$fatal(1,"baseline control mismatch");
   if(axis_tx_valid)begin
    if(mask[3])begin if(axis_tx_data!==color[3])$fatal(1,"caption pixel got %h want %h",axis_tx_data,color[3]);end
    else begin
     if(axis_tx_data!==old_rgb)$fatal(1,"transparent/background pixel got %h baseline %h",axis_tx_data,old_rgb);
     background_checks=background_checks+1;
    end
    checks=checks+1;
    if(fd)$fwrite(fd,"%c%c%c",axis_tx_data[23:16],axis_tx_data[15:8],axis_tx_data[7:0]);
   end
  end
 end
 task frame(input integer p,input bit show,input bit hud,input bit settings);
  begin
   @(negedge clk_pixel);valid_in=0;user_in=0;last_in=0;repeat(8)@(negedge clk_pixel);
   phrase=p;width=p==0?224:p==1?352:288;left_edge=(1280-width)/2;
   force dut.u_promo_marquee.phrase_id=phrase;
   force dut.u_promo_marquee.scroll_offset=1584;
   ui_status_payload_pixel[77]=show;ui_status_payload_pixel[15]=hud;
   ui_status_payload_pixel[63:60]=settings?3:2;
   if(show&&!settings)begin fd=$fopen($sformatf("caption_%0d.ppm",p),"wb");$fwrite(fd,"P6\n1280 720\n255\n");end
   for(yy=0;yy<720;yy=yy+1)begin
    for(xx=0;xx<1280;xx=xx+1)begin
     x=xx;y=yy;valid_in=1;user_in=xx==0&&yy==0;last_in=xx==1279;
     rgb_in={8'(40+xx/8),8'(35+yy/5),8'(60+(xx+yy)/14)};
     @(negedge clk_pixel);
     if(xx%128==31)begin valid_in=0;user_in=0;last_in=0;@(negedge clk_pixel);end
    end
    valid_in=0;user_in=0;last_in=0;repeat(3)@(negedge clk_pixel);
   end
   repeat(8)@(negedge clk_pixel);if(fd)begin $fclose(fd);fd=0;end
  end
 endtask
 initial begin
  ui_status_payload_pixel[30:27]=5;ui_status_payload_pixel[13:10]=5;ui_status_payload_pixel[63:60]=2;
  repeat(5)@(negedge clk_pixel);rst_pixel=0;
  repeat(300)@(negedge clk_pixel);user_in=1;valid_in=1;
  @(negedge clk_pixel);user_in=0;valid_in=0;repeat(8)@(negedge clk_pixel);
  if(!dut.parameters_valid)$fatal(1,"color table not committed");running=1;
  frame(0,0,1,0);frame(0,1,1,0);frame(1,1,0,0);frame(2,1,1,0);frame(1,1,1,1);
  if(checks!=4608000||ink_checks<100||outline_checks<100)$fatal(1,"coverage missing");
  $display("SUBTITLE_PIXELS_PASS pixels=%0d ink=%0d outline=%0d unchanged=%0d delay4",checks,ink_checks,outline_checks,background_checks);$finish;
 end
 initial begin #80000000;$fatal(1,"pixel timeout");end
endmodule
