// Passive first-block RGB888 CRC32 observer. Never gates functional traffic.
// CRC is standard reflected IEEE, byte order R, G, B, init/final XOR FFFFFFFF.
// LED bits: started, complete, expected CRC+metadata match, metadata/CRC error.
`timescale 1ns/1ps
`default_nettype none
module xiangsu_crc_zhenduan #(
    parameter [31:0] EXPECTED_CRC=32'd0,
    parameter FRAME_WIDTH=1280,
    parameter FRAME_HEIGHT=720,
    parameter CHECK_WRITE_ADDR=0,
    parameter LAST_MODE=0, // 0 ignore; 1 last frame pixel; 2 last line pixel
    parameter CHECK_USER=0
)(
    input wire clk, rst, take,
    input wire [23:0] rgb,
    input wire [20:0] addr,
    input wire last, user,
    output wire [3:0] flags
);
wire [10:0] frame_width=FRAME_WIDTH;
wire [10:0] frame_height=FRAME_HEIGHT;
    wire [20:0] FRAME_WORDS=FRAME_WIDTH*FRAME_HEIGHT;
    reg [19:0] count;
    reg [10:0] x, y;
    reg selected_slot;
    reg [31:0] crc;
    reg started, complete, match_ok, bad;
    reg final_pending;
    wire [20:0] row_addr=y*frame_width;
    wire [20:0] slot_base=selected_slot ? FRAME_WORDS : 0;
    wire [20:0] expected_addr=row_addr+{10'd0,x}+slot_base;
    wire addr_bad=CHECK_WRITE_ADDR &&
        (count==0 ? (addr!=row_addr && addr!=row_addr+FRAME_WORDS) : addr!=expected_addr);
    wire last_bad=LAST_MODE!=0 && last!=(LAST_MODE==1 ? count==FRAME_WORDS-1 : x==frame_width-1);
    wire user_bad=CHECK_USER && user!=(count==0);
    wire meta_bad=addr_bad || last_bad || user_bad;
    function [31:0] crc_byte;
        input [31:0] previous;
        input [7:0] data;
        reg [31:0] value;
        integer bit_number;
        begin
            value=previous^{24'd0,data};
            for(bit_number=0;bit_number<8;bit_number=bit_number+1)
                value=value[0] ? (value>>1)^32'hedb88320 : value>>1;
            crc_byte=value;
        end
    endfunction
    wire [31:0] next_crc=crc_byte(crc_byte(crc_byte(crc,rgb[23:16]),rgb[15:8]),rgb[7:0]);
    assign flags={bad,match_ok,complete,started};
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            count<=0; x<=0; y<=CHECK_WRITE_ADDR ? frame_height-1 : 0;
            selected_slot<=0; crc<=32'hffffffff;
            started<=0; complete<=0; match_ok<=0; bad<=0;
            final_pending<=0;
        end else if(final_pending) begin
            // Compare the registered final CRC, rather than extending the
            // 24-bit CRC feedback path through a full equality comparator.
            // Passive completion flags become valid one clock later.
            final_pending<=0;
            complete<=1;
            match_ok<=((crc^32'hffffffff)==EXPECTED_CRC) && !bad;
            if((crc^32'hffffffff)!=EXPECTED_CRC) bad<=1;
        end else if(take && !complete) begin
            started<=1;
            crc<=next_crc;
            if(CHECK_WRITE_ADDR && count==0) selected_slot<=addr>=FRAME_WORDS;
            if(meta_bad) bad<=1;
            if(x==frame_width-1) begin
                x<=0;
                if(CHECK_WRITE_ADDR) begin if(y!=0) y<=y-1'b1; end
                else y<=y==frame_height-1 ? 10'd0 : y+1'b1;
            end else x<=x+1'b1;
            if(count==FRAME_WORDS-1) begin
                final_pending<=1;
            end else count<=count+1'b1;
        end
    end
endmodule
`default_nettype wire
