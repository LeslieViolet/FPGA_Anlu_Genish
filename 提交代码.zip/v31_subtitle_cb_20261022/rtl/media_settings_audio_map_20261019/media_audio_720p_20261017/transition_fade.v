// Per-channel 0..16/16 fade. OSD is drawn after this stage and stays legible.
`default_nettype none
module transition_fade (
    input  wire [23:0] rgb_in,
    input  wire [4:0]  level,
    output wire [23:0] rgb_out
);
    // All levels 16..31 clamp to full brightness. Lower levels need only
    // a four-bit multiplier; this removes the clamp from its input path.
    wire [11:0] r = rgb_in[23:16] * level[3:0];
    wire [11:0] g = rgb_in[15:8]  * level[3:0];
    wire [11:0] b = rgb_in[7:0]   * level[3:0];
    assign rgb_out = level[4] ? rgb_in : {r[11:4], g[11:4], b[11:4]};
endmodule
`default_nettype wire
