`default_nettype none

// NEC协议解码模块。
// 本模块不直接采样HX1838引脚，而是接收nec_pulse_measure给出的
// “上一段电平及其持续时钟数”，再识别引导码、数据位和重复帧。
// 以下默认计数值基于50 MHz时钟：1个时钟周期=20 ns。
//大致为多个状态机不断随着接收模块检测的结果进行更新和判断
module nec_decoder #(
    parameter integer T_LEAD_LOW    = 450_000, // 完整帧引导码：9 ms低电平
    parameter integer T_LEAD_HIGH   = 225_000, // 完整帧引导码：4.5 ms高电平
    parameter integer T_REPEAT_HIGH = 112_500, // 重复帧引导码：2.25 ms高电平
    parameter integer T_BIT_LOW     = 28_000,  // 每个数据位固定的560 us低电平
    parameter integer T_ZERO_HIGH   = 28_000,  // 逻辑0对应的560 us高电平
    parameter integer T_ONE_HIGH    = 84_500,  // 逻辑1对应的约1.69 ms高电平
    parameter integer TOL_PCT       = 20       // 脉宽允许误差百分比，当前为±20%
)(
    input  wire        clk,            // 50 MHz系统时钟
    input  wire        rst,            // 高电平有效复位
    input  wire        pulse_valid,    // 新脉宽结果有效，只保持一个时钟周期
    input  wire        pulse_level,    // 刚结束的电平：0=低电平，1=高电平
    input  wire [19:0] pulse_ticks,    // 刚结束的电平持续了多少个50 MHz时钟周期
    input  wire        pulse_overflow, // 脉宽计数器溢出，当前帧应当丢弃
    output reg         event_valid,    // 成功产生按键事件，只保持一个时钟周期
    output reg  [7:0]  event_command,  // 解码得到的8位NEC命令码
    output reg         event_repeat,   // 1=长按重复帧事件，0=完整32位帧事件
    output reg         frame_error     // 帧格式或校验错误，只保持一个时钟周期
);

    // 状态常量
    localparam [2:0] S_IDLE       = 3'd0; // 等待9 ms引导低电平
    localparam [2:0] S_LEAD_HIGH  = 3'd1; // 判断4.5 ms完整帧或2.25 ms重复帧
    localparam [2:0] S_DATA_LOW   = 3'd2; // 检查每位固定的560 us低电平
    localparam [2:0] S_DATA_HIGH  = 3'd3; // 根据高电平时间判断逻辑0或逻辑1
    localparam [2:0] S_STOP_LOW   = 3'd4; // 检查完整帧末尾的560 us低电平
    localparam [2:0] S_REPEAT_LOW = 3'd5; // 检查重复帧末尾的560 us低电平

    reg [2:0]  state;                 // 状态机当前状态
    reg [5:0]  bit_count;             // 当前正在接收第几个数据位，取值0～31
    reg [31:0] data_buf;              // 当前完整帧已接收的32位数据，按NEC的LSB先传顺序存放
    reg [7:0]  pending_command;       // 32位数据已通过反码校验、但尚未验证帧尾时暂存的命令
    reg        pending_command_valid; // 1表示pending_command可在正确帧尾后提交
    reg [7:0]  last_command;          // 最近一次完整且帧尾也正确的命令码
    reg        last_command_valid;    // 1表示last_command有效；重复帧据此重发命令

    // 范围判断函数：value处于nominal的±TOL_PCT范围内时返回1。
    function automatic in_range;
        input [19:0] value;     // 实际测得的时钟周期数
        input integer nominal;  // 要比较的标称时钟周期数
        integer lower;          // 允许范围下限
        integer upper;          // 允许范围上限
        begin
            lower = nominal - (nominal * TOL_PCT / 100);
            upper = nominal + (nominal * TOL_PCT / 100);
            in_range = (value >= lower) && (value <= upper);
        end
    endfunction

    // 时序状态机：所有状态和输出只在clk上升沿更新。
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state              <= S_IDLE;
            bit_count          <= 6'd0;
            data_buf           <= 32'd0;
            pending_command       <= 8'd0;
            pending_command_valid <= 1'b0;
            last_command       <= 8'd0;
            last_command_valid <= 1'b0;
            event_valid        <= 1'b0;
            event_command      <= 8'd0;
            event_repeat       <= 1'b0;
            frame_error        <= 1'b0;
        end else begin
            // 这三个输出是单周期脉冲，每个周期先恢复为0。
            event_valid  <= 1'b0;
            event_repeat <= 1'b0;
            frame_error  <= 1'b0;

            // 溢出可能在没有pulse_valid时发生，因此优先独立处理。
            if (pulse_overflow) begin
                // 正在等待的电平过长，当前帧不再可信。
                state                 <= S_IDLE;
                bit_count             <= 6'd0;
                pending_command_valid <= 1'b0;
                frame_error           <= 1'b1;
            end else if (pulse_valid) begin
                case (state)
                    S_IDLE: begin
                        // 等待刚刚结束的一段9 ms低电平。
                        if (!pulse_level && in_range(pulse_ticks, T_LEAD_LOW)) begin
                            state <= S_LEAD_HIGH;
                        end else begin
                            state <= S_IDLE;
                        end
                    end

                    S_LEAD_HIGH: begin
                        if (pulse_level && in_range(pulse_ticks, T_LEAD_HIGH)) begin
                            // 完整帧：清空旧数据，准备接收32位数据。
                            bit_count             <= 6'd0;
                            data_buf              <= 32'd0;
                            pending_command_valid <= 1'b0;
                            state                 <= S_DATA_LOW;
                        end else if (pulse_level && in_range(pulse_ticks, T_REPEAT_HIGH)) begin
                            // 重复帧还必须有末尾560 us低电平，不能在这里提前输出事件。
                            state <= S_REPEAT_LOW;
                        end else begin
                            state                 <= S_IDLE;
                            pending_command_valid <= 1'b0;
                            frame_error           <= 1'b1;
                        end
                    end

                    S_DATA_LOW: begin
                        // NEC每个数据位都从约560 us低电平开始。
                        if (!pulse_level && in_range(pulse_ticks, T_BIT_LOW)) begin
                            state <= S_DATA_HIGH;
                        end else begin
                            state                 <= S_IDLE;
                            pending_command_valid <= 1'b0;
                            frame_error           <= 1'b1;
                        end
                    end

                    S_DATA_HIGH: begin
                        // 高电平约560 us表示0，约1.69 ms表示1。
                        if (pulse_level &&
                            (in_range(pulse_ticks, T_ZERO_HIGH) ||
                             in_range(pulse_ticks, T_ONE_HIGH))) begin
                            data_buf[bit_count] <= in_range(pulse_ticks, T_ONE_HIGH);

                            if (bit_count == 6'd31) begin
                                // 当前刚收到第32位；该位尚未写回data_buf，
                                // 因而校验命令反码时单独拼入本次判断结果。
                                if ((data_buf[7:0] ^ data_buf[15:8]) == 8'hFF &&
                                    (data_buf[23:16] ^ {in_range(pulse_ticks, T_ONE_HIGH),
                                     data_buf[30:24]}) == 8'hFF) begin
                                    // 先暂存命令；只有2帧尾低电平也正确，才真正产生事件。
                                    pending_command       <= data_buf[23:16];
                                    pending_command_valid <= 1'b1;
                                    state                 <= S_STOP_LOW;
                                end else begin
                                    pending_command_valid <= 1'b0;
                                    state                 <= S_IDLE;
                                    frame_error           <= 1'b1;
                                end
                            end else begin
                                bit_count <= bit_count + 1'b1;
                                state     <= S_DATA_LOW;
                            end
                        end else begin
                            state                 <= S_IDLE;
                            pending_command_valid <= 1'b0;
                            frame_error           <= 1'b1;
                        end
                    end

                    S_STOP_LOW: begin
                        // 完整帧最后必须再有约560 us低电平。
                        if (!pulse_level && in_range(pulse_ticks, T_BIT_LOW) &&
                            pending_command_valid) begin
                            event_valid        <= 1'b1;
                            event_command      <= pending_command;
                            event_repeat       <= 1'b0;
                            last_command       <= pending_command;
                            last_command_valid <= 1'b1;
                            state              <= S_IDLE;
                        end else begin
                            frame_error <= 1'b1;
                            state       <= S_IDLE;
                        end
                        // 这个暂存值只服务于一帧，离开本状态后必须失效。
                        pending_command_valid <= 1'b0;
                    end

                    S_REPEAT_LOW: begin
                        // NEC重复帧：9 ms低 + 2.25 ms高 + 560 us低。
                        // 跳转回1状态，从那里的重复判定回来持续输出
                        if (!pulse_level && in_range(pulse_ticks, T_BIT_LOW)) begin
                            if (last_command_valid) begin
                                event_valid   <= 1'b1;
                                event_command <= last_command;
                                event_repeat  <= 1'b1;
                            end
                            // 复位后先收到重复帧时没有可重发的命令。
                            state <= S_IDLE;
                        end else begin
                            state       <= S_IDLE;
                            frame_error <= 1'b1;
                        end
                    end

                    default: begin
                        state                 <= S_IDLE;
                        bit_count             <= 6'd0;
                        pending_command_valid <= 1'b0;
                        frame_error           <= 1'b1;
                    end
                endcase
            end
        end
    end
endmodule

`default_nettype wire
