`default_nettype none
// Source-domain coordinator. A logical abort MUST NOT abandon a physical read.
module audio_bgm_file_session #(
 parameter integer TIMEOUT_CYCLES=250000000,
 parameter integer MAX_CHAIN_CLUSTERS=65535
)(
 input wire clk,rst,start_valid,stop,loop_enable,input wire [1:0] track_select,
 output wire start_ready,
 output wire read_valid,input wire read_ready,output wire [31:0] read_lba,
 input wire [7:0] data,input wire data_valid,output wire data_ready,input wire data_last,
 input wire read_done,read_error,
 output wire core_abort,output wire wav_open_valid,input wire wav_open_ready,
 output wire [31:0] wav_file_length,
 output wire sector_start_valid,input wire sector_start_ready,
 output wire [9:0] sector_valid_bytes,output wire sector_file_last,
 output wire provisional_valid,input wire provisional_ready,
 output wire [7:0] provisional_data,output wire provisional_last,
 output wire sector_finish_valid,sector_finish_ok,
 input wire file_parsed,core_fault,input wire [3:0] core_fault_code,
 input wire playback_end,
 output reg result_valid,input wire result_ready,output reg [7:0] result_code,
 output reg reset_required,output wire busy
);
 localparam [3:0] IDLE=0,CLEAR=1,LOC_START=2,FIND=3,WAV_OPEN=4,
    WALK_OPEN=5,RUN=6,WAIT_END=7,DRAIN=8,REPORT=9;
 localparam [1:0] OWNER_LOC=0,OWNER_FAT=1,OWNER_PCM=2;
 localparam integer TIMER_BITS=TIMEOUT_CYCLES>1?$clog2(TIMEOUT_CYCLES):1;
 reg [3:0] state;
 reg [2:0] clear_count;
 reg looping,parsed_seen,end_seen,transaction_active;
 reg [1:0] selected_track;
 reg [1:0] owner;
 reg [TIMER_BITS-1:0] drain_count;
 wire loc_start_ready,loc_read_valid,loc_read_ready,loc_data_ready,loc_result_valid;
 wire [31:0] loc_lba,first_cluster,file_size,fat_base,data_base,max_cluster;
 wire [32:0] volume_end;
 wire [7:0] spc;
 wire [3:0] loc_code,walk_code;
 wire walk_open_ready,walk_sector_valid,walk_sector_ready,walk_meta_valid,walk_meta_ready;
 wire walk_meta_data_ready,walk_result_valid;
 wire [31:0] walk_lba,walk_meta_lba;
 wire [9:0] walk_bytes;
 wire walk_last;
 wire children_abort=core_abort;
 wire operational=state==FIND||state==RUN;
 // Report physical failures immediately, rather than racing a cache fault
 // against the walker's result through different numbers of register stages.
 wire io_failed=transaction_active&&operational&&read_error;
 wire cancel=stop||io_failed||((state==WAV_OPEN||state==WALK_OPEN||state==RUN||state==WAIT_END)&&core_fault);
 wire issue=operational&&!transaction_active&&!cancel&&!rst;
 wire selecting_loc=state==FIND;
 wire selecting_fat=!selecting_loc&&walk_meta_valid;
 wire selecting_pcm=!selecting_loc&&!walk_meta_valid;
 wire request_available=selecting_loc?loc_read_valid:
       (selecting_fat?walk_meta_valid:(walk_sector_valid&&sector_start_ready));
 assign read_valid=issue&&request_available;
 assign read_lba=selecting_loc?loc_lba:(selecting_fat?walk_meta_lba:walk_lba);
 assign loc_read_ready=issue&&selecting_loc&&read_ready;
 assign walk_meta_ready=issue&&selecting_fat&&read_ready;
 assign walk_sector_ready=issue&&selecting_pcm&&read_ready&&sector_start_ready;
 assign sector_start_valid=issue&&selecting_pcm&&walk_sector_valid&&read_ready;
 assign sector_valid_bytes=walk_bytes;
 assign sector_file_last=walk_last;
 wire route=transaction_active&&operational&&!cancel;
 assign data_ready=transaction_active?(!route?1'b1:
     (owner==OWNER_LOC?loc_data_ready:(owner==OWNER_FAT?walk_meta_data_ready:provisional_ready))):1'b0;
 assign provisional_valid=route&&owner==OWNER_PCM&&data_valid;
 assign provisional_data=data;
 assign provisional_last=data_last;
 assign sector_finish_valid=route&&owner==OWNER_PCM&&(read_done||read_error);
 assign sector_finish_ok=read_done&&!read_error;
 assign core_abort=rst||state==IDLE||state==CLEAR||state==DRAIN||state==REPORT;
 assign wav_open_valid=state==WAV_OPEN&&!cancel&&!rst;
 assign wav_file_length=file_size;
 assign start_ready=state==IDLE&&!reset_required&&!transaction_active&&!stop&&!rst;
 assign busy=state!=IDLE&&state!=REPORT;

 fat32_bgm_locator #(.TIMEOUT_CYCLES(TIMEOUT_CYCLES),.MAX_CHAIN_CLUSTERS(MAX_CHAIN_CLUSTERS)) locator(
  .clk(clk),.rst(rst),.abort(children_abort),.start_valid(state==LOC_START&&!stop),.start_ready(loc_start_ready),
  .track_select(selected_track),
  .read_valid(loc_read_valid),.read_ready(loc_read_ready),.read_lba(loc_lba),
  .data(data),.data_valid(data_valid&&route&&owner==OWNER_LOC),.data_ready(loc_data_ready),.data_last(data_last),
  .read_done(read_done&&route&&owner==OWNER_LOC),.read_error(read_error&&route&&owner==OWNER_LOC),
  .result_valid(loc_result_valid),.result_ready(1'b0),.result_code(loc_code),
  .file_first_cluster(first_cluster),.file_size(file_size),.partition_lba(),
  .fat_start_lba(fat_base),.data_start_lba(data_base),.sectors_per_cluster(spc),
  .max_cluster(max_cluster),.volume_end_lba(volume_end),.busy());
 fat32_file_sector_walker #(.TIMEOUT_CYCLES(TIMEOUT_CYCLES),.MAX_CHAIN_CLUSTERS(MAX_CHAIN_CLUSTERS),.LATCH_GEOMETRY(0)) walker(
  .clk(clk),.rst(rst),.abort(children_abort),.open_valid(state==WALK_OPEN&&!cancel&&!rst),.open_ready(walk_open_ready),
  .file_first_cluster(first_cluster),.file_length(file_size),.fat_start_lba(fat_base),.data_start_lba(data_base),
  .max_cluster(max_cluster),.volume_end_lba(volume_end),.sectors_per_cluster(spc),
  .sector_valid(walk_sector_valid),.sector_ready(walk_sector_ready),.sector_lba(walk_lba),
  .sector_valid_bytes(walk_bytes),.sector_file_last(walk_last),
  .sector_done(read_done&&route&&owner==OWNER_PCM),.sector_error(read_error&&route&&owner==OWNER_PCM),
  .meta_read_valid(walk_meta_valid),.meta_read_ready(walk_meta_ready),.meta_read_lba(walk_meta_lba),
  .meta_data(data),.meta_data_valid(data_valid&&route&&owner==OWNER_FAT),.meta_data_ready(walk_meta_data_ready),
  .meta_data_last(data_last),.meta_done(read_done&&route&&owner==OWNER_FAT),.meta_error(read_error&&route&&owner==OWNER_FAT),
  .result_valid(walk_result_valid),.result_ready(state==RUN&&walk_result_valid&&walk_code==0&&parsed_seen),
  .result_code(walk_code),.file_read_done(),.busy());

 always @(posedge clk or posedge rst)begin
  if(rst)begin
   state<=IDLE;clear_count<=0;looping<=0;parsed_seen<=0;end_seen<=0;
   transaction_active<=0;owner<=OWNER_LOC;drain_count<=0;selected_track<=2'd1;
   result_valid<=0;result_code<=0;reset_required<=0;
  end else begin
   if(read_valid&&read_ready)begin
    transaction_active<=1;
    owner<=selecting_loc?OWNER_LOC:(selecting_fat?OWNER_FAT:OWNER_PCM);
   end
   if(transaction_active&&(read_done||read_error))transaction_active<=0;
   if(state==RUN||state==WAIT_END)begin
    if(file_parsed)parsed_seen<=1;
    if(playback_end)end_seen<=1;
   end
   if(cancel&&state!=IDLE&&state!=DRAIN&&state!=REPORT)begin
    result_code<=stop?8'h00:(io_failed?(owner==OWNER_LOC?8'h16:8'h25):{4'h3,core_fault_code});
    state<=DRAIN;drain_count<=0;
   end else case(state)
    IDLE:if(start_valid&&start_ready)begin
     state<=CLEAR;clear_count<=0;looping<=loop_enable;
     selected_track<=track_select;
     result_code<=0;parsed_seen<=0;end_seen<=0;
    end
    CLEAR:if(clear_count==7)state<=LOC_START;else clear_count<=clear_count+1'b1;
    LOC_START:if(loc_start_ready)state<=FIND;
    FIND:if(loc_result_valid)begin
     if(loc_code!=0)begin result_code<={4'h1,loc_code};state<=DRAIN;drain_count<=0;end
     else state<=WAV_OPEN;
    end
    WAV_OPEN:if(wav_open_ready)begin state<=WALK_OPEN;parsed_seen<=0;end_seen<=0;end
    WALK_OPEN:if(walk_open_ready)state<=RUN;
    RUN:if(walk_result_valid)begin
     if(walk_code!=0)begin result_code<={4'h2,walk_code};state<=DRAIN;drain_count<=0;end
     else if(parsed_seen)state<=looping?WAV_OPEN:WAIT_END;
    end
    WAIT_END:if(end_seen||playback_end)begin state<=DRAIN;drain_count<=0;end
    DRAIN:begin
     if(!transaction_active)begin state<=REPORT;result_valid<=1;end
     else if(TIMEOUT_CYCLES==0||drain_count>=TIMEOUT_CYCLES-1)begin
      reset_required<=1;result_code<=8'h40;result_valid<=1;state<=REPORT;
     end else drain_count<=drain_count+1'b1;
    end
    REPORT:if(result_valid&&result_ready)begin result_valid<=0;state<=IDLE;end
    default:begin state<=DRAIN;result_code<=8'h40;reset_required<=1;end
   endcase
  end
 end
endmodule
`default_nettype wire
