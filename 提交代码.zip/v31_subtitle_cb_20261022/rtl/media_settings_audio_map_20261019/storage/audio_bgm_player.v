`default_nettype none
// Internal integration only. One external CRC-checking sector service is owned
// by the parent. Source and pixel controls must already be in their domains.
module audio_bgm_player #(
 parameter integer PIXEL_HZ=25000000,
 parameter integer FIFO_ADDR_WIDTH=10,
 parameter integer PREFILL_SAMPLES=768,
 parameter integer TIMEOUT_CYCLES=250000000,
 parameter integer MAX_CHAIN_CLUSTERS=65535
)(
 input wire source_clk,pixel_clk,rst,
 input wire start_valid,stop,loop_enable,input wire [1:0] track_select,output wire start_ready,
 output wire read_valid,input wire read_ready,output wire [31:0] read_lba,
 input wire [7:0] data,input wire data_valid,output wire data_ready,input wire data_last,
 input wire read_done,read_error,
 input wire play_enable,mute,input wire [3:0] volume_level,
 input wire visualizer_enable,settings_visible,video_active,
 input wire [9:0] ui_x,ui_y,input wire [23:0] ui_pixel_in,
 output wire [23:0] ui_pixel_out,
 output wire audio_valid,output wire [23:0] audio_left_data,audio_right_data,
 output wire acr_valid,output wire [19:0] acr_cts,acr_n,
 output wire meter_valid,output wire [3:0] level_left,level_right,
 output wire [31:0] underflow_count,output wire track_end,
 output wire [FIFO_ADDR_WIDTH:0] buffered_samples,buffered_source,
 output wire result_valid,input wire result_ready,output wire [7:0] result_code,
 output wire reset_required,busy
);
 (* async_reg="true" *) reg [2:0] source_release,pixel_release;
 always @(posedge source_clk or posedge rst)
  if(rst)source_release<=3'b111;else source_release<={source_release[1:0],1'b0};
 always @(posedge pixel_clk or posedge rst)
  if(rst)pixel_release<=3'b111;else pixel_release<={pixel_release[1:0],1'b0};
 wire source_rst=source_release[2],pixel_rst=pixel_release[2];
 wire core_abort,wav_open_valid,wav_open_ready,sector_start_valid,sector_start_ready;
 wire [31:0] wav_file_length;
 wire [9:0] sector_valid_bytes;
 wire sector_file_last,provisional_valid,provisional_ready,provisional_last;
 wire [7:0] provisional_data;
 wire sector_finish_valid,sector_finish_ok,file_parsed,core_fault;
 wire [3:0] core_fault_code;
 reg end_toggle;
 (* async_reg="true" *) reg [2:0] end_sync;
 reg end_seen;
 wire end_source_reset=source_rst||core_abort;
 wire end_pixel_reset=pixel_rst||core_abort;
 (* async_reg="true" *) reg [1:0] end_pixel_release;
 always @(posedge pixel_clk or posedge end_pixel_reset)
  if(end_pixel_reset)end_pixel_release<=2'b11;
  else end_pixel_release<={end_pixel_release[0],1'b0};
 always @(posedge pixel_clk)
  if(end_pixel_release[1])end_toggle<=0;
  else if(track_end)end_toggle<=~end_toggle;
 always @(posedge source_clk or posedge end_source_reset)
  if(end_source_reset)begin end_sync<=0;end_seen<=0;end
  else begin end_sync<={end_sync[1:0],end_toggle};end_seen<=end_sync[2];end
 wire playback_end=end_sync[2]^end_seen;
 audio_bgm_file_session #(.TIMEOUT_CYCLES(TIMEOUT_CYCLES),.MAX_CHAIN_CLUSTERS(MAX_CHAIN_CLUSTERS)) u_session(
  .clk(source_clk),.rst(source_rst),.start_valid(start_valid),.stop(stop),.loop_enable(loop_enable),.track_select(track_select),.start_ready(start_ready),
  .read_valid(read_valid),.read_ready(read_ready),.read_lba(read_lba),.data(data),.data_valid(data_valid),.data_ready(data_ready),
  .data_last(data_last),.read_done(read_done),.read_error(read_error),
  .core_abort(core_abort),.wav_open_valid(wav_open_valid),.wav_open_ready(wav_open_ready),.wav_file_length(wav_file_length),
  .sector_start_valid(sector_start_valid),.sector_start_ready(sector_start_ready),.sector_valid_bytes(sector_valid_bytes),
  .sector_file_last(sector_file_last),.provisional_valid(provisional_valid),.provisional_ready(provisional_ready),
  .provisional_data(provisional_data),.provisional_last(provisional_last),.sector_finish_valid(sector_finish_valid),.sector_finish_ok(sector_finish_ok),
  .file_parsed(file_parsed),.core_fault(core_fault),.core_fault_code(core_fault_code),.playback_end(playback_end),
  .result_valid(result_valid),.result_ready(result_ready),.result_code(result_code),.reset_required(reset_required),.busy(busy));
 audio_slideshow_core #(.PIXEL_HZ(PIXEL_HZ),.FIFO_ADDR_WIDTH(FIFO_ADDR_WIDTH),.PREFILL_SAMPLES(PREFILL_SAMPLES),
   .BYTE_TIMEOUT_CYCLES(TIMEOUT_CYCLES)) u_audio(
  .source_clk(source_clk),.pixel_clk(pixel_clk),.rst(source_rst),.abort(core_abort),
  .open_valid(wav_open_valid),.open_ready(wav_open_ready),.file_length(wav_file_length),
  .sector_start_valid(sector_start_valid),.sector_start_ready(sector_start_ready),.sector_valid_bytes(sector_valid_bytes),.sector_file_last(sector_file_last),
  .provisional_valid(provisional_valid),.provisional_ready(provisional_ready),.provisional_data(provisional_data),.provisional_last(provisional_last),
  .sector_finish_valid(sector_finish_valid),.sector_finish_ok(sector_finish_ok),
  .play_enable(play_enable),.mute(mute),.volume_level(volume_level),.visualizer_enable(visualizer_enable),.settings_visible(settings_visible),
  .video_active(video_active),.ui_x(ui_x),.ui_y(ui_y),.ui_pixel_in(ui_pixel_in),.ui_pixel_out(ui_pixel_out),
  .audio_valid(audio_valid),.audio_left_data(audio_left_data),.audio_right_data(audio_right_data),
  .acr_valid(acr_valid),.acr_cts(acr_cts),.acr_n(acr_n),.meter_valid(meter_valid),.level_left(level_left),.level_right(level_right),
  .underflow_count(underflow_count),.track_end(track_end),.file_parsed(file_parsed),.fault(core_fault),.fault_code(core_fault_code),
  .buffered_samples(buffered_samples),.buffered_source(buffered_source));
endmodule
`default_nettype wire
