// Part 5: validated frame ingress to a 32-bit memory-write adapter.
// A frame succeeds only after all 921600 writes and the adapter flush complete.
`default_nettype none
module zhen_xieru (
    input wire clk,
    input wire rst,
    input wire target_buffer_sel,
    input wire [1:0] target_physical_slot,
    input wire abort,

    input wire frame_valid,
    output wire frame_ready,
    input wire [15:0] frame_width,
    input wire [15:0] frame_height,
    input wire frame_bottom_up,
    input wire [15:0] frame_index,

    input wire pixel_valid,
    output wire pixel_ready,
    input wire [23:0] pixel_rgb,
    input wire [15:0] pixel_x,
    input wire [15:0] pixel_y,
    input wire pixel_last,

    input wire source_result_valid,
    output wire source_result_ready,
    input wire [3:0] source_result_code,
    input wire [15:0] source_result_index,
    output wire source_cancel,

    output wire mem_write_valid,
    input wire mem_write_ready,
    output wire [20:0] mem_write_addr,
    output wire [31:0] mem_write_data,
    output wire mem_flush_req,
    input wire mem_flush_done,
    input wire memory_fault,

    output wire idle,
    output wire busy,
    output wire result_valid,
    input wire result_ready,
    output reg [3:0] result_code, // 0 OK,1 descriptor,2 pixels,3 source,4 memory,5 abort
    output wire [15:0] result_index,
    output wire result_buffer_sel,
    output reg reset_required
);
    localparam active_hd = 1'b1;
    localparam [2:0] IDLE=0, PIXELS=1, WAIT_SOURCE=2, CANCEL_SOURCE=3,
                     DRAIN=4, FLUSH=5, RESULT=6, LOCKED=7;
    reg [2:0] state;
    reg buffer_reg, bottom_up_reg, write_pending, source_finished;
    reg [1:0] physical_slot_reg;
    reg [15:0] index_reg, expected_x, expected_y;
    wire [15:0] FRAME_WIDTH = 16'd1280;
    wire [15:0] FRAME_HEIGHT = 16'd720;
    wire [19:0] FRAME_WORDS = 20'd921600;
    reg [19:0] pixel_count;
    reg [20:0] write_addr_reg;
    reg [31:0] write_data_reg;
    wire mapped_valid;
    wire [20:0] mapped_addr;
    wire final_expected = pixel_count == FRAME_WORDS-1'b1;
    wire coordinate_ok = pixel_x==expected_x && pixel_y==expected_y;
    wire incoming_ok = mapped_valid && coordinate_ok && pixel_last==final_expected;

    xie_dizhi_yingshe  u_xie_dizhi_yingshe (
        
        .image_index(physical_slot_reg), .bottom_up(bottom_up_reg),
        .pixel_x(pixel_x), .pixel_y(pixel_y),
        .word_addr(mapped_addr), .addr_valid(mapped_valid)
    );

    assign idle = !rst && state==IDLE && !reset_required && !memory_fault;
    assign busy = !rst && state!=IDLE && state!=RESULT && state!=LOCKED;
    assign frame_ready = idle;
    // An early source failure may arrive before a valid BMP produces a descriptor.
    assign source_result_ready = !rst &&
        (state==IDLE || state==PIXELS || state==WAIT_SOURCE || state==CANCEL_SOURCE);
    assign pixel_ready = !rst && state==PIXELS && !write_pending &&
                         !source_result_valid && !abort && !memory_fault;
    assign source_cancel = !rst && state==CANCEL_SOURCE;
    assign mem_write_valid = !rst && write_pending &&
        (state==PIXELS || state==WAIT_SOURCE || state==CANCEL_SOURCE || state==DRAIN);
    assign mem_write_addr = write_addr_reg;
    assign mem_write_data = write_data_reg;
    assign mem_flush_req = !rst && state==FLUSH;
    assign result_valid = !rst && state==RESULT;
    assign result_index = index_reg;
    assign result_buffer_sel = buffer_reg;

    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=IDLE; buffer_reg<=0; physical_slot_reg<=0;
            bottom_up_reg<=0; index_reg<=0;
            expected_x<=0; expected_y<=0; pixel_count<=0;
            write_pending<=0; source_finished<=0; write_addr_reg<=0; write_data_reg<=0;
            result_code<=0; reset_required<=0;
        end else begin
            if(mem_write_valid && mem_write_ready) write_pending<=0;
            if(state!=IDLE && state!=RESULT && state!=LOCKED &&
               memory_fault && !reset_required) begin
                result_code<=4; reset_required<=1; write_pending<=0;
                state<=source_finished ? RESULT : CANCEL_SOURCE;
            end else if((state==PIXELS || state==WAIT_SOURCE || state==DRAIN) && abort) begin
                result_code<=5;
                state<=source_finished ? DRAIN : CANCEL_SOURCE;
            end else case(state)
                IDLE: begin
                    reset_required<=0;
                    if(frame_valid && frame_ready) begin
                        buffer_reg<=target_buffer_sel;
                        physical_slot_reg<=target_physical_slot;
                        bottom_up_reg<=frame_bottom_up;
                        index_reg<=frame_index; expected_x<=0; expected_y<=FRAME_HEIGHT-1'b1;
                        pixel_count<=0; write_pending<=0; source_finished<=0; result_code<=0;
                        if(frame_width!=FRAME_WIDTH || frame_height!=FRAME_HEIGHT ||
                           target_physical_slot[1]) begin
                            result_code<=1; state<=CANCEL_SOURCE;
                        end else state<=PIXELS;
                    end else if(source_result_valid && source_result_ready) begin
                        buffer_reg<=target_buffer_sel;
                        physical_slot_reg<=target_physical_slot;
                        index_reg<=source_result_index;
                        source_finished<=1;
                        result_code<=source_result_code==0 ? 4'd2 : 4'd3;
                        state<=DRAIN;
                    end
                end
                PIXELS: begin
                    if(source_result_valid && source_result_ready) begin
                        source_finished<=1;
                        result_code<=source_result_code==0 ? 4'd2 : 4'd3;
                        if(source_result_index!=index_reg) result_code<=2;
                        state<=DRAIN;
                    end else if(pixel_valid && pixel_ready) begin
                        if(!incoming_ok) begin
                            result_code<=2; write_pending<=0; state<=CANCEL_SOURCE;
                        end else begin
                            write_addr_reg<=mapped_addr;
                            write_data_reg<={pixel_rgb,8'h00};
                            write_pending<=1;
                            pixel_count<=pixel_count+1'b1;
                            if(expected_x==FRAME_WIDTH-1'b1) begin
                                expected_x<=0;
                                if(expected_y!=0) expected_y<=expected_y-1'b1;
                            end else expected_x<=expected_x+1'b1;
                            if(final_expected) state<=WAIT_SOURCE;
                        end
                    end
                end
                WAIT_SOURCE: if(source_result_valid && source_result_ready) begin
                    source_finished<=1;
                    if(source_result_code!=0) begin
                        result_code<=3; state<=DRAIN;
                    end else if(source_result_index!=index_reg || pixel_count!=FRAME_WORDS) begin
                        result_code<=2; state<=DRAIN;
                    end else state<=DRAIN;
                end
                CANCEL_SOURCE: if(source_result_valid && source_result_ready) begin
                    source_finished<=1;
                    if(source_result_index!=index_reg && result_code!=1) result_code<=2;
                    state<=result_code==4 ? RESULT : DRAIN;
                end
                DRAIN: if(!write_pending || (mem_write_valid && mem_write_ready)) state<=FLUSH;
                FLUSH: if(mem_flush_done) state<=RESULT;
                RESULT: if(result_ready) state<=reset_required ? LOCKED : IDLE;
                LOCKED: state<=LOCKED;
                default: begin state<=RESULT; result_code<=4; reset_required<=1; write_pending<=0; end
            endcase
        end
    end
endmodule
`default_nettype wire
