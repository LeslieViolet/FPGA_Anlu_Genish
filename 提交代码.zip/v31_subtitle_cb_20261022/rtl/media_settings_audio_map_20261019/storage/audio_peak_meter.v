`default_nettype none
// No multiplier: actual signed PCM absolute peak per window, including -32768.
module audio_peak_meter #(parameter integer WINDOW_SAMPLES=1024)(
 input wire clk,rst,clear,input wire sample_fire,
 input wire signed [15:0] pcm_left,pcm_right,
 output reg update_valid,output reg [15:0] peak_left,peak_right,
 output wire [3:0] level_left,level_right
);
 localparam COUNT_W=WINDOW_SAMPLES<2?1:$clog2(WINDOW_SAMPLES);
 reg [COUNT_W-1:0] count;reg [15:0] max_left,max_right;
 wire [15:0] abs_left=pcm_left[15]?(~pcm_left+16'd1):pcm_left;
 wire [15:0] abs_right=pcm_right[15]?(~pcm_right+16'd1):pcm_right;
 wire [15:0] next_left=abs_left>max_left?abs_left:max_left;
 wire [15:0] next_right=abs_right>max_right?abs_right:max_right;
 assign level_left=peak_left[15:12];
 assign level_right=peak_right[15:12];
 always @(posedge clk or posedge rst)begin
  if(rst)begin count<=0;max_left<=0;max_right<=0;peak_left<=0;peak_right<=0;update_valid<=0;end
  else begin
   update_valid<=0;
   if(clear)begin count<=0;max_left<=0;max_right<=0;peak_left<=0;peak_right<=0;end
   else if(sample_fire)begin
    if(count==WINDOW_SAMPLES-1)begin
     peak_left<=next_left;peak_right<=next_right;update_valid<=1;count<=0;max_left<=0;max_right<=0;
    end else begin count<=count+1'b1;max_left<=next_left;max_right<=next_right;end
   end
  end
 end
endmodule
`default_nettype wire
