`default_nettype none
// 运行于未被软件复位停止的50MHz参考时钟。
// 不能用本模块输出复位自己，否则请求只会维持一拍。
module software_reset_hold #(parameter integer HOLD_CYCLES=500000)(
 input wire clk,base_reset,request,output reg active
);
 localparam integer WIDTH=(HOLD_CYCLES<2)?1:$clog2(HOLD_CYCLES);
 reg [WIDTH-1:0] remaining;
 always @(posedge clk or posedge base_reset)begin
  if(base_reset)begin active<=0;remaining<=0;end
  else if(active)begin
   if(remaining==0)active<=0;else remaining<=remaining-1'b1;
  end else if(request)begin active<=1;remaining<=HOLD_CYCLES-1;end
 end
endmodule
`default_nettype wire
