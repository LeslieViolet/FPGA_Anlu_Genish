`default_nettype none
// Pixel-domain click event consumption and signed PCM mixing. WAV cadence and
// ACR remain those of the WAV source. Inputs are already registered in this
// domain; the entire selected tuple stays combinational, like the former mux.
module ui_audio_click_mix(
 input wire clk,rst,ui_update,ui_click_toggle,
 output wire click_trigger,
 input wire external_enable,external_valid,
 input wire [23:0] external_left,external_right,
 input wire external_acr_valid,input wire [19:0] external_acr_cts,external_acr_n,
 input wire generated_valid,input wire [23:0] generated_left,generated_right,
 input wire generated_acr_valid,input wire [19:0] generated_acr_cts,generated_acr_n,
 output reg audio_valid,output reg [23:0] audio_left,audio_right,
 output reg acr_valid,output reg [19:0] acr_cts,acr_n
);
 reg click_seen;
 assign click_trigger=!rst && ui_update && ui_click_toggle!=click_seen;
 always @(posedge clk or posedge rst)
  if(rst)click_seen<=0;
  else if(ui_update)click_seen<=ui_click_toggle;
 function [23:0] saturated_add;
  input signed [23:0] a,b;
  reg signed [24:0] sum;
  begin
   sum=$signed({a[23],a})+$signed({b[23],b});
   if(sum[24]!=sum[23])saturated_add=sum[24]?24'h800000:24'h7fffff;
   else saturated_add=sum[23:0];
  end
 endfunction
 always @* begin
  if(rst)begin
   audio_valid=0;audio_left=0;audio_right=0;
   acr_valid=0;acr_cts=0;acr_n=0;
  end else begin
   audio_valid=external_enable?external_valid:generated_valid;
   audio_left=external_enable?saturated_add(external_left,generated_left):generated_left;
   audio_right=external_enable?saturated_add(external_right,generated_right):generated_right;
   acr_valid=external_enable?external_acr_valid:generated_acr_valid;
   acr_cts=external_enable?external_acr_cts:generated_acr_cts;
   acr_n=external_enable?external_acr_n:generated_acr_n;
  end
 end
endmodule
`default_nettype wire
