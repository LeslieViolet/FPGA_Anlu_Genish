`default_nettype none
// UI-to-media bridge for Scheme 2.
// UI commands are generated in clk_sys; the teammate media contract is in clk_sd.
// Commands and results cross with toggle mailboxes. Catalog metadata is held
// stable by the media side and sampled only after its ready level is synchronized.
module media_control_adapter #(
    parameter integer CLK_SD_HZ = 50000000,
    parameter integer AUTO_SECONDS = 5
)(
    input  wire        clk_sys,
    input  wire        rst_sys,
    input  wire        clk_sd,
    input  wire        rst_sd,

    input  wire        media_open_req,
    input  wire        media_next_req,
    input  wire        media_prev_req,
    input  wire        media_play_toggle,
    input  wire [15:0] browser_index,
    input  wire        home_active_sys,
    input wire autoplay_run_sys,input wire [3:0] auto_interval_sys,
    output reg         sys_cmd_busy,

    input  wire        catalog_done_sd,
    input  wire        catalog_ok_sd,
    input  wire [4:0]  asset_count_sd,
    input  wire        storage_ready_sd,
    output wire        catalog_ready_sys,
    output reg  [4:0]  asset_count_sys,
    output reg         [3:0] current_id_sys,
    output reg         auto_enabled_sys,
    output reg         media_busy_sys,
    output reg         result_valid_sys,
    output reg  [3:0]  result_code_sys,

    output reg         media_request_valid_sd,
    input  wire        media_request_ready_sd,
    output reg  [3:0]  media_request_id_sd,
    input  wire        media_result_valid_sd,
    input  wire [3:0]  media_result_code_sd,
    output reg         media_request_cancel_sd,
    output reg         media_request_started_sd,
    output reg         auto_enabled_sd
);
    localparam [1:0] CMD_OPEN = 2'd0;
    localparam [1:0] CMD_NEXT = 2'd1;
    localparam [1:0] CMD_PREV = 2'd2;
    localparam [1:0] CMD_TOGGLE = 2'd3;
    // Atomic settings transfer; multi-bit interval never crosses bit-by-bit.
    wire cfg_ready,cfg_valid;
    wire [4:0] cfg_payload;
    reg [4:0] cfg_last;
    reg cfg_sent;
    wire [4:0] cfg_now={autoplay_run_sys,auto_interval_sys};
    reg run_sd;
    reg [3:0] interval_sd;
    // 常数选择器，不为秒值推断运行时乘法器。
    reg [31:0] interval_cycles;
    always @* case(interval_sd)
        1:interval_cycles=CLK_SD_HZ;2:interval_cycles=CLK_SD_HZ*2;
        3:interval_cycles=CLK_SD_HZ*3;4:interval_cycles=CLK_SD_HZ*4;
        6:interval_cycles=CLK_SD_HZ*6;7:interval_cycles=CLK_SD_HZ*7;
        8:interval_cycles=CLK_SD_HZ*8;9:interval_cycles=CLK_SD_HZ*9;
        default:interval_cycles=CLK_SD_HZ*5;
    endcase
    always @(posedge clk_sys or posedge rst_sys)
        if(rst_sys)begin cfg_last<=0;cfg_sent<=0;end
        else if(cfg_ready && (!cfg_sent || cfg_last!=cfg_now))begin cfg_last<=cfg_now;cfg_sent<=1;end
    ui_snapshot_mailbox #(.PAYLOAD_W(5)) u_playback_config(
        .src_clk(clk_sys),.src_rst(rst_sys),.src_valid(!cfg_sent || cfg_last!=cfg_now),
        .src_ready(cfg_ready),.src_payload(cfg_now),.dst_clk(clk_sd),
        .dst_rst(rst_sd),.dst_valid(cfg_valid),.dst_ready(1'b1),.dst_payload(cfg_payload));
    always @(posedge clk_sd or posedge rst_sd)
        if(rst_sd)begin run_sd<=0;interval_sd<=5;end
        else if(cfg_valid)begin run_sd<=cfg_payload[4];interval_sd<=cfg_payload[3:0];end

    reg cmd_toggle_sys;
    reg [1:0] cmd_opcode_sys;
    reg [15:0] cmd_index_sys;
    reg result_toggle_sd;
    reg [3:0] result_code_sd;
    reg [3:0] result_id_sd;

    reg result_toggle_s0, result_toggle_s1, result_toggle_seen;
    reg [3:0] result_code_s0, result_code_s1;
    reg [3:0] result_id_s0, result_id_s1;
    reg auto_s0, auto_s1, busy_s0, busy_s1;
    reg catalog_done_s0, catalog_done_s1;
    reg catalog_ok_s0, catalog_ok_s1;
    reg storage_ready_s0, storage_ready_s1;
    reg [4:0] asset_count_s0, asset_count_s1;

    always @(posedge clk_sys or posedge rst_sys) begin
        if (rst_sys) begin
            cmd_toggle_sys <= 1'b0;
            cmd_opcode_sys <= CMD_OPEN;
            cmd_index_sys <= 16'd0;
            sys_cmd_busy <= 1'b0;
            result_toggle_s0 <= 1'b0;
            result_toggle_s1 <= 1'b0;
            result_toggle_seen <= 1'b0;
            result_code_s0 <= 4'd0;
            result_code_s1 <= 4'd0;
            result_id_s0 <= 4'd0;
            result_id_s1 <= 4'd0;
            auto_s0 <= 1'b0; auto_s1 <= 1'b0;
            busy_s0 <= 1'b0; busy_s1 <= 1'b0;
            catalog_done_s0 <= 1'b0; catalog_done_s1 <= 1'b0;
            catalog_ok_s0 <= 1'b0; catalog_ok_s1 <= 1'b0;
            storage_ready_s0 <= 1'b0; storage_ready_s1 <= 1'b0;
            asset_count_s0 <= 3'd0; asset_count_s1 <= 3'd0;
            asset_count_sys <= 3'd0;
            current_id_sys <= 4'd0;
            auto_enabled_sys <= 1'b0;
            media_busy_sys <= 1'b0;
            result_valid_sys <= 1'b0;
            result_code_sys <= 4'd0;
        end else begin
            result_toggle_s0 <= result_toggle_sd;
            result_toggle_s1 <= result_toggle_s0;
            result_code_s0 <= result_code_sd;
            result_code_s1 <= result_code_s0;
            result_id_s0 <= result_id_sd;
            result_id_s1 <= result_id_s0;
            auto_s0 <= auto_enabled_sd; auto_s1 <= auto_s0;
            busy_s0 <= media_request_valid_sd; busy_s1 <= busy_s0;
            catalog_done_s0 <= catalog_done_sd; catalog_done_s1 <= catalog_done_s0;
            catalog_ok_s0 <= catalog_ok_sd; catalog_ok_s1 <= catalog_ok_s0;
            storage_ready_s0 <= storage_ready_sd; storage_ready_s1 <= storage_ready_s0;
            asset_count_s0 <= asset_count_sd; asset_count_s1 <= asset_count_s0;
            // Physical asset 0 is reserved for the home wallpaper.  The UI
            // sees only the remaining user media assets.
            asset_count_sys <= (!catalog_ready_sys || asset_count_s1 == 0) ? 3'd0 :
                               (asset_count_s1>10 ? 5'd9 : asset_count_s1 - 1'b1);
            auto_enabled_sys <= auto_s1;
            media_busy_sys <= busy_s1 | sys_cmd_busy;
            result_valid_sys <= 1'b0;

            if (result_toggle_s1 != result_toggle_seen) begin
                result_toggle_seen <= result_toggle_s1;
                result_valid_sys <= 1'b1;
                result_code_sys <= result_code_s1;
                current_id_sys <= result_id_s1;
                sys_cmd_busy <= 1'b0;
            end

            if (!sys_cmd_busy && catalog_ready_sys) begin
                if (media_open_req) begin
                    cmd_opcode_sys <= CMD_OPEN;
                    cmd_index_sys <= browser_index;
                    cmd_toggle_sys <= ~cmd_toggle_sys;
                    sys_cmd_busy <= 1'b1;
                end else if (media_next_req) begin
                    cmd_opcode_sys <= CMD_NEXT;
                    cmd_index_sys <= 16'd0;
                    cmd_toggle_sys <= ~cmd_toggle_sys;
                    sys_cmd_busy <= 1'b1;
                end else if (media_prev_req) begin
                    cmd_opcode_sys <= CMD_PREV;
                    cmd_index_sys <= 16'd0;
                    cmd_toggle_sys <= ~cmd_toggle_sys;
                    sys_cmd_busy <= 1'b1;
                end else if (media_play_toggle) begin
                    cmd_opcode_sys <= CMD_TOGGLE;
                    cmd_index_sys <= 16'd0;
                    cmd_toggle_sys <= ~cmd_toggle_sys;
                    sys_cmd_busy <= 1'b1;
                end
            end
            if(!catalog_ready_sys)begin
                sys_cmd_busy<=0;media_busy_sys<=0;auto_enabled_sys<=0;
                result_toggle_seen<=result_toggle_s1;
            end
        end
    end

    assign catalog_ready_sys = catalog_done_s1 && catalog_ok_s1 && storage_ready_s1;

    reg cmd_toggle_s0, cmd_toggle_s1, cmd_toggle_seen;
    reg [1:0] cmd_opcode_s0, cmd_opcode_s1;
    reg [15:0] cmd_index_s0, cmd_index_s1;
    reg command_pending;
    reg [1:0] pending_opcode;
    reg [15:0] pending_index;
    reg inflight;
    reg [3:0] current_id_sd;
    reg [4:0] asset_count_latched;
    reg catalog_ready_latched;reg media_offline_sd;
    reg [31:0] auto_count;
    reg home_active_s0, home_active_s1, home_active_seen;
    reg home_request_pending;
    reg request_home_tag, inflight_home;

    // Convert a logical browser index into a physical catalog index.  Index
    // zero is the wallpaper, so normal media starts at physical index one.
    function [3:0] clamp_index;
        input [15:0] requested;
        input [4:0] count;
        begin
            if (count <= 1) clamp_index = 4'd0;
            else if (requested >= count - 1'b1) clamp_index = count - 1'b1;
            else clamp_index = requested[3:0] + 1'b1;
        end
    endfunction

    function [3:0] next_index;
        input [3:0] current;
        input [4:0] count;
        begin
            if (count <= 2) next_index = 4'd1;
            else if (current < 1 || {1'b0,current} + 5'd1 >= count) next_index = 4'd1;
            else next_index = current + 1'b1;
        end
    endfunction

    function [3:0] prev_index;
        input [3:0] current;
        input [4:0] count;
        begin
            if (count <= 2) prev_index = 4'd1;
            else if (current <= 1) prev_index = count - 1'b1;
            else prev_index = current - 1'b1;
        end
    endfunction

    always @(posedge clk_sd or posedge rst_sd) begin
        if (rst_sd) begin
            cmd_toggle_s0 <= 1'b0; cmd_toggle_s1 <= 1'b0; cmd_toggle_seen <= 1'b0;
            cmd_opcode_s0 <= CMD_OPEN; cmd_opcode_s1 <= CMD_OPEN;
            cmd_index_s0 <= 16'd0; cmd_index_s1 <= 16'd0;
            command_pending <= 1'b0; pending_opcode <= CMD_OPEN; pending_index <= 16'd0;
            inflight <= 1'b0;
            // Physical index one is the first normal media item.  Keeping the
            // reset value here avoids an underflow in a failed first request.
            current_id_sd <= 4'd1;
            asset_count_latched <= 3'd0;
            catalog_ready_latched <= 1'b0;media_offline_sd<=0;
            auto_count <= 32'd0;
            home_active_s0 <= 1'b0;
            home_active_s1 <= 1'b0;
            home_active_seen <= 1'b0;
            home_request_pending <= 1'b0;
            request_home_tag <= 1'b0;
            inflight_home <= 1'b0;
            media_request_valid_sd <= 1'b0;
            media_request_id_sd <= 4'd0;
            media_request_cancel_sd <= 1'b0;
            media_request_started_sd <= 1'b0;
            auto_enabled_sd <= 1'b0;
            result_toggle_sd <= 1'b0;
            result_code_sd <= 4'd0;
            result_id_sd <= 4'd0;
        end else begin
            cmd_toggle_s0 <= cmd_toggle_sys;
            cmd_toggle_s1 <= cmd_toggle_s0;
            cmd_opcode_s0 <= cmd_opcode_sys;
            cmd_opcode_s1 <= cmd_opcode_s0;
            cmd_index_s0 <= cmd_index_sys;
            cmd_index_s1 <= cmd_index_s0;
            home_active_s0 <= home_active_sys;
            home_active_s1 <= home_active_s0;
            media_request_started_sd <= 1'b0;
            media_request_cancel_sd <= 1'b0;

            // Every transition into HOME schedules a wallpaper reload.  The
            // request waits for a valid catalog, so boot order is harmless.
            if (!home_active_s1) begin
                home_active_seen <= 1'b0;
                home_request_pending <= 1'b0;
            end else if (!home_active_seen) begin
                home_active_seen <= 1'b1;
                home_request_pending <= 1'b1;
                auto_enabled_sd <= 1'b0;
                auto_count <= 32'd0;
            end

            if (catalog_done_sd && catalog_ok_sd && storage_ready_sd) begin
                asset_count_latched <= asset_count_sd>10 ? 5'd10 : asset_count_sd;
                catalog_ready_latched <= 1'b1;media_offline_sd<=0;
            end

            if (cmd_toggle_s1 != cmd_toggle_seen) begin
                cmd_toggle_seen <= cmd_toggle_s1;
                command_pending <= 1'b1;
                pending_opcode <= cmd_opcode_s1;
                pending_index <= cmd_index_s1;
            end

            if (media_request_valid_sd && media_request_ready_sd) begin
                media_request_valid_sd <= 1'b0;
                inflight <= 1'b1;
                inflight_home <= request_home_tag;
                media_request_started_sd <= 1'b1;
            end

            if (media_result_valid_sd && inflight) begin
                inflight <= 1'b0;
                if (!inflight_home) begin
                    result_code_sd <= media_result_code_sd;
                    if (media_result_code_sd == 0)
                        current_id_sd <= media_request_id_sd;
                    result_id_sd <= (media_result_code_sd == 0) ?
                                    (media_request_id_sd - 1'b1) :
                                    (current_id_sd - 1'b1);
                    result_toggle_sd <= ~result_toggle_sd;
                end
                inflight_home <= 1'b0;
                auto_count <= 32'd0;
            end

            if (home_request_pending && home_active_s1 &&
                catalog_ready_latched && asset_count_latched != 0 &&
                !inflight && !media_request_valid_sd) begin
                home_request_pending <= 1'b0;
                media_request_valid_sd <= 1'b1;
                media_request_id_sd <= 4'd0;
                request_home_tag <= 1'b1;
                auto_count <= 32'd0;
            end else if (command_pending && !inflight && !media_request_valid_sd) begin
                command_pending <= 1'b0;
                if (pending_opcode == CMD_TOGGLE) begin
                    auto_enabled_sd <= run_sd;
                    auto_count <= 32'd0;
                    result_code_sd <= 4'd0;
                    result_id_sd <= current_id_sd - 1'b1;
                    result_toggle_sd <= ~result_toggle_sd;
                end else if (catalog_ready_latched && asset_count_latched > 1) begin
                    media_request_valid_sd <= 1'b1;
                    request_home_tag <= 1'b0;
                    case (pending_opcode)
                        CMD_OPEN: media_request_id_sd <= clamp_index(pending_index, asset_count_latched);
                        CMD_NEXT: media_request_id_sd <= next_index(current_id_sd, asset_count_latched);
                        CMD_PREV: media_request_id_sd <= prev_index(current_id_sd, asset_count_latched);
                        default: media_request_id_sd <= current_id_sd;
                    endcase
                end else begin
                    result_code_sd <= 4'd1;
                    result_id_sd <= current_id_sd - 1'b1;
                    result_toggle_sd <= ~result_toggle_sd;
                end
            end else if (run_sd && !home_active_s1 &&
                         catalog_ready_latched && asset_count_latched > 1 &&
                         !inflight && !media_request_valid_sd) begin
                if (auto_count >= interval_cycles-1) begin
                    media_request_valid_sd <= 1'b1;
                    media_request_id_sd <= next_index(current_id_sd, asset_count_latched);
                    request_home_tag <= 1'b0;
                    auto_count <= 32'd0;
                end else begin
                    auto_count <= auto_count + 1'b1;
                end
            end
            // Settings pause freezes elapsed dwell time. Interval changes restart it.
            auto_enabled_sd<=run_sd && catalog_ready_latched && !home_active_s1;
            if(cfg_valid && cfg_payload[3:0]!=interval_sd)auto_count<=0;
            if((media_offline_sd || catalog_ready_latched) && !(catalog_done_sd && catalog_ok_sd && storage_ready_sd))begin
                media_offline_sd<=1;
                catalog_ready_latched<=0;asset_count_latched<=0;
                media_request_valid_sd<=0;command_pending<=0;inflight<=0;inflight_home<=0;
                auto_enabled_sd<=0;auto_count<=0;home_active_seen<=0;home_request_pending<=0;
                cmd_toggle_seen<=cmd_toggle_s1;
            end
        end
    end
endmodule
`default_nettype wire
