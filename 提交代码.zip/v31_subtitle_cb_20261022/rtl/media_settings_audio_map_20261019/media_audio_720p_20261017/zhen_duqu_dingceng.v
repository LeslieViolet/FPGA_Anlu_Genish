// Parts 1..7 unified wrapper. Part 8 supplies the physical memory adapter.
`default_nettype none
module zhen_duqu_dingceng (
    input wire rst_catalog, input wire rst_reader,
    input wire clk_write, rst_write,
    input wire [95:0] ui_status_payload_pixel,
    input wire scan_valid, output wire scan_ready,
    input wire [31:0] scan_first_lba, scan_last_lba,
    output wire scan_done, output wire [3:0] scan_status,
    output wire [4:0] asset_count,
    input wire request_valid, output wire request_ready,
    input wire [3:0] request_id, input wire request_cancel,
    output wire request_result_valid, input wire request_result_ready,
    output wire [3:0] request_result_code,
    output wire [15:0] request_result_index,
    output wire request_result_buffer_sel,
    output wire [1:0] slot_busy, output wire reset_required,
    output wire [3:0] reader_error_code,
    output wire mem_write_valid, input wire mem_write_ready,
    output wire [20:0] mem_write_addr,
    output wire [31:0] mem_write_data,
    output wire mem_flush_req, input wire mem_flush_done,
    output wire mem_read_valid, input wire mem_read_ready,
    output wire [20:0] mem_read_addr,
    input wire mem_read_data_valid, output wire mem_read_data_ready,
    input wire [31:0] mem_read_data,
    output wire mem_read_cancel_req, input wire mem_read_cancel_done,
    input wire memory_fault,
    input wire clk_display, rst_display,
    output wire frame_ready, input wire disp_req, output wire disp_ack,
    input wire disp_keep_old, output wire disp_valid,
    output wire disp_buffer_sel,
    output wire [1:0] disp_physical_slot,
    output wire [15:0] disp_width, disp_height, disp_index,
    output wire [31:0] disp_generation,
    output wire disp_previous_valid, disp_previous_sel,
    input wire disp_previous_release_req,
    output wire disp_previous_release_ack,
    input wire read_req, output wire read_ack,
    input wire read_buffer_sel,
    input wire [31:0] read_start_addr, read_length,
    output wire read_pixel_valid, input wire read_pixel_ready,
    output wire [23:0] read_pixel_data, output wire read_pixel_last,
    output wire read_done, input wire read_done_ready,
    output wire [3:0] read_status,
    input wire read_cancel_req, output wire read_cancel_ack,
    output wire card_ready,
    output wire bgm_selected, bgm_audio_valid,
    output wire [23:0] bgm_audio_left, bgm_audio_right,
    output wire bgm_acr_valid,
    output wire [19:0] bgm_acr_cts, bgm_acr_n,
    output wire bgm_meter_valid,
    output wire bgm_visualizer_enable,
    output wire [3:0] bgm_level_left, bgm_level_right,
    output wire tf_cs_n, tf_sclk, tf_mosi, input wire tf_miso
);
    localparam active_hd = 1'b1;
    wire buffer_reset_required, read_reset_required, display_reads_idle;
    // The adapter reports a sticky asynchronous summary assembled from three
    // clock domains. Synchronize that level before either state machine uses it.
    (* async_reg = "true" *) reg [1:0] memory_fault_write_sync;
    (* async_reg = "true" *) reg [1:0] memory_fault_read_sync;

    always @(posedge clk_write or posedge rst_write) begin
        if(rst_write) memory_fault_write_sync <= 2'b00;
        else memory_fault_write_sync <= {memory_fault_write_sync[0],memory_fault};
    end

    always @(posedge clk_display or posedge rst_display) begin
        if(rst_display) memory_fault_read_sync <= 2'b00;
        else memory_fault_read_sync <= {memory_fault_read_sync[0],memory_fault};
    end

    shuang_huanchong_dingceng  u_shuang_huanchong_dingceng (
    
        .rst_catalog(rst_catalog),.rst_reader(rst_reader),
        
        .clk_write(clk_write), .rst_write(rst_write),
        .ui_status_payload_pixel(ui_status_payload_pixel),
        .scan_valid(scan_valid), .scan_ready(scan_ready),
        .scan_first_lba(scan_first_lba), .scan_last_lba(scan_last_lba),
        .scan_done(scan_done), .scan_status(scan_status),
        .asset_count(asset_count), .request_valid(request_valid),
        .request_ready(request_ready), .request_id(request_id),
        .request_cancel(request_cancel),
        .request_result_valid(request_result_valid),
        .request_result_ready(request_result_ready),
        .request_result_code(request_result_code),
        .request_result_index(request_result_index),
        .request_result_buffer_sel(request_result_buffer_sel),
        .slot_busy(slot_busy), .reset_required(buffer_reset_required),
        .reader_error_code(reader_error_code),
        .mem_write_valid(mem_write_valid), .mem_write_ready(mem_write_ready),
        .mem_write_addr(mem_write_addr), .mem_write_data(mem_write_data),
        .mem_flush_req(mem_flush_req), .mem_flush_done(mem_flush_done),
        .memory_fault(memory_fault_write_sync[1]), .clk_display(clk_display),
        .rst_display(rst_display), .frame_ready(frame_ready),
        .disp_req(disp_req), .disp_ack(disp_ack),
        .disp_keep_old(disp_keep_old),
        .display_reads_idle(display_reads_idle), .disp_valid(disp_valid),
        .disp_buffer_sel(disp_buffer_sel), .disp_width(disp_width),
        .disp_height(disp_height), .disp_index(disp_index),
        .disp_physical_slot(disp_physical_slot),
        .disp_generation(disp_generation),
        .disp_previous_valid(disp_previous_valid),
        .disp_previous_sel(disp_previous_sel),
        .disp_previous_release_req(disp_previous_release_req),
        .disp_previous_release_ack(disp_previous_release_ack),
        .card_ready(card_ready),
        .bgm_selected(bgm_selected),.bgm_audio_valid(bgm_audio_valid),
        .bgm_audio_left(bgm_audio_left),.bgm_audio_right(bgm_audio_right),
        .bgm_acr_valid(bgm_acr_valid),.bgm_acr_cts(bgm_acr_cts),.bgm_acr_n(bgm_acr_n),
        .bgm_meter_valid(bgm_meter_valid),.bgm_level_left(bgm_level_left),.bgm_level_right(bgm_level_right),
        .bgm_visualizer_enable(bgm_visualizer_enable),
        .tf_cs_n(tf_cs_n), .tf_sclk(tf_sclk),
        .tf_mosi(tf_mosi), .tf_miso(tf_miso)
    );

    zhen_duqu  u_zhen_duqu (
        
        .clk(clk_display), .rst(rst_display),
        .disp_valid(disp_valid), .disp_buffer_sel(disp_buffer_sel),
        .disp_index(disp_index), .disp_physical_slot(disp_physical_slot),
        .disp_width(disp_width), .disp_height(disp_height),
        .disp_previous_valid(disp_previous_valid),
        .disp_previous_sel(disp_previous_sel),
        .read_req(read_req), .read_ack(read_ack),
        .read_buffer_sel(read_buffer_sel),
        .read_start_addr(read_start_addr), .read_length(read_length),
        .read_pixel_valid(read_pixel_valid),
        .read_pixel_ready(read_pixel_ready),
        .read_pixel_data(read_pixel_data), .read_pixel_last(read_pixel_last),
        .read_done(read_done), .read_done_ready(read_done_ready),
        .read_status(read_status), .read_cancel_req(read_cancel_req),
        .read_cancel_ack(read_cancel_ack),
        .mem_read_valid(mem_read_valid), .mem_read_ready(mem_read_ready),
        .mem_read_addr(mem_read_addr),
        .mem_read_data_valid(mem_read_data_valid),
        .mem_read_data_ready(mem_read_data_ready),
        .mem_read_data(mem_read_data),
        .mem_read_cancel_req(mem_read_cancel_req),
        .mem_read_cancel_done(mem_read_cancel_done),
        .memory_fault(memory_fault_read_sync[1]),
        .display_reads_idle(display_reads_idle),
        .reset_required(read_reset_required)
    );
    assign reset_required=buffer_reset_required || read_reset_required;
endmodule
`default_nettype wire
