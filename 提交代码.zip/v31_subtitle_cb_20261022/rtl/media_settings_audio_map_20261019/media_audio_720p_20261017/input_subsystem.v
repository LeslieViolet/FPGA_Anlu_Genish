// A subsystem: board controls and media playback scheduling.
`default_nettype none
module input_subsystem(
    input wire key_next_n,
    input wire key_auto_n,
    input wire clk_sys,
    input wire clk_sd,
    input wire rst_sys,
    input wire rst_sd,
    output wire img_frame_start,
    input wire img_start_ready,
    output wire [15:0] img_width,
    output wire [15:0] img_height,
    output wire img_bottom_up,
    output wire [15:0] img_index,
    output wire img_pixel_valid,
    input wire img_pixel_ready,
    output wire [23:0] img_pixel_data,
    output wire img_frame_end,
    input wire img_end_ready,
    output wire img_abort,
    input wire img_abort_ready,
    input wire img_result_valid,
    output wire img_result_ready,
    input wire [3:0] img_result_code,
    input wire [15:0] img_result_index,
    input wire media_catalog_done,
    input wire media_catalog_ok,
    input wire [4:0] media_asset_count,
    input wire media_storage_ready,
    output wire media_request_valid,
    input wire media_request_ready,
    output wire [3:0] media_request_id,
    output wire media_request_cancel,
    input wire media_result_valid,
    input wire [3:0] media_result_code,
    output wire media_request_started,
    output wire input_fault
);
assign img_frame_start = 1'd0;
assign img_width = 16'd0;
assign img_height = 16'd0;
assign img_bottom_up = 1'd0;
assign img_index = 16'd0;
assign img_pixel_valid = 1'd0;
assign img_pixel_data = 24'd0;
assign img_frame_end = 1'd0;
assign img_abort = 1'd0;
assign img_result_ready = 1'd0;
assign input_fault = 1'd0;

// A owns key handling and playback policy.  B reports its media catalogue and
// executes the request/response transaction; the whole interface is clk_sd.
wire media_auto_enabled;
wire [3:0] media_current_id;
wire media_load_active;
media_playback_scheduler #(
    .CLK_FREQ_HZ(50000000), .AUTO_SECONDS(5), .DEBOUNCE_MS(20)
) u_media_playback_scheduler (
    .clk(clk_sd), .rst(rst_sd),
    .key_next_n(key_next_n), .key_auto_n(key_auto_n),
    .catalog_done(media_catalog_done),
    .catalog_ok(media_catalog_ok),
    .asset_count(media_asset_count),
    .storage_ready(media_storage_ready),
    .request_valid(media_request_valid),
    .request_ready(media_request_ready),
    .request_id(media_request_id),
    .result_valid(media_result_valid),
    .result_code(media_result_code),
    .auto_enabled(media_auto_enabled),
    .current_id(media_current_id),
    .load_active(media_load_active),
    .request_started(media_request_started)
);
assign media_request_cancel = 1'b0;

// TF/BMP processing belongs to B.  The legacy img_* stream remains a stub
// until A gains a second external image source.
endmodule
`default_nettype wire
