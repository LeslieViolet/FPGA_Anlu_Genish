// Passive counters and wait indicators. No output controls the datapath.
`timescale 1ns/1ps
`default_nettype none
module liucheng_jishu_zhenduan #(
    parameter MARK1=1024, MARK2=65536, MARK3=262144, MARK4=307200,
    parameter STALL_CYCLES=4096
)(
    input wire clk, rst,
    input wire count_take, progress, wait_for_event,
    output wire [3:0] milestones,
    output wire stalled
);
    reg [18:0] transfer_count;
    reg [20:0] wait_count;
    assign milestones={transfer_count>=MARK4,transfer_count>=MARK3,
                       transfer_count>=MARK2,transfer_count>=MARK1};
    assign stalled=wait_count>=STALL_CYCLES;
    always @(posedge clk or posedge rst) begin
        if(rst) begin transfer_count<=0; wait_count<=0; end
        else begin
            if(count_take && transfer_count<MARK4)
                transfer_count<=transfer_count+1'b1;
            if(!wait_for_event || progress) wait_count<=0;
            else if(wait_count<STALL_CYCLES) wait_count<=wait_count+1'b1;
        end
    end
endmodule
`default_nettype wire
