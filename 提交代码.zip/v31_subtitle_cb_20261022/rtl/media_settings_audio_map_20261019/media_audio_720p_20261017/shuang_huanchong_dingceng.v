// Parts 1..6. Part 8 supplies the memory adapter; Part 7 supplies read-idle state.
`default_nettype none
module shuang_huanchong_dingceng (
    input wire rst_catalog, input wire rst_reader,
    input wire clk_write, rst_write,
    input wire [95:0] ui_status_payload_pixel,
    input wire scan_valid,
    output wire scan_ready,
    input wire [31:0] scan_first_lba, scan_last_lba,
    output wire scan_done,
    output wire [3:0] scan_status,
    output wire [4:0] asset_count,
    input wire request_valid,
    output wire request_ready,
    input wire [3:0] request_id,
    input wire request_cancel,
    output wire request_result_valid,
    input wire request_result_ready,
    output wire [3:0] request_result_code,
    output wire [15:0] request_result_index,
    output wire request_result_buffer_sel,
    output wire [1:0] slot_busy,
    output wire reset_required,
    output wire [3:0] reader_error_code,
    output wire mem_write_valid,
    input wire mem_write_ready,
    output wire [20:0] mem_write_addr,
    output wire [31:0] mem_write_data,
    output wire mem_flush_req,
    input wire mem_flush_done,
    input wire memory_fault,
    input wire clk_display, rst_display,
    output wire frame_ready,
    input wire disp_req,
    output wire disp_ack,
    input wire disp_keep_old,
    input wire display_reads_idle,
    output wire disp_valid,
    output wire disp_buffer_sel,
    output wire [1:0] disp_physical_slot,
    output wire [15:0] disp_width, disp_height, disp_index,
    output wire [31:0] disp_generation,
    output wire disp_previous_valid, disp_previous_sel,
    input wire disp_previous_release_req,
    output wire disp_previous_release_ack,
    output wire card_ready,
    output wire bgm_selected, bgm_audio_valid,
    output wire [23:0] bgm_audio_left, bgm_audio_right,
    output wire bgm_acr_valid,
    output wire [19:0] bgm_acr_cts, bgm_acr_n,
    output wire bgm_meter_valid,
    output wire bgm_visualizer_enable,
    output wire [3:0] bgm_level_left, bgm_level_right,
    output wire tf_cs_n, tf_sclk, tf_mosi,
    input wire tf_miso
);
    localparam active_hd = 1'b1;
    wire load_valid, load_ready, load_buffer_sel, load_abort;
    wire [1:0] load_physical_slot;
    wire [3:0] load_id;
    wire write_result_valid, write_result_ready, write_result_buffer_sel;
    wire [3:0] write_result_code;
    wire [15:0] write_result_index;
    wire writer_reset, writer_busy;

    zhen_xieru_dingceng  u_zhen_xieru_dingceng (
        .rst_catalog(rst_catalog),.rst_reader(rst_reader),
        .clk_pixel(clk_display),.rst_pixel(rst_display),
        .ui_status_payload_pixel(ui_status_payload_pixel),
        
        .clk(clk_write), .rst(rst_write), .scan_valid(scan_valid), .scan_ready(scan_ready),
        .scan_first_lba(scan_first_lba), .scan_last_lba(scan_last_lba),
        .scan_done(scan_done), .scan_status(scan_status), .asset_count(asset_count),
        .load_valid(load_valid), .load_ready(load_ready), .load_id(load_id),
        .load_buffer_sel(load_buffer_sel), .load_physical_slot(load_physical_slot),
        .abort(load_abort), .busy(writer_busy),
        .reset_required(writer_reset), .result_valid(write_result_valid),
        .result_ready(write_result_ready), .result_code(write_result_code),
        .result_index(write_result_index), .result_buffer_sel(write_result_buffer_sel),
        .reader_error_code(reader_error_code), .mem_write_valid(mem_write_valid),
        .mem_write_ready(mem_write_ready), .mem_write_addr(mem_write_addr),
        .mem_write_data(mem_write_data), .mem_flush_req(mem_flush_req),
        .mem_flush_done(mem_flush_done), .memory_fault(memory_fault), .card_ready(card_ready),
        .bgm_selected(bgm_selected),.bgm_audio_valid(bgm_audio_valid),
        .bgm_audio_left(bgm_audio_left),.bgm_audio_right(bgm_audio_right),
        .bgm_acr_valid(bgm_acr_valid),.bgm_acr_cts(bgm_acr_cts),.bgm_acr_n(bgm_acr_n),
        .bgm_meter_valid(bgm_meter_valid),.bgm_level_left(bgm_level_left),.bgm_level_right(bgm_level_right),
        .bgm_visualizer_enable(bgm_visualizer_enable),
        .tf_cs_n(tf_cs_n), .tf_sclk(tf_sclk), .tf_mosi(tf_mosi), .tf_miso(tf_miso)
    );

    shuang_huanchong  u_shuang_huanchong (
    
        
        .clk_write(clk_write), .rst_write(rst_write),
        .request_valid(request_valid), .request_ready(request_ready),
        .request_id(request_id), .asset_count(asset_count),
        .request_cancel(request_cancel),
        .load_valid(load_valid), .load_ready(load_ready), .load_id(load_id),
        .load_buffer_sel(load_buffer_sel), .load_physical_slot(load_physical_slot),
        .load_abort(load_abort),
        .write_result_valid(write_result_valid), .write_result_ready(write_result_ready),
        .write_result_code(write_result_code), .write_result_index(write_result_index),
        .write_result_buffer_sel(write_result_buffer_sel),
        .write_reset_required(writer_reset), .request_result_valid(request_result_valid),
        .request_result_ready(request_result_ready), .request_result_code(request_result_code),
        .request_result_index(request_result_index),
        .request_result_buffer_sel(request_result_buffer_sel), .write_busy(), .slot_busy(slot_busy),
        .clk_display(clk_display), .rst_display(rst_display), .frame_ready(frame_ready),
        .disp_req(disp_req), .disp_ack(disp_ack), .disp_keep_old(disp_keep_old),
        .display_reads_idle(display_reads_idle), .disp_valid(disp_valid),
        .disp_buffer_sel(disp_buffer_sel), .disp_width(disp_width), .disp_height(disp_height),
        .disp_index(disp_index), .disp_physical_slot(disp_physical_slot),
        .disp_generation(disp_generation),
        .disp_previous_valid(disp_previous_valid), .disp_previous_sel(disp_previous_sel),
        .disp_previous_release_req(disp_previous_release_req),
        .disp_previous_release_ack(disp_previous_release_ack)
    );
    assign reset_required = writer_reset;
endmodule
`default_nettype wire
