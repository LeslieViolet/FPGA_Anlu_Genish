`default_nettype none
// Only valid SOF advances animation. No rectangle overlay is generated.
module promo_marquee_renderer #(parameter FRAME_WIDTH=1280)(
 input wire clk,rst,enabled,input wire [10:0] x,y,input wire user_in,valid_in,
 output reg font_valid,output wire [8:0] font_address,
 output wire [3:0] font_col,output reg [1:0] font_palette
);
 localparam integer VIEW_X=FRAME_WIDTH/2-320,VIEW_END=FRAME_WIDTH/2+320;
 localparam [10:0] OFFSET_START=2048-VIEW_END;
 localparam [1:0] ENTER=0,HOLD=1,EXIT=2;
 reg [1:0] phrase_id,phase;
 reg [6:0] hold_frames;
 reg [10:0] scroll_offset;
 localparam [10:0] CENTER_OFFSET=2048-(FRAME_WIDTH-352)/2;
 localparam [10:0] END_OFFSET=2048-VIEW_X+352;
 wire [10:0] next_offset=scroll_offset+11'd4;
 wire [10:0] text_rel_x=x+scroll_offset;
 wire [3:0] character=text_rel_x[8:5];
 wire [3:0] font_row=y[4:1]+4'd4;
 reg [4:0] glyph_bias;
 reg character_valid;
 wire [4:0] glyph_index={1'b0,character}+glyph_bias;
 assign font_address={glyph_index,font_row};
 assign font_col=text_rel_x[4:1];
 always @*begin
  case(phrase_id)
   0:begin glyph_bias=30;character_valid=character>=2&&character<9;end
   1:begin glyph_bias=7;character_valid=character<11;end
   default:begin glyph_bias=17;character_valid=character>=1&&character<10;end
  endcase
 end
 always @(posedge clk or posedge rst)begin
  if(rst)begin phrase_id<=0;phase<=ENTER;hold_frames<=0;scroll_offset<=OFFSET_START;end
  else if(enabled&&valid_in&&user_in)begin
   case(phase)
    ENTER:begin
     scroll_offset<=next_offset;
     if(next_offset==CENTER_OFFSET)begin phase<=HOLD;hold_frames<=0;end
    end
    HOLD:begin
     if(hold_frames==7'd119)begin phase<=EXIT;scroll_offset<=next_offset;end
     else hold_frames<=hold_frames+7'd1;
    end
    EXIT:begin
     if(scroll_offset==END_OFFSET)begin
      phrase_id<=phrase_id==2?2'd0:phrase_id+2'd1;
      scroll_offset<=OFFSET_START;phase<=ENTER;
     end else scroll_offset<=next_offset;
    end
    default:begin phrase_id<=0;phase<=ENTER;hold_frames<=0;scroll_offset<=OFFSET_START;end
   endcase
  end
 end
 always @*begin
  font_valid=enabled&&valid_in&&x>=VIEW_X&&x<VIEW_END&&y>=24&&y<56&&text_rel_x<352&&character_valid;
  font_palette=0;
  if(phrase_id==1)begin
   if(character<6)font_palette=1;
   else if(character>=7)font_palette=2;
  end
 end
endmodule
`default_nettype wire
