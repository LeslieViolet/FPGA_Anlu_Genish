module tone_generator (
    input  wire               clk,
    input  wire               rst,
    input  wire               sample_tick,
    input  wire               tone_enable,
    input  wire [31:0]        phase_step,

    output reg signed [23:0]  pcm_sample
);

    // 32位相位累加器。phase_step越大，输出音调越高。
    reg [31:0] phase_accumulator;

    // 约为24位满幅的1/8，给后续音量调节预留余量。
    localparam signed [23:0] TONE_AMPLITUDE = 24'sd1048576;

    always @(posedge clk) begin
        if (rst) begin
            phase_accumulator <= 32'd0;
            pcm_sample         <= 24'sd0;
        end
        else if (sample_tick) begin
            if (tone_enable) begin
                phase_accumulator <= phase_accumulator + phase_step;

                // 相位最高位决定方波的正、负半周。
                if (phase_accumulator[31])
                    pcm_sample <= -TONE_AMPLITUDE;
                else
                    pcm_sample <=  TONE_AMPLITUDE;
            end
            else begin
                phase_accumulator <= 32'd0;
                pcm_sample         <= 24'sd0;
            end
        end
    end

endmodule
