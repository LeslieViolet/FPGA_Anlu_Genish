`default_nettype none
// Static-720p adapter around the one physical image/WAV TF storage service.
module audio_board_shared_reader #(
    parameter integer PIXEL_HZ = 75000000
)(
    input wire clk_sd,
    input wire rst_sd,
    input wire clk_pixel,
    input wire rst_pixel,
    input wire [95:0] ui_status_payload_pixel,
    input wire read_valid,
    output wire read_ready,
    input wire [31:0] read_lba,
    output wire [7:0] data,
    output wire data_valid,
    output wire data_last,
    input wire data_ready,
    output reg busy,
    output wire card_ready,
    output wire done,
    output wire error,
    output wire [3:0] error_code,
    input wire image_cancel,
    output reg reader_changed,
    output wire bgm_selected,
    output wire bgm_audio_valid,
    output wire [23:0] bgm_audio_left,
    output wire [23:0] bgm_audio_right,
    output wire bgm_acr_valid,
    output wire [19:0] bgm_acr_cts,
    output wire [19:0] bgm_acr_n,
    output wire bgm_meter_valid,
    output wire bgm_visualizer_enable,
    output wire [3:0] bgm_level_left,
    output wire [3:0] bgm_level_right,
    output wire tf_cs_n,
    output wire tf_sclk,
    output wire tf_mosi,
    input wire tf_miso
);
    wire policy_bgm_selected;
    wire audio_session_request;
    wire audio_play_enable;
    wire settings_visible;
    wire mute;
    wire [3:0] volume_level;
    wire visualizer_enable;
    wire [1:0] policy_audio_track;
    reg [1:0] session_track_pixel;
    wire [1:0] audio_control_pixel=audio_session_request?session_track_pixel:2'd0;
    reg [1:0] audio_control_last_pixel;
    wire audio_control_src_ready,audio_control_dst_valid;
    wire [1:0] audio_control_sd;
    reg [1:0] audio_track_desired_sd;
    reg [1:0] active_track_sd;

    audio_ui_policy u_audio_ui_policy (
        .ui_status_payload_pixel(ui_status_payload_pixel),
        .bgm_selected(policy_bgm_selected),
        .audio_session_request(audio_session_request),
        .audio_play_enable(audio_play_enable),
        .settings_visible(settings_visible),
        .mute(mute),
        .volume_level(volume_level),
        .visualizer_enable(visualizer_enable),
        .audio_track_select(policy_audio_track)
    );

    assign bgm_selected = !rst_pixel && policy_bgm_selected;
    assign bgm_visualizer_enable = !rst_pixel && visualizer_enable;

    always @(posedge clk_pixel or posedge rst_pixel) begin
        if (rst_pixel) begin
            session_track_pixel <= 2'd0;
            audio_control_last_pixel <= 2'd0;
        end else begin
            if (!settings_visible)
                session_track_pixel <= policy_audio_track;
            if (audio_control_src_ready && audio_control_pixel != audio_control_last_pixel)
                audio_control_last_pixel <= audio_control_pixel;
        end
    end

    ui_snapshot_mailbox #(.PAYLOAD_W(2)) u_audio_control_mailbox (
        .src_clk(clk_pixel), .src_rst(rst_pixel),
        .src_valid(audio_control_pixel != audio_control_last_pixel),
        .src_ready(audio_control_src_ready), .src_payload(audio_control_pixel),
        .dst_clk(clk_sd), .dst_rst(rst_sd),
        .dst_valid(audio_control_dst_valid), .dst_ready(1'b1),
        .dst_payload(audio_control_sd)
    );

    wire audio_start_ready;
    wire audio_start_valid = (audio_track_desired_sd != 2'd0) &&
                             (active_track_sd == 2'd0) &&
                             audio_start_ready && card_ready;
    wire audio_stop = (active_track_sd != 2'd0) &&
                      (audio_track_desired_sd != active_track_sd);
    wire audio_result_valid;
    wire [7:0] audio_result_code;
    wire audio_busy;
    wire image_block_done;
    wire [31:0] audio_underflow;
    wire unused_track_end;
    wire storage_reset_required;
    reg storage_reinit;
    reg recovery_pending;
    reg image_cancel_seen;
    wire storage_rst = rst_sd | storage_reinit;

    always @(posedge clk_sd or posedge rst_sd) begin
        if (rst_sd) begin
            storage_reinit <= 1'b0;
            recovery_pending <= 1'b0;
            reader_changed <= 1'b0;
            image_cancel_seen <= 1'b0;
        end else begin
            storage_reinit <= 1'b0;
            reader_changed <= 1'b0;

            if (read_valid && read_ready)
                image_cancel_seen <= image_cancel;
            else if (busy && image_cancel)
                image_cancel_seen <= 1'b1;

            // Audio file/parser errors end only that track session. The audio
            // session and sector service separately assert reset_required for
            // a stuck or unhealthy physical read that needs card recovery.
            if (storage_reset_required ||
                (error && error_code != 4'd12 && !image_cancel_seen && !image_cancel)) begin
                storage_reinit <= 1'b1;
                recovery_pending <= 1'b1;
                image_cancel_seen <= 1'b0;
            end else if (recovery_pending && card_ready) begin
                reader_changed <= 1'b1;
                recovery_pending <= 1'b0;
            end
        end
    end

    always @(posedge clk_sd or posedge storage_rst) begin
        if (storage_rst) begin
            active_track_sd <= 2'd0;
            busy <= 1'b0;
        end else begin
            if (audio_start_valid) begin
                active_track_sd <= audio_track_desired_sd;
            end else if (audio_stop) begin
                active_track_sd <= 2'd0;
            end

            if (read_valid && read_ready)
                busy <= 1'b1;
            else if (done || error)
                busy <= 1'b0;
        end
    end

    always @(posedge clk_sd or posedge rst_sd) begin
        if (rst_sd) begin
            audio_track_desired_sd <= 2'd0;
        end else if (audio_control_dst_valid) begin
            audio_track_desired_sd <= audio_control_sd;
        end
    end

    audio_slideshow_storage #(.PIXEL_HZ(PIXEL_HZ)) u_shared_storage (
        .source_clk(clk_sd),
        .pixel_clk(clk_pixel),
        .rst(storage_rst),
        .audio_start_valid(audio_start_valid),
        .audio_track_select(audio_track_desired_sd),
        .audio_stop(audio_stop),
        .audio_loop(1'b1),
        .audio_start_ready(audio_start_ready),
        .audio_result_valid(audio_result_valid),
        .audio_result_ready(1'b1),
        .audio_result_code(audio_result_code),
        .audio_busy(audio_busy),
        .reset_required(storage_reset_required),
        .card_ready(card_ready),
        .image_req_valid(read_valid),
        .image_req_ready(read_ready),
        .image_lba(read_lba),
        .image_blocks(16'd1),
        .image_cancel(image_cancel),
        .image_data(data),
        .image_data_valid(data_valid),
        .image_data_last(data_last),
        .image_data_ready(data_ready),
        .image_block_done(image_block_done),
        .image_done(done),
        .image_error(error),
        .image_error_code(error_code),
        .play_enable(audio_play_enable),
        .mute(mute),
        .volume_level(volume_level),
        .visualizer_enable(visualizer_enable),
        .settings_visible(settings_visible),
        .video_active(1'b0),
        .ui_x(10'd0),
        .ui_y(10'd0),
        .ui_pixel_in(24'd0),
        .ui_pixel_out(),
        .audio_valid(bgm_audio_valid),
        .audio_left_data(bgm_audio_left),
        .audio_right_data(bgm_audio_right),
        .acr_valid(bgm_acr_valid),
        .acr_cts(bgm_acr_cts),
        .acr_n(bgm_acr_n),
        .meter_valid(bgm_meter_valid),
        .level_left(bgm_level_left),
        .level_right(bgm_level_right),
        .underflow_count(audio_underflow),
        .track_end(unused_track_end),
        .tf_cs_n(tf_cs_n),
        .tf_sclk(tf_sclk),
        .tf_mosi(tf_mosi),
        .tf_miso(tf_miso)
    );
endmodule
`default_nettype wire
