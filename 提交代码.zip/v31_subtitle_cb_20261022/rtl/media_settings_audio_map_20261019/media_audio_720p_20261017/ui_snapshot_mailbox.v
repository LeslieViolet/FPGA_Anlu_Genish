`default_nettype none

// Stable-payload mailbox for UI snapshots crossing clk_sys -> clk_pixel.
// The payload is held in the source domain until the destination consumes it.
// Only the request/ack toggles cross through two-flop synchronizers.
module ui_snapshot_mailbox #(
    parameter integer PAYLOAD_W = 64
)(
    input  wire                   src_clk,
    input  wire                   src_rst,
    input  wire                   src_valid,
    output wire                   src_ready,
    input  wire [PAYLOAD_W-1:0]   src_payload,
    input  wire                   dst_clk,
    input  wire                   dst_rst,
    output reg                    dst_valid,
    input  wire                   dst_ready,
    output reg  [PAYLOAD_W-1:0]   dst_payload
);
reg req_toggle;
reg ack_toggle;
(* async_reg = "true" *) reg ack_sync1, ack_sync2;
(* async_reg = "true" *) reg req_sync1, req_sync2;
reg [PAYLOAD_W-1:0] payload_hold;

assign src_ready = (req_toggle == ack_sync2);

always @(posedge src_clk or posedge src_rst) begin
    if (src_rst) begin
        req_toggle <= 1'b0;
        payload_hold <= {PAYLOAD_W{1'b0}};
        ack_sync1 <= 1'b0;
        ack_sync2 <= 1'b0;
    end else begin
        ack_sync1 <= ack_toggle;
        ack_sync2 <= ack_sync1;
        if (src_valid && src_ready) begin
            payload_hold <= src_payload;
            req_toggle <= ~req_toggle;
        end
    end
end

always @(posedge dst_clk or posedge dst_rst) begin
    if (dst_rst) begin
        req_sync1 <= 1'b0;
        req_sync2 <= 1'b0;
        ack_toggle <= 1'b0;
        dst_valid <= 1'b0;
        dst_payload <= {PAYLOAD_W{1'b0}};
    end else begin
        req_sync1 <= req_toggle;
        req_sync2 <= req_sync1;
        if (dst_valid && dst_ready) begin
            dst_valid <= 1'b0;
            ack_toggle <= req_sync2;
        end else if (!dst_valid && (req_sync2 != ack_toggle)) begin
            // payload_hold has been stable since the request toggle crossed.
            dst_payload <= payload_hold;
            dst_valid <= 1'b1;
        end
    end
end
endmodule
`default_nettype wire
