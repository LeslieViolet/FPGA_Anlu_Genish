`default_nettype none
// UI media input replacement for the teammate A handoff module.
// Legacy img_* stream remains idle; media request/result follows the handoff contract.
module ui_media_input_subsystem #(parameter integer DEMO_IMAGES=0) (
    input wire key_next_n, input wire key_auto_n, input wire key_aux_n, input wire ir_rx_async,
    input wire clk_sys, input wire clk_sd, input wire clk_pixel, input wire rst_sys, input wire rst_sd, input wire rst_pixel,
    output wire img_frame_start, input wire img_start_ready,
    output wire [15:0] img_width, output wire [15:0] img_height,
    output wire img_bottom_up, output wire [15:0] img_index,
    output wire img_pixel_valid, input wire img_pixel_ready,
    output wire [23:0] img_pixel_data, output wire img_frame_end,
    input wire img_end_ready, output wire img_abort, input wire img_abort_ready,
    input wire img_result_valid, output wire img_result_ready,
    input wire [3:0] img_result_code, input wire [15:0] img_result_index,
    input wire media_card_offline,input wire media_catalog_done, input wire media_catalog_ok,
    input wire [4:0] media_asset_count, input wire media_storage_ready,
    output wire media_request_valid, input wire media_request_ready,
    output wire [3:0] media_request_id, output wire media_request_cancel,
    input wire media_result_valid, input wire [3:0] media_result_code,
    output wire media_request_started, output wire input_fault, output wire software_reset_req,
    output wire [95:0] ui_status_payload_pixel, output wire ui_status_valid_pixel,
    output wire ir_debug_event_valid, output wire [7:0] ir_debug_command,
    output wire ir_debug_fault, output wire ir_debug_edge_valid
);
    wire catalog_ready_sys, media_busy_sys, result_valid_sys;
    wire [4:0] asset_count_sys;
    wire [3:0] current_id_sys, result_code_sys;
    wire auto_enabled_sys;
    wire [3:0] ui_state;
    wire [1:0] home_focus;
    wire [1:0] launch_mode;
    wire [15:0] browser_index;
    wire [3:0] brightness_level, zoom_level;
    wire [1:0] rotation_mode;
    wire playback_rate_valid;
    wire [1:0] playback_rate_code;
    wire [2:0] settings_page, settings_focus;
    wire [3:0] bgm_map_picture;
    wire [1:0] bgm_map_track,current_bgm_track;
    wire [3:0] volume_level, contrast_level;
    wire [3:0] auto_interval_code, edit_value;
    wire [1:0] transition_mode,settings_feedback;
    wire confirm_active,confirm_yes;
    wire mute_enabled, osd_enabled, audio_visualizer_enabled, subtitle_enabled, player_playing;
    wire slideshow_auto,audio_enabled;
    wire ui_fault;
    wire settings_numeric_edit;
    wire ui_click_toggle_sys;
    assign img_frame_start = 1'b0;
    assign img_width = 16'd0;
    assign img_height = 16'd0;
    assign img_bottom_up = 1'b0;
    assign img_index = 16'd0;
    assign img_pixel_valid = 1'b0;
    assign img_pixel_data = 24'd0;
    assign img_frame_end = 1'b0;
    assign img_abort = 1'b0;
    assign img_result_ready = 1'b0;
    assign input_fault = ui_fault;
    wire home_enable_sys = (ui_state == 4'd0) || (ui_state == 4'd8);
    // Display/control snapshot V6. All fields cross clk_sys->clk_pixel as one
    // acknowledged transaction; list count/index cannot tear independently.
    wire [63:0] ui_status_payload_legacy = {
        ui_state,                 // 63:60
        home_enable_sys,          // 59
        home_focus,               // 58:57
        launch_mode,              // 56:55
        catalog_ready_sys,        // 54
        ~ir_debug_fault,          // 53
        auto_enabled_sys,         // 52
        media_busy_sys,           // 51
        asset_count_sys[2:0],     // 50:48 compatibility
        browser_index[2:0],       // 47:45
        (DEMO_IMAGES?browser_index[2:0]:current_id_sys[2:0]), // 44:42
        result_code_sys,          // 41:38
        zoom_level,               // 37:34
        rotation_mode,            // 33:32
        ui_fault,                 // 31
        brightness_level,         // 30:27
        settings_page,            // 26:24
        settings_focus,           // 23:21
        volume_level,             // 20:17
        mute_enabled,             // 16
        osd_enabled,              // 15
        audio_visualizer_enabled, // 14 runtime spectrum switch
        contrast_level,           // 13:10
        current_bgm_track,       // 9:8 当前已加载图片的配乐编号
        transition_mode,          // 7:6
        player_playing,           // 5
        1'b0,ui_click_toggle_sys, // 4 reserved; 3 acknowledged click event toggle
        slideshow_auto, audio_enabled, settings_numeric_edit // 2 auto preference; 1 audio enable; 0 editing
    };
    wire [95:0] ui_status_payload_sys={edit_value,auto_interval_code,settings_feedback,confirm_active,confirm_yes,bgm_map_picture,bgm_map_track,subtitle_enabled,current_id_sys,browser_index[3:0],asset_count_sys,ui_status_payload_legacy};
    reg [95:0] ui_status_last_sys;
    wire ui_status_changed = (ui_status_payload_sys != ui_status_last_sys);
    wire ui_status_src_ready;
        always @(posedge clk_sys or posedge rst_sys) begin
            if (rst_sys) ui_status_last_sys <= 96'd0;
            else if (ui_status_changed && ui_status_src_ready)
                ui_status_last_sys <= ui_status_payload_sys;
        end
    ui_snapshot_mailbox #(.PAYLOAD_W(96)) u_ui_status_mailbox (
        .src_clk(clk_sys), .src_rst(rst_sys),
        .src_valid(ui_status_changed), .src_ready(ui_status_src_ready),
        .src_payload(ui_status_payload_sys),
        .dst_clk(clk_pixel), .dst_rst(rst_pixel),
        .dst_valid(ui_status_valid_pixel), .dst_ready(1'b1),
        .dst_payload(ui_status_payload_pixel)
    );
    ui_media_control_subsystem #(.DEMO_IMAGES(DEMO_IMAGES),.CLK_SYS_HZ(50000000), .CLK_SD_HZ(50000000), .AUTO_SECONDS(5)) u_ui_media (
        .clk_sys(clk_sys), .rst_sys(rst_sys), .clk_sd(clk_sd), .rst_sd(rst_sd),
        .key_next_n(key_next_n), .key_auto_n(key_auto_n), .key_aux_n(key_aux_n),
        .ir_rx_async(ir_rx_async), .card_offline_sd(media_card_offline),.catalog_done_sd(media_catalog_done),
        .catalog_ok_sd(media_catalog_ok), .asset_count_sd(media_asset_count),
        .storage_ready_sd(media_storage_ready),
        .media_request_ready_sd(media_request_ready),
        .media_result_valid_sd(media_result_valid), .media_result_code_sd(media_result_code),
        .media_request_valid_sd(media_request_valid), .media_request_id_sd(media_request_id),
        .media_request_cancel_sd(media_request_cancel),
        .media_request_started_sd(media_request_started), .catalog_ready_sys(catalog_ready_sys),
        .asset_count_sys(asset_count_sys), .current_id_sys(current_id_sys),
        .auto_enabled_sys(auto_enabled_sys), .media_busy_sys(media_busy_sys),
        .result_valid_sys(result_valid_sys), .result_code_sys(result_code_sys),
        .ui_state(ui_state), .browser_index(browser_index),
        .home_focus(home_focus), .launch_mode(launch_mode),
        .brightness_level(brightness_level), .zoom_level(zoom_level),
        .rotation_mode(rotation_mode), .settings_page(settings_page),
        .playback_rate_valid(playback_rate_valid), .playback_rate_code(playback_rate_code),
        .settings_focus(settings_focus), .volume_level(volume_level),
        .bgm_map_picture(bgm_map_picture),.bgm_map_track(bgm_map_track),.current_bgm_track(current_bgm_track),
        .mute_enabled(mute_enabled), .contrast_level(contrast_level),
        .auto_interval_code(auto_interval_code), .transition_mode(transition_mode),
        .osd_enabled(osd_enabled), .audio_visualizer_enabled(audio_visualizer_enabled),
        .subtitle_enabled(subtitle_enabled),.slideshow_auto(slideshow_auto),.audio_enabled(audio_enabled),
        .settings_numeric_edit(settings_numeric_edit), .player_playing(player_playing),
        .ui_fault(ui_fault), .ir_hold_active(),
        .edit_value(edit_value), .settings_feedback(settings_feedback),
        .confirm_active(confirm_active), .confirm_yes(confirm_yes), .software_reset_req(software_reset_req),
        .ui_click_toggle(ui_click_toggle_sys),
        .ir_debug_event_valid(ir_debug_event_valid),
        .ir_debug_command(ir_debug_command), .ir_debug_fault(ir_debug_fault),
        .ir_debug_edge_valid(ir_debug_edge_valid)
    );
endmodule
`default_nettype wire
