`default_nettype none
// Audio-first shared TF service. Image payload is provisional until block_done
// and the whole image must still pass its parent's frame commit protocol.
module audio_slideshow_storage #(
 parameter integer PIXEL_HZ=25000000,
 parameter integer POWER_UP_CYCLES=1000000,
 parameter [15:0] INIT_HALF_PERIOD=16'd125,DATA_HALF_PERIOD=16'd2,
 parameter integer TIMEOUT_CYCLES=250000000,
 parameter integer STOP_TIMEOUT_BYTES=65535
)(
 input wire source_clk,pixel_clk,rst,
 input wire audio_start_valid,audio_stop,audio_loop,input wire [1:0] audio_track_select,output wire audio_start_ready,
 output wire audio_result_valid,input wire audio_result_ready,output wire [7:0] audio_result_code,
 output wire audio_busy,reset_required,card_ready,
 input wire image_req_valid,output wire image_req_ready,input wire [31:0] image_lba,
 input wire [15:0] image_blocks,input wire image_cancel,
 output wire [7:0] image_data,output wire image_data_valid,image_data_last,
 input wire image_data_ready,output wire image_block_done,image_done,image_error,
 output wire [3:0] image_error_code,
 input wire play_enable,mute,input wire [3:0] volume_level,
 input wire visualizer_enable,settings_visible,video_active,
 input wire [9:0] ui_x,ui_y,input wire [23:0] ui_pixel_in,
 output wire [23:0] ui_pixel_out,
 output wire audio_valid,output wire [23:0] audio_left_data,audio_right_data,
 output wire acr_valid,output wire [19:0] acr_cts,acr_n,
 output wire meter_valid,output wire [3:0] level_left,level_right,
 output wire [31:0] underflow_count,output wire track_end,
 output wire tf_cs_n,tf_sclk,tf_mosi,input wire tf_miso
);
 (* async_reg="true" *) reg [2:0] source_release;
 always @(posedge source_clk or posedge rst)
  if(rst)source_release<=3'b111;else source_release<={source_release[1:0],1'b0};
 wire source_rst=source_release[2];
 wire a_req,a_ready,a_data_valid,a_data_ready,a_last,a_finish,a_finish_ok;
 wire [31:0] a_lba;
 wire [7:0] a_data;
 wire [10:0] audio_buffered_source;
 wire audio_reset_required,service_reset_required;
 wire p_valid,p_ready,p_data_valid,p_data_ready,p_last,p_block_done,p_done,p_error;
 wire [31:0] p_lba;wire [15:0] p_blocks;wire [7:0] p_data;
 wire [3:0] p_error_code;
 wire [1:0] svc_ready,svc_valid,svc_last,svc_blocks,svc_busy,svc_card,svc_cancel,svc_done,svc_error;
 wire [7:0] svc_error_code;
 wire raw_image_ready;
 reg owner_active,owner_image;
 always @(posedge source_clk or posedge source_rst)begin
  if(source_rst)begin owner_active<=0;owner_image<=0;end
  else begin
   // The arbiter now accepts a registered descriptor before physical ready.
   // Keep cancellation ownership throughout that queue wait as well as SPI.
   if((a_req&&a_ready)||(image_req_valid&&image_req_ready))begin
    owner_active<=1;owner_image<=image_req_valid&&image_req_ready;
   end
   if(owner_active&&(a_finish||image_done||image_error))owner_active<=0;
  end
 end
 wire cancel_owner=svc_cancel[0]||(image_cancel&&owner_active&&owner_image);
 assign reset_required=audio_reset_required||service_reset_required;
 assign card_ready=svc_card[0]&&!reset_required;
 assign image_req_ready=raw_image_ready&&!image_cancel&&!reset_required;
 assign p_ready=svc_ready[0];assign p_data_valid=svc_valid[0];assign p_last=svc_last[0];
 assign p_block_done=svc_blocks[0];assign p_done=svc_done[0];assign p_error=svc_error[0];
 assign p_error_code=svc_error_code[3:0];
 audio_bgm_player #(.PIXEL_HZ(PIXEL_HZ),.TIMEOUT_CYCLES(TIMEOUT_CYCLES)) u_player(
  .source_clk(source_clk),.pixel_clk(pixel_clk),.rst(source_rst),
  .start_valid(audio_start_valid),.stop(audio_stop),.loop_enable(audio_loop),.track_select(audio_track_select),.start_ready(audio_start_ready),
  .read_valid(a_req),.read_ready(a_ready),.read_lba(a_lba),.data(a_data),.data_valid(a_data_valid),.data_ready(a_data_ready),.data_last(a_last),
  .read_done(a_finish&&a_finish_ok),.read_error(a_finish&&!a_finish_ok),
  .play_enable(play_enable),.mute(mute),.volume_level(volume_level),.visualizer_enable(visualizer_enable),.settings_visible(settings_visible),
  .video_active(video_active),.ui_x(ui_x),.ui_y(ui_y),.ui_pixel_in(ui_pixel_in),.ui_pixel_out(ui_pixel_out),
  .audio_valid(audio_valid),.audio_left_data(audio_left_data),.audio_right_data(audio_right_data),.acr_valid(acr_valid),.acr_cts(acr_cts),.acr_n(acr_n),
  .meter_valid(meter_valid),.level_left(level_left),.level_right(level_right),.underflow_count(underflow_count),.track_end(track_end),
  .buffered_samples(),.buffered_source(audio_buffered_source),.result_valid(audio_result_valid),.result_ready(audio_result_ready),
  .result_code(audio_result_code),.reset_required(audio_reset_required),.busy(audio_busy));
 audio_image_sector_arbiter u_arbiter(
  .clk(source_clk),.rst(source_rst),.abort(cancel_owner),.audio_urgent(audio_buffered_source<11'd512),
  .audio_req_valid(a_req),.audio_req_ready(a_ready),.audio_lba(a_lba),.audio_valid_bytes(10'd512),.audio_file_last(1'b0),
  .audio_sector_start_valid(),.audio_sector_start_ready(1'b1),.audio_sector_valid_bytes(),.audio_sector_file_last(),
  .audio_provisional_data(a_data),.audio_provisional_valid(a_data_valid),.audio_provisional_ready(a_data_ready),.audio_provisional_last(a_last),
  .audio_finish_valid(a_finish),.audio_finish_ok(a_finish_ok),
  .image_req_valid(image_req_valid&&!image_cancel&&!reset_required),.image_req_ready(raw_image_ready),.image_lba(image_lba),.image_blocks(image_blocks),
  .image_data(image_data),.image_data_valid(image_data_valid),.image_data_last(image_data_last),.image_data_ready(image_data_ready),
  .image_block_done(image_block_done),.image_done(image_done),.image_error(image_error),.image_error_code(image_error_code),
  .physical_read_valid(p_valid),.physical_read_ready(p_ready),.physical_lba(p_lba),.physical_blocks(p_blocks),
  .physical_data(p_data),.physical_data_valid(p_data_valid),.physical_data_last(p_last),.physical_data_ready(p_data_ready),
  .physical_block_done(p_block_done),.physical_done(p_done),.physical_error(p_error),.physical_error_code(p_error_code));
 media_sector_service #(.POWER_UP_CYCLES(POWER_UP_CYCLES),.INIT_HALF_PERIOD(INIT_HALF_PERIOD),.DATA_HALF_PERIOD(DATA_HALF_PERIOD),
   .SWITCH_TIMEOUT_CYCLES(TIMEOUT_CYCLES),.STOP_TIMEOUT_BYTES(STOP_TIMEOUT_BYTES)) u_service(
  .clk(source_clk),.rst(source_rst),.mode_valid(1'b0),.mode_ready(),.requested_mode(1'b0),.active_mode(),.mode_result_valid(),.mode_result_ready(1'b1),
  .mode_result_code(),.switching(),.reset_required(service_reset_required),.clients_idle({1'b1,!owner_active}),.client_cancel_supported(2'b00),
  .memory_drained(1'b1),.display_reads_retired(1'b1),.external_fault(audio_reset_required),
  .client_read_valid({1'b0,p_valid}),.client_read_ready(svc_ready),.client_lba({32'd0,p_lba}),.client_blocks({16'd0,p_blocks}),
  .client_data(p_data),.client_data_valid(svc_valid),.client_data_last(svc_last),.client_data_ready({1'b1,p_data_ready}),
  .client_block_done(svc_blocks),.client_busy(svc_busy),.client_card_ready(svc_card),.client_cancel(svc_cancel),
  .client_done(svc_done),.client_error(svc_error),.client_error_code(svc_error_code),
  .tf_cs_n(tf_cs_n),.tf_sclk(tf_sclk),.tf_mosi(tf_mosi),.tf_miso(tf_miso));
endmodule
`default_nettype wire
