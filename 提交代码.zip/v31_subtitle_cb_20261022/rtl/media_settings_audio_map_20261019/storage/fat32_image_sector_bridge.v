`default_nettype none
// File-relative BMP reader to FAT32 physical sectors. All ports share clk.
// Metadata responses remain private; owner is held until physical done/error,
// including cancellation. The physical port is the existing image client of
// the WAV/image service, not another card controller.
module fat32_image_sector_bridge #(
 parameter integer TIMEOUT_CYCLES=200000000
)(
 input wire clk,rst,abort,
 input wire open_valid,output wire open_ready,
 input wire [31:0] file_first_cluster,file_length,fat_start_lba,data_start_lba,max_cluster,
 input wire [32:0] volume_end_lba,input wire [7:0] sectors_per_cluster,
 input wire client_valid,output wire client_ready,
 output wire [7:0] client_data,output wire client_data_valid,
 input wire client_data_ready,output wire client_data_last,client_done,client_error,
 output wire busy,
 output wire read_valid,input wire read_ready,output wire [31:0] read_lba,
 input wire [7:0] data,input wire data_valid,data_last,
 output wire data_ready,input wire reader_done,reader_error
);
 localparam [1:0] NONE=0,FILE_DATA=1,FAT_META=2,VIRTUAL_ERROR=3;
 reg [1:0] owner;
 reg draining;
 wire w_sector_valid,w_sector_ready,w_meta_valid,w_meta_ready,w_meta_data_ready;
 wire w_result_valid,w_open_ready;
 wire [3:0] w_code;
 wire [31:0] w_sector_lba,w_meta_lba;
 wire meta_select=w_meta_valid;
 wire file_select=w_sector_valid && client_valid;
 assign read_valid=owner==NONE && !rst && !abort && (meta_select || file_select);
 assign read_lba=meta_select?w_meta_lba:w_sector_lba;
 assign w_meta_ready=read_ready && read_valid && meta_select;
 assign w_sector_ready=read_ready && read_valid && !meta_select;
 wire failed=w_result_valid && w_code!=0;
 assign client_ready=!rst && !abort && owner==NONE &&
       (failed || (w_sector_valid && !meta_select && read_ready));
 assign client_data=data;
 assign client_data_valid=owner==FILE_DATA && data_valid;
 assign client_data_last=data_last;
 assign client_done=owner==FILE_DATA && reader_done;
 assign client_error=(owner==FILE_DATA && reader_error) || owner==VIRTUAL_ERROR;
 assign data_ready=owner==FAT_META ? ((abort || draining)?1'b1:w_meta_data_ready) :
                   owner==FILE_DATA ? client_data_ready : 1'b1;
 assign busy=owner!=NONE;
 assign open_ready=w_open_ready && owner==NONE;
 always @(posedge clk or posedge rst)begin
  if(rst)begin owner<=NONE;draining<=0;end
  else begin
   if(owner==NONE)draining<=0;else if(abort)draining<=1;
   if(owner==NONE)begin
    if(read_valid && read_ready)owner<=meta_select?FAT_META:FILE_DATA;
    else if(client_valid && client_ready && failed)owner<=VIRTUAL_ERROR;
   end else if(owner==VIRTUAL_ERROR || reader_done || reader_error)owner<=NONE;
  end
 end
 fat32_file_sector_walker #(.TIMEOUT_CYCLES(TIMEOUT_CYCLES)) u_file_walker(
  .clk(clk),.rst(rst),.abort(abort),.open_valid(open_valid),.open_ready(w_open_ready),
  .file_first_cluster(file_first_cluster),.file_length(file_length),
  .fat_start_lba(fat_start_lba),.data_start_lba(data_start_lba),.max_cluster(max_cluster),
  .volume_end_lba(volume_end_lba),.sectors_per_cluster(sectors_per_cluster),
  .sector_valid(w_sector_valid),.sector_ready(w_sector_ready),.sector_lba(w_sector_lba),
  .sector_valid_bytes(),.sector_file_last(),
  .sector_done(reader_done && owner==FILE_DATA),.sector_error(reader_error && owner==FILE_DATA),
  .meta_read_valid(w_meta_valid),.meta_read_ready(w_meta_ready),.meta_read_lba(w_meta_lba),
  .meta_data(data),.meta_data_valid(data_valid && owner==FAT_META),.meta_data_ready(w_meta_data_ready),
  .meta_data_last(data_last),.meta_done(reader_done && owner==FAT_META),.meta_error(reader_error && owner==FAT_META),
  .result_valid(w_result_valid),.result_ready(1'b0),.result_code(w_code),.file_read_done(),.busy());
endmodule
`default_nettype wire
