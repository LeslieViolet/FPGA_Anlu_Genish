module video_rgb_to_axis #(
    parameter FRAME_WIDTH = 1280
) (
    input  wire        clk,
    input  wire        rst,

    input  wire [10:0] x,
    input  wire [10:0] y,
    input  wire        de,
    input  wire [23:0] rgb_in,

    output wire        axis_user,
    output wire        axis_valid,
    output wire        axis_last,
    output wire [23:0] axis_data
);
    wire [11:0] active_width = FRAME_WIDTH;
    wire active_hd = (FRAME_WIDTH>640);

    assign axis_valid = de;

    assign axis_user = de &&(x == 11'd0) &&(y == 11'd0);
       
    assign axis_last = de &&(x == active_width-1);

    assign axis_data = de ? rgb_in : 24'h000000;

endmodule
