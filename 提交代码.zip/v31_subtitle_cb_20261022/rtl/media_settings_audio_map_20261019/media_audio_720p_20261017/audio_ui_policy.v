`default_nettype none
module audio_ui_policy(
    input wire [95:0] ui_status_payload_pixel,
    output wire bgm_selected,
    output wire audio_session_request,
    output wire audio_play_enable,
    output wire settings_visible,
    output wire mute,
    output wire [3:0] volume_level,
    output wire visualizer_enable,
    output wire [1:0] audio_track_select
);
    wire [3:0] ui_state = ui_status_payload_pixel[63:60];
    wire slideshow_context = (ui_state == 4'd2) || (ui_state == 4'd4) ||
                             (ui_state == 4'd5) || (ui_state == 4'd6) ||
                             (ui_state == 4'd9);
    wire slideshow_mode = (ui_status_payload_pixel[56:55] == 2'd1);
    assign audio_track_select = ui_status_payload_pixel[9:8];

    assign settings_visible = (ui_state == 4'd9);
    assign audio_session_request = slideshow_mode && slideshow_context &&
                                   ui_status_payload_pixel[1];
    assign bgm_selected = audio_session_request && (audio_track_select != 2'd0);
    assign audio_play_enable = bgm_selected && !settings_visible;
    assign mute = ui_status_payload_pixel[16];
    assign volume_level = ui_status_payload_pixel[20:17];
    assign visualizer_enable = ui_status_payload_pixel[14] && bgm_selected;
endmodule
`default_nettype wire
