`default_nettype none
// Same-clock transaction mux in front of media_sector_service client 0.
// Client 1/video stays owned by the existing service mode switch.
module audio_image_sector_arbiter(
 input wire clk,rst,abort,audio_urgent,
 input wire audio_req_valid,output wire audio_req_ready,input wire [31:0] audio_lba,
 input wire [9:0] audio_valid_bytes,input wire audio_file_last,
 output wire audio_sector_start_valid,input wire audio_sector_start_ready,
 output wire [9:0] audio_sector_valid_bytes,output wire audio_sector_file_last,
 output wire [7:0] audio_provisional_data,output wire audio_provisional_valid,
 input wire audio_provisional_ready,output wire audio_provisional_last,
 output wire audio_finish_valid,audio_finish_ok,
 input wire image_req_valid,output wire image_req_ready,input wire [31:0] image_lba,
 input wire [15:0] image_blocks,
 output wire [7:0] image_data,output wire image_data_valid,image_data_last,
 input wire image_data_ready,output wire image_block_done,
 output wire image_done,output wire image_error,output wire [3:0] image_error_code,
 output wire physical_read_valid,input wire physical_read_ready,
 output wire [31:0] physical_lba,output wire [15:0] physical_blocks,
 input wire [7:0] physical_data,input wire physical_data_valid,physical_data_last,
 output wire physical_data_ready,input wire physical_block_done,
 input wire physical_done,physical_error,input wire [3:0] physical_error_code
);
 // A logical request owns the arbiter from admission until its terminal event.
 // Register the descriptor before presenting it to the physical reader: its
 // ready signal must not feed back through both clients' request generators.
 reg active,issued,owner_audio,cancelled,invalid_descriptor;
 reg [31:0] request_lba;
 reg [15:0] request_blocks;
 wire audio_candidate=audio_req_valid&&audio_sector_start_ready;
 wire choose_audio=audio_candidate&&(audio_urgent||!image_req_valid);
 wire audio_descriptor_ok=audio_valid_bytes!=0&&audio_valid_bytes<=10'd512;
 wire image_descriptor_ok=image_blocks!=0&&image_blocks<=16'd8;
 wire admission=!rst&&!abort&&!active;
 wire accepted_audio=audio_req_valid&&audio_req_ready;
 wire accepted_image=image_req_valid&&image_req_ready;
 wire queued_failure=active&&!issued&&(abort||cancelled||invalid_descriptor);
 wire issued_terminal=active&&issued&&(physical_done||physical_error);
 assign audio_req_ready=admission&&choose_audio;
 assign image_req_ready=admission&&!choose_audio;
 assign audio_sector_start_valid=audio_req_valid&&audio_req_ready;
 assign audio_sector_valid_bytes=audio_valid_bytes;
 assign audio_sector_file_last=audio_file_last;
 assign physical_read_valid=active&&!issued&&!rst&&!abort&&!cancelled&&!invalid_descriptor;
 assign physical_lba=request_lba;
 assign physical_blocks=request_blocks;
 assign physical_data_ready=active&&issued&&
   (abort||cancelled|| (owner_audio?audio_provisional_ready:image_data_ready));
 assign audio_provisional_data=physical_data;
 assign audio_provisional_valid=active&&issued&&owner_audio&&!abort&&!cancelled&&physical_data_valid;
 assign audio_provisional_last=audio_provisional_valid&&physical_data_last;
 assign audio_finish_valid=owner_audio&&(issued_terminal||queued_failure);
 assign audio_finish_ok=audio_finish_valid&&issued&&physical_done&&!physical_error&&!cancelled&&!abort;
 assign image_data=physical_data;
 assign image_data_valid=active&&issued&&!owner_audio&&!abort&&!cancelled&&physical_data_valid;
 assign image_data_last=image_data_valid&&physical_data_last;
 assign image_block_done=active&&issued&&!owner_audio&&!cancelled&&!abort&&physical_block_done;
 assign image_done=issued_terminal&&!owner_audio&&physical_done&&!physical_error&&!cancelled&&!abort;
 assign image_error=!owner_audio&&(queued_failure||
   (issued_terminal&&(physical_error||cancelled||abort)));
 assign image_error_code=cancelled||abort?4'd12:
   (invalid_descriptor?4'd9:physical_error_code);
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   active<=0;issued<=0;owner_audio<=0;cancelled<=0;invalid_descriptor<=0;
   request_lba<=0;request_blocks<=0;
  end
  else begin
   if(abort&&active)cancelled<=1;
   if(accepted_audio||accepted_image)begin
    active<=1;issued<=0;owner_audio<=accepted_audio;cancelled<=0;
    invalid_descriptor<=accepted_audio?!audio_descriptor_ok:!image_descriptor_ok;
    request_lba<=accepted_audio?audio_lba:image_lba;
    request_blocks<=accepted_audio?16'd1:image_blocks;
   end
   if(physical_read_valid&&physical_read_ready)issued<=1;
   // An unissued request can be retired locally. An issued one always drains
   // to the physical terminal, even after the one-cycle abort has disappeared.
   if(queued_failure||issued_terminal)begin
    active<=0;issued<=0;cancelled<=0;invalid_descriptor<=0;
   end
  end
 end
endmodule
`default_nettype wire
