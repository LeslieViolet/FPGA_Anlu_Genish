// Fixed logical 640x480 UI canvas, mapped to the entire 720p raster.
// Coordinate/color contract: D:/FPGA/work/docs/UI_HOME_SPEC.md
module ui_home_renderer #(parameter EXTERNAL_FONT = 0) (
    input  wire [9:0]  x,
    input  wire [9:0]  y,
    input  wire        video_active,
    input  wire        home_enable,
    input  wire        wallpaper_valid,
    input  wire [1:0]  focus_index,
    input  wire        tf_ready,
    input  wire        ir_ready,
    input  wire [23:0] pixel_in,
    output reg  [23:0] pixel_out,
    input wire [15:0] font_bits_in,
    output wire [6:0] font_glyph_out,
    output wire [3:0] font_row_out,
    output wire [3:0] font_col_out,
    output wire font_valid_out,
    output wire [23:0] font_color_out
);
// Constant coordinate comparisons as a Boolean prefix tree.
    // For constant boundary bits this maps to LUT logic, not long carry chains.
    function automatic coord_ge;
        input [9:0] coordinate;
        input [9:0] boundary;
        integer k;
        reg ge;
        begin
            ge=1'b1;
            for(k=0;k<10;k=k+1)
                if(boundary[k]) ge=coordinate[k]&ge;
                else ge=coordinate[k]|ge;
            coord_ge=ge;
        end
    endfunction

    localparam [23:0] COLOR_BLACK        = 24'h000000;
    localparam [23:0] BG_BASE            = 24'h07152E;
    localparam [23:0] BG_BAND            = 24'h0B2144;
    localparam [23:0] HEADER             = 24'h081A3A;
    localparam [23:0] CARD_NORMAL        = 24'h202C5C;
    localparam [23:0] CARD_SELECTED      = 24'h126FAE;
    localparam [23:0] FOCUS              = 24'h19D8FF;
    localparam [23:0] TEXT_MAIN          = 24'hF4F8FF;
    localparam [23:0] TEXT_MUTED         = 24'hAFC2DE;
    localparam [23:0] STATUS_OK          = 24'h38D996;
    localparam [23:0] STATUS_OFF         = 24'h54627A;
    localparam [23:0] ICON_FILE          = 24'h66D1FF;
    localparam [23:0] ICON_SLIDE         = 24'h9D8CFF;
    localparam [23:0] ICON_SETTING       = 24'h7BE0C3;

    function [23:0] shade_half;
        input [23:0] color;
        begin
            shade_half = {1'b0,color[23:17],1'b0,color[15:9],1'b0,color[7:1]};
        end
    endfunction

    function [23:0] shade_three_quarters;
        input [23:0] color;
        reg [8:0] red;
        reg [8:0] green;
        reg [8:0] blue;
        begin
            red   = {1'b0,color[23:16]} - ({1'b0,color[23:16]} >> 2);
            green = {1'b0,color[15:8]}  - ({1'b0,color[15:8]}  >> 2);
            blue  = {1'b0,color[7:0]}   - ({1'b0,color[7:0]}   >> 2);
            shade_three_quarters = {red[7:0],green[7:0],blue[7:0]};
        end
    endfunction

    reg        text_hit;
    reg [6:0]  text_glyph;
    reg [3:0]  text_row;
    reg [3:0]  text_col;
    reg [23:0] text_color;
    wire [15:0] glyph_bits;

    // Each card has constant bounds. Decode those in parallel rather than
    // selecting card_left and then subtracting it from x on the pixel path.
    wire [2:0] card_column,card_edge;
    genvar c;
    generate for(c=0;c<3;c=c+1) begin: card_geometry
        localparam [9:0] L=32+c*200, R=208+c*200;
        assign card_column[c]=coord_ge(x,L) && !coord_ge(x,R);
        assign card_edge[c]=card_column[c] &&
            (!coord_ge(x,L+10'd4) || coord_ge(x,R-10'd4));
    end endgenerate
    wire card_hit=|card_column;
    wire card_selected=(focus_index<3) && card_column[focus_index];
    wire card_border=(|card_edge) || !coord_ge(y,10'd190) || coord_ge(y,10'd396);

    assign font_glyph_out = text_glyph;
    assign font_row_out = text_row;
    assign font_col_out=text_col;
    assign font_valid_out=text_hit && home_enable && video_active;
    assign font_color_out=text_color;
    generate if (EXTERNAL_FONT == 2) begin : font_descriptor
        assign glyph_bits=16'd0;
    end else if (EXTERNAL_FONT) begin : shared_font
        assign glyph_bits = font_bits_in;
    end else begin : local_font
        ui_font16_rom u_font(.glyph_id(text_glyph), .row(text_row), .bits(glyph_bits));
    end endgenerate

    function [6:0] glyph_for;
        input [3:0] string_id;
        input [3:0] position;
        begin
            glyph_for = 6'd0;
            case ({string_id, position})
                8'h00: glyph_for = 6'd0;  8'h01: glyph_for = 6'd1;
                8'h02: glyph_for = 6'd2;  8'h03: glyph_for = 6'd3;
                8'h04: glyph_for = 6'd4;
                8'h10: glyph_for = 6'd5;  8'h11: glyph_for = 6'd6;
                8'h12: glyph_for = 6'd7;  8'h13: glyph_for = 6'd8;
                8'h14: glyph_for = 6'd9;  8'h15: glyph_for = 6'd10;
                8'h16: glyph_for = 6'd11;
                8'h20: glyph_for = 6'd12; 8'h21: glyph_for = 6'd13;
                8'h22: glyph_for = 6'd14; 8'h23: glyph_for = 6'd1;
                8'h24: glyph_for = 6'd2;  8'h25: glyph_for = 6'd15;
                8'h26: glyph_for = 6'd16;
                8'h30: glyph_for = 6'd10; 8'h31: glyph_for = 6'd11;
                8'h40: glyph_for = 6'd17; 8'h41: glyph_for = 6'd18;
                8'h42: glyph_for = 6'd13;
                8'h50: glyph_for = 6'd19; 8'h51: glyph_for = 6'd20;
                8'h52: glyph_for = 6'd21; 8'h53: glyph_for = 6'd22;
                8'h60: glyph_for = 6'd23; 8'h61: glyph_for = 6'd24;
                8'h70: glyph_for = 6'd25; 8'h71: glyph_for = 6'd26;
                8'h72: glyph_for = 6'd3;
                8'h80: glyph_for = 6'd29; 8'h81: glyph_for = 6'd30;
                8'h82: glyph_for = 6'd31; 8'h83: glyph_for = 6'd32;
                8'h90: glyph_for = 6'd33; 8'h91: glyph_for = 6'd34;
                8'h92: glyph_for = 6'd35; 8'h93: glyph_for = 6'd36;
                8'hA0: glyph_for = 6'd37; 8'hA1: glyph_for = 6'd38;
                8'hA2: glyph_for = 6'd39;
                8'hB0: glyph_for = 7'd81; 8'hB1: glyph_for = 6'd41;
                8'hB2: glyph_for = 6'd42;
                8'hC0: glyph_for = 6'd7;  8'hC1: glyph_for = 6'd8;
                8'hD0: glyph_for = 6'd27; 8'hD1: glyph_for = 6'd28;
                default: glyph_for = 6'd0;
            endcase
        end
    endfunction

    // Select at most one text cell for the current pixel.
    always @* begin
        text_hit   = 1'b0;
        text_glyph = 6'd0;
        text_row   = 4'd0;
        text_col   = 4'd0;
        text_color = TEXT_MAIN;

        if ((coord_ge(x,10'd24)) && ((~coord_ge(x,10'd184))) && (coord_ge(y,10'd12)) && ((~coord_ge(y,10'd44)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd0, (x - 10'd24) >> 5);
            text_col   = ((x - 10'd24) >> 1) & 4'hF;
            text_row   = ((y - 10'd12) >> 1) & 4'hF;
        end else if ((coord_ge(x,10'd32)) && ((~coord_ge(x,10'd256))) && (coord_ge(y,10'd78)) && ((~coord_ge(y,10'd110)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd1, (x - 10'd32) >> 5);
            text_col   = ((x - 10'd32) >> 1) & 4'hF;
            text_row   = ((y - 10'd78) >> 1) & 4'hF;
        end else if ((coord_ge(x,10'd32)) && ((~coord_ge(x,10'd144))) && (coord_ge(y,10'd122)) && ((~coord_ge(y,10'd138)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd2, (x - 10'd32) >> 4);
            text_col   = (x - 10'd32) & 4'hF;
            text_row   = (y - 10'd122) & 4'hF;
            text_color = TEXT_MUTED;
        end else if ((coord_ge(x,10'd104)) && ((~coord_ge(x,10'd136))) && (coord_ge(y,10'd350)) && ((~coord_ge(y,10'd366)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd3, (x - 10'd104) >> 4);
            text_col   = (x - 10'd104) & 4'hF;
            text_row   = (y - 10'd350) & 4'hF;
        end else if ((coord_ge(x,10'd296)) && ((~coord_ge(x,10'd344))) && (coord_ge(y,10'd350)) && ((~coord_ge(y,10'd366)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd4, (x - 10'd296) >> 4);
            text_col   = (x - 10'd296) & 4'hF;
            text_row   = (y - 10'd350) & 4'hF;
        end else if ((coord_ge(x,10'd504)) && ((~coord_ge(x,10'd536))) && (coord_ge(y,10'd350)) && ((~coord_ge(y,10'd366)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd6, (x - 10'd504) >> 4);
            text_col   = (x - 10'd504) & 4'hF;
            text_row   = (y - 10'd350) & 4'hF;
        end else if ((coord_ge(x,10'd24)) && ((~coord_ge(x,10'd88))) && (coord_ge(y,10'd446)) && ((~coord_ge(y,10'd462)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd8, (x - 10'd24) >> 4);
            text_col   = (x - 10'd24) & 4'hF;
            text_row   = (y - 10'd446) & 4'hF;
            text_color = TEXT_MUTED;
        end else if ((coord_ge(x,10'd128)) && ((~coord_ge(x,10'd192))) && (coord_ge(y,10'd446)) && ((~coord_ge(y,10'd462)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd9, (x - 10'd128) >> 4);
            text_col   = (x - 10'd128) & 4'hF;
            text_row   = (y - 10'd446) & 4'hF;
            text_color = TEXT_MUTED;
        end else if ((coord_ge(x,10'd224)) && ((~coord_ge(x,10'd272))) && (coord_ge(y,10'd446)) && ((~coord_ge(y,10'd462)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd10, (x - 10'd224) >> 4);
            text_col   = (x - 10'd224) & 4'hF;
            text_row   = (y - 10'd446) & 4'hF;
            text_color = TEXT_MUTED;
        end else if ((coord_ge(x,10'd304)) && ((~coord_ge(x,10'd352))) && (coord_ge(y,10'd446)) && ((~coord_ge(y,10'd462)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd11, (x - 10'd304) >> 4);
            text_col   = (x - 10'd304) & 4'hF;
            text_row   = (y - 10'd446) & 4'hF;
            text_color = TEXT_MUTED;
        end else if ((coord_ge(x,10'd522)) && ((~coord_ge(x,10'd554))) && (coord_ge(y,10'd20)) && ((~coord_ge(y,10'd36)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd12, (x - 10'd522) >> 4);
            text_col   = (x - 10'd522) & 4'hF;
            text_row   = (y - 10'd20) & 4'hF;
        end else if ((coord_ge(x,10'd576)) && ((~coord_ge(x,10'd608))) && (coord_ge(y,10'd20)) && ((~coord_ge(y,10'd36)))) begin
            text_hit   = 1'b1;
            text_glyph = glyph_for(4'd13, (x - 10'd576) >> 4);
            text_col   = (x - 10'd576) & 4'hF;
            text_row   = (y - 10'd20) & 4'hF;
        end
    end

    always @* begin
        // The loaded TF wallpaper is the base layer only when the display
        // lease really contains physical asset zero.  During boot, failure,
        // or a return-home reload, deterministic internal colors remain.
        if (wallpaper_valid) begin
            pixel_out = pixel_in;
            if ((coord_ge(y,10'd150)) && ((~coord_ge(y,10'd424))))
                pixel_out = shade_three_quarters(pixel_in);
            if (((~coord_ge(y,10'd56))) || (coord_ge(y,10'd424)))
                pixel_out = shade_half(pixel_in);
        end else begin
            pixel_out = BG_BASE;
            if ((coord_ge(y,10'd150)) && ((~coord_ge(y,10'd424))))
                pixel_out = BG_BAND;
            if (((~coord_ge(y,10'd56))) || (coord_ge(y,10'd424)))
                pixel_out = HEADER;
        end

        if (card_hit && (card_selected ? coord_ge(y,10'd186) : coord_ge(y,10'd210)) && !coord_ge(y,10'd400)) begin
            if (card_selected && card_border)
                pixel_out = FOCUS;
            else if (card_selected)
                pixel_out = CARD_SELECTED;
            else
                pixel_out = CARD_NORMAL;
        end

        // File icon.
        if (((coord_ge(x,10'd80)) && ((~coord_ge(x,10'd161))) && (coord_ge(y,10'd250)) && ((~coord_ge(y,10'd307)))) ||
            ((coord_ge(x,10'd88)) && ((~coord_ge(x,10'd120)))  && (coord_ge(y,10'd238)) && ((~coord_ge(y,10'd250)))))
            pixel_out = ICON_FILE;
        if ((coord_ge(x,10'd88)) && ((~coord_ge(x,10'd153))) && (coord_ge(y,10'd263)) && ((~coord_ge(y,10'd299))))
            pixel_out = HEADER;

        // Slideshow icon: frame plus stylized mountain/sun.
        if ((coord_ge(x,10'd276)) && ((~coord_ge(x,10'd364))) && (coord_ge(y,10'd242)) && ((~coord_ge(y,10'd311))))
            pixel_out = ICON_SLIDE;
        if ((coord_ge(x,10'd283)) && ((~coord_ge(x,10'd357))) && (coord_ge(y,10'd249)) && ((~coord_ge(y,10'd304))))
            pixel_out = CARD_NORMAL;
        if ((coord_ge(x,10'd338)) && ((~coord_ge(x,10'd349))) && (coord_ge(y,10'd257)) && ((~coord_ge(y,10'd268))))
            pixel_out = ICON_SLIDE;
        if ((coord_ge(y,10'd280)) && ((~coord_ge(y,10'd301))) &&
            (x >= (10'd296 + ((y - 10'd280) >> 1))) &&
            (x <= (10'd343 - ((y - 10'd280) >> 2))))
            pixel_out = ICON_SLIDE;

        // Settings icon: three sliders.
        if (((coord_ge(y,10'd254)) && ((~coord_ge(y,10'd260))) && (coord_ge(x,10'd477)) && ((~coord_ge(x,10'd563)))) ||
            ((coord_ge(y,10'd274)) && ((~coord_ge(y,10'd280))) && (coord_ge(x,10'd477)) && ((~coord_ge(x,10'd563)))) ||
            ((coord_ge(y,10'd294)) && ((~coord_ge(y,10'd300))) && (coord_ge(x,10'd477)) && ((~coord_ge(x,10'd563)))))
            pixel_out = ICON_SETTING;
        if (((coord_ge(x,10'd494)) && ((~coord_ge(x,10'd506))) && (coord_ge(y,10'd248)) && ((~coord_ge(y,10'd266)))) ||
            ((coord_ge(x,10'd530)) && ((~coord_ge(x,10'd542))) && (coord_ge(y,10'd268)) && ((~coord_ge(y,10'd286)))) ||
            ((coord_ge(x,10'd508)) && ((~coord_ge(x,10'd520))) && (coord_ge(y,10'd288)) && ((~coord_ge(y,10'd306)))))
            pixel_out = TEXT_MAIN;


        // TF/IR status dots.
        if ((coord_ge(x,10'd508)) && ((~coord_ge(x,10'd516))) && (coord_ge(y,10'd24)) && ((~coord_ge(y,10'd32))))
            pixel_out = tf_ready ? STATUS_OK : STATUS_OFF;
        if ((coord_ge(x,10'd562)) && ((~coord_ge(x,10'd570))) && (coord_ge(y,10'd24)) && ((~coord_ge(y,10'd32))))
            pixel_out = ir_ready ? STATUS_OK : STATUS_OFF;

        if (text_hit && glyph_bits[15 - text_col])
            pixel_out = text_color;

        if (!home_enable)
            pixel_out = pixel_in;
        if (!video_active)
            pixel_out = COLOR_BLACK;
    end
endmodule

