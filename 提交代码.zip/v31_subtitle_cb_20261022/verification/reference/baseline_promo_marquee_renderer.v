`default_nettype none
module baseline_promo_marquee_renderer #(parameter FRAME_WIDTH=1280)(
 input wire clk,rst,enabled,input wire [10:0] x,y,input wire user_in,valid_in,
 output reg panel_hit,font_valid,output reg [9:0] text_address,
 output reg [3:0] font_row,font_col,font_palette
);
 localparam integer VIEW_X=32;
 localparam integer VIEW_WIDTH=FRAME_WIDTH-336;
 localparam [10:0] OFFSET_RESTART=2048-(VIEW_X+VIEW_WIDTH-32);
 localparam [10:0] OFFSET_END=416-VIEW_X;
 reg [10:0] scroll_offset;
 // Modular arithmetic also rejects pixels to the left of the text: their
 // wrapped local coordinate is above 416, without a second subtraction chain.
 wire [10:0] text_rel_x=x+scroll_offset;
 always @(posedge clk or posedge rst)begin
  if(rst)scroll_offset<=OFFSET_RESTART;
  else if(enabled&&valid_in&&user_in)begin
   if(scroll_offset==OFFSET_END)scroll_offset<=OFFSET_RESTART;
   else scroll_offset<=scroll_offset+11'd1;
  end
 end
 always @*begin
  panel_hit=enabled&&valid_in&&x>=VIEW_X&&x<VIEW_X+VIEW_WIDTH&&y>=16&&y<64;
  font_valid=0;text_address=10'h3ff;font_row=0;font_col=0;font_palette=4'd13;
  if(enabled&&valid_in&&x>=VIEW_X&&x<VIEW_X+VIEW_WIDTH&&
     y>=24&&y<56&&text_rel_x<416)begin
   font_valid=1;font_row=(y-11'd24)>>1;font_col=text_rel_x[4:1];
   text_address={6'd52,text_rel_x[8:5]};
  end
 end
endmodule
`default_nettype wire
