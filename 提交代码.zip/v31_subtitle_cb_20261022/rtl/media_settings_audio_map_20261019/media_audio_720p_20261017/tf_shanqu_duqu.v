// SDHC single-sector reader using the TF card's SPI mode.
// It initializes the card after reset and uses CMD17 for each 512-byte read.
`default_nettype none

module tf_shanqu_duqu #(
    parameter integer POLL_CYCLES = 12500000, // 250 ms at the board's 50 MHz clock
    parameter integer RETRY_CYCLES = 50000000,
    parameter integer POWER_UP_CYCLES     = 1000000,
    parameter integer ACMD41_MAX_TRIES    = 1024,
    parameter integer R1_TIMEOUT_BYTES    = 16,
    parameter integer TOKEN_TIMEOUT_BYTES = 65535,
    parameter [15:0]  INIT_HALF_PERIOD    = 16'd125,
    parameter [15:0]  DATA_HALF_PERIOD    = 16'd2
) (
    input  wire        clk,
    input  wire        rst,
    input  wire        read_valid,
    output wire        read_ready,
    input  wire [31:0] read_lba,
    output reg  [7:0]  data,
    output reg         data_valid,
    input  wire        data_ready,
    output reg         data_last,
    output reg         busy,
    output reg         card_ready,
    output reg         media_changed,
    output reg         done,
    output reg         error,
    output reg  [3:0]  error_code,
    output reg         tf_cs_n,
    output wire        tf_sclk,
    output wire        tf_mosi,
    input  wire        tf_miso
);

    localparam [3:0] ERR_NONE       = 4'd0;
    localparam [3:0] ERR_CMD0       = 4'd1;
    localparam [3:0] ERR_CMD8       = 4'd2;
    localparam [3:0] ERR_ACMD41     = 4'd3;
    localparam [3:0] ERR_CMD58      = 4'd4;
    localparam [3:0] ERR_CMD17      = 4'd5;
    localparam [3:0] ERR_DATA_TOKEN = 4'd6;
    localparam [3:0] ERR_DATA_CRC   = 4'd7;

    localparam [5:0] ST_POWER_WAIT          = 6'd0;
    localparam [5:0] ST_DUMMY_START         = 6'd1;
    localparam [5:0] ST_DUMMY_WAIT          = 6'd2;
    localparam [5:0] ST_CMD0_PREP           = 6'd3;
    localparam [5:0] ST_CMD8_PREP           = 6'd4;
    localparam [5:0] ST_CMD55_PREP          = 6'd5;
    localparam [5:0] ST_ACMD41_PREP         = 6'd6;
    localparam [5:0] ST_CMD58_PREP          = 6'd7;
    localparam [5:0] ST_CMD17_PREP          = 6'd8;
    localparam [5:0] ST_CMD_SEND_START      = 6'd9;
    localparam [5:0] ST_CMD_SEND_WAIT       = 6'd10;
    localparam [5:0] ST_R1_START            = 6'd11;
    localparam [5:0] ST_R1_WAIT             = 6'd12;
    localparam [5:0] ST_CMD0_CHECK          = 6'd13;
    localparam [5:0] ST_CMD8_CHECK          = 6'd14;
    localparam [5:0] ST_CMD8_EXTRA_PREP     = 6'd15;
    localparam [5:0] ST_EXTRA_START         = 6'd16;
    localparam [5:0] ST_EXTRA_WAIT          = 6'd17;
    localparam [5:0] ST_CMD8_EXTRA_CHECK    = 6'd18;
    localparam [5:0] ST_CMD55_CHECK         = 6'd19;
    localparam [5:0] ST_ACMD41_CHECK        = 6'd20;
    localparam [5:0] ST_CMD58_CHECK         = 6'd21;
    localparam [5:0] ST_CMD58_EXTRA_PREP    = 6'd22;
    localparam [5:0] ST_CMD58_EXTRA_CHECK   = 6'd23;
    localparam [5:0] ST_GAP_START           = 6'd24;
    localparam [5:0] ST_GAP_WAIT            = 6'd25;
    localparam [5:0] ST_IDLE                = 6'd26;
    localparam [5:0] ST_CMD17_CHECK         = 6'd27;
    localparam [5:0] ST_TOKEN_START         = 6'd28;
    localparam [5:0] ST_TOKEN_WAIT          = 6'd29;
    localparam [5:0] ST_DATA_START          = 6'd30;
    localparam [5:0] ST_DATA_WAIT           = 6'd31;
    localparam [5:0] ST_DATA_HOLD           = 6'd32;
    localparam [5:0] ST_CRC1_START          = 6'd33;
    localparam [5:0] ST_CRC1_WAIT           = 6'd34;
    localparam [5:0] ST_CRC2_START          = 6'd35;
    localparam [5:0] ST_CRC2_WAIT           = 6'd36;
    localparam [5:0] ST_READ_END_GAP_START  = 6'd37;
    localparam [5:0] ST_READ_END_GAP_WAIT   = 6'd38;
    localparam [5:0] ST_READ_FAIL_GAP_START = 6'd39;
    localparam [5:0] ST_READ_FAIL_GAP_WAIT  = 6'd40;
    localparam [5:0] ST_FATAL               = 6'd41;

    localparam [5:0] ST_CMD13_PREP=42, ST_CMD13_CHECK=43,
                     ST_STATUS2_START=44, ST_STATUS2_WAIT=45;
    reg had_failure;
    reg [5:0]  state;
    reg [31:0] power_count;
    wire poll_due = power_count >= POLL_CYCLES-1;
    reg [3:0]  dummy_count;
    reg [15:0] acmd41_tries;
    reg         spi_start;
    reg [7:0]   spi_tx_data;
    wire [7:0]  spi_rx_data;
    wire        spi_busy;
    wire        spi_done;
    reg [15:0]  spi_half_period;
    reg [5:0]   command_state_after_r1;
    reg [3:0]   command_error_code;
    reg [5:0]   gap_return_state;
    reg [5:0]   extra_return_state;
    reg [5:0]   command_index;
    reg [5:0]   command_number;
    reg [31:0]  command_argument;
    reg [7:0]   command_crc;
    reg [7:0]   r1_response;
    reg [7:0]   r1_wait_count;
    reg [2:0]   extra_count;
    reg [31:0]  extra_data;
    reg [31:0]  active_lba;
    reg [15:0]  token_wait_count;
    reg [8:0]   data_count;
    reg [15:0]  data_crc;
    reg [7:0]   received_crc_high;

    assign read_ready = card_ready && !busy && (state == ST_IDLE) && !poll_due;

    function [7:0] command_byte;
        input [5:0] index;
        input [5:0] number;
        input [31:0] argument;
        input [7:0] crc;
        begin
            case (index)
                6'd0: command_byte = {2'b01, number};
                6'd1: command_byte = argument[31:24];
                6'd2: command_byte = argument[23:16];
                6'd3: command_byte = argument[15:8];
                6'd4: command_byte = argument[7:0];
                default: command_byte = crc;
            endcase
        end
    endfunction

    function [15:0] crc16_next;
        input [15:0] current_crc;
        input [7:0] next_data;
        integer bit_number;
        reg [15:0] result;
        begin
            result = current_crc;
            for (bit_number = 7; bit_number >= 0; bit_number = bit_number - 1) begin
                if (result[15] ^ next_data[bit_number])
                    result = {result[14:0], 1'b0} ^ 16'h1021;
                else
                    result = {result[14:0], 1'b0};
            end
            crc16_next = result;
        end
    endfunction

    spi_zijie_shoufa u_spi_zijie_shoufa (
        .clk(clk), .rst(rst), .start(spi_start), .tx_data(spi_tx_data),
        .half_period_cycles(spi_half_period), .busy(spi_busy),
        .done(spi_done), .rx_data(spi_rx_data), .spi_sclk(tf_sclk),
        .spi_mosi(tf_mosi), .spi_miso(tf_miso)
    );

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= ST_POWER_WAIT;
            had_failure<=0;media_changed<=0;
            power_count <= 32'd0;
            dummy_count <= 4'd0;
            acmd41_tries <= 16'd0;
            spi_start <= 1'b0;
            spi_tx_data <= 8'hff;
            spi_half_period <= INIT_HALF_PERIOD;
            command_state_after_r1 <= ST_FATAL;
            command_error_code <= ERR_NONE;
            gap_return_state <= ST_FATAL;
            extra_return_state <= ST_FATAL;
            command_index <= 6'd0;
            command_number <= 6'd0;
            command_argument <= 32'd0;
            command_crc <= 8'h01;
            r1_response <= 8'hff;
            r1_wait_count <= 8'd0;
            extra_count <= 3'd0;
            extra_data <= 32'd0;
            active_lba <= 32'd0;
            token_wait_count <= 16'd0;
            data_count <= 9'd0;
            data_crc <= 16'd0;
            received_crc_high <= 8'd0;
            data <= 8'd0;
            data_valid <= 1'b0;
            data_last <= 1'b0;
            busy <= 1'b0;
            card_ready <= 1'b0;
            done <= 1'b0;
            error <= 1'b0;
            error_code <= ERR_NONE;
            tf_cs_n <= 1'b1;
        end else begin
            spi_start <= 1'b0;
            done <= 1'b0;media_changed<=1'b0;
            case (state)
                ST_POWER_WAIT: begin
                    tf_cs_n <= 1'b1;
                    spi_half_period <= INIT_HALF_PERIOD;
                    if (power_count >= POWER_UP_CYCLES - 1) begin
                        power_count <= 32'd0;
                        dummy_count <= 4'd0;
                        state <= ST_DUMMY_START;
                    end else power_count <= power_count + 32'd1;
                end
                ST_DUMMY_START: if (!spi_busy) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_DUMMY_WAIT;
                end
                ST_DUMMY_WAIT: if (spi_done) begin
                    if (dummy_count == 4'd9) state <= ST_CMD0_PREP;
                    else begin dummy_count <= dummy_count + 4'd1; state <= ST_DUMMY_START; end
                end
                ST_CMD0_PREP: begin
                    tf_cs_n <= 1'b0; command_number <= 6'd0; command_argument <= 32'd0;
                    command_crc <= 8'h95; command_state_after_r1 <= ST_CMD0_CHECK;
                    command_error_code <= ERR_CMD0; command_index <= 6'd0;
                    r1_wait_count <= 8'd0; state <= ST_CMD_SEND_START;
                end
                ST_CMD8_PREP: begin
                    tf_cs_n <= 1'b0; command_number <= 6'd8; command_argument <= 32'h000001aa;
                    command_crc <= 8'h87; command_state_after_r1 <= ST_CMD8_CHECK;
                    command_error_code <= ERR_CMD8; command_index <= 6'd0;
                    r1_wait_count <= 8'd0; state <= ST_CMD_SEND_START;
                end
                ST_CMD55_PREP: begin
                    tf_cs_n <= 1'b0; command_number <= 6'd55; command_argument <= 32'd0;
                    command_crc <= 8'h01; command_state_after_r1 <= ST_CMD55_CHECK;
                    command_error_code <= ERR_ACMD41; command_index <= 6'd0;
                    r1_wait_count <= 8'd0; state <= ST_CMD_SEND_START;
                end
                ST_ACMD41_PREP: begin
                    tf_cs_n <= 1'b0; command_number <= 6'd41; command_argument <= 32'h40000000;
                    command_crc <= 8'h01; command_state_after_r1 <= ST_ACMD41_CHECK;
                    command_error_code <= ERR_ACMD41; command_index <= 6'd0;
                    r1_wait_count <= 8'd0; state <= ST_CMD_SEND_START;
                end
                ST_CMD58_PREP: begin
                    tf_cs_n <= 1'b0; command_number <= 6'd58; command_argument <= 32'd0;
                    command_crc <= 8'h01; command_state_after_r1 <= ST_CMD58_CHECK;
                    command_error_code <= ERR_CMD58; command_index <= 6'd0;
                    r1_wait_count <= 8'd0; state <= ST_CMD_SEND_START;
                end
                ST_CMD17_PREP: begin
                    tf_cs_n <= 1'b0; command_number <= 6'd17; command_argument <= active_lba;
                    command_crc <= 8'h01; command_state_after_r1 <= ST_CMD17_CHECK;
                    command_error_code <= ERR_CMD17; command_index <= 6'd0;
                    r1_wait_count <= 8'd0; state <= ST_CMD_SEND_START;
                end
                ST_CMD_SEND_START: if (!spi_busy) begin
                    spi_tx_data <= command_byte(command_index, command_number,
                                                command_argument, command_crc);
                    spi_start <= 1'b1; state <= ST_CMD_SEND_WAIT;
                end
                ST_CMD_SEND_WAIT: if (spi_done) begin
                    if (command_index == 6'd5) state <= ST_R1_START;
                    else begin command_index <= command_index + 6'd1; state <= ST_CMD_SEND_START; end
                end
                ST_R1_START: if (!spi_busy) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_R1_WAIT;
                end
                ST_R1_WAIT: if (spi_done) begin
                    if (spi_rx_data != 8'hff) begin
                        r1_response <= spi_rx_data; state <= command_state_after_r1;
                    end else if (r1_wait_count >= R1_TIMEOUT_BYTES - 1) begin
                        error <= 1'b1; error_code <= command_error_code; tf_cs_n <= 1'b1;
                        if (card_ready) begin card_ready<=0;had_failure<=1;power_count<=0;state <= ST_READ_FAIL_GAP_START;end
                        else state <= ST_FATAL;
                    end else begin r1_wait_count <= r1_wait_count + 8'd1; state <= ST_R1_START; end
                end
                ST_CMD0_CHECK: begin
                    if (r1_response == 8'h01) begin
                        tf_cs_n <= 1'b1; gap_return_state <= ST_CMD8_PREP; state <= ST_GAP_START;
                    end else begin error <= 1'b1; error_code <= ERR_CMD0; tf_cs_n <= 1'b1; state <= ST_FATAL; end
                end
                ST_CMD8_CHECK: begin
                    if (r1_response == 8'h01) state <= ST_CMD8_EXTRA_PREP;
                    else begin error <= 1'b1; error_code <= ERR_CMD8; tf_cs_n <= 1'b1; state <= ST_FATAL; end
                end
                ST_CMD8_EXTRA_PREP: begin
                    extra_count <= 3'd0; extra_data <= 32'd0;
                    extra_return_state <= ST_CMD8_EXTRA_CHECK; state <= ST_EXTRA_START;
                end
                ST_EXTRA_START: if (!spi_busy) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_EXTRA_WAIT;
                end
                ST_EXTRA_WAIT: if (spi_done) begin
                    extra_data <= {extra_data[23:0], spi_rx_data};
                    if (extra_count == 3'd3) state <= extra_return_state;
                    else begin extra_count <= extra_count + 3'd1; state <= ST_EXTRA_START; end
                end
                ST_CMD8_EXTRA_CHECK: begin
                    if (extra_data[15:0] == 16'h01aa) begin
                        tf_cs_n <= 1'b1; gap_return_state <= ST_CMD55_PREP; state <= ST_GAP_START;
                    end else begin error <= 1'b1; error_code <= ERR_CMD8; tf_cs_n <= 1'b1; state <= ST_FATAL; end
                end
                ST_CMD55_CHECK: begin
                    if ((r1_response == 8'h01) || (r1_response == 8'h00)) begin
                        tf_cs_n <= 1'b1; gap_return_state <= ST_ACMD41_PREP; state <= ST_GAP_START;
                    end else begin error <= 1'b1; error_code <= ERR_ACMD41; tf_cs_n <= 1'b1; state <= ST_FATAL; end
                end
                ST_ACMD41_CHECK: begin
                    if (r1_response == 8'h00) begin
                        tf_cs_n <= 1'b1; gap_return_state <= ST_CMD58_PREP; state <= ST_GAP_START;
                    end else if ((r1_response == 8'h01) && (acmd41_tries < ACMD41_MAX_TRIES - 1)) begin
                        acmd41_tries <= acmd41_tries + 16'd1; tf_cs_n <= 1'b1;
                        gap_return_state <= ST_CMD55_PREP; state <= ST_GAP_START;
                    end else begin error <= 1'b1; error_code <= ERR_ACMD41; tf_cs_n <= 1'b1; state <= ST_FATAL; end
                end
                ST_CMD58_CHECK: begin
                    if (r1_response == 8'h00) state <= ST_CMD58_EXTRA_PREP;
                    else begin error <= 1'b1; error_code <= ERR_CMD58; tf_cs_n <= 1'b1; state <= ST_FATAL; end
                end
                ST_CMD58_EXTRA_PREP: begin
                    extra_count <= 3'd0; extra_data <= 32'd0;
                    extra_return_state <= ST_CMD58_EXTRA_CHECK; state <= ST_EXTRA_START;
                end
                ST_CMD58_EXTRA_CHECK: begin
                    if (extra_data[30]) begin
                        card_ready <= 1'b1; error <= 1'b0; error_code <= ERR_NONE;
                        media_changed<=had_failure;had_failure<=0;power_count<=0;
                        spi_half_period <= DATA_HALF_PERIOD; tf_cs_n <= 1'b1;
                        gap_return_state <= ST_IDLE; state <= ST_GAP_START;
                    end else begin error <= 1'b1; error_code <= ERR_CMD58; tf_cs_n <= 1'b1; state <= ST_FATAL; end
                end
                ST_GAP_START: if (!spi_busy) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_GAP_WAIT;
                end
                ST_GAP_WAIT: if (spi_done) state <= gap_return_state;
                ST_IDLE: begin
                    tf_cs_n <= 1'b1;
                    if(poll_due)begin busy<=1;power_count<=0;state<=ST_CMD13_PREP;end
                    else if (read_valid) begin
                        power_count<=0;active_lba <= read_lba; busy <= 1'b1; error <= 1'b0;
                        error_code <= ERR_NONE; data_valid <= 1'b0; data_last <= 1'b0;
                        token_wait_count <= 16'd0; state <= ST_CMD17_PREP;
                    end else power_count<=power_count+1'b1;
                end
                ST_CMD17_CHECK: begin
                    if (r1_response == 8'h00) begin token_wait_count <= 16'd0; state <= ST_TOKEN_START; end
                    else begin error <= 1'b1; error_code <= ERR_CMD17; tf_cs_n <= 1'b1; state <= ST_READ_FAIL_GAP_START; end
                end
                ST_TOKEN_START: if (!spi_busy) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_TOKEN_WAIT;
                end
                ST_TOKEN_WAIT: if (spi_done) begin
                    if (spi_rx_data == 8'hfe) begin data_count <= 9'd0; data_crc <= 16'd0; state <= ST_DATA_START; end
                    else if (spi_rx_data != 8'hff) begin error <= 1'b1; error_code <= ERR_DATA_TOKEN; tf_cs_n <= 1'b1; state <= ST_READ_FAIL_GAP_START; end
                    else if (token_wait_count >= TOKEN_TIMEOUT_BYTES - 1) begin card_ready<=0;had_failure<=1;power_count<=0;error <= 1'b1; error_code <= ERR_DATA_TOKEN; tf_cs_n <= 1'b1; state <= ST_READ_FAIL_GAP_START; end
                    else begin token_wait_count <= token_wait_count + 16'd1; state <= ST_TOKEN_START; end
                end
                ST_DATA_START: if (!spi_busy && !data_valid) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_DATA_WAIT;
                end
                ST_DATA_WAIT: if (spi_done) begin
                    data <= spi_rx_data; data_valid <= 1'b1;
                    data_last <= (data_count == 9'd511);
                    data_crc <= crc16_next(data_crc, spi_rx_data); state <= ST_DATA_HOLD;
                end
                ST_DATA_HOLD: if (data_valid && data_ready) begin
                    data_valid <= 1'b0; data_last <= 1'b0;
                    if (data_count == 9'd511) state <= ST_CRC1_START;
                    else begin data_count <= data_count + 9'd1; state <= ST_DATA_START; end
                end
                ST_CRC1_START: if (!spi_busy) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_CRC1_WAIT;
                end
                ST_CRC1_WAIT: if (spi_done) begin received_crc_high <= spi_rx_data; state <= ST_CRC2_START; end
                ST_CRC2_START: if (!spi_busy) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_CRC2_WAIT;
                end
                ST_CRC2_WAIT: if (spi_done) begin
                    tf_cs_n <= 1'b1;
                    if ({received_crc_high, spi_rx_data} == data_crc) state <= ST_READ_END_GAP_START;
                    else begin error <= 1'b1; error_code <= ERR_DATA_CRC; state <= ST_READ_FAIL_GAP_START; end
                end
                ST_READ_END_GAP_START: if (!spi_busy) begin
                    spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_READ_END_GAP_WAIT;
                end
                ST_READ_END_GAP_WAIT: if (spi_done) begin power_count<=0;busy <= 1'b0; done <= 1'b1; state <= ST_IDLE; end
                ST_READ_FAIL_GAP_START: begin
                    tf_cs_n <= 1'b1;
                    if (!spi_busy) begin spi_tx_data <= 8'hff; spi_start <= 1'b1; state <= ST_READ_FAIL_GAP_WAIT; end
                end
                ST_READ_FAIL_GAP_WAIT: if (spi_done) begin busy <= 1'b0;state <= card_ready ? ST_IDLE : ST_FATAL;end
                // CMD13 SEND_STATUS uses a two-byte R2 response in SPI mode.
                // A probe never asserts sector data_valid/done.
                ST_CMD13_PREP:begin
                    tf_cs_n<=0;command_number<=13;command_argument<=0;command_crc<=8'h01;
                    command_state_after_r1<=ST_CMD13_CHECK;command_error_code<=ERR_CMD17;
                    command_index<=0;r1_wait_count<=0;state<=ST_CMD_SEND_START;
                end
                ST_CMD13_CHECK:begin
                    if(r1_response==0)state<=ST_STATUS2_START;
                    else begin card_ready<=0;had_failure<=1;power_count<=0;
                        error<=1;error_code<=ERR_CMD17;tf_cs_n<=1;state<=ST_READ_FAIL_GAP_START;end
                end
                ST_STATUS2_START:if(!spi_busy)begin
                    spi_tx_data<=8'hff;spi_start<=1;state<=ST_STATUS2_WAIT;
                end
                ST_STATUS2_WAIT:if(spi_done)begin
                    if(spi_rx_data==0)begin
                        tf_cs_n<=1;busy<=0;power_count<=0;
                        gap_return_state<=ST_IDLE;state<=ST_GAP_START;
                    end else begin card_ready<=0;had_failure<=1;power_count<=0;
                        error<=1;error_code<=ERR_CMD17;tf_cs_n<=1;state<=ST_READ_FAIL_GAP_START;end
                end
                ST_FATAL: begin
                    tf_cs_n<=1;busy<=0;card_ready<=0;data_valid<=0;data_last<=0;had_failure<=1;
                    if(power_count>=RETRY_CYCLES-1)begin
                        power_count<=0;acmd41_tries<=0;spi_half_period<=INIT_HALF_PERIOD;
                        state<=ST_POWER_WAIT;
                    end else power_count<=power_count+1'b1;
                end
                default: begin
                    error <= 1'b1; error_code <= ERR_CMD0; tf_cs_n <= 1'b1;
                    busy <= 1'b0; card_ready <= 1'b0; state <= ST_FATAL;
                end
            endcase
        end
    end
endmodule

`default_nettype wire
