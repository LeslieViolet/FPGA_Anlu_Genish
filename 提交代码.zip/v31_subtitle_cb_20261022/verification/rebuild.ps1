param([string]$TdExecutable='D:/FPGA/anlu/bin/td_commands_prompt.exe')
$ErrorActionPreference='Stop'
if(!(Test-Path -LiteralPath $TdExecutable)){throw "找不到TD，请用-TdExecutable指定td_commands_prompt.exe完整路径"}
$taskRelease=Split-Path -Parent $PSScriptRoot
$taskRun=Join-Path $taskRelease 'rebuild_output'
New-Item -ItemType Directory -Force -Path $taskRun | Out-Null
foreach($taskPhase in @(@('rebuild.tcl','SUBTITLE_CB_IMPLEMENTATION_READY'),@('signoff_and_bitgen.tcl','SUBTITLE_CB_SIGNOFF_BITGEN_PASS'))){
 $taskScript=(Join-Path $PSScriptRoot $taskPhase[0]).Replace('\','/')
 $taskLog=Join-Path $taskRun ($taskPhase[0]+'.log')
 Write-Output ('运行 '+$taskPhase[0])
 & $TdExecutable $taskScript *> $taskLog
 if($LASTEXITCODE -ne 0 -or !(Select-String -LiteralPath $taskLog -SimpleMatch $taskPhase[1] -Quiet)){throw ('构建失败，请查看 '+$taskLog)}
}
$taskBit=Join-Path $taskRun 'v31_subtitle_cb_20261022.bit'
if(!(Test-Path -LiteralPath $taskBit)){throw '未生成位流'}
Get-FileHash -LiteralPath $taskBit -Algorithm SHA256
