`default_nettype none
// 16-bit stereo file stream -> one async FIFO -> timed HDMI PCM.
// Control inputs play_enable, mute and volume_level belong to pixel_clk.
// session_reset is asynchronous assertion for both domains; the vendor wrapper
// releases each FIFO side synchronously. Meter ports are retained for interface
// compatibility and tied low; they do not participate in PCM playback.
module audio_pcm_output #(
 parameter integer PIXEL_HZ=25000000,
 parameter integer FIFO_ADDR_WIDTH=10,
 parameter integer PREFILL_SAMPLES=768,
 parameter integer METER_WINDOW=1024
)(
 input wire source_clk,pixel_clk,rst,session_reset,
 input wire sample_valid,output wire sample_ready,
 input wire signed [15:0] sample_left,sample_right,input wire sample_last,
 input wire play_enable,mute,input wire [3:0] volume_level,
 output reg audio_valid,output reg [23:0] audio_left_data,audio_right_data,
 output reg track_end,output reg [31:0] underflow_count,
 output wire meter_valid,output wire [3:0] level_left,level_right,
 output wire [15:0] peak_left,peak_right,
 output wire fifo_overflow,output wire [FIFO_ADDR_WIDTH:0] buffered_samples,
 output wire [FIFO_ADDR_WIDTH:0] buffered_source
);
 assign meter_valid=1'b0;
 assign level_left=4'd0;
 assign level_right=4'd0;
 assign peak_left=16'd0;
 assign peak_right=16'd0;
 wire clear_fifo=rst||session_reset;
 (* async_reg="true" *) reg [3:0] pixel_release;
 always @(posedge pixel_clk or posedge clear_fifo)
  if(clear_fifo)pixel_release<=4'b1111;
  else pixel_release<={pixel_release[2:0],1'b0};
 wire pixel_hold=pixel_release[3];
 wire fifo_full,fifo_empty,fifo_valid,fifo_underflow;
 // A finite file shorter than PREFILL must not wait forever. Only this
 // single-bit sticky level crosses here; PCM and last remain in the FIFO.
 reg source_file_end;
 (* async_reg="true" *) reg [1:0] file_end_sync;
 always @(posedge source_clk or posedge clear_fifo)
  if(clear_fifo)source_file_end<=0;
  else if(sample_valid&&sample_ready&&sample_last)source_file_end<=1;
 always @(posedge pixel_clk or posedge pixel_hold)
  if(pixel_hold)file_end_sync<=0;
  else file_end_sync<={file_end_sync[0],source_file_end};
 wire [32:0] fifo_data;
 wire [FIFO_ADDR_WIDTH:0] wr_count,rd_count;
 reg [31:0] phase;
 reg armed;
 localparam [31:0] RATE=48000;
 wire tick_now=phase>=PIXEL_HZ-RATE;
 // Session control is asynchronous to pixel_clk. Only the local release
 // chain may drive functional pixel logic; raw clear_fifo must not gate RE.
 wire fifo_pop=!pixel_hold&&play_enable&&armed&&tick_now&&fifo_valid;
 assign sample_ready=!clear_fifo&&!fifo_full;
 assign buffered_samples=rd_count;
 assign buffered_source=wr_count;
 guanfang_yibu_fifo #(.DATA_WIDTH(33),.ADDR_WIDTH(FIFO_ADDR_WIDTH),
  .ALMOST_FULL_LEVEL((1<<FIFO_ADDR_WIDTH)-8),.ALMOST_EMPTY_LEVEL(4)) u_pcm_fifo(
  .rst(clear_fifo),.wr_clk(source_clk),.wr_en(sample_valid&&sample_ready),
  .wr_data({sample_last,sample_left,sample_right}),.full(fifo_full),
  .almost_full(),.wr_usedw(wr_count),.overflow(fifo_overflow),
  .rd_clk(pixel_clk),.rd_en(fifo_pop),.rd_data(fifo_data),.empty(fifo_empty),
  .almost_empty(),.valid(fifo_valid),.rd_usedw(rd_count),.underflow(fifo_underflow));
 function [8:0] coeff(input [3:0] volume);
  begin case(volume)
   0:coeff=0;1:coeff=28;2:coeff=57;3:coeff=85;4:coeff=114;
   5:coeff=142;6:coeff=171;7:coeff=199;8:coeff=228;
   default:coeff=256;
  endcase end
 endfunction
 localparam [1:0] MIX_IDLE=0,MIX_LEFT=1,MIX_RIGHT=2,MIX_SEND=3;
 reg [1:0] mix_state;
 reg signed [15:0] raw_left,raw_right,scaled_left,scaled_right;
 reg [8:0] gain_latched;
 reg last_latched;
 // One time-multiplexed multiplier for both channels; SEND occurs 3 pixel clocks
 // after the sampling boundary, before the next 48kHz sample is due.
 wire signed [15:0] mul_operand=mix_state==MIX_RIGHT?raw_right:raw_left;
 wire signed [25:0] gain_product=mul_operand*$signed({1'b0,gain_latched});
 always @(posedge pixel_clk or posedge pixel_hold)begin
  if(pixel_hold)begin
   phase<=0;armed<=0;mix_state<=MIX_IDLE;
   raw_left<=0;raw_right<=0;scaled_left<=0;scaled_right<=0;
   gain_latched<=0;last_latched<=0;
   audio_valid<=0;audio_left_data<=0;audio_right_data<=0;
   track_end<=0;underflow_count<=0;
  end else begin
   audio_valid<=0;track_end<=0;
   if(tick_now)phase<=phase+RATE-PIXEL_HZ;
   else phase<=phase+RATE;
   if(!armed&&(rd_count>=PREFILL_SAMPLES||(file_end_sync[1]&&rd_count!=0)))armed<=1;
   if(tick_now)begin
    if(play_enable&&armed&&!fifo_valid)underflow_count<=underflow_count+1'b1;
    if(mix_state==MIX_IDLE)begin
     if(fifo_pop)begin
      raw_left<=fifo_data[31:16];raw_right<=fifo_data[15:0];
      gain_latched<=mute?9'd0:coeff(volume_level);
      last_latched<=fifo_data[32];mix_state<=MIX_LEFT;
     end else begin
      raw_left<=0;raw_right<=0;gain_latched<=0;last_latched<=0;
      mix_state<=MIX_LEFT;
     end
    end
   end
   case(mix_state)
    MIX_LEFT:begin scaled_left<=gain_product[23:8];mix_state<=MIX_RIGHT;end
    MIX_RIGHT:begin scaled_right<=gain_product[23:8];mix_state<=MIX_SEND;end
    MIX_SEND:begin
     audio_left_data<={scaled_left,8'd0};audio_right_data<={scaled_right,8'd0};
     audio_valid<=1;track_end<=last_latched;mix_state<=MIX_IDLE;
    end
    default:begin end
   endcase
  end
 end
 initial if(PIXEL_HZ<4*RATE||PREFILL_SAMPLES<1||PREFILL_SAMPLES>=(1<<FIFO_ADDR_WIDTH))
  $error("audio_pcm_output clock or FIFO configuration invalid");
endmodule
`default_nettype wire
