`default_nettype none
// Integration entry point. Fixed-rate AXIS video, with SOF on pixel (0,0)
// and EOL on the last active pixel. No READY/backpressure. Blanking is valid=0.
// Every pixel tuple, including bypass, has exactly 3 register stages.
// mode_hd must remain stable between resets (use the existing mode sequencer).
module audio_spectrum_axis_overlay #(
    parameter RUNTIME_MODE=1,
    parameter FRAME_WIDTH=640,
    parameter FRAME_HEIGHT=480,
    parameter AUDIO_CHANNEL=0,
    parameter PEAK_HOLD_FRAMES=10
)(
    input wire clk,rst,mode_hd,enabled,audio_running,
    input wire audio_sample_valid,
    input wire signed [23:0] audio_left_data,audio_right_data,
    input wire [23:0] rgb_in,
    input wire user_in,last_in,valid_in,
    output wire [23:0] rgb_out,
    output wire user_out,last_out,valid_out,
    output wire [10:0] x_out,y_out,
    output wire analysis_busy,analysis_overrun,analysis_update
);
    wire [10:0] active_width=RUNTIME_MODE?(mode_hd?11'd1280:11'd640):FRAME_WIDTH;
    wire [10:0] active_height=RUNTIME_MODE?(mode_hd?11'd720:11'd480):FRAME_HEIGHT;
    reg [10:0] next_x,next_y;
    wire [10:0] x=user_in?11'd0:next_x;
    wire [10:0] y=user_in?11'd0:next_y;
    always @(posedge clk or posedge rst)begin
        if(rst)begin next_x<=0;next_y<=0;end
        else if(valid_in)begin
            if(user_in)begin
                next_x<=last_in?11'd0:11'd1;
                next_y<=last_in&&active_height>1?11'd1:11'd0;
            end else if(last_in)begin
                next_x<=0;
                next_y<=next_y==active_height-1'b1 ? 11'd0:next_y+1'b1;
            end else next_x<=next_x==active_width-1'b1 ? 11'd0:next_x+1'b1;
        end
    end
    audio_spectrum_overlay #(.RUNTIME_MODE(RUNTIME_MODE),.FRAME_WIDTH(FRAME_WIDTH),
        .FRAME_HEIGHT(FRAME_HEIGHT),.AUDIO_CHANNEL(AUDIO_CHANNEL),.PEAK_HOLD_FRAMES(PEAK_HOLD_FRAMES)) u_overlay(
        .clk(clk),.rst(rst),.mode_hd(mode_hd),.enabled(enabled),.audio_running(audio_running),
        .audio_sample_valid(audio_sample_valid),.audio_left_data(audio_left_data),.audio_right_data(audio_right_data),
        .x(x),.y(y),.rgb_in(rgb_in),.user_in(user_in),.last_in(last_in),.valid_in(valid_in),
        .x_out(x_out),.y_out(y_out),.rgb_out(rgb_out),.user_out(user_out),.last_out(last_out),.valid_out(valid_out),
        .analysis_busy(analysis_busy),.analysis_overrun(analysis_overrun),.analysis_update(analysis_update));
endmodule
`default_nettype wire
