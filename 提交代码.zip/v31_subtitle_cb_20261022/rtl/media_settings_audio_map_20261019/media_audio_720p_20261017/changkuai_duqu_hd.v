// 720p SDRAM read scheduler. One accepted command produces one native read.
// Unlike the SD 128-word collector, command dequeue overlaps native reads.
`timescale 1ns/1ps
`default_nettype none
module changkuai_duqu_hd #(
    parameter [20:0] USED_WORDS = 21'd1843200,
    parameter [31:0] TIMEOUT = 32'd1000000
)(
    input wire clk, rst, enable, refresh, cancel,
    input wire cmd_valid, cmd_empty,
    input wire [9:0] cmd_count, rsp_count,
    input wire [20:0] cmd_addr,
    input wire native_valid, rsp_full,
    output wire cmd_pop, rd, put, busy, cancel_done,
    output wire [20:0] addr,
    output reg fault
);
    // APUG011 consumes BL4 groups, not independently stallable word requests.
    // Reserve a complete 128-word run before launch. Dequeue overlaps reads;
    // no collect pass and no response/command stalls inside a physical run.
    localparam WAIT=2'd0, ISSUE=2'd1, DRAIN=2'd2;
    reg [1:0] state;
    reg [7:0] issued,received;
    reg [20:0] expected_addr;
    reg discarded;
    localparam IDLE_BITS=TIMEOUT==0 ? 32 : TIMEOUT<=2 ? 1 : $clog2(TIMEOUT);
    reg [IDLE_BITS-1:0] idle_count;
    wire available=cmd_valid && !cmd_empty;
    wire launch=enable && !cancel && !fault && !refresh &&
                cmd_count>=10'd128 && rsp_count<=10'd384;
    assign busy=state!=WAIT;
    assign addr=cmd_addr;
    // Refresh may start in the cycle after launch was accepted. Wait before
    // beat zero; once the first beat starts, the controller defers refresh.
    assign rd=!rst && state==ISSUE && (issued!=0 || !refresh);
    assign cmd_pop=!rst && (rd || (state==WAIT && cancel && available));
    assign put=!rst && native_valid && state!=WAIT && !cancel && !discarded && !fault && !rsp_full;
    assign cancel_done=cancel && state==WAIT && cmd_empty;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=WAIT;issued<=0;received<=0;expected_addr<=0;
            discarded<=0;idle_count<=0;fault<=0;
        end else begin
            if(state==WAIT)begin
                issued<=0;received<=0;discarded<=0;idle_count<=0;
                if(native_valid)fault<=1;
                if(launch && available)begin
                    if(cmd_addr[6:0]!=0 || cmd_addr>USED_WORDS-21'd128)fault<=1;
                    else begin expected_addr<=cmd_addr;state<=ISSUE;end
                end
            end else begin
                if(cancel)discarded<=1;
                if(native_valid)begin
                    received<=received+1'b1;
                    if(received>=issued || received>=128)fault<=1;
                    if(rsp_full && !cancel && !discarded)fault<=1;
                end
                if(rd || native_valid)idle_count<=0;
                else if(idle_count==TIMEOUT-1'b1)fault<=1;
                else idle_count<=idle_count+1'b1;
                case(state)
                    ISSUE:if(rd)begin
                        if(!available || cmd_addr!=expected_addr || refresh)fault<=1;
                        expected_addr<=expected_addr+1'b1;
                        issued<=issued+1'b1;
                        if(issued==127)state<=DRAIN;
                    end
                    DRAIN:if(received==128)state<=WAIT;
                    default:state<=WAIT;
                endcase
            end
        end
    end
endmodule
`default_nettype wire
