`default_nettype none
// Reconstruct the coordinate of this AXIS pixel, after all UI latency.
// No READY here: this is the existing fixed-rate HDMI stream. Blanking holds
// position, SOF relocks the origin, and EOL advances the active row.
module axis_osd_coordinates #(
    parameter FRAME_WIDTH=1280,
    parameter FRAME_HEIGHT=720
)(
    input wire clk, rst, input wire user_in, last_in, valid_in,
    output wire [10:0] x,y
);
    wire [10:0] active_width=FRAME_WIDTH;
    wire [10:0] active_height=FRAME_HEIGHT;
    reg [10:0] next_x,next_y;
    assign x=user_in ? 11'd0 : next_x;
    assign y=user_in ? 11'd0 : next_y;
    always @(posedge clk or posedge rst) begin
        if(rst) begin next_x<=0;next_y<=0;end
        else if(valid_in) begin
            if(user_in) begin
                next_x<=last_in ? 11'd0 : 11'd1;
                next_y<=last_in && active_height>1 ? 11'd1 : 11'd0;
            end else if(last_in) begin
                next_x<=0;
                next_y<=next_y==active_height-1'b1 ? 11'd0 : next_y+1'b1;
            end else begin
                next_x<=next_x==active_width-1'b1 ? 11'd0 : next_x+1'b1;
            end
        end
    end
endmodule
`default_nettype wire
