module audio_acr #(
    parameter [19:0] ACR_N = 20'd6144
) (
    input  wire        clk,
    input  wire        rst,
    input  wire        audio_valid,

    output reg         acr_valid,
    output reg  [19:0] acr_cts,
    output reg  [19:0] acr_n
);

    // N/128 = 48：每收到48个音频样本更新一次CTS/N。
    localparam [6:0] AUDIO_SAMPLES_PER_ACR = ACR_N >> 7;

    reg [6:0]  audio_sample_count;
    reg [19:0] cts_clock_count;

    always @(posedge clk) begin
        if (rst) begin
            audio_sample_count <= 7'd0;
            cts_clock_count    <= 20'd0;
            acr_valid          <= 1'b0;
            acr_cts            <= 20'd0;
            acr_n              <= 20'd0;
        end
        else begin
            acr_valid <= 1'b0;
            acr_cts   <= 20'd0;
            acr_n     <= 20'd0;

            if (audio_valid &&
                (audio_sample_count == AUDIO_SAMPLES_PER_ACR - 7'd1)) begin
                // 记录48个样本实际经过的像素时钟数。
                audio_sample_count <= 7'd0;
                cts_clock_count    <= 20'd0;
                acr_valid          <= 1'b1;
                acr_cts            <= cts_clock_count + 20'd1;
                acr_n              <= ACR_N;
            end
            else begin
                cts_clock_count <= cts_clock_count + 20'd1;

                if (audio_valid)
                    audio_sample_count <= audio_sample_count + 7'd1;
            end
        end
    end

endmodule
