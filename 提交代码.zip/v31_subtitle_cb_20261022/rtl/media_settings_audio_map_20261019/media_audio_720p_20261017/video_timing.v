module video_timing #(
    parameter H_ACTIVE = 1280,
    parameter H_FRONT  = 110,
    parameter H_SYNC   = 40,
    parameter H_BACK   = 220,
    parameter V_ACTIVE = 720,
    parameter V_FRONT  = 5,
    parameter V_SYNC   = 5,
    parameter V_BACK   = 20
)(
    input clk,
input rst,

output reg [10:0] h_count,
output reg [10:0] v_count,

output reg [10:0] x,
output reg [10:0] y,

output reg hs,
output reg vs,
output reg de
 );
wire [11:0] cfg_V_SYNC=V_SYNC;
wire [11:0] cfg_V_FRONT=V_FRONT;
wire [11:0] cfg_H_SYNC=H_SYNC;
wire [11:0] cfg_H_FRONT=H_FRONT;
    wire [11:0] active_height = V_ACTIVE;
    wire [11:0] active_width = H_ACTIVE;
    wire active_hd = 0;


wire [11:0] H_TOTAL=H_ACTIVE+H_FRONT+H_SYNC+H_BACK;
wire [11:0] V_TOTAL=V_ACTIVE+V_FRONT+V_SYNC+V_BACK;
always @(posedge clk)begin
    if(rst)begin
        h_count <= 0;
        v_count <= 0;
    end
    else begin 
        if(h_count == H_TOTAL - 1)begin 
            h_count <= 0;
            if(v_count == V_TOTAL - 1) v_count <= 0;
            else v_count <= v_count + 1;
        end 
        else h_count <= h_count + 1;
    end
end
always@(*)begin 
    x = h_count;
    y = v_count;
    de = (h_count < active_width)&&(v_count < active_height);
    if((h_count >= active_width + cfg_H_FRONT)&&(h_count < active_width + cfg_H_FRONT + cfg_H_SYNC))hs = 0;
    else hs = 1;
    if((v_count >= active_height + cfg_V_FRONT)&&(v_count < active_height + cfg_V_FRONT + cfg_V_SYNC))vs = 0;
    else vs = 1;
end
endmodule
