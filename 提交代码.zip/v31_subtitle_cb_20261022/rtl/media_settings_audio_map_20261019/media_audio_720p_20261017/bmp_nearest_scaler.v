// Load-time bilinear scaler. Legacy name preserves the existing project ports.
// Bottom-up rows, Q8 fractions, one final rounding; no HDMI-domain arithmetic.
`default_nettype none
module bmp_nearest_scaler #(
    parameter DST_WIDTH=1280, DST_HEIGHT=720,
    parameter MAX_SOURCE_WIDTH=2048, MAX_SOURCE_HEIGHT=1536,
    parameter COMPACT_SOURCE_ROW=0,
    // Asset zero is the UI background; photos retain their original aspect fit.
    parameter WALLPAPER_STRETCH=0,
    parameter OUTPUT_GAP_CYCLES=32
)(
    input wire clk, rst, abort,
    input wire source_frame_valid, output wire source_frame_ready,
    input wire [15:0] source_width, source_height, source_index,
    input wire source_pixel_valid, output wire source_pixel_ready,
    input wire [23:0] source_pixel_rgb,
    input wire [15:0] source_pixel_x, source_pixel_y,
    input wire source_pixel_last,
    output wire frame_valid, input wire frame_ready,
    output wire [15:0] frame_width, frame_height, frame_index,
    output wire frame_bottom_up,
    output wire pixel_valid, input wire pixel_ready,
    output wire [23:0] pixel_rgb,
    output wire [15:0] pixel_x, pixel_y,
    output wire pixel_last, complete, output reg fault,
    input wire result_consumed
);
    wire [11:0] active_height = DST_HEIGHT;
    wire [11:0] active_width = DST_WIDTH;
    wire active_hd = 0;
    localparam [4:0] IDLE=0,FIT=1,DESCRIPTOR=2,INPUT=3,PREPARE=4,
        WEIGHTS=5,READ0=6,CAPTURE0=7,READ1=8,CAPTURE1=9,
        MAC_PREPARE=10,MAC_MULTIPLY=11,MAC_SUM=12,OUTPUT_SEND=13,
        STEP_X=14,STEP_Y=15,DONE=16,BAD=17,IDENTITY=18;
    localparam [5:0] OUTPUT_GAP=OUTPUT_GAP_CYCLES>0 ? OUTPUT_GAP_CYCLES-1 : 0;
    localparam integer SOURCE_WIDTH_W = MAX_SOURCE_WIDTH < 2 ? 1 : $clog2(MAX_SOURCE_WIDTH+1);
    localparam integer SOURCE_HEIGHT_W = MAX_SOURCE_HEIGHT < 2 ? 1 : $clog2(MAX_SOURCE_HEIGHT+1);
    localparam integer MAX_OUTPUT_WIDTH = DST_WIDTH;
    localparam integer MAX_OUTPUT_HEIGHT = DST_HEIGHT;
    localparam integer OUTPUT_DIM_W =
        (MAX_OUTPUT_WIDTH > MAX_OUTPUT_HEIGHT ? MAX_OUTPUT_WIDTH : MAX_OUTPUT_HEIGHT) < 2 ? 1 :
        $clog2((MAX_OUTPUT_WIDTH > MAX_OUTPUT_HEIGHT ? MAX_OUTPUT_WIDTH : MAX_OUTPUT_HEIGHT)+1);
    localparam integer FIT_NUM_A = MAX_SOURCE_HEIGHT * MAX_OUTPUT_WIDTH;
    localparam integer FIT_NUM_B = MAX_SOURCE_WIDTH * MAX_OUTPUT_HEIGHT;
    localparam integer FIT_NUM_MAX = FIT_NUM_A > FIT_NUM_B ? FIT_NUM_A : FIT_NUM_B;
    localparam integer FIT_NUM_W = FIT_NUM_MAX < 2 ? 1 : $clog2(FIT_NUM_MAX+1);
    localparam integer FIT_DIV_W = SOURCE_WIDTH_W > SOURCE_HEIGHT_W ? SOURCE_WIDTH_W : SOURCE_HEIGHT_W;
    reg [4:0] state;
    reg [SOURCE_WIDTH_W-1:0] width_reg;
    reg [SOURCE_HEIGHT_W-1:0] height_reg;
    // 在接收尺寸时保存末行/末列，避免运行中反复做减法再比较。
    reg [SOURCE_WIDTH_W-1:0] last_source_x;
    reg [SOURCE_HEIGHT_W-1:0] last_source_row;
    reg [15:0] index_reg;
    reg fit_wide;
    reg [FIT_NUM_W-1:0] fit_remainder;
    reg [FIT_DIV_W-1:0] fit_divisor;
    reg [OUTPUT_DIM_W-1:0] fit_quotient,fit_limit,content_width,content_height,x_offset,y_offset;
    reg [SOURCE_WIDTH_W-1:0] source_x,read_x;
    reg [SOURCE_HEIGHT_W-1:0] source_row,needed_row;
    reg [OUTPUT_DIM_W-1:0] output_x,output_row;
    reg [13:0] horizontal_fraction,vertical_fraction;
    reg source_done;
    reg [5:0] output_cooldown;
    reg [23:0] p00,p10,p01,p11,interpolated_rgb;
    reg [12:0] weight_x_remainder,weight_y_remainder;
    reg [7:0] weight_x,weight_y;
    reg [2:0] weight_bit;
    reg [1:0] channel,mac_phase;
    reg [15:0] horizontal0,horizontal1;
    reg signed [16:0] multiply_delta;
    reg signed [8:0] multiply_weight;
    reg signed [25:0] multiply_result;
    reg signed [26:0] multiply_base;
    wire [FIT_NUM_W-1:0] fit_height_numerator=source_height*active_width;
    wire [FIT_NUM_W-1:0] fit_width_numerator=source_width*active_height;
    wire [OUTPUT_DIM_W-1:0] fit_value=fit_quotient==0 ? {{(OUTPUT_DIM_W-1){1'b0}},1'b1} : fit_quotient;
    wire in_content_row=output_row>=y_offset && output_row<y_offset+content_height;
    wire in_content_column=output_x>=x_offset && output_x<x_offset+content_width;
    wire black_pixel=!in_content_row || !in_content_column;
    wire next_column_content=output_x+1'b1>=x_offset && output_x+1'b1<x_offset+content_width;
    wire next_row_content=output_row+1'b1>=y_offset && output_row+1'b1<y_offset+content_height;
    // Clamp the neighbour at the image edge; no out-of-range RAM access.
    wire [SOURCE_HEIGHT_W-1:0] neighbour_row=needed_row==last_source_row ? needed_row : needed_row+1'b1;
    wire [SOURCE_WIDTH_W-1:0] neighbour_x=read_x==last_source_x ? read_x : read_x+1'b1;
    wire [SOURCE_WIDTH_W-1:0] ram_x=state==READ1 || state==CAPTURE1 ? neighbour_x : read_x;
    wire [23:0] row0_value,row1_value;
    wire [23:0] first_row_pixel=needed_row[0] ? row1_value : row0_value;
    wire [23:0] second_row_pixel=neighbour_row[0] ? row1_value : row0_value;
    wire [13:0] doubled_x={weight_x_remainder,1'b0};
    wire [13:0] doubled_y={weight_y_remainder,1'b0};
    wire x_weight_bit=doubled_x>={2'b0,content_width};
    wire y_weight_bit=doubled_y>={2'b0,content_height};
    wire source_take=source_pixel_valid && source_pixel_ready;
    wire sink_take=pixel_valid && pixel_ready;
    wire source_coordinate_ok=source_pixel_x=={{(16-SOURCE_WIDTH_W){1'b0}},source_x} &&
        source_pixel_y==({{(16-SOURCE_HEIGHT_W){1'b0}},last_source_row}-
                         {{(16-SOURCE_HEIGHT_W){1'b0}},source_row}) &&
        source_pixel_last==((source_x==last_source_x)&&(source_row==last_source_row));
    wire signed [26:0] mac_value=multiply_base+$signed({multiply_result[25],multiply_result});
    wire signed [26:0] rounded_value=mac_value+27'sd32768;
    function [7:0] component;
        input [23:0] value; input [1:0] select_channel;
        begin case(select_channel)
            0:component=value[23:16]; 1:component=value[15:8];
            default:component=value[7:0];
        endcase end
    endfunction
    wire [7:0] c00=component(p00,channel),c10=component(p10,channel);
    wire [7:0] c01=component(p01,channel),c11=component(p11,channel);
    assign source_frame_ready=!rst && !abort && state==IDLE;
    assign source_pixel_ready=!rst && !abort && (state==INPUT || (state==IDENTITY && pixel_ready));
    assign frame_valid=!rst && !abort && state==DESCRIPTOR;
    assign frame_width=active_width; assign frame_height=active_height;
    assign frame_index=index_reg; assign frame_bottom_up=1'b1;
    assign pixel_valid=!rst && !abort && ((state==OUTPUT_SEND && output_cooldown==0) ||
        (state==IDENTITY && source_pixel_valid));
    assign pixel_rgb=state==IDENTITY ? source_pixel_rgb : black_pixel ? 24'h0 : interpolated_rgb;
    assign pixel_x=state==IDENTITY ? source_pixel_x : {4'd0,output_x};
    assign pixel_y=state==IDENTITY ? source_pixel_y : active_height-1-{4'd0,output_row};
    assign pixel_last=state==IDENTITY ? source_pixel_last :
        (output_x==active_width-1 && output_row==active_height-1);
    assign complete=state==DONE;
    // Keep the general 2048-pixel profile intact. The fixed 640-wide board
    // profile uses two compact rows instead of four 1024-word banks.
    generate if (COMPACT_SOURCE_ROW) begin : g_compact_source_rows
        reg [23:0] row_even [0:MAX_SOURCE_WIDTH-1];
        reg [23:0] row_odd  [0:MAX_SOURCE_WIDTH-1];
        reg [23:0] even_q,odd_q;
        always @(posedge clk) begin
            if(state==INPUT && source_take && !fault && !source_done) begin
                if(source_row[0]) row_odd[source_x]<=source_pixel_rgb;
                else row_even[source_x]<=source_pixel_rgb;
            end
            if(state==READ0 || state==READ1) begin
                even_q<=row_even[ram_x];
                odd_q<=row_odd[ram_x];
            end
        end
        assign row0_value=even_q;
        assign row1_value=odd_q;
    end else begin : g_wide_source_rows
        reg [23:0] row0_lo[0:1023],row0_hi[0:1023];
        reg [23:0] row1_lo[0:1023],row1_hi[0:1023];
        reg [23:0] q0_lo,q0_hi,q1_lo,q1_hi;
        always @(posedge clk) begin
            if(state==INPUT && source_take && !fault && !source_done) begin
                if(!source_row[0] && !source_x[10]) row0_lo[source_x[9:0]]<=source_pixel_rgb;
                if(!source_row[0] && source_x[10]) row0_hi[source_x[9:0]]<=source_pixel_rgb;
                if(source_row[0] && !source_x[10]) row1_lo[source_x[9:0]]<=source_pixel_rgb;
                if(source_row[0] && source_x[10]) row1_hi[source_x[9:0]]<=source_pixel_rgb;
            end
            if(state==READ0 || state==READ1) begin
                q0_lo<=row0_lo[ram_x[9:0]]; q0_hi<=row0_hi[ram_x[9:0]];
                q1_lo<=row1_lo[ram_x[9:0]]; q1_hi<=row1_hi[ram_x[9:0]];
            end
        end
        assign row0_value=ram_x[10] ? q0_hi : q0_lo;
        assign row1_value=ram_x[10] ? q1_hi : q1_lo;
    end endgenerate
    // Shared signed multiplier with registered operands, result and accumulation.
    always @(posedge clk)
        if(state==MAC_MULTIPLY) multiply_result<=multiply_delta*multiply_weight;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=IDLE; width_reg<=0;height_reg<=0;index_reg<=0;
            last_source_x<=0;last_source_row<=0;
            fit_wide<=0;fit_remainder<=0;fit_divisor<=0;fit_quotient<=0;fit_limit<=0;
            content_width<=0;content_height<=0;x_offset<=0;y_offset<=0;
            source_x<=0;source_row<=0;needed_row<=0;read_x<=0;output_x<=0;output_row<=0;
            horizontal_fraction<=0;vertical_fraction<=0;source_done<=0;output_cooldown<=0;fault<=0;
            weight_x_remainder<=0;weight_y_remainder<=0;weight_x<=0;weight_y<=0;weight_bit<=0;
            p00<=0;p10<=0;p01<=0;p11<=0;interpolated_rgb<=0;
            channel<=0;mac_phase<=0;horizontal0<=0;horizontal1<=0;
            multiply_delta<=0;multiply_weight<=0;multiply_base<=0;
        end else if(abort) begin
            state<=IDLE;fault<=0;source_done<=0;output_cooldown<=0;
        end else begin
            if(output_cooldown!=0) output_cooldown<=output_cooldown-1'b1;
            case(state)
                IDLE:if(source_frame_valid && source_frame_ready) begin
                    width_reg<=source_width;height_reg<=source_height;index_reg<=source_index;
                    last_source_x<=source_width-16'd1;last_source_row<=source_height-16'd1;
                    source_x<=0;source_row<=0;needed_row<=0;read_x<=0;output_x<=0;output_row<=0;
                    horizontal_fraction<=0;vertical_fraction<=0;
                    source_done<=0;output_cooldown<=0;fault<=0;
                    fit_wide<=(fit_height_numerator<=fit_width_numerator);
                    if(source_width==0 || source_width>MAX_SOURCE_WIDTH || source_width>2048 ||
                        source_height==0 || source_height>MAX_SOURCE_HEIGHT || source_height>1536 ||
                        active_width<1 || active_height<1 || active_width>4095 || active_height>4095) begin
                        fault<=1;state<=BAD;
                    end else if((WALLPAPER_STRETCH && source_index==0) ||
                                (source_width==active_width && source_height==active_height)) begin
                        content_width<=active_width;content_height<=active_height;x_offset<=0;y_offset<=0;
                        state<=DESCRIPTOR;
                    end else begin
                        if(fit_height_numerator<=fit_width_numerator) begin
                            fit_remainder<=fit_height_numerator;fit_divisor<=source_width;fit_limit<=active_height;
                        end else begin
                            fit_remainder<=fit_width_numerator;fit_divisor<=source_height;fit_limit<=active_width;
                        end
                        fit_quotient<=0;state<=FIT;
                    end
                end
                FIT:if(fit_remainder>=fit_divisor && fit_quotient<fit_limit) begin
                    fit_remainder<=fit_remainder-fit_divisor;fit_quotient<=fit_quotient+1'b1;
                end else begin
                    if(fit_wide) begin
                        content_width<=active_width;content_height<=fit_value;
                        x_offset<=0;y_offset<=(active_height-fit_value)>>1;
                    end else begin
                        content_width<=fit_value;content_height<=active_height;
                        x_offset<=(active_width-fit_value)>>1;y_offset<=0;
                    end
                    state<=DESCRIPTOR;
                end
                DESCRIPTOR:if(frame_valid && frame_ready)
                    state<=width_reg==active_width && height_reg==active_height ? IDENTITY : PREPARE;
                IDENTITY:if(source_take) begin
                    if(!source_coordinate_ok) begin fault<=1;state<=BAD;end
                    else if(source_pixel_last) begin source_done<=1;state<=DONE;end
                    else if(source_x==last_source_x) begin source_x<=0;source_row<=source_row+1'b1;end
                    else source_x<=source_x+1'b1;
                end
                INPUT:if(source_take) begin
                    if(!source_coordinate_ok || source_done) begin fault<=1;state<=BAD;end
                    else if(source_x==last_source_x) begin
                        source_x<=0;source_row<=source_row+1'b1;
                        if(source_pixel_last) source_done<=1;
                        if(output_row==active_height) begin if(source_pixel_last) state<=DONE;end
                        else if(source_row==neighbour_row) state<=PREPARE;
                        else if(source_pixel_last) begin fault<=1;state<=BAD;end
                    end else source_x<=source_x+1'b1;
                end
                PREPARE:begin
                    if(black_pixel) state<=OUTPUT_SEND;
                    else if(neighbour_row>=source_row) begin
                        if(source_done) begin fault<=1;state<=BAD;end else state<=INPUT;
                    end else begin
                        weight_x_remainder<=horizontal_fraction[12:0];
                        weight_y_remainder<=vertical_fraction[12:0];
                        weight_x<=0;weight_y<=0;weight_bit<=0;state<=WEIGHTS;
                    end
                end
                // Eight serial fraction bits: no variable combinational divider.
                WEIGHTS:begin
                    weight_x_remainder<=x_weight_bit ? doubled_x-{2'b0,content_width} : doubled_x;
                    weight_y_remainder<=y_weight_bit ? doubled_y-{2'b0,content_height} : doubled_y;
                    weight_x<={weight_x[6:0],x_weight_bit};weight_y<={weight_y[6:0],y_weight_bit};
                    if(weight_bit==7) state<=READ0;else weight_bit<=weight_bit+1'b1;
                end
                READ0:state<=CAPTURE0;
                CAPTURE0:begin p00<=first_row_pixel;p01<=second_row_pixel;state<=READ1;end
                READ1:state<=CAPTURE1;
                CAPTURE1:begin
                    p10<=first_row_pixel;p11<=second_row_pixel;channel<=0;mac_phase<=0;state<=MAC_PREPARE;
                end
                MAC_PREPARE:begin
                    if(mac_phase==0) begin
                        multiply_delta<=$signed({1'b0,c10})-$signed({1'b0,c00});
                        multiply_weight<=$signed({1'b0,weight_x});
                        multiply_base<=$signed({11'd0,c00,8'd0});
                    end else if(mac_phase==1) begin
                        multiply_delta<=$signed({1'b0,c11})-$signed({1'b0,c01});
                        multiply_weight<=$signed({1'b0,weight_x});
                        multiply_base<=$signed({11'd0,c01,8'd0});
                    end else begin
                        multiply_delta<=$signed({1'b0,horizontal1})-$signed({1'b0,horizontal0});
                        multiply_weight<=$signed({1'b0,weight_y});
                        multiply_base<=$signed({3'd0,horizontal0,8'd0});
                    end
                    state<=MAC_MULTIPLY;
                end
                MAC_MULTIPLY:state<=MAC_SUM;
                MAC_SUM:begin
                    if(mac_phase==0) begin horizontal0<=mac_value[15:0];mac_phase<=1;state<=MAC_PREPARE;end
                    else if(mac_phase==1) begin horizontal1<=mac_value[15:0];mac_phase<=2;state<=MAC_PREPARE;end
                    else begin
                        case(channel)
                            0:interpolated_rgb[23:16]<=rounded_value[23:16];
                            1:interpolated_rgb[15:8]<=rounded_value[23:16];
                            2:interpolated_rgb[7:0]<=rounded_value[23:16];
                        endcase
                        if(channel==2) state<=OUTPUT_SEND;
                        else begin channel<=channel+1'b1;mac_phase<=0;state<=MAC_PREPARE;end
                    end
                end
                OUTPUT_SEND:if(sink_take) begin
                    output_cooldown<=OUTPUT_GAP;
                    if(output_x==active_width-1) begin
                        output_x<=0;read_x<=0;horizontal_fraction<=0;
                        if(output_row==active_height-1) begin
                            output_row<=active_height;state<=source_done ? DONE : INPUT;
                        end else begin
                            output_row<=output_row+1'b1;
                            if(in_content_row && next_row_content) begin
                                vertical_fraction<=vertical_fraction+height_reg;state<=STEP_Y;
                            end else state<=PREPARE;
                        end
                    end else begin
                        output_x<=output_x+1'b1;
                        if(in_content_row && in_content_column && next_column_content) begin
                            horizontal_fraction<=horizontal_fraction+width_reg;state<=STEP_X;
                        end else state<=PREPARE;
                    end
                end
                // Exact integer coordinates, including very narrow/tall pictures.
                STEP_X:if(horizontal_fraction>=content_width) begin
                    horizontal_fraction<=horizontal_fraction-content_width;read_x<=read_x+1'b1;
                end else state<=PREPARE;
                STEP_Y:if(vertical_fraction>=content_height) begin
                    vertical_fraction<=vertical_fraction-content_height;needed_row<=needed_row+1'b1;
                end else state<=PREPARE;
                DONE:if(result_consumed) state<=IDLE;
                BAD:if(result_consumed) begin fault<=0;state<=IDLE;end
                default:begin state<=BAD;fault<=1;end
            endcase
        end
    end
endmodule
`default_nettype wire
