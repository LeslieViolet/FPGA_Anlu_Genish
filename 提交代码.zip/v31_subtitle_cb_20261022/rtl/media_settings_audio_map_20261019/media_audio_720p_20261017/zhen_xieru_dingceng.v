// Parts 1..5 integration. The memory adapter is supplied by Part 8.
`default_nettype none
module zhen_xieru_dingceng (
    input wire rst_catalog, input wire rst_reader,
    input wire clk, rst,
    input wire clk_pixel, rst_pixel,
    input wire [95:0] ui_status_payload_pixel,
    input wire scan_valid,
    output wire scan_ready,
    input wire [31:0] scan_first_lba, scan_last_lba,
    output wire scan_done,
    output wire [3:0] scan_status,
    output wire [4:0] asset_count,
    input wire load_valid,
    output wire load_ready,
    input wire [3:0] load_id,
    input wire load_buffer_sel,
    input wire [1:0] load_physical_slot,
    input wire abort,
    output wire busy,
    output wire reset_required,
    output wire result_valid,
    input wire result_ready,
    output wire [3:0] result_code,
    output wire [15:0] result_index,
    output wire result_buffer_sel,
    output wire [3:0] reader_error_code,
    output wire mem_write_valid,
    input wire mem_write_ready,
    output wire [20:0] mem_write_addr,
    output wire [31:0] mem_write_data,
    output wire mem_flush_req,
    input wire mem_flush_done,
    input wire memory_fault,
    output wire card_ready,
    output wire bgm_selected, bgm_audio_valid,
    output wire [23:0] bgm_audio_left, bgm_audio_right,
    output wire bgm_acr_valid,
    output wire [19:0] bgm_acr_cts, bgm_acr_n,
    output wire bgm_meter_valid,
    output wire bgm_visualizer_enable,
    output wire [3:0] bgm_level_left, bgm_level_right,
    output wire tf_cs_n, tf_sclk, tf_mosi,
    input wire tf_miso
);
    localparam active_hd = 1'b1;
    wire loader_ready, loader_busy, loader_reset, writer_idle;
    wire loader_result_valid, loader_result_ready, writer_result_ready;
    wire [3:0] loader_result_code;
    wire [15:0] loader_result_index;
    wire frame_valid, frame_ready, frame_bottom_up;
    wire [15:0] frame_width, frame_height, frame_index;
    wire pixel_valid, pixel_ready, pixel_last, writer_cancel;
    wire [23:0] pixel_rgb;
    wire [15:0] pixel_x, pixel_y;
    wire writer_reset;
    wire scaled_frame_valid, scaled_frame_ready, scaled_bottom_up;
    wire [15:0] scaled_width, scaled_height, scaled_index;
    wire scaled_pixel_valid, scaled_pixel_ready, scaled_pixel_last;
    wire [23:0] scaled_pixel_rgb;
    wire [15:0] scaled_pixel_x, scaled_pixel_y;
    wire scaler_complete, scaler_fault;
    wire scaler_idle = !scaled_frame_valid && !scaled_pixel_valid &&
                       !scaler_complete && !scaler_fault && !loader_busy;
    wire release_result = loader_result_code != 0 || scaler_complete || scaler_fault;
    assign loader_result_ready = writer_result_ready && release_result;
    assign load_ready = loader_ready && writer_idle && scaler_idle && !memory_fault && !abort;
    assign busy = loader_busy || !writer_idle || !scaler_idle;
    assign reset_required = loader_reset || writer_reset;

    tuxiang_jiazai_dingceng #(.KEEP_CATALOG(0)) u_tuxiang_jiazai_dingceng (
        .rst_catalog(rst_catalog),.rst_reader(rst_reader),
        .clk_pixel(clk_pixel),.rst_pixel(rst_pixel),
        .ui_status_payload_pixel(ui_status_payload_pixel),
        .clk(clk), .rst(rst), .scan_valid(scan_valid), .scan_ready(scan_ready),
        .scan_first_lba(scan_first_lba), .scan_last_lba(scan_last_lba),
        .scan_done(scan_done), .scan_status(scan_status), .asset_count(asset_count),
        .load_valid(load_valid && writer_idle && scaler_idle && !memory_fault && !abort), .load_ready(loader_ready),
        .load_id(load_id), .cancel(abort || writer_cancel), .busy(loader_busy),
        .reset_required(loader_reset), .result_valid(loader_result_valid),
        .result_ready(loader_result_ready), .result_code(loader_result_code),
        .reader_error_code(reader_error_code), .result_index(loader_result_index),
        .frame_valid(frame_valid), .frame_ready(frame_ready), .frame_width(frame_width),
        .frame_height(frame_height), .frame_index(frame_index), .frame_bottom_up(frame_bottom_up),
        .pixel_valid(pixel_valid), .pixel_ready(pixel_ready), .pixel_rgb(pixel_rgb),
        .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_last(pixel_last), .card_ready(card_ready),
        .bgm_selected(bgm_selected),.bgm_audio_valid(bgm_audio_valid),
        .bgm_audio_left(bgm_audio_left),.bgm_audio_right(bgm_audio_right),
        .bgm_acr_valid(bgm_acr_valid),.bgm_acr_cts(bgm_acr_cts),.bgm_acr_n(bgm_acr_n),
        .bgm_meter_valid(bgm_meter_valid),.bgm_level_left(bgm_level_left),.bgm_level_right(bgm_level_right),
        .bgm_visualizer_enable(bgm_visualizer_enable),
        .tf_cs_n(tf_cs_n), .tf_sclk(tf_sclk), .tf_mosi(tf_mosi), .tf_miso(tf_miso)
    );

    bmp_nearest_scaler #(.DST_WIDTH(1280),
                         .DST_HEIGHT(720),
                         .MAX_SOURCE_WIDTH(2048),
                         .MAX_SOURCE_HEIGHT(1536),
                         .COMPACT_SOURCE_ROW(0),
                         .WALLPAPER_STRETCH(1),
                         // The downstream writer already supplies ready/backpressure.
                         // A zero fixed gap keeps the bilinear engine at its maximum
                         // useful rate without changing frame order or commit rules.
                         .OUTPUT_GAP_CYCLES(0)) u_bmp_nearest_scaler (
        
        .clk(clk), .rst(rst),
        .abort(abort || writer_cancel ||
               (loader_result_valid && loader_result_code!=0)),
        .source_frame_valid(frame_valid), .source_frame_ready(frame_ready),
        .source_width(frame_width), .source_height(frame_height),
        .source_index(frame_index),
        .source_pixel_valid(pixel_valid), .source_pixel_ready(pixel_ready),
        .source_pixel_rgb(pixel_rgb), .source_pixel_x(pixel_x),
        .source_pixel_y(pixel_y), .source_pixel_last(pixel_last),
        .frame_valid(scaled_frame_valid), .frame_ready(scaled_frame_ready),
        .frame_width(scaled_width), .frame_height(scaled_height),
        .frame_index(scaled_index), .frame_bottom_up(scaled_bottom_up),
        .pixel_valid(scaled_pixel_valid), .pixel_ready(scaled_pixel_ready),
        .pixel_rgb(scaled_pixel_rgb), .pixel_x(scaled_pixel_x),
        .pixel_y(scaled_pixel_y), .pixel_last(scaled_pixel_last),
        .complete(scaler_complete), .fault(scaler_fault),
        .result_consumed(loader_result_valid && loader_result_ready)
    );

    zhen_xieru  u_zhen_xieru (
        
        .clk(clk), .rst(rst), .target_buffer_sel(load_buffer_sel),
        .target_physical_slot(load_physical_slot), .abort(abort || scaler_fault),
        .frame_valid(scaled_frame_valid), .frame_ready(scaled_frame_ready),
        .frame_width(scaled_width), .frame_height(scaled_height),
        .frame_bottom_up(scaled_bottom_up), .frame_index(scaled_index),
        .pixel_valid(scaled_pixel_valid), .pixel_ready(scaled_pixel_ready),
        .pixel_rgb(scaled_pixel_rgb), .pixel_x(scaled_pixel_x),
        .pixel_y(scaled_pixel_y), .pixel_last(scaled_pixel_last),
        .source_result_valid(loader_result_valid && release_result),
        .source_result_ready(writer_result_ready),
        .source_result_code(loader_result_code), .source_result_index(loader_result_index),
        .source_cancel(writer_cancel), .mem_write_valid(mem_write_valid),
        .mem_write_ready(mem_write_ready), .mem_write_addr(mem_write_addr),
        .mem_write_data(mem_write_data), .mem_flush_req(mem_flush_req),
        .mem_flush_done(mem_flush_done), .memory_fault(memory_fault),
        .idle(writer_idle), .busy(), .result_valid(result_valid), .result_ready(result_ready),
        .result_code(result_code), .result_index(result_index),
        .result_buffer_sel(result_buffer_sel), .reset_required(writer_reset)
    );
endmodule
`default_nettype wire
