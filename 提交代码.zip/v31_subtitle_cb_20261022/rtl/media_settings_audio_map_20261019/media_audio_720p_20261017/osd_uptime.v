`default_nettype none

// System-domain HH:MM:SS uptime, delivered as a stable BCD snapshot to pixels.
// rst_pixel resets only the mailbox protocol; elapsed time is reset by rst_sys.
module osd_uptime #(
    parameter integer CLOCK_HZ = 50000000
)(
    input  wire        clk_sys,
    input  wire        rst_sys,
    input  wire        clk_pixel,
    input  wire        rst_pixel,
    output wire [23:0] time_bcd_pixel
);
    function integer clog2;
        input integer value;
        integer remaining;
        begin
            remaining = value - 1;
            clog2 = 0;
            while (remaining > 0) begin
                remaining = remaining >> 1;
                clog2 = clog2 + 1;
            end
        end
    endfunction
    localparam integer SECOND_W = (CLOCK_HZ <= 1) ? 1 : clog2(CLOCK_HZ);
    localparam [SECOND_W-1:0] SECOND_LAST = CLOCK_HZ - 1;
    reg [SECOND_W-1:0] second_count;
    reg [23:0] time_bcd_sys;

    // Each decimal digit has an explicit terminal count; 99:59:59 wraps to zero.
    always @(posedge clk_sys or posedge rst_sys) begin
        if (rst_sys) begin
            second_count <= {SECOND_W{1'b0}};
            time_bcd_sys <= 24'h000000;
        end else if (second_count == SECOND_LAST) begin
            second_count <= {SECOND_W{1'b0}};
            if (time_bcd_sys[3:0] != 4'd9)
                time_bcd_sys[3:0] <= time_bcd_sys[3:0] + 4'd1;
            else begin
                time_bcd_sys[3:0] <= 4'd0;
                if (time_bcd_sys[7:4] != 4'd5)
                    time_bcd_sys[7:4] <= time_bcd_sys[7:4] + 4'd1;
                else begin
                    time_bcd_sys[7:4] <= 4'd0;
                    if (time_bcd_sys[11:8] != 4'd9)
                        time_bcd_sys[11:8] <= time_bcd_sys[11:8] + 4'd1;
                    else begin
                        time_bcd_sys[11:8] <= 4'd0;
                        if (time_bcd_sys[15:12] != 4'd5)
                            time_bcd_sys[15:12] <= time_bcd_sys[15:12] + 4'd1;
                        else begin
                            time_bcd_sys[15:12] <= 4'd0;
                            if (time_bcd_sys[19:16] != 4'd9)
                                time_bcd_sys[19:16] <= time_bcd_sys[19:16] + 4'd1;
                            else begin
                                time_bcd_sys[19:16] <= 4'd0;
                                if (time_bcd_sys[23:20] != 4'd9)
                                    time_bcd_sys[23:20] <= time_bcd_sys[23:20] + 4'd1;
                                else
                                    time_bcd_sys[23:20] <= 4'd0;
                            end
                        end
                    end
                end
            end
        end else begin
            second_count <= second_count + 1'b1;
        end
    end

    // Mode reset is held for >=1 ms by the mode controller, so both protocol
    // endpoints return to their initial toggles before the pixel side releases.
    (* async_reg = "true" *) reg [1:0] rst_pixel_sync;
    always @(posedge clk_sys or posedge rst_sys) begin
        if (rst_sys)
            rst_pixel_sync <= 2'b11;
        else
            rst_pixel_sync <= {rst_pixel_sync[0], rst_pixel};
    end
    wire source_protocol_reset = rst_sys | rst_pixel_sync[1];
    reg [23:0] time_bcd_shadow;
    wire source_ready;
    wire source_publish = source_ready && (time_bcd_sys != time_bcd_shadow);
    wire destination_valid;

    always @(posedge clk_sys or posedge source_protocol_reset) begin
        if (source_protocol_reset)
            time_bcd_shadow <= 24'hffffff;
        else if (source_publish)
            time_bcd_shadow <= time_bcd_sys;
    end

    ui_snapshot_mailbox #(.PAYLOAD_W(24)) u_time_mailbox (
        .src_clk     (clk_sys),
        .src_rst     (source_protocol_reset),
        .src_valid   (source_publish),
        .src_ready   (source_ready),
        .src_payload (time_bcd_sys),
        .dst_clk     (clk_pixel),
        .dst_rst     (rst_pixel),
        .dst_valid   (destination_valid),
        .dst_ready   (1'b1),
        .dst_payload (time_bcd_pixel)
    );
endmodule
`default_nettype wire
