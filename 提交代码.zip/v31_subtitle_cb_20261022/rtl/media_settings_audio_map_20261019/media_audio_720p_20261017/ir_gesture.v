`default_nettype none

// Convert the board-verified NEC event stream into UI gestures.
//
// NEC has no release frame.  LEFT/RIGHT therefore remain pending until either
// a repeat frame proves a hold, or the first-repeat window expires and proves
// a tap.  During a hold every matching repeat refreshes the release timer.
module ir_gesture #(
    parameter integer CLOCK_HZ             = 50_000_000,
    parameter integer TAP_DECISION_MS      = 100,
    parameter integer RELEASE_TIMEOUT_MS   = 180
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       raw_event_valid,
    input  wire [3:0] raw_event_code,
    input  wire       raw_event_repeat,
    output reg        tap_valid,
    output reg  [3:0] tap_code,
    output reg        hold_start,
    output reg        hold_active,
    output reg        hold_release,
    output reg  [3:0] hold_code
);
    localparam [3:0] EVT_LEFT  = 4'd3;
    localparam [3:0] EVT_RIGHT = 4'd4;

    localparam integer TICKS_PER_MS = (CLOCK_HZ < 1000) ? 1 : CLOCK_HZ / 1000;
    localparam integer TAP_TICKS_RAW = TICKS_PER_MS * TAP_DECISION_MS;
    localparam integer REL_TICKS_RAW = TICKS_PER_MS * RELEASE_TIMEOUT_MS;
    localparam integer TAP_TICKS = (TAP_TICKS_RAW < 1) ? 1 : TAP_TICKS_RAW;
    localparam integer REL_TICKS = (REL_TICKS_RAW < 1) ? 1 : REL_TICKS_RAW;
    localparam integer MAX_TIMER_TICKS = (TAP_TICKS > REL_TICKS) ? TAP_TICKS : REL_TICKS;
    localparam integer TIMER_WIDTH = (MAX_TIMER_TICKS > 1) ? $clog2(MAX_TIMER_TICKS) : 1;
    localparam [TIMER_WIDTH-1:0] TIMER_ZERO = {TIMER_WIDTH{1'b0}};
    localparam [TIMER_WIDTH-1:0] TIMER_ONE = {{(TIMER_WIDTH-1){1'b0}}, 1'b1};
    localparam [TIMER_WIDTH-1:0] TAP_LAST_TICK = TAP_TICKS - 1;
    localparam [TIMER_WIDTH-1:0] REL_LAST_TICK = REL_TICKS - 1;

    localparam [2:0] S_IDLE = 3'd0, S_LEFT_PENDING = 3'd1,
                     S_RIGHT_PENDING = 3'd2, S_LEFT_HOLD = 3'd3,
                     S_RIGHT_HOLD = 3'd4;

    reg [2:0]  state;
    reg [TIMER_WIDTH-1:0] timer;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state        <= S_IDLE;
            timer        <= TIMER_ZERO;
            tap_valid    <= 1'b0;
            tap_code     <= 4'd0;
            hold_start   <= 1'b0;
            hold_active  <= 1'b0;
            hold_release <= 1'b0;
            hold_code    <= 4'd0;
        end else begin
            tap_valid    <= 1'b0;
            hold_start   <= 1'b0;
            hold_release <= 1'b0;

            if (raw_event_valid && !raw_event_repeat) begin
                // A different first frame cancels any pending tap.  If a hold
                // was active, report its inferred release before accepting the
                // new key.
                if ((state == S_LEFT_HOLD) || (state == S_RIGHT_HOLD)) begin
                    hold_release <= 1'b1;
                end
                hold_active <= 1'b0;
                timer <= TIMER_ZERO;

                if (raw_event_code == EVT_LEFT) begin
                    state <= S_LEFT_PENDING;
                    hold_code <= EVT_LEFT;
                end else if (raw_event_code == EVT_RIGHT) begin
                    state <= S_RIGHT_PENDING;
                    hold_code <= EVT_RIGHT;
                end else begin
                    state <= S_IDLE;
                    tap_valid <= 1'b1;
                    tap_code <= raw_event_code;
                end
            end else if (raw_event_valid && raw_event_repeat) begin
                case (state)
                    S_LEFT_PENDING: if (raw_event_code == EVT_LEFT) begin
                        state <= S_LEFT_HOLD;
                        timer <= TIMER_ZERO;
                        hold_start <= 1'b1;
                        hold_active <= 1'b1;
                        hold_code <= EVT_LEFT;
                    end
                    S_RIGHT_PENDING: if (raw_event_code == EVT_RIGHT) begin
                        state <= S_RIGHT_HOLD;
                        timer <= TIMER_ZERO;
                        hold_start <= 1'b1;
                        hold_active <= 1'b1;
                        hold_code <= EVT_RIGHT;
                    end
                    S_LEFT_HOLD: if (raw_event_code == EVT_LEFT)
                        timer <= TIMER_ZERO;
                    S_RIGHT_HOLD: if (raw_event_code == EVT_RIGHT)
                        timer <= 32'd0;
                    default: begin end
                endcase
            end else begin
                case (state)
                    S_LEFT_PENDING: begin
                        if (timer == TAP_LAST_TICK) begin
                            state <= S_IDLE;
                            timer <= TIMER_ZERO;
                            tap_valid <= 1'b1;
                            tap_code <= EVT_LEFT;
                        end else timer <= timer + TIMER_ONE;
                    end
                    S_RIGHT_PENDING: begin
                        if (timer == TAP_LAST_TICK) begin
                            state <= S_IDLE;
                            timer <= TIMER_ZERO;
                            tap_valid <= 1'b1;
                            tap_code <= EVT_RIGHT;
                        end else timer <= timer + TIMER_ONE;
                    end
                    S_LEFT_HOLD, S_RIGHT_HOLD: begin
                        if (timer == REL_LAST_TICK) begin
                            state <= S_IDLE;
                            timer <= TIMER_ZERO;
                            hold_release <= 1'b1;
                            hold_active <= 1'b0;
                        end else timer <= timer + TIMER_ONE;
                    end
                    default: begin
                        state <= S_IDLE;
                        timer <= TIMER_ZERO;
                    end
                endcase
            end
        end
    end
endmodule

`default_nettype wire
