`default_nettype none
// Restore the existing 20261011 original 48 ms UI click at the actual pixel clock.
module ui_click_sound #(parameter integer CLK_HZ=75000000)(
 input wire clk,rst,trigger,
 output reg signed [23:0] pcm_sample,
 output wire pcm_valid
);
 localparam [26:0] CLOCK_RATE=CLK_HZ, SAMPLE_RATE=48000;
 reg [26:0] sample_accumulator;
 wire sample_tick=sample_accumulator>=CLOCK_RATE-SAMPLE_RATE;
 reg active;
 reg [11:0] sample_index;
 // 24-bit DDS has 0.00286 Hz resolution at 48 kHz. Removing inaudible
 // fractional precision saves carry/FF resources without shortening the click.
 reg [23:0] phase;
 reg [19:0] step;
 reg [7:0] envelope;
 wire [4:0] quarter_index=phase[22]?~phase[21:17]:phase[21:17];
 function [15:0] quarter_sine;
  input [4:0] i;
  begin case(i)
   0:quarter_sine=0;1:quarter_sine=1608;2:quarter_sine=3212;3:quarter_sine=4808;
   4:quarter_sine=6393;5:quarter_sine=7962;6:quarter_sine=9512;7:quarter_sine=11039;
   8:quarter_sine=12539;9:quarter_sine=14010;10:quarter_sine=15446;11:quarter_sine=16846;
   12:quarter_sine=18204;13:quarter_sine=19519;14:quarter_sine=20787;15:quarter_sine=22005;
   16:quarter_sine=23170;17:quarter_sine=24279;18:quarter_sine=25329;19:quarter_sine=26319;
   20:quarter_sine=27245;21:quarter_sine=28105;22:quarter_sine=28898;23:quarter_sine=29621;
   24:quarter_sine=30273;25:quarter_sine=30852;26:quarter_sine=31356;27:quarter_sine=31785;
   28:quarter_sine=32137;29:quarter_sine=32412;30:quarter_sine=32609;31:quarter_sine=32727;
  endcase end
 endfunction
 wire signed [16:0] magnitude=$signed({1'b0,quarter_sine(quarter_index)});
 wire signed [16:0] wave=phase[23]?-magnitude:magnitude;
 wire signed [25:0] scaled=wave*$signed({1'b0,envelope});
 wire [11:0] remaining=12'd2304-sample_index;
 always @* begin
  if(sample_index<128)envelope={1'b0,sample_index[6:0]};
  else if(remaining>=2032)envelope=127;
  else envelope=remaining[11:4];
 end
 assign pcm_valid=1'b1;
 always @(posedge clk) begin
  if(rst)begin
   sample_accumulator<=0;active<=0;sample_index<=0;phase<=0;step<=0;pcm_sample<=0;
  end else begin
   if(sample_tick)sample_accumulator<=sample_accumulator+SAMPLE_RATE-CLOCK_RATE;
   else sample_accumulator<=sample_accumulator+SAMPLE_RATE;
   if(trigger)begin active<=1;sample_index<=0;phase<=0;step<=20'd559240;pcm_sample<=0;end
   else if(sample_tick)begin
    if(active)begin
     if(sample_index==2303)begin active<=0;pcm_sample<=0;end
     else begin
      sample_index<=sample_index+1'b1;phase<=phase+step;step<=step-20'd91;
      pcm_sample<=scaled>>>1;
     end
    end else pcm_sample<=0;
   end
  end
 end
endmodule
`default_nettype wire
