# Audited exception for asynchronous assertion into the PCM FIFO read-domain
# four-stage reset release chain. Never cut raw session_reset (also gates READY).
# Pixel-release FFs are audited too, because a dual-FF slice can share their SR.
set pcm_base {u_video_top_core/u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_zhen_xieru_dingceng/u_tuxiang_jiazai_dingceng/u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm}
set pcm_clock [v31_one [get_nets {u_video_top_core/u_c/u_hdmi_phy/I_pixel_clk}] pcm_pixel_clock]
set pcm_cells {};set pcm_q {};set pcm_d {};set pcm_sr {};set pcm_rd_sr {}
set pcm_reset_name {}
foreach chain [list $pcm_base/u_pcm_fifo/rd_release $pcm_base/pixel_release] {
 set cq {};set cd {};set cn {}
 for {set s 0} {$s<4} {incr s} {
  set n [v31_one [get_nets [format {%s[%d]} $chain $s]] pcm_stage_net]
  v31_require [v31_prop ASYNC_REG $n] {pcm_stage_missing_ASYNC_REG}
  v31_require [expr {[v31_prop BUS_WIDTH $n]==4}] {pcm_stage_not_four_bit_chain}
  set drivers {}
  foreach pn [get_pins -of $n] {if {[v31_prop DIRECTION [get_pins $pn]]==1} {lappend drivers $pn}}
  set q [lindex [v31_one $drivers pcm_stage_driver] 0]
  v31_require [regexp {^(.*)\.q\[([01])\]$} $q -> cell_name qi] {pcm_driver_not_physical_FF}
  set cell [v31_one [get_cells $cell_name] pcm_stage_cell]
  set sr [lindex [v31_one [get_pins $cell_name.sr] pcm_stage_SR] 0]
  set d [lindex [v31_one [get_pins [format {%s.mi[%d]} $cell_name $qi]] pcm_stage_D] 0]
  set clk [v31_one [get_pins $cell_name.clk] pcm_stage_clock]
  v31_require [expr {[v31_prop NET_NAME $clk] eq [v31_prop NAME $pcm_clock]}] {pcm_wrong_clock}
  foreach {k v} {DFFMODE :FF CEMUX :1 CLKMUX :CLK SRMODE :ASYNC SRMUX :SR} {v31_attr $cell $k $v}
  v31_attr $cell REG${qi}_REGSET :SET
  v31_attr $cell REG${qi}_SD :MI
  set reset_name [v31_prop NET_NAME [get_pins $sr]]
  if {$pcm_reset_name eq {}} {set pcm_reset_name $reset_name}
  v31_require [expr {$reset_name eq $pcm_reset_name}] {pcm_release_chains_different_raw_reset}
  lappend pcm_cells $cell_name;lappend pcm_q $q;lappend pcm_d $d;lappend pcm_sr $sr
  if {$chain eq "$pcm_base/u_pcm_fifo/rd_release"} {lappend pcm_rd_sr $sr}
  lappend cq $q;lappend cd $d;lappend cn [lindex $n 0]
  puts "PCM_RESET_STAGE chain=$chain stage=$s Q=$q D=$d SR=$sr"
 }
 v31_require [expr {[v31_prop CONST_VALUE [get_pins [lindex $cd 0]]] eq "0"}] {pcm_stage0_D_not_zero}
 for {set s 1} {$s<4} {incr s} {
  v31_require [expr {[v31_prop NET_NAME [get_pins [lindex $cd $s]]] eq [lindex $cn [expr {$s-1}]]}] {pcm_D_not_previous_stage_Q}
 }
 for {set s 0} {$s<3} {incr s} {
  set pins [lsort [get_pins -of [get_nets [lindex $cn $s]]]]
  set expected [lsort [list [lindex $cq $s] [lindex $cd [expr {$s+1}]]]]
  v31_require [expr {$pins eq $expected}] {pcm_intermediate_stage_has_functional_fanout}
 }
}
v31_require [expr {[llength [lsort -unique $pcm_q]]==8}] {pcm_expected_eight_distinct_release_FFs}
foreach c [lsort -unique $pcm_cells] {
 set expected {};set connected {}
 for {set i 0} {$i<8} {incr i} {if {[lindex $pcm_cells $i] eq $c} {lappend expected [lindex $pcm_q $i]}}
 foreach pn [get_pins -of [get_cells $c]] {
  if {[regexp {\.q\[[01]\]$} $pn] && [v31_prop IS_CONNECTED [get_pins $pn]]} {lappend connected $pn}
 }
 v31_require [expr {[lsort $expected] eq [lsort $connected]}] {pcm_target_SR_also_resets_functional_FF}
}
set pcm_targets [lsort -unique $pcm_rd_sr]
v31_require [expr {[llength $pcm_targets]>=2 && [llength $pcm_targets]<=4}] {pcm_unexpected_physical_SR_count}
set pcm_file [file join $run_dir pcm_rd_reset_entry.sdc]
set pf [open $pcm_file w]
puts $pf {# Only audited async SR inputs of the four read-domain release FFs.}
puts $pf [format {set_false_path -to [get_pins {%s}]} [join $pcm_targets { }]]
close $pf
read_sdc $pcm_file
puts "PCM_RD_RESET_PHYSICAL_AUDIT_PASS RD_RELEASE_FF=4 PIXEL_RELEASE_FF=4 SR_ONLY=[llength $pcm_targets] DQ_TIMED=true"
