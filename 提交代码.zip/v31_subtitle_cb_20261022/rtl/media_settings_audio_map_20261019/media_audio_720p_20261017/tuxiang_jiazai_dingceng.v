// Single physical TF reader shared by catalog and image loader. Parts 1..4.
`default_nettype none
module tuxiang_jiazai_dingceng #(parameter KEEP_CATALOG=0) (
    input wire clk, rst, input wire rst_catalog, input wire rst_reader,
    input wire clk_pixel, rst_pixel,
    input wire [95:0] ui_status_payload_pixel,
    input wire scan_valid,
    output wire scan_ready,
    input wire [31:0] scan_first_lba, scan_last_lba,
    output wire scan_done,
    output wire [3:0] scan_status,
    output wire [4:0] asset_count,
    input wire load_valid,
    output wire load_ready,
    input wire [3:0] load_id,
    input wire cancel,
    output wire busy, reset_required,
    output wire result_valid,
    input wire result_ready,
    output wire [3:0] result_code, reader_error_code,
    output wire [15:0] result_index,
    output wire frame_valid,
    input wire frame_ready,
    output wire [15:0] frame_width, frame_height, frame_index,
    output wire frame_bottom_up,
    output wire pixel_valid,
    input wire pixel_ready,
    output wire [23:0] pixel_rgb,
    output wire [15:0] pixel_x, pixel_y,
    output wire pixel_last,
    output wire card_ready,
    output wire bgm_selected, bgm_audio_valid,
    output wire [23:0] bgm_audio_left, bgm_audio_right,
    output wire bgm_acr_valid,
    output wire [19:0] bgm_acr_cts, bgm_acr_n,
    output wire bgm_meter_valid,
    output wire bgm_visualizer_enable,
    output wire [3:0] bgm_level_left, bgm_level_right,
    output wire tf_cs_n, tf_sclk, tf_mosi,
    input wire tf_miso
);
    wire reader_changed;reg rescan_pending;
    always @(posedge clk or posedge rst)begin
        if(rst)rescan_pending<=0;else if(reader_changed)rescan_pending<=1;else if(scan_ready)rescan_pending<=0;
    end
    wire reader_busy, read_valid, read_ready, data_valid, data_last, data_ready;
    wire reader_done, reader_error;
    wire [31:0] read_lba;
    wire [7:0] data;
    wire [3:0] read_error_code;
    audio_board_shared_reader #(.PIXEL_HZ(75000000)) u_tf_audio_reader (
        .clk_sd(clk), .rst_sd(rst_reader), .clk_pixel(clk_pixel), .rst_pixel(rst_pixel),
        .ui_status_payload_pixel(ui_status_payload_pixel),
        .read_valid(read_valid), .read_ready(read_ready), .read_lba(read_lba),
        .data(data), .data_valid(data_valid), .data_last(data_last), .data_ready(data_ready),
        .busy(reader_busy), .card_ready(card_ready), .done(reader_done), .error(reader_error),
        .error_code(read_error_code), .image_cancel(cancel), .reader_changed(reader_changed),
        .bgm_selected(bgm_selected), .bgm_audio_valid(bgm_audio_valid),
        .bgm_audio_left(bgm_audio_left), .bgm_audio_right(bgm_audio_right),
        .bgm_acr_valid(bgm_acr_valid), .bgm_acr_cts(bgm_acr_cts), .bgm_acr_n(bgm_acr_n),
        .bgm_meter_valid(bgm_meter_valid), .bgm_level_left(bgm_level_left),
        .bgm_level_right(bgm_level_right),.bgm_visualizer_enable(bgm_visualizer_enable),
        .tf_cs_n(tf_cs_n), .tf_sclk(tf_sclk), .tf_mosi(tf_mosi), .tf_miso(tf_miso)
    );
    sucai_jiazai_tongdao #(.KEEP_CATALOG(KEEP_CATALOG)) u_sucai_jiazai_tongdao (
        .rst_catalog(rst_catalog | reader_changed),
        // A cold boot with no card can leave the owner in LOCKED. A new
        // responding card must reset the owner/loader as well as the catalog.
        .clk(clk), .rst(rst | reader_changed), .scan_valid(scan_valid | rescan_pending), .scan_ready(scan_ready),
        .scan_first_lba(scan_first_lba), .scan_last_lba(scan_last_lba),
        .scan_done(scan_done), .scan_status(scan_status), .asset_count(asset_count),
        .load_valid(load_valid), .load_ready(load_ready), .load_id(load_id), .cancel(cancel),
        .busy(busy), .reset_required(reset_required), .result_valid(result_valid), .result_ready(result_ready),
        .result_code(result_code), .result_index(result_index), .reader_error_code(reader_error_code),
        .frame_valid(frame_valid), .frame_ready(frame_ready), .frame_width(frame_width),
        .frame_height(frame_height), .frame_index(frame_index), .frame_bottom_up(frame_bottom_up),
        .pixel_valid(pixel_valid), .pixel_ready(pixel_ready), .pixel_rgb(pixel_rgb),
        .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_last(pixel_last),
        .card_ready(card_ready), .reader_busy(reader_busy), .read_valid(read_valid), .read_ready(read_ready),
        .read_lba(read_lba), .data(data), .data_valid(data_valid), .data_last(data_last), .data_ready(data_ready),
        .reader_done(reader_done), .reader_error(reader_error), .read_error_code(read_error_code)
    );
endmodule
`default_nettype wire
