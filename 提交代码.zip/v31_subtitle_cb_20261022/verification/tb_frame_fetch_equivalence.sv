`timescale 1ns/1ps
module tb_frame_fetch_equivalence;
 reg clk=0,rst=1;always #5 clk=~clk;
 reg [10:0] h_count=0,v_count=0;
 always @(posedge clk or posedge rst)begin
  if(rst)begin h_count<=0;v_count<=0;end
  else if(h_count==11)begin h_count<=0;v_count<=v_count==5?0:v_count+1;end
  else h_count<=h_count+1;
 end
 reg [1:0] requested_transition_style=0;
 reg frame_ready=1,disp_ack=0,disp_valid=0,disp_buffer_sel=0;
 reg [15:0] disp_width=8,disp_height=4;
 reg read_ack=0,read_pixel_valid=0,read_pixel_last=0,read_done=0,read_cancel_ack=0;
 reg [23:0] read_pixel_data=0;reg [3:0] read_status=0;
 wire [23:0] frame_rgb,r_frame_rgb;wire frame_active,r_frame_active;
 wire [4:0] fade_level,r_fade_level;wire [1:0] active_transition_style,r_active_transition_style;
 wire disp_req,r_disp_req,read_req,r_read_req,read_buffer_sel,r_read_buffer_sel;
 wire [31:0] read_start_addr,r_read_start_addr,read_length,r_read_length;
 wire read_pixel_ready,r_read_pixel_ready,read_done_ready,r_read_done_ready;
 wire read_cancel_req,r_read_cancel_req,output_fault,r_output_fault;
 wire [3:0] flow_status,r_flow_status;
 `define COMMON .clk(clk),.rst(rst),.h_count(h_count),.v_count(v_count),.requested_transition_style(requested_transition_style),.frame_ready(frame_ready),.disp_ack(disp_ack),.disp_valid(disp_valid),.disp_buffer_sel(disp_buffer_sel),.disp_width(disp_width),.disp_height(disp_height),.read_ack(read_ack),.read_pixel_valid(read_pixel_valid),.read_pixel_data(read_pixel_data),.read_pixel_last(read_pixel_last),.read_done(read_done),.read_status(read_status),.read_cancel_ack(read_cancel_ack)
 bc_frame_fetch_for_video_pipe #(.FRAME_WIDTH(8),.FRAME_HEIGHT(4),.FRAME_HTOTAL(12),.FRAME_VTOTAL(6),.PREFILL_WORDS(4),.PREFILL_TIMEOUT(120)) dut(
 `COMMON,.frame_rgb(frame_rgb),.frame_active(frame_active),.fade_level(fade_level),.active_transition_style(active_transition_style),.disp_req(disp_req),.read_req(read_req),.read_buffer_sel(read_buffer_sel),.read_start_addr(read_start_addr),.read_length(read_length),.read_pixel_ready(read_pixel_ready),.read_done_ready(read_done_ready),.read_cancel_req(read_cancel_req),.output_fault(output_fault),.flow_status(flow_status));
 baseline_bc_frame_fetch_for_video_pipe #(.FRAME_WIDTH(8),.FRAME_HEIGHT(4),.FRAME_HTOTAL(12),.FRAME_VTOTAL(6),.PREFILL_WORDS(4),.PREFILL_TIMEOUT(120)) reference(
 `COMMON,.frame_rgb(r_frame_rgb),.frame_active(r_frame_active),.fade_level(r_fade_level),.active_transition_style(r_active_transition_style),.disp_req(r_disp_req),.read_req(r_read_req),.read_buffer_sel(r_read_buffer_sel),.read_start_addr(r_read_start_addr),.read_length(r_read_length),.read_pixel_ready(r_read_pixel_ready),.read_done_ready(r_read_done_ready),.read_cancel_req(r_read_cancel_req),.output_fault(r_output_fault),.flow_status(r_flow_status));
 `undef COMMON
 integer mode,cycle,index,checks=0,starts=0,coincident=0,active_cycles=0,cancels=0;
 reg busy=0,take_now,done_now;
 reg [31:0] random_bits=32'h73ab592d;
 always @(posedge clk)begin
  #1;
  if(!rst)begin
   if({frame_rgb,frame_active,fade_level,active_transition_style,disp_req,read_req,read_buffer_sel,read_start_addr,read_length,read_pixel_ready,read_done_ready,read_cancel_req,output_fault,flow_status}!==
      {r_frame_rgb,r_frame_active,r_fade_level,r_active_transition_style,r_disp_req,r_read_req,r_read_buffer_sel,r_read_start_addr,r_read_length,r_read_pixel_ready,r_read_done_ready,r_read_cancel_req,r_output_fault,r_flow_status})$fatal(1,"frame fetch mismatch mode=%0d cycle=%0d",mode,cycle);
   checks=checks+1;
   if(frame_active&&mode<2)active_cycles=active_cycles+1;
   if(read_cancel_req)cancels=cancels+1;
  end
 end
 initial begin
  for(mode=0;mode<6;mode=mode+1)begin
   @(negedge clk);rst=1;busy=0;index=0;read_pixel_valid=0;read_done=0;read_ack=0;disp_ack=0;disp_valid=0;frame_ready=1;
   repeat(8)@(negedge clk);rst=0;requested_transition_style=mode%4;
   for(cycle=0;cycle<4000;cycle=cycle+1)begin
    random_bits={random_bits[30:0],random_bits[31]^random_bits[21]^random_bits[1]^random_bits[0]};
    disp_ack=0;read_ack=0;read_cancel_ack=read_cancel_req;
    if(cycle==200)frame_ready=1;
    if(disp_req)begin disp_ack=1;disp_valid=1;frame_ready=0;disp_buffer_sel=~disp_buffer_sel;end
    if(read_req&&!busy)begin read_ack=1;busy=1;index=0;starts=starts+1;end
    read_pixel_valid=busy&&index<32&&mode!=5&&(mode<2||random_bits[1:0]!=0);
    read_pixel_data=24'h594000+index;read_pixel_last=index==31;
    if(mode==3&&index==7)read_pixel_last=1;
    #1;
    read_done=busy&&(read_cancel_req||index>=32||(mode==1&&index==31&&read_pixel_valid&&read_pixel_ready)||(mode==2&&index==16));
    read_status=mode==4?4'd3:4'd0;
    #1;take_now=read_pixel_valid&&read_pixel_ready;done_now=read_done&&read_done_ready;
    if(take_now&&done_now)coincident=coincident+1;
    @(posedge clk);#2;
    if(take_now)index=index+1;
    if(done_now)busy=0;
    @(negedge clk);
   end
   if(mode<2&&output_fault)$fatal(1,"clean stream raised fault mode %0d",mode);
  end
  if(checks<24000||starts<5||coincident<1||active_cycles<100||cancels<1)$fatal(1,"incomplete frame equivalence coverage");
  $display("FRAME_FETCH_EQUIVALENCE_PASS cycles=%0d transactions=%0d same_cycle_done=%0d display=%0d cancel=%0d",checks,starts,coincident,active_cycles,cancels);$finish;
 end
 initial begin #1000000;$fatal(1,"frame equivalence timeout");end
endmodule
