# Asynchronous assertion into four PCM read-domain reset-release FFs.
# D/Q remain timed. Physical implementation must also pass the 8-FF audit.
set_false_path -to [get_pins {*u_tf_audio_reader/u_shared_storage/u_player/u_audio/u_pcm/u_pcm_fifo/rd_release_reg*.sr}]
