// B module: write-side pixel coordinate to SDRAM word address.
// Two persistent 1280 x 720 slots, one 32-bit word per pixel.
// Word contents are {RGB888, 8'h00}; addresses are NOT byte addresses.
`default_nettype none

module xie_dizhi_yingshe (
    input  wire [1:0]  image_index, // persistent physical slot 0..1
    input  wire        bottom_up,   // Source metadata; pixel_y is already top-origin
    input  wire [15:0] pixel_x,     // Column in the scaled frame: 0..1279
    input  wire [15:0] pixel_y,     // Row in the scaled frame: 0..719
    output wire [20:0] word_addr,   // Address to the SDRAM adapter
    output wire        addr_valid  // Coordinate is within the fixed frame
);

    wire [15:0] FRAME_WIDTH  = 16'd1280;
    wire [15:0] FRAME_HEIGHT = 16'd720;
    wire [20:0] SLOT_WORDS   = 21'd921600;

    wire [20:0] row_extended;
    wire [20:0] row_offset;
    wire [20:0] slot_base;
    wire [20:0] mapped_addr;

    assign addr_valid = (pixel_x < FRAME_WIDTH) &&
                        (pixel_y < FRAME_HEIGHT) &&
                        (image_index < 2);

    // Part 3 already converts BMP row order into top-origin coordinates.
    // bottom_up remains in the descriptor for traceability and future inputs;
    // applying it here would incorrectly flip the image a second time.

    // Explicitly widen before shifting: 1280*y = (y<<10) + (y<<8).
    assign row_extended = {5'd0, pixel_y};
    assign row_offset   = (row_extended << 10) + (row_extended << 8);
    assign slot_base    = image_index[0] ? 21'd921600 : 21'd0;
    assign mapped_addr  = slot_base + row_offset + {5'd0, pixel_x};

    // Invalid coordinates return zero, but zero is also a real address.
    // The caller MUST gate accesses with addr_valid, transaction state,
    // slot ownership and the SDRAM adapter's acceptance handshake.
    assign word_addr = addr_valid ? mapped_addr : 21'd0;

endmodule

`default_nettype wire
