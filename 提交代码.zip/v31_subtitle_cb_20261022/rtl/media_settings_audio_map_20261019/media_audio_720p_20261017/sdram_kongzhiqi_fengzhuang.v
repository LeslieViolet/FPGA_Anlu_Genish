// Board-specific wrapper for the APUG011 controller and EG4S20 SDRAM SIP.
`timescale 1ns/1ps
`default_nettype none
module sdram_kongzhiqi_fengzhuang(
    input  wire        clk_mem,
    input  wire        clk_mem_sft,
    input  wire        rst_mem,
    input  wire        app_wr_en,
    input  wire [20:0] app_wr_addr,
    input  wire [3:0]  app_wr_dm,
    input  wire [31:0] app_wr_data,
    input  wire        app_rd_en,
    input  wire [20:0] app_rd_addr,
    output wire        app_rd_data_valid,
    output wire [31:0] app_rd_data,
    output wire [31:0] raw_read_data,
    output wire        init_done,
    output wire        refresh_active,
    output wire        controller_busy
);
    wire [31:0] controller_raw_data;
`ifdef B_FANGZHEN
    fangzhen_sdram_kongzhiqi u_model (
        .clk_mem(clk_mem), .rst_mem(rst_mem),
        .app_wr_en(app_wr_en), .app_wr_addr(app_wr_addr),
        .app_wr_dm(app_wr_dm), .app_wr_data(app_wr_data),
        .app_rd_en(app_rd_en), .app_rd_addr(app_rd_addr),
        .app_rd_data_valid(app_rd_data_valid), .app_rd_data(controller_raw_data),
        .init_done(init_done), .refresh_active(refresh_active),
        .controller_busy(controller_busy)
    );
`else
    wire sdram_clk;
    wire sdram_ras_n;
    wire sdram_cas_n;
    wire sdram_we_n;
    wire [1:0] sdram_ba;
    wire [10:0] sdram_addr;
    wire [3:0] sdram_dm;
    wire [31:0] sdram_dq;

    sdr_as_ram #(.self_refresh_open(1'b1)) u_apug011 (
        .Sdr_clk(clk_mem), .Sdr_clk_sft(clk_mem_sft), .Rst(rst_mem),
        .Sdr_init_done(init_done), .Sdr_init_ref_vld(refresh_active),
        .Sdr_busy(controller_busy), .App_ref_req(1'b0),
        .App_wr_en(app_wr_en), .App_wr_addr(app_wr_addr),
        .App_wr_dm(app_wr_dm), .App_wr_din(app_wr_data),
        .App_rd_en(app_rd_en), .App_rd_addr(app_rd_addr),
        .Sdr_rd_en(app_rd_data_valid), .Sdr_rd_dout(controller_raw_data),
        .SDRAM_CLK(sdram_clk), .SDR_RAS(sdram_ras_n),
        .SDR_CAS(sdram_cas_n), .SDR_WE(sdram_we_n),
        .SDR_BA(sdram_ba), .SDR_ADDR(sdram_addr),
        .SDR_DM(sdram_dm), .SDR_DQ(sdram_dq)
    );

    // Official reference topology: controller SDRAM_CLK drives SIP directly.
    EG_PHY_SDRAM_2M_32 u_sdram_sip (
        .clk(sdram_clk), .ras_n(sdram_ras_n), .cas_n(sdram_cas_n),
        .we_n(sdram_we_n), .addr(sdram_addr), .ba(sdram_ba),
        .dq(sdram_dq), .cs_n(1'b0), .dm0(sdram_dm[0]),
        .dm1(sdram_dm[1]), .dm2(sdram_dm[2]), .dm3(sdram_dm[3]),
        .cke(1'b1)
    );
`endif
    // Full-range board self-test passed raw data aligned with native VALID.
    // Preserve VALID timing; do not insert a one-cycle data-only delay.
    assign app_rd_data=controller_raw_data;
    assign raw_read_data=controller_raw_data;
endmodule
`default_nettype wire
