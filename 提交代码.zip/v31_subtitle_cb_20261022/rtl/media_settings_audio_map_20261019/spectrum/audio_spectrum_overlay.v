`default_nettype none
// Self-contained pixel-domain spectrum. No image/frame RAM and no backpressure.
// PCM24 uses the HDMI convention: signed PCM16 occupies bits[23:8].
// Input sampled at stage1 -> output at stage3, including disabled/blank data.
module audio_spectrum_overlay #(
    parameter RUNTIME_MODE=1,
    parameter FRAME_WIDTH=640,
    parameter FRAME_HEIGHT=480,
    parameter AUDIO_CHANNEL=0, //0 left,1 right,2 signed stereo average
    parameter PEAK_HOLD_FRAMES=10
)(
    input wire clk,rst,mode_hd,enabled,audio_running,
    input wire audio_sample_valid,
    input wire signed [23:0] audio_left_data,audio_right_data,
    input wire [10:0] x,y,
    input wire [23:0] rgb_in,
    input wire user_in,last_in,valid_in,
    output reg [10:0] x_out,y_out,
    output reg [23:0] rgb_out,
    output reg user_out,last_out,valid_out,
    output wire analysis_busy,analysis_overrun,analysis_update
);
    wire signed [15:0] left16=audio_left_data[23:8],right16=audio_right_data[23:8];
    wire signed [16:0] stereo_sum=$signed({left16[15],left16})+$signed({right16[15],right16});
    wire signed [15:0] pcm=AUDIO_CHANNEL==1?right16:AUDIO_CHANNEL==2?stereo_sum[16:1]:left16;
    wire [127:0] levels;
    fft64_audio_analyzer u_analyzer(.clk(clk),.rst(rst),.audio_running(audio_running),
        .sample_valid(audio_sample_valid),.sample_data(pcm),.levels(levels),
        .levels_valid(analysis_update),.overrun(analysis_overrun),.busy(analysis_busy),
        .bin_valid(),.bin_index(),.bin_real(),.bin_imag());
    // 32 display columns packed in a small synchronous dual-port RAM.
    // Even entries hold one FFT band; odd entries interpolate its neighbour.
    // Bits[6:0]=height,[13:7]=peak,[17:14]=hold counter (even only).
    reg [17:0] bars[0:31];
    reg [17:0] render_q,update_q,write_value;
    reg [4:0] update_addr;
    reg write_enable;
    reg [127:0] frame_levels;
    reg [3:0] update_index;
    reg [2:0] update_state;
    reg [6:0] new_height,new_peak,previous_height,previous_peak;
    reg [3:0] new_hold;
    reg enabled_frame,bars_initialized;
    localparam UP_IDLE=0,UP_READ=1,UP_WAIT=2,UP_CALC=3,UP_EVEN=4,UP_ODD=5,UP_LAST=6,UP_PEAK=7;
    wire active_hd=RUNTIME_MODE?mode_hd:FRAME_WIDTH>640;
    wire [10:0] nx=active_hd?{1'b0,x[10:1]}:x;
    wire [10:0] ny=active_hd?{1'b0,y[10:1]}:y;
    wire [10:0] base_y=active_hd?11'd360:11'd408;
    wire [10:0] lx=nx-11'd64;
    wire region=enabled_frame&&valid_in&&nx>=64&&nx<576&&ny>=base_y-(active_hd?11'd49:11'd97)&&ny<base_y&&lx[3:0]<12;
    wire [6:0] target_height=frame_levels[{update_index,3'b000}+:7];
    wire [6:0] old_height=update_q[6:0],old_peak=update_q[13:7];
    wire [3:0] old_hold=update_q[17:14];
    wire [6:0] fallen_height=old_height>2?old_height-7'd2:7'd0;
    wire [6:0] smoothed_height=target_height>fallen_height?target_height:fallen_height;
    wire [7:0] interp_height={1'b0,previous_height}+{1'b0,new_height}+8'd1;
    wire [7:0] interp_peak={1'b0,previous_peak}+{1'b0,new_peak}+8'd1;
    // Both reads registered: constant video latency, no asynchronous RAM mux.
    always @(posedge clk)begin
        render_q<=bars[lx[8:4]];
        update_q<=bars[update_addr];
        if(write_enable&&!rst)bars[update_addr]<=write_value;
    end
    always @*begin
        update_addr={update_index,1'b0};write_enable=0;write_value=0;
        case(update_state)
            UP_EVEN:begin write_enable=1;write_value={new_hold,new_peak,new_height};end
            UP_ODD:begin
                update_addr={update_index-4'd1,1'b1};write_enable=1;
                write_value={4'd0,interp_peak[7:1],interp_height[7:1]};
            end
            UP_LAST:begin update_addr=31;write_enable=1;write_value={4'd0,new_peak,new_height};end
            default:begin end
        endcase
    end
    // Snapshot at SOF, finish within 110 clocks on the first row.
    // The first rendered row is 311 (HD virtual or SD), so render and
    // update ports never access the same cell when the video uses its data.
    // No RAM reset needed: all cells are written before the bar region.
    always @(posedge clk or posedge rst)begin
        if(rst)begin
            enabled_frame<=0;bars_initialized<=0;frame_levels<=0;update_index<=0;update_state<=UP_IDLE;
            new_height<=0;new_peak<=0;new_hold<=0;previous_height<=0;previous_peak<=0;
        end else if(valid_in&&user_in)begin
            enabled_frame<=enabled&&audio_running;frame_levels<=levels;
            update_index<=0;update_state<=UP_READ;
        end else case(update_state)
            UP_READ:update_state<=UP_WAIT;
            UP_WAIT:update_state<=UP_CALC;
            UP_CALC:begin
                // 先寄存平滑高度，下一拍再计算峰值，缩短 RAM 到寄存器路径。
                if(!enabled_frame)new_height<=0;
                else if(!bars_initialized)new_height<=target_height;
                else new_height<=smoothed_height;
                update_state<=UP_PEAK;
            end
            UP_PEAK:begin
                // 地址未变，update_q 中的旧峰值/保持时间仍属于本频带。
                if(!enabled_frame)begin new_peak<=0;new_hold<=0;end
                else if(!bars_initialized)begin new_peak<=new_height;new_hold<=PEAK_HOLD_FRAMES;end
                else begin
                    if(new_height>=old_peak)begin new_peak<=new_height;new_hold<=PEAK_HOLD_FRAMES;end
                    else begin
                        new_peak<=old_hold!=0?old_peak:(old_peak!=0?old_peak-1'b1:7'd0);
                        new_hold<=old_hold!=0?old_hold-1'b1:4'd0;
                    end
                end
                update_state<=UP_EVEN;
            end
            UP_EVEN:begin
                if(update_index==0)begin
                    previous_height<=new_height;previous_peak<=new_peak;update_index<=1;update_state<=UP_READ;
                end else update_state<=UP_ODD;
            end
            UP_ODD:begin
                previous_height<=new_height;previous_peak<=new_peak;
                if(update_index==15)update_state<=UP_LAST;
                else begin update_index<=update_index+1'b1;update_state<=UP_READ;end
            end
            UP_LAST:begin bars_initialized<=1;update_state<=UP_IDLE;end
            default:update_state<=UP_IDLE;
        endcase
    end
    function [23:0] rainbow;
        input [5:0] column;
        reg [7:0] rise,fall;
        begin
            rise={column[2:0],5'b00000};fall=8'd255-rise;
            case(column[5:3])
                0:rainbow={8'hff,rise,8'h20};
                1:rainbow={fall,8'hff,8'h20};
                2:rainbow={8'h20,8'hff,rise};
                3:rainbow={8'h20,fall,8'hff};
                4:rainbow={rise,8'h20,8'hff};
                5:rainbow={8'hff,8'h20,fall};
                6:rainbow={8'hff,rise,8'h80};
                default:rainbow={8'hff,8'h40,fall};
            endcase
        end
    endfunction
    function [23:0] mix75;
        input [23:0] background,foreground;
        integer c;
        reg [9:0] v;
        begin
            for(c=0;c<3;c=c+1)begin
                v={2'b0,background[c*8+:8]}+{1'b0,foreground[c*8+:8],1'b0}+{2'b0,foreground[c*8+:8]}+10'd2;
                mix75[c*8+:8]=v[9:2];
            end
        end
    endfunction
    // Stage1: a bounded coordinate region and one band's registered height.
    reg [10:0] x1,y1,x2,y2;
    reg [23:0] rgb1,rgb2,color1,color2;
    // HD坐标缩半后再把柱高缩半：最终720p最大约96px，底边位于y=719。
    wire [6:0] height1=active_hd?{1'b0,render_q[6:1]}:render_q[6:0];
    wire [6:0] peak1=active_hd?{1'b0,render_q[13:8]}:render_q[13:7];
    reg [10:0] dy1;
    reg region1,ink2;
    reg user1,last1,valid1,user2,last2,valid2;
    wire peak_ink=peak1!=0&&(dy1=={4'd0,peak1}||dy1=={4'd0,peak1}+1'b1);
    always @(posedge clk or posedge rst)begin
        if(rst)begin
            x1<=0;y1<=0;x2<=0;y2<=0;x_out<=0;y_out<=0;
            rgb1<=0;rgb2<=0;rgb_out<=0;color1<=0;color2<=0;dy1<=0;
            region1<=0;ink2<=0;user1<=0;last1<=0;valid1<=0;user2<=0;last2<=0;valid2<=0;
            user_out<=0;last_out<=0;valid_out<=0;
        end else begin
            x1<=x;y1<=y;rgb1<=rgb_in;user1<=user_in;last1<=last_in;valid1<=valid_in;
            dy1<=base_y-ny;region1<=region;color1<=rainbow({lx[8:4],1'b0});
            x2<=x1;y2<=y1;rgb2<=rgb1;user2<=user1;last2<=last1;valid2<=valid1;
            ink2<=region1&&(dy1<={4'd0,height1}||peak_ink);
            color2<=peak_ink?24'hffffff:color1;
            x_out<=x2;y_out<=y2;user_out<=user2;last_out<=last2;valid_out<=valid2;
            rgb_out<=ink2?mix75(rgb2,color2):rgb2;
        end
    end
endmodule
`default_nettype wire
