# Audit the mapped asynchronous reset pins selected by software_reset_entry.sdc.
# Functional D/Q paths and locator CE paths remain under normal timing analysis.
puts {TRIAL_GATE_RESET_ENTRY_REPORT_BEGIN}
set reset_specs {
    top_sys {*u_video_top_core/u_k/release_sys_reg*.sr} 3
    top_sd {*u_video_top_core/u_k/release_sd_reg*.sr} 3
    top_mem {*u_video_top_core/u_k/release_mem_reg*.sr} 3
    top_pixel {*u_video_top_core/u_k/release_pixel_reg*.sr} 3
    top_hdmi_serial {*u_video_top_core/u_k/release_hdmi_serial_reg*.sr} 3
    player_end_pixel {*u_video_top_core/u_b/*u_player/end_pixel_release_reg*.sr} 2
    pcm_fifo_wr {*u_video_top_core/u_b/*u_player/u_audio/u_pcm/u_pcm_fifo/wr_release_reg*.sr} 4
    pcm_fifo_rd {*u_video_top_core/u_b/*u_player/u_audio/u_pcm/u_pcm_fifo/rd_release_reg*.sr} 4
}
set reset_total 0
foreach {group pattern expected} $reset_specs {
    set pins [get_pins $pattern]
    if {[llength $pins] != $expected} {
        puts "TRIAL_RESET_MAP_FAIL group=$group expected=$expected actual=[llength $pins] pins=$pins"
        exit 1
    }
    puts "TRIAL_RESET_GROUP group=$group count=[llength $pins]"
    foreach reset_pin $pins {
        set cell_name [string range $reset_pin 0 [expr {[string last . $reset_pin]-1}]]
        puts "TRIAL_RESET_CELL group=$group pin=$reset_pin"
        report_cells [get_cells $cell_name] -attributes -connection
        incr reset_total
    }
}
if {$reset_total != 25} {
    puts "TRIAL_RESET_MAP_FAIL expected=25 actual=$reset_total"
    exit 1
}
puts {TRIAL_GATE_RESET_ENTRY_MAPPING_PASS SR_ONLY=25 DQ_TIMED=true}
puts {TRIAL_GATE_RESET_ENTRY_REPORT_END}
