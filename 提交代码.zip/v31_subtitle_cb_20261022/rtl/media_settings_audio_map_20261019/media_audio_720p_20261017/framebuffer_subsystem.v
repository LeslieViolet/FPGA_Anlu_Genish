// Diagnostic copy only. Main RTL is unchanged.
// B parts 1..8: TF input, BMP load, double buffering and APUG011 SDRAM access.
`default_nettype none
module framebuffer_subsystem #(
    parameter DIAGNOSTICS = 1
)(
    input wire rst_catalog,
    input wire clk_sys,
    input wire clk_sd,
    input wire clk_mem,
    input wire clk_mem_sft,
    input wire clk_pixel,
    input wire rst_sys,
    input wire rst_sd,
    input wire rst_mem,
    input wire rst_pixel,
    output wire media_catalog_done,
    output reg media_card_offline,
    output wire media_catalog_ok,
    output wire [4:0] media_asset_count,
    output wire media_storage_ready,
    input wire media_request_valid,
    output wire media_request_ready,
    input wire [3:0] media_request_id,
    input wire media_request_cancel,
    output wire media_result_valid,
    output wire [3:0] media_result_code,
    input wire media_request_started,
    input wire img_frame_start,
    output wire img_start_ready,
    input wire [15:0] img_width,
    input wire [15:0] img_height,
    input wire img_bottom_up,
    input wire [15:0] img_index,
    input wire img_pixel_valid,
    output wire img_pixel_ready,
    input wire [23:0] img_pixel_data,
    input wire img_frame_end,
    output wire img_end_ready,
    input wire img_abort,
    output wire img_abort_ready,
    output wire img_result_valid,
    input wire img_result_ready,
    output wire [3:0] img_result_code,
    output wire [15:0] img_result_index,
    output wire frame_ready,
    input wire disp_req,
    output wire disp_ack,
    input wire disp_keep_old,
    output wire disp_valid,
    output wire disp_buffer_sel,
    output wire [15:0] disp_width,
    output wire [15:0] disp_height,
    output wire [15:0] disp_index,
    output wire [1:0] disp_physical_slot,
    output wire [31:0] disp_generation,
    output wire disp_previous_valid,
    output wire disp_previous_sel,
    input wire disp_previous_release_req,
    output wire disp_previous_release_ack,
    input wire read_req,
    output wire read_ack,
    input wire read_buffer_sel,
    input wire [31:0] read_start_addr,
    input wire [31:0] read_length,
    output wire read_pixel_valid,
    input wire read_pixel_ready,
    output wire [23:0] read_pixel_data,
    output wire read_pixel_last,
    output wire read_done,
    input wire read_done_ready,
    output wire [3:0] read_status,
    input wire read_cancel_req,
    output wire read_cancel_ack,
    output wire memory_fault,
    output wire tf_load_fault,
    output wire [3:0] tf_scan_status,
    output wire [3:0] tf_reader_error_code,
    output wire [3:0] boot_progress,
    output wire [7:0] memory_diag,
    output wire [3:0] read_request_diag,
    output wire [11:0] pixel_crc_diag,
    output wire [3:0] native_write_crc,
    output wire [6:0] alignment_match,
    output wire [3:0] alignment_status,
    output wire [3:0] native_read_addr_diag,
    output wire [3:0] native_access_diag,
    input wire [95:0] ui_status_payload_pixel,
    output wire bgm_selected, bgm_audio_valid,
    output wire [23:0] bgm_audio_left, bgm_audio_right,
    output wire bgm_acr_valid,
    output wire [19:0] bgm_acr_cts, bgm_acr_n,
    output wire bgm_meter_valid,
    output wire bgm_visualizer_enable,
    output wire [3:0] bgm_level_left, bgm_level_right,
    input  wire tf_miso,
    output wire tf_sclk,
    output wire tf_mosi,
    output wire tf_cs_n
);
    // Losing a responding SPI card invalidates the complete media epoch.
    // The physical SPI engine keeps running so it can retry initialization;
    // cached frames/CDC FIFOs and the catalog are reset independently.
    wire physical_card_ready;
    reg card_ready_previous, removal_reset;
    reg [4:0] removal_count;
    always @(posedge clk_sd or posedge rst_sd)begin
        if(rst_sd)begin card_ready_previous<=0;removal_reset<=0;removal_count<=0;media_card_offline<=0;end
        else begin
            card_ready_previous<=physical_card_ready;
            if(physical_card_ready)media_card_offline<=0;
            if(card_ready_previous && !physical_card_ready)begin media_card_offline<=1;removal_reset<=1;removal_count<=31;end
            else if(removal_reset)begin
                if(removal_count==0)removal_reset<=0;
                else removal_count<=removal_count-1'b1;
            end
        end
    end
    wire media_rst_sd=rst_sd | removal_reset;
    wire media_catalog_reset=rst_catalog | removal_reset;
    (* async_reg="true" *) reg [2:0] media_release_mem,media_release_pixel;
    always @(posedge clk_mem or posedge rst_mem or posedge removal_reset)
        if(rst_mem || removal_reset)media_release_mem<=3'b111;
        else media_release_mem<={media_release_mem[1:0],1'b0};
    always @(posedge clk_pixel or posedge rst_pixel or posedge removal_reset)
        if(rst_pixel || removal_reset)media_release_pixel<=3'b111;
        else media_release_pixel<={media_release_pixel[1:0],1'b0};
    wire media_rst_mem=media_release_mem[2],media_rst_pixel=media_release_pixel[2];
    localparam active_hd = 1'b1;
// Match the official reference scan window (first 64 MiB).  This allows BMP
// files copied onto a freshly formatted FAT32 card to be discovered when their
// data clusters are contiguous.  It is still a sector scanner, not FAT parsing.
localparam [31:0] SUCAI_FIRST_LBA = 32'd0;
localparam [31:0] SUCAI_LAST_LBA  = 32'd131071;
reg         sucai_scan_valid;
wire        sucai_scan_ready;
wire        sucai_scan_done;
wire [3:0]  sucai_scan_status;
wire [3:0]  sucai_reader_error_code;
wire [4:0]  sucai_count;
wire        huanchong_request_ready;
wire        huanchong_reset_required;
wire        huanchong_result_valid;
wire [3:0]  huanchong_result_code;
wire [1:0]  huanchong_slot_busy;
wire        huanchong_mem_write_valid;
wire [20:0] huanchong_mem_write_addr;
wire [31:0] huanchong_mem_write_data;
wire        huanchong_mem_flush_req;
wire        duqu_mem_read_valid;
wire [20:0] duqu_mem_read_addr;
wire        duqu_mem_read_data_ready;
wire        duqu_mem_read_cancel_req;
wire        huanchong_mem_write_ready;
wire        huanchong_mem_flush_done;
wire        duqu_mem_read_ready;
wire        duqu_mem_read_data_valid;
wire [31:0] duqu_mem_read_data;
wire        duqu_mem_read_cancel_done;
wire        sdram_ready;
reg         tf_load_fault_latched;
reg         first_load_success;

// B publishes catalogue/storage status and executes A's media request.
assign media_catalog_done = sucai_scan_done && physical_card_ready;
assign media_catalog_ok = physical_card_ready && (sucai_scan_status == 4'd0);
assign media_asset_count = physical_card_ready ? sucai_count : 5'd0;
// Stable after scan completion. Expose the reason for a TF failure on LEDs.
assign tf_scan_status = sucai_scan_status;
assign tf_reader_error_code = sucai_reader_error_code;
assign media_storage_ready = sdram_ready;
assign media_request_ready = huanchong_request_ready;
assign media_result_valid = huanchong_result_valid;
assign media_result_code = huanchong_result_code;
// Read-only board milestones; all four bits belong to clk_sd.
assign boot_progress = {first_load_success, media_request_started, sdram_ready,
                        sucai_scan_done && sucai_scan_status==0 && sucai_count!=0};
always @(posedge clk_sd or posedge media_rst_sd) begin
    if (media_rst_sd) first_load_success <= 1'b0;
    else if (huanchong_result_valid && huanchong_result_code==0)
        first_load_success <= 1'b1;
end

// Preserve short completion/error pulses for the board LED until reset.
assign tf_load_fault = tf_load_fault_latched;
always @(posedge clk_sd or posedge media_rst_sd) begin
    if (media_rst_sd)
        tf_load_fault_latched <= 1'b0;
    else if ((sucai_scan_done && (sucai_scan_status != 4'd0 || sucai_count == 0)) ||
             (huanchong_result_valid && huanchong_result_code != 4'd0))
        tf_load_fault_latched <= 1'b1;
end

always @(posedge clk_sd or posedge media_catalog_reset) begin
    if (media_catalog_reset)
        sucai_scan_valid <= 1'b1;
    else if (sucai_scan_valid && sucai_scan_ready)
        sucai_scan_valid <= 1'b0;
end

// Passive first-frame observers, clk_sd on write and clk_pixel on returns.
generate if(DIAGNOSTICS)begin:legacy_pattern_crc
xiangsu_crc_zhenduan #(.EXPECTED_CRC(32'hc9ea9ad9),.CHECK_WRITE_ADDR(1)) u_write_crc (
    
    .clk(clk_sd),.rst(media_rst_sd),
    .take(huanchong_mem_write_valid && huanchong_mem_write_ready),
    .rgb(huanchong_mem_write_data[31:8]),.addr(huanchong_mem_write_addr),
    .last(1'b0),.user(1'b0),.flags(pixel_crc_diag[3:0])
);
xiangsu_crc_zhenduan #(.EXPECTED_CRC(32'hc2338e8b)) u_memory_return_crc (
    
    .clk(clk_pixel),.rst(media_rst_pixel),
    .take(duqu_mem_read_data_valid && duqu_mem_read_data_ready),
    .rgb(duqu_mem_read_data[31:8]),.addr(21'd0),
    .last(1'b0),.user(1'b0),.flags(pixel_crc_diag[7:4])
);
xiangsu_crc_zhenduan #(.EXPECTED_CRC(32'hc2338e8b),.LAST_MODE(1)) u_b_pixel_crc (
    
    .clk(clk_pixel),.rst(media_rst_pixel),.take(read_pixel_valid && read_pixel_ready),
    .rgb(read_pixel_data),.addr(21'd0),.last(read_pixel_last),.user(1'b0),
    .flags(pixel_crc_diag[11:8])
);
end else begin:no_legacy_pattern_crc
assign pixel_crc_diag=0;
end endgenerate
// Parts 1..7 chain connected to the Part 8 physical memory adapter.
zhen_duqu_dingceng  u_zhen_duqu_dingceng (
    
        .rst_catalog(media_catalog_reset),.rst_reader(rst_sd),
        
    .clk_write          (clk_sd),
    .rst_write          (media_rst_sd),
    .ui_status_payload_pixel(ui_status_payload_pixel),
    .scan_valid         (sucai_scan_valid),
    .scan_ready         (sucai_scan_ready),
    .scan_first_lba     (SUCAI_FIRST_LBA),
    .scan_last_lba      (SUCAI_LAST_LBA),
    .scan_done          (sucai_scan_done),
    .scan_status        (sucai_scan_status),
    .reader_error_code  (sucai_reader_error_code),
    .asset_count        (sucai_count),
    .request_valid      (media_request_valid),
    .request_ready      (huanchong_request_ready),
    .request_id         (media_request_id),
    .request_cancel     (media_request_cancel),
    .request_result_valid (huanchong_result_valid),
    .request_result_ready (1'b1),
    .request_result_code  (huanchong_result_code),
    .request_result_index (),
    .request_result_buffer_sel (),
    .slot_busy          (huanchong_slot_busy),
    .reset_required     (huanchong_reset_required),
    .mem_write_valid    (huanchong_mem_write_valid),
    .mem_write_ready    (huanchong_mem_write_ready),
    .mem_write_addr     (huanchong_mem_write_addr),
    .mem_write_data     (huanchong_mem_write_data),
    .mem_flush_req      (huanchong_mem_flush_req),
    .mem_flush_done     (huanchong_mem_flush_done),
    .mem_read_valid     (duqu_mem_read_valid),
    .mem_read_ready     (duqu_mem_read_ready),
    .mem_read_addr      (duqu_mem_read_addr),
    .mem_read_data_valid(duqu_mem_read_data_valid),
    .mem_read_data_ready(duqu_mem_read_data_ready),
    .mem_read_data      (duqu_mem_read_data),
    .mem_read_cancel_req(duqu_mem_read_cancel_req),
    .mem_read_cancel_done(duqu_mem_read_cancel_done),
    .memory_fault       (memory_fault),
    .clk_display        (clk_pixel),
    .rst_display        (media_rst_pixel),
    .frame_ready        (frame_ready),
    .disp_req           (disp_req),
    .disp_ack           (disp_ack),
    .disp_keep_old      (disp_keep_old),
    .disp_valid         (disp_valid),
    .disp_buffer_sel    (disp_buffer_sel),
    .disp_width         (disp_width),
    .disp_height        (disp_height),
    .disp_index         (disp_index),
    .disp_physical_slot (disp_physical_slot),
    .disp_generation    (disp_generation),
    .disp_previous_valid (disp_previous_valid),
    .disp_previous_sel  (disp_previous_sel),
    .disp_previous_release_req (disp_previous_release_req),
    .disp_previous_release_ack (disp_previous_release_ack),
    .read_req           (read_req),
    .read_ack           (read_ack),
    .read_buffer_sel    (read_buffer_sel),
    .read_start_addr    (read_start_addr),
    .read_length        (read_length),
    .read_pixel_valid   (read_pixel_valid),
    .read_pixel_ready   (read_pixel_ready),
    .read_pixel_data    (read_pixel_data),
    .read_pixel_last    (read_pixel_last),
    .read_done          (read_done),
    .read_done_ready    (read_done_ready),
    .read_status        (read_status),
    .read_cancel_req    (read_cancel_req),
    .read_cancel_ack    (read_cancel_ack),
    .bgm_selected       (bgm_selected),
    .bgm_audio_valid    (bgm_audio_valid),
    .bgm_audio_left     (bgm_audio_left),
    .bgm_audio_right    (bgm_audio_right),
    .bgm_acr_valid      (bgm_acr_valid),
    .bgm_acr_cts        (bgm_acr_cts),
    .bgm_acr_n          (bgm_acr_n),
    .bgm_meter_valid    (bgm_meter_valid),
    .bgm_visualizer_enable(bgm_visualizer_enable),
    .bgm_level_left     (bgm_level_left),
    .bgm_level_right    (bgm_level_right),
    .card_ready         (physical_card_ready),
    .tf_cs_n            (tf_cs_n),
    .tf_sclk            (tf_sclk),
    .tf_mosi            (tf_mosi),
    .tf_miso            (tf_miso)
);

sdram_shipeiqi #(.DIAGNOSTICS(DIAGNOSTICS)) u_sdram_shipeiqi (
    
    
    .clk_write(clk_sd), .rst_write(media_rst_sd),
    .mem_write_valid(huanchong_mem_write_valid),
    .mem_write_ready(huanchong_mem_write_ready),
    .mem_write_addr(huanchong_mem_write_addr),
    .mem_write_data(huanchong_mem_write_data),
    .mem_flush_req(huanchong_mem_flush_req),
    .mem_flush_done(huanchong_mem_flush_done),
    .clk_read(clk_pixel), .rst_read(media_rst_pixel),
    .mem_read_valid(duqu_mem_read_valid),
    .mem_read_ready(duqu_mem_read_ready),
    .mem_read_addr(duqu_mem_read_addr),
    .mem_read_data_valid(duqu_mem_read_data_valid),
    .mem_read_data_ready(duqu_mem_read_data_ready),
    .mem_read_data(duqu_mem_read_data),
    .mem_read_cancel_req(duqu_mem_read_cancel_req),
    .mem_read_cancel_done(duqu_mem_read_cancel_done),
    .clk_mem(clk_mem), .clk_mem_sft(clk_mem_sft), .rst_mem(media_rst_mem),
    .memory_ready(sdram_ready), .memory_fault(memory_fault),
    .memory_diag(memory_diag), .read_request_diag(read_request_diag),
    .native_write_crc(native_write_crc),.alignment_match(alignment_match),
    .alignment_status(alignment_status),
    .native_read_addr_diag(native_read_addr_diag),.native_access_diag(native_access_diag)
);

// The updated division gives TF/B ownership to this subsystem. The legacy
// A-to-B image stream remains intentionally unused until A's contract is revised.
assign img_start_ready = 1'd0;
assign img_pixel_ready = 1'd0;
assign img_end_ready = 1'd0;
assign img_abort_ready = 1'd0;
assign img_result_valid = 1'd0;
assign img_result_code = 4'd0;
assign img_result_index = 16'd0;
endmodule
`default_nettype wire
