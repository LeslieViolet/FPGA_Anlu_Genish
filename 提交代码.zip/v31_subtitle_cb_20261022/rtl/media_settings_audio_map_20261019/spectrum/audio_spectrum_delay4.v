`default_nettype none

// Four pixel clocks from input tuple to output tuple, including bypass.
module audio_spectrum_delay4 #(
    parameter FRAME_WIDTH = 1280,
    parameter FRAME_HEIGHT = 720
)(
    input wire clk,
    input wire rst,
    input wire enabled,
    input wire audio_running,
    input wire audio_sample_valid,
    input wire signed [23:0] audio_left_data,
    input wire signed [23:0] audio_right_data,
    input wire [23:0] rgb_in,
    input wire user_in,
    input wire last_in,
    input wire valid_in,
    output reg [23:0] rgb_out,
    output reg user_out,
    output reg last_out,
    output reg valid_out,
    output wire analysis_busy,
    output wire analysis_overrun,
    output wire analysis_update
);
    wire [23:0] spectrum_rgb;
    wire spectrum_user, spectrum_last, spectrum_valid;

    audio_spectrum_axis_overlay #(
        .RUNTIME_MODE(0),
        .FRAME_WIDTH(FRAME_WIDTH),
        .FRAME_HEIGHT(FRAME_HEIGHT)
    ) u_spectrum (
        .clk(clk), .rst(rst), .mode_hd(1'b1),
        .enabled(enabled), .audio_running(audio_running),
        .audio_sample_valid(audio_sample_valid),
        .audio_left_data(audio_left_data), .audio_right_data(audio_right_data),
        .rgb_in(rgb_in), .user_in(user_in), .last_in(last_in), .valid_in(valid_in),
        .rgb_out(spectrum_rgb), .user_out(spectrum_user),
        .last_out(spectrum_last), .valid_out(spectrum_valid),
        .x_out(), .y_out(),
        .analysis_busy(analysis_busy),
        .analysis_overrun(analysis_overrun),
        .analysis_update(analysis_update)
    );

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            rgb_out <= 24'd0;
            user_out <= 1'b0;
            last_out <= 1'b0;
            valid_out <= 1'b0;
        end else begin
            rgb_out <= spectrum_rgb;
            user_out <= spectrum_user;
            last_out <= spectrum_last;
            valid_out <= spectrum_valid;
        end
    end
endmodule

`default_nettype wire
