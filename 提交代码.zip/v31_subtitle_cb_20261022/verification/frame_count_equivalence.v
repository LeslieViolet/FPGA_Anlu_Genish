module frame_count_equivalence(input [31:0] count,words,input take,output same);
 wire [32:0] original_after={1'b0,count}+take;
 wire original_complete=original_after=={1'b0,words};
 wire expected_last=count==words-32'd1;
 wire compact_complete=take?(words!=0&&expected_last):(count==words);
 assign same=original_complete==compact_complete;
endmodule
