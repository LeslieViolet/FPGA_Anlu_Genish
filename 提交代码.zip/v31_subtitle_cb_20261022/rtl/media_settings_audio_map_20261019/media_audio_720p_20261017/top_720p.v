// Production board entry: fixed 1280x720 output.
`default_nettype none
module top_720p (
    input wire clk_50m,
    input wire reset_n,
    input wire key_next_n,
    input wire key_aux_n,
    input wire key_auto_n,
    input wire ir_rx,
    input wire [3:0] switches,
    input wire tf_miso,
    output wire tf_sclk,
    output wire tf_mosi,
    output wire tf_cs_n,
    output wire hdmi_clk_p,
    output wire [2:0] hdmi_data_p,
    output wire hdmi_ddc_scl,
    inout wire hdmi_ddc_sda,
    output wire [3:0] led_status
);
    // Board keys/SW remain physical ports only; no functional consumers.
    video_top_core #(.DIAGNOSTICS(0),.ENABLE_RICH_PICTURE_OSD(0)) u_video_top_core (
        .clk_50m(clk_50m), .reset_n(reset_n),
        .key_next_n(1'b1), .key_aux_n(1'b1),
        .key_auto_n(1'b1), .ir_rx(ir_rx), .switches(4'b0000),
        .tf_miso(tf_miso), .tf_sclk(tf_sclk), .tf_mosi(tf_mosi),
        .tf_cs_n(tf_cs_n), .hdmi_clk_p(hdmi_clk_p),
        .hdmi_data_p(hdmi_data_p), .hdmi_ddc_scl(hdmi_ddc_scl),
        .hdmi_ddc_sda(hdmi_ddc_sda), .led_status(led_status)
    );
endmodule
`default_nettype wire
