module gain_mute (
    input  wire signed [23:0] pcm_in,
    input  wire               pcm_valid_in,
    input  wire               mute,
    input  wire [1:0]         volume,

    output reg signed [23:0]  pcm_out,
    output wire               pcm_valid_out
);

    // 静音只把样本值变为0，不中断后续音频有效节拍。
    assign pcm_valid_out = pcm_valid_in;

    always @(*) begin
        if (!pcm_valid_in || mute) begin
            pcm_out = 24'sd0;
        end
        else begin
            case (volume)
                2'b00: pcm_out = pcm_in >>> 3; // 1/8音量
                2'b01: pcm_out = pcm_in >>> 2; // 1/4音量
                2'b10: pcm_out = pcm_in >>> 1; // 1/2音量
                2'b11: pcm_out = pcm_in;       // 全音量
                default: pcm_out = 24'sd0;
            endcase
        end
    end

endmodule
