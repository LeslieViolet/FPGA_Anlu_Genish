// Part 4: contiguous-file sector loader + Part 3 parser, Verilog-2001.
// One exclusive reader transaction at a time. Same clk/rst for all ports.
`default_nettype none
module tuxiang_jiazai #(
    parameter TRUST_HEADER_OFFSET=0,
    parameter [31:0] IO_TIMEOUT_CYCLES = 32'd200000000
)(
    input wire clk, rst,
    input wire load_valid,
    output wire load_ready,
    input wire descriptor_valid,
    input wire [31:0] asset_lba, asset_length, asset_offset,
    input wire [15:0] asset_index,
    input wire cancel,
    output wire busy,
    output reg reset_required,
    output wire result_valid,
    input wire result_ready,
    output reg [3:0] result_code, // 0 OK,1 descriptor,2 BMP,3 IO,4 protocol,5 timeout,6 cancel
    output wire [15:0] result_index,
    output reg [3:0] reader_error_code,
    output wire frame_valid,
    input wire frame_ready,
    output wire [15:0] frame_width, frame_height, frame_index,
    output wire frame_bottom_up,
    output wire pixel_valid,
    input wire pixel_ready,
    output wire [23:0] pixel_rgb,
    output wire [15:0] pixel_x, pixel_y,
    output wire pixel_last,
    input wire card_ready, reader_busy,
    output wire read_valid,
    input wire read_ready,
    output wire [31:0] read_lba,
    input wire [7:0] data,
    input wire data_valid, data_last,
    output wire data_ready,
    input wire reader_done, reader_error,
    input wire [3:0] read_error_code
);
    localparam [3:0] IDLE=0, START=1, ISSUE=2, RECEIVE=3,
                     CONFIRM=4, WAIT_RESULT=5, CLEAN=6, RESULT=7, LOCKED=8;
    localparam integer TIMEOUT_WIDTH =
        IO_TIMEOUT_CYCLES <= 1 ? 1 : $clog2(IO_TIMEOUT_CYCLES);
    reg [3:0] state;
    reg [31:0] lba_reg, length_reg, offset_reg, remaining;
    reg [TIMEOUT_WIDTH-1:0] timer;
    reg [15:0] index_reg;
    reg [9:0] sector_count;
    reg parser_active;
    wire p_start_ready, p_byte_ready, p_finish_ready, p_result_valid;
    wire [3:0] p_result_code;
    wire p_result_ready = state==CLEAN || state==WAIT_RESULT;
    wire active = state!=IDLE && state!=RESULT && state!=LOCKED;
    wire stopping = cancel || !card_ready || (state==RECEIVE && reader_error);
    wire byte_fire = data_valid && data_ready;
    wire [10:0] received = {1'b0,sector_count} + (byte_fire ? 11'd1 : 11'd0);
    wire bad_sector = (byte_fire && (sector_count>=512 || data_last!=(sector_count==511))) ||
                      (reader_done && received!=512);
    wire timeout = IO_TIMEOUT_CYCLES==0 || timer>=IO_TIMEOUT_CYCLES-1'b1;
    wire [32:0] span = ({1'b0,asset_length}+33'd511)>>9;
    wire [32:0] end_lba = {1'b0,asset_lba}+span;
    // The parser validates width, height and exact pixel extent from the BMP
    // header. This preliminary check cannot assume a fixed 640x480 payload.
    wire desc_ok = descriptor_valid && asset_length>=54 &&
                   (TRUST_HEADER_OFFSET || (asset_offset>=54 && asset_offset<asset_length)) &&
                   end_lba<=33'h100000000;
    // Input valid must not depend on parser ready. Only the handshake advances.
    wire p_byte_valid = state==RECEIVE && !stopping && !p_result_valid &&
                        data_valid && remaining!=0 && sector_count<512;
    assign load_ready = !rst && state==IDLE && !reset_required;
    assign busy = !rst && active;
    assign result_valid = !rst && state==RESULT;
    assign result_index = index_reg;
    assign read_lba = lba_reg;
    assign read_valid = !rst && state==ISSUE && !cancel && card_ready;
    assign data_ready = !rst && ((state==CLEAN || state==LOCKED || (state==RESULT && reset_required)) ||
        (state==RECEIVE && !stopping &&
         (remaining==0 || sector_count>=512 || p_byte_ready)));

    bmp_jiexi #(.TRUST_HEADER_OFFSET(TRUST_HEADER_OFFSET)) u_bmp_jiexi (
        .clk(clk), .rst(rst), .start_valid(state==START && !stopping), .start_ready(p_start_ready),
        .file_length(length_reg), .file_pixel_offset(offset_reg), .file_index(index_reg),
        .byte_data(data), .byte_valid(p_byte_valid), .byte_ready(p_byte_ready),
        .byte_last(remaining==1), .source_error(1'b0),
        .abort(state==CLEAN || state==LOCKED || (active && stopping)),
        .finish_valid(state==CONFIRM && !stopping), .finish_ready(p_finish_ready),
        .frame_valid(frame_valid), .frame_ready(frame_ready),
        .frame_width(frame_width), .frame_height(frame_height),
        .frame_bottom_up(frame_bottom_up), .frame_index(frame_index),
        .pixel_valid(pixel_valid), .pixel_ready(pixel_ready), .pixel_rgb(pixel_rgb),
        .pixel_x(pixel_x), .pixel_y(pixel_y), .pixel_last(pixel_last), .busy(),
        .result_valid(p_result_valid), .result_ready(p_result_ready),
        .result_code(p_result_code), .result_index()
    );

    always @(posedge clk or posedge rst) begin
        if(rst) begin
            state<=IDLE; lba_reg<=0; length_reg<=0; offset_reg<=0;
            remaining<=0; timer<=0; index_reg<=0; sector_count<=0;
            parser_active<=0; reset_required<=0; result_code<=0; reader_error_code<=0;
        end else begin
            if(p_result_valid && p_result_ready) parser_active<=0;
            if(active && state!=CLEAN && stopping) begin
                result_code<=(!card_ready || (state==RECEIVE && reader_error)) ? 4'd3 : 4'd6;
                if(!card_ready || (state==RECEIVE && reader_error)) begin
                    reset_required<=1; reader_error_code<=read_error_code;
                end
                state<=CLEAN; timer<=0;
            end else case(state)
                IDLE: if(load_valid && load_ready) begin
                    lba_reg<=asset_lba; length_reg<=asset_length; offset_reg<=asset_offset;
                    remaining<=asset_length; index_reg<=asset_index;
                    sector_count<=0; timer<=0; result_code<=0; reader_error_code<=0;
                    if(!desc_ok) begin result_code<=1; state<=RESULT; end
                    else state<=START;
                end
                START: if(p_start_ready) begin parser_active<=1; state<=ISSUE; timer<=0; end
                ISSUE: begin
                    if(read_valid && read_ready) begin sector_count<=0; timer<=0; state<=RECEIVE; end
                    else if(timeout) begin result_code<=5; reset_required<=1; state<=CLEAN; timer<=0; end
                    else timer<=timer+1'b1;
                end
                RECEIVE: begin
                    if(bad_sector) begin result_code<=4; reset_required<=1; state<=CLEAN; timer<=0; end
                    else if(p_result_valid) begin result_code<=2; state<=CLEAN; timer<=0; end
                    else begin
                        if(byte_fire) begin
                            sector_count<=sector_count+1'b1;
                            if(remaining!=0) remaining<=remaining-1'b1;
                        end
                        if(reader_done) begin
                            timer<=0;
                            if(remaining==0 || (remaining==1 && byte_fire)) state<=CONFIRM;
                            else begin lba_reg<=lba_reg+1'b1; state<=ISSUE; end
                        end else if(byte_fire || !data_ready) timer<=0;
                        else if(timeout) begin result_code<=5; reset_required<=1; state<=CLEAN; timer<=0; end
                        else timer<=timer+1'b1;
                    end
                end
                CONFIRM: begin
                    if(p_result_valid) begin result_code<=2; state<=CLEAN; timer<=0; end
                    else if(p_finish_ready) state<=WAIT_RESULT;
                end
                WAIT_RESULT: if(p_result_valid) begin
                    result_code<=p_result_code==0 ? 4'd0 : 4'd2;
                    state<=RESULT;
                end
                CLEAN: begin
                    // Drain the current physical sector before allowing another task.
                    // A wedged reader must never be reassigned; it requires common reset.
                    if(!reader_busy && !parser_active) state<=RESULT;
                    else if(byte_fire || (p_result_valid && p_result_ready)) timer<=0;
                    else if(timeout) begin
                        reset_required<=1; result_code<=5; state<=RESULT;
                    end else timer<=timer+1'b1;
                end
                RESULT: if(result_ready) state<=reset_required ? LOCKED : IDLE;
                LOCKED: state<=LOCKED;
                default: begin reset_required<=1; result_code<=4; state<=CLEAN; timer<=0; end
            endcase
        end
    end
endmodule
`default_nettype wire
