# 透明居中字幕 C+B 板测版本

本版将上一版顶部字幕改为透明背景、顶部居中、短句滚入与滚出，暖白文字配金色折扣、珊瑚色赠送文案及深色细描边。三句循环，居中停留约1.98秒。字幕只覆盖笔画和轮廓，画面其余区域保留；不访问TF，不增加帧缓存。

## 使用文件

- 位流：D:/FPGA/deliverables/v31_subtitle_cb_20261022/bit/v31_subtitle_cb_20261022.bit
- TD工程：D:/FPGA/deliverables/v31_subtitle_cb_20261022/project/media_audio_720p_20261017.al
- 源码：D:/FPGA/deliverables/v31_subtitle_cb_20261022/rtl/media_settings_audio_map_20261019/media_audio_720p_20261017
- 工程记录：D:/FPGA/deliverables/v31_subtitle_cb_20261022/工程记录_透明居中字幕_CB_20261022.docx

BitWriter下载到PROGRAM_SRAM，进入幻灯片即可显示。设置→显示→字幕沿用原开关，默认开。打开设置隐藏并暂停，关闭后恢复；状态栏开关不改变字幕位置，底部频谱保留。无需向TF卡新增字幕文件。

三句为“夏日清凉好滋味”“全场9.5折，买一送一”“欢迎光临，清凉一夏”。目前文案固定；修改文案或字形需要重新生成字库并重建位流。

三首配乐规则仍为0静音、1/2/3对应MEDIA/BGM1.WAV、BGM2.WAV、BGM3.WAV。保持标准44字节WAV头、48kHz、16bit有符号PCM，单声道或双声道。图片目录、8.3短文件名、720p、自适应缩放、转场和音频策略沿用上版。

## 修改与接口

原有4份RTL修改：promo_marquee_renderer.v负责三句运动与描述符；ui_media_compositor.v只在文字/轮廓处覆盖；transition_fade.v将限幅后的5bit乘法等价改成4bit乘法加满亮直通；bc_frame_fetch_for_video_pipe.v仅等价改写完成谓词，复用末像素比较，消除计数加法串行路径。新增promo_subtitle_font_rom.v，512×32bit同步ROM，低16bit笔画、高16bit轮廓。102份其他RTL与上次交付逐字节相同。

字幕窗口x320..959、y24..55；中心x640。每有效SOF移动4像素，居中保持120帧。16×16字模放大2倍，轮廓在生成时预计算。三句字符基址0/7/18，ROM地址9bit，高5bit为全局字符号，低4bit为行。96bit UI快照保留位77继续控制字幕，只在PLAYER状态显示，没有新增CDC、物理端口或时钟域。RGB/SOF/EOL/valid仍同延迟4拍。

## 本轮检查结果

5组定向仿真通过：512个ROM地址独立轮廓检查；1450帧运动/暂停/循环检查；4608000像素比较（4760笔画、8952轮廓、4594288原画面像素）；8192组渐变输入、24576次通道比较；帧读取24005周期294次事务的全部输出与原模块一致，含104次末像素与完成同时到达、77次取消。

Z3 5.3.1形式证明覆盖计数32bit、目标32bit、取数1bit的全部组合，包括零目标和32bit溢出边界，结果UNSAT。只证明完成谓词的组合等价，不将其称为整个HDMI系统的形式签核。原状态机、FIFO、帧租约、握手及错误周期保持。

实际TD读取101份生效RTL，TOP=top_720p，器件EG4S20BG256。布局seed=1，策略=v4_area_routable。最终LUT=15784/19600、REG=10111/19600、BRAM9K=56/64、BRAM32K=2/16、DSP=10/29、PLL=2/4。

最终原时钟约束下：SWNS: 0.263ns, STNS: 0.000ns. HWNS: 0.027ns, HTNS: 0.000ns. STA覆盖率99.98%，无效约束0，路由DRC及复位SR审计通过，6条释放链D/Q连接保留setup/hold检查。原ADC/SDC保持；没有新增功能路径时序例外。原PLL反馈补偿警告仍在。

位流638941字节，SHA256：8530037219bd82e6197a464ad72f67166f4ea0acf301c84a6dfe8f1bff4d537b。新版尚未上板；原正常工程和位流未覆盖。

## 实际命令与证据

工作区实际执行器：C:/Users/ChengCheng/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe

工作区脚本根目录：D:/FPGA/work/verification/v31_subtitle_cb_20261022

实际执行：run_checks.py font、run_checks.py motion、run_pixels.py --fast、run_fade.py、run_formal.py、run_frame_equiv.py、audit.py；本次所选实现为build_physical.py 1 build v4_area_routable和build_physical.py 1 signoff v4_area_routable。所有编译和仿真工具均正常退出0；具体Icarus、Verilator、LLVM及TD完整参数保存于evidence的command.json和Tcl中。

TD程序：D:/FPGA/anlu/bin/td_commands_prompt.exe。evidence保存所选构建/签核脚本、日志、物理资源、时序、复位审计和输入哈希。早期失败版不包含新交付bit；失败日志仍在D:/FPGA/work/sim/v31_subtitle_cb_20261022各physical目录。

资料依据：work/docs/ARCHITECTURE.md、INTERFACE_CONTRACT.md、BOARD_PIN_MAP.md、SIMULATION_FLOW.md、SUBTITLE_CB_SPEC_20261022.md，原ADC/SDC与fpga_board.al、上次真实交付源码/工程/验收，以及安路SWUG105_TCL_Command_User_Guide.pdf中的实现参数。

## 复核与重建

先核对交付文件，不重新计算资源：

    python D:/FPGA/deliverables/v31_subtitle_cb_20261022/verification/check_release.py

列出验证文件路径：

    python D:/FPGA/deliverables/v31_subtitle_cb_20261022/verification/run_release_simulations.py --list

重新运行仿真时可传入--iverilog及--vvp的完整路径。该便携入口使用Icarus；本轮完整像素比较实际使用Verilator/LLVM，相关生成、编译、执行日志保留。两者测试文件相同。

完整TD重建：

    powershell -NoProfile -ExecutionPolicy Bypass -File D:/FPGA/deliverables/v31_subtitle_cb_20261022/verification/rebuild.ps1

AL用于查看、编辑源码。重建脚本包括原约束、已审计复位入口、实现阶段附加建立目标及独立进程恢复原约束后的签核；本轮没有在交付解压目录重复跑整套实现。改变源码、路径或策略后应重新检查最终资源与时序，不能沿用旧报告。

## 上板验收

检查三句的字体、透明背景、居中停留、滚出和循环。分别开关字幕与状态栏，打开/关闭设置后检查位置、隐藏和续播。连续正反切图，检查原缩放及全部转场，试听三首WAV及设置暂停后原位置继续、底部频谱。通过这些板测前，release_status.json中的board_verified保持false。
