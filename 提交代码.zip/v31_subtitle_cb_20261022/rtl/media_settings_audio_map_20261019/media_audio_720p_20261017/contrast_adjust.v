`default_nettype none
// Contrast level: 0..100. 0 collapses to mid-gray, 50 is neutral and
// 100 is approximately 2x contrast about RGB value 128.
module contrast_adjust (
    input  wire [23:0] rgb_in,
    input  wire [6:0]  level,
    output wire [23:0] rgb_out
);
    function [7:0] scale_q6;
        input [6:0] requested_level;
        reg [7:0] bounded_level;
        begin
            bounded_level = requested_level > 7'd100 ? 8'd100 :
                            {1'b0,requested_level};
            // Low-cost approximation of level*128/100. Exact at 0, 50, 100.
            if (bounded_level == 8'd50)
                scale_q6 = 8'd64;
            else
                scale_q6 = bounded_level + (bounded_level >> 2) +
                           (bounded_level >> 5);
        end
    endfunction

    function [7:0] adjust;
        input [7:0] channel;
        input [6:0] requested_level;
        reg signed [9:0] deviation;
        reg signed [17:0] product;
        reg signed [18:0] value;
        reg [7:0] factor;
        begin
            factor = scale_q6(requested_level);
            deviation = $signed({1'b0,channel}) - 10'sd128;
            product = deviation * $signed({1'b0,factor});
            value = 19'sd128 + (product >>> 6);
            if (value < 0)
                adjust = 8'd0;
            else if (value > 19'sd255)
                adjust = 8'hff;
            else
                adjust = value[7:0];
        end
    endfunction

    assign rgb_out = {adjust(rgb_in[23:16],level),
                      adjust(rgb_in[15:8],level),
                      adjust(rgb_in[7:0],level)};
endmodule
`default_nettype wire
