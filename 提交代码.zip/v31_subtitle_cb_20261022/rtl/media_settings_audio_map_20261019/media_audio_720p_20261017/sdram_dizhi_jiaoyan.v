// Passive first-frame native read address/ownership check. No functional gates.
`timescale 1ns/1ps
`default_nettype none
module sdram_dizhi_jiaoyan #(
    parameter FRAME_WORDS=307200)(
    input wire clk,rst,write_take,read_take,
    input wire [20:0] write_addr,read_addr,
    output wire [3:0] flags
);
wire [20:0] frame_words=FRAME_WORDS;
    reg write_seen,written_slot,started,complete,bad,match_ok;
    reg [19:0] count;
    wire [20:0] expected_addr=count+(written_slot ? frame_words : 0);
    wire wrong=!write_seen || read_addr!=expected_addr;
    assign flags={bad,match_ok,complete,started};
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            write_seen<=0;written_slot<=0;started<=0;complete<=0;
            bad<=0;match_ok<=0;count<=0;
        end else begin
            if(write_take && !write_seen) begin
                write_seen<=1;written_slot<=write_addr>=frame_words;
            end
            if(read_take && !complete) begin
                started<=1;
                if(wrong) bad<=1;
                if(count==frame_words-1) begin
                    complete<=1;match_ok<=!bad && !wrong;
                end else count<=count+1'b1;
            end
        end
    end
endmodule
`default_nettype wire
