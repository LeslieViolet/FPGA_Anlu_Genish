`default_nettype none
// Internal audio integration stage. The external owner supplies one CRC-checked
// SD completion per provisional sector and owns the single physical TF reader.
module audio_slideshow_core #(
 parameter integer PIXEL_HZ=25000000,
 parameter integer FIFO_ADDR_WIDTH=10,
 parameter integer PREFILL_SAMPLES=768,
 parameter integer BYTE_TIMEOUT_CYCLES=250000000
)(
 input wire source_clk,pixel_clk,rst,abort,
 input wire open_valid,output wire open_ready,input wire [31:0] file_length,
 input wire sector_start_valid,output wire sector_start_ready,
 input wire [9:0] sector_valid_bytes,input wire sector_file_last,
 input wire provisional_valid,output wire provisional_ready,
 input wire [7:0] provisional_data,input wire provisional_last,
 input wire sector_finish_valid,sector_finish_ok,
 input wire play_enable,mute,input wire [3:0] volume_level,
 input wire visualizer_enable,settings_visible,video_active,
 input wire [9:0] ui_x,ui_y,input wire [23:0] ui_pixel_in,
 output wire [23:0] ui_pixel_out,
 output wire audio_valid,output wire [23:0] audio_left_data,audio_right_data,
 output wire acr_valid,output wire [19:0] acr_cts,acr_n,
 output wire meter_valid,output wire [3:0] level_left,level_right,
 output wire [31:0] underflow_count,output wire track_end,
 output wire file_parsed,output reg fault,output reg [3:0] fault_code,
 output wire [FIFO_ADDR_WIDTH:0] buffered_samples,buffered_source
);
 wire byte_valid,byte_ready,byte_last,sector_done,sector_error;
 wire [7:0] byte_data;
 wire [2:0] sector_error_code;
 wire sample_valid,sample_ready,sample_last,wav_error,wav_opened;
 wire signed [15:0] sample_left,sample_right;
 wire [3:0] wav_error_code;
 wire internal_abort=abort||fault||sector_error;
 wire fifo_overflow;
 // rst is used by source-domain logic. ACR owns an independent pixel-domain
 // synchronous release, even when source and pixel derive from one PLL.
 (* async_reg="true" *) reg [2:0] acr_reset_release;
 always @(posedge pixel_clk or posedge rst)
  if(rst)acr_reset_release<=3'b111;
  else acr_reset_release<={acr_reset_release[1:0],1'b0};
 // Source-domain terminal errors stop this session. Controller must issue abort
 // before restarting; no failed bytes or stale PCM survive into the next song.
 always @(posedge source_clk or posedge rst)begin
  if(rst)begin fault<=0;fault_code<=0;end
  else if(abort)begin fault<=0;fault_code<=0;end
  else if(!fault)begin
   if(sector_error)begin fault<=1;fault_code<={1'b0,sector_error_code};end
   else if(wav_error)begin fault<=1;fault_code<={1'b1,wav_error_code[2:0]};end
   else if(fifo_overflow)begin fault<=1;fault_code<=4'd15;end
  end
 end
 audio_crc_sector_buffer u_sector(
  .clk(source_clk),.rst(rst),.abort(internal_abort),
  .start_valid(sector_start_valid&&!fault),.start_ready(sector_start_ready),
  .valid_bytes(sector_valid_bytes),.file_last(sector_file_last),
  .provisional_valid(provisional_valid),.provisional_ready(provisional_ready),
  .provisional_data(provisional_data),.provisional_last(provisional_last),
  .finish_valid(sector_finish_valid),.finish_ok(sector_finish_ok),
  .byte_valid(byte_valid),.byte_ready(byte_ready),.byte_data(byte_data),.byte_last(byte_last),
  .done(sector_done),.error(sector_error),.error_code(sector_error_code));
 audio_wav_stream #(.BYTE_TIMEOUT_CYCLES(BYTE_TIMEOUT_CYCLES)) u_wav(
  .clk(source_clk),.rst(rst),.abort(internal_abort),
  .open_valid(open_valid&&!fault),.open_ready(open_ready),.file_length(file_length),
  .byte_valid(byte_valid),.byte_ready(byte_ready),.byte_data(byte_data),.byte_last(byte_last),
  .sample_valid(sample_valid),.sample_ready(sample_ready),
  .pcm_left(sample_left),.pcm_right(sample_right),.sample_last(sample_last),
  .opened(wav_opened),.done(file_parsed),.error(wav_error),.error_code(wav_error_code),
  .sample_count(),.stereo());
 audio_pcm_output #(.PIXEL_HZ(PIXEL_HZ),.FIFO_ADDR_WIDTH(FIFO_ADDR_WIDTH),
  .PREFILL_SAMPLES(PREFILL_SAMPLES)) u_pcm(
  .source_clk(source_clk),.pixel_clk(pixel_clk),.rst(rst),.session_reset(internal_abort||wav_error),
  .sample_valid(sample_valid),.sample_ready(sample_ready),
  .sample_left(sample_left),.sample_right(sample_right),.sample_last(sample_last),
  .play_enable(play_enable),.mute(mute),.volume_level(volume_level),
  .audio_valid(audio_valid),.audio_left_data(audio_left_data),.audio_right_data(audio_right_data),
  .track_end(track_end),.underflow_count(underflow_count),
  .meter_valid(meter_valid),.level_left(level_left),.level_right(level_right),
  .peak_left(),.peak_right(),.fifo_overflow(fifo_overflow),
  .buffered_samples(buffered_samples),.buffered_source(buffered_source));
 audio_acr u_acr(.clk(pixel_clk),.rst(acr_reset_release[2]),.audio_valid(audio_valid),
  .acr_valid(acr_valid),.acr_cts(acr_cts),.acr_n(acr_n));
 audio_level_overlay u_visualizer(.enabled(visualizer_enable&&settings_visible),
  .video_active(video_active),.x(ui_x),.y(ui_y),
  .level_left(level_left),.level_right(level_right),
  .pixel_in(ui_pixel_in),.pixel_out(ui_pixel_out));
endmodule
`default_nettype wire
