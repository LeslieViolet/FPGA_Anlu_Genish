// B's storage path feeds C video_pipe through a prefetched frame_rgb adapter.
// The timing/source/AXIS leaf modules retain their original interfaces.
`default_nettype none
module av_output_subsystem #(parameter DIAGNOSTICS=1,
    parameter ENABLE_RICH_PICTURE_OSD=1,
    parameter FRAME_WIDTH = 1280,
    parameter FRAME_HEIGHT = 720,
    parameter H_FRONT = 110,
    parameter H_SYNC = 40,
    parameter H_BACK = 220,
    parameter V_FRONT = 5,
    parameter V_SYNC = 5,
    parameter V_BACK = 20,
    parameter VIDEO_VIC = 4
)(
    output wire frame_boundary,
    input wire [95:0] ui_status_payload_pixel,
    input wire ui_status_valid_pixel,
    input wire media_catalog_done,
    input wire [4:0] media_asset_count,
    input wire key_aux_n,
    input wire [3:0] switches,
    input wire ext_audio_enable,
    input wire ext_audio_valid,
    input wire [23:0] ext_audio_left,
    input wire [23:0] ext_audio_right,
    input wire ext_acr_valid,
    input wire [19:0] ext_acr_cts, ext_acr_n,
    input wire ext_meter_valid,
    input wire [3:0] ext_level_left, ext_level_right,
    input wire ext_visualizer_enable,
    output wire hdmi_clk_p,
    output wire [2:0] hdmi_data_p,
    output wire hdmi_ddc_scl,
    inout wire hdmi_ddc_sda,
    input wire clk_sys,
    input wire clk_pixel,
    input wire clk_hdmi_serial,
    input wire rst_sys,
    input wire rst_pixel,
    input wire rst_hdmi_serial,
    input wire frame_ready,
    output wire disp_req,
    input wire disp_ack,
    output wire disp_keep_old,
    input wire disp_valid,
    input wire disp_buffer_sel,
    input wire [15:0] disp_width,
    input wire [15:0] disp_height,
    input wire [15:0] disp_index,
    input wire [31:0] disp_generation,
    input wire disp_previous_valid,
    input wire disp_previous_sel,
    output wire disp_previous_release_req,
    input wire disp_previous_release_ack,
    output wire read_req,
    input wire read_ack,
    output wire read_buffer_sel,
    output wire [31:0] read_start_addr,
    output wire [31:0] read_length,
    input wire read_pixel_valid,
    output wire read_pixel_ready,
    input wire [23:0] read_pixel_data,
    input wire read_pixel_last,
    input wire read_done,
    output wire read_done_ready,
    input wire [3:0] read_status,
    output wire read_cancel_req,
    input wire read_cancel_ack,
    output wire output_fault,
    output wire [3:0] display_progress,
    output wire [15:0] output_diag,
    output wire [3:0] axis_crc_diag
);
wire        axis_s_user;
wire        axis_s_valid;
wire        axis_s_last;
wire [23:0] axis_s_data;
wire [23:0] axis_tx_data;
wire axis_tx_user,axis_tx_last,axis_tx_valid;
wire [23:0] axis_ui_data;
wire axis_ui_user,axis_ui_last,axis_ui_valid;
wire [10:0] axis_x,axis_y;
wire [11:0] active_htotal=FRAME_WIDTH+H_FRONT+H_SYNC+H_BACK;
assign frame_boundary=h_count==active_htotal-1'b1 && v_count==active_vtotal-1'b1;
wire [11:0] active_vtotal=FRAME_HEIGHT+V_FRONT+V_SYNC+V_BACK;
wire [10:0] h_count;
wire [10:0] v_count;
reg [95:0] ui_pending,ui_frame;
reg ui_mode_frame;
wire ui_active=ui_mode_frame;
always @(posedge clk_pixel or posedge rst_pixel) begin
 if(rst_pixel) begin ui_pending<=0;ui_frame<=0;ui_mode_frame<=0;end
 else begin
  if(ui_status_valid_pixel)ui_pending<=ui_status_payload_pixel;
  if(h_count==active_htotal-1 && v_count==active_vtotal-1)begin ui_frame<=ui_pending;ui_mode_frame<=1'b1;end
 end
end
// UI settings arrive atomically through the mailbox and are applied between
// frames. The fetch adapter then latches this choice for the whole transition.
wire [1:0] requested_transition_style = ui_active ? ui_frame[7:6] : 2'b00;
wire [23:0] frame_rgb;
wire        fetched_frame_active;
wire        fetch_fault;
wire [4:0]  transition_fade_level;
wire [1:0]  transition_style_active;
// B's asset count becomes stable before catalog_done rises. Synchronize that
// completion level, then capture the held five-bit payload in clk_pixel.
(* async_reg = "true" *) reg [1:0] catalog_done_sync;
reg [4:0] catalog_count_pixel;
reg catalog_count_valid;
always @(posedge clk_pixel or posedge rst_pixel) begin
    if (rst_pixel) begin
        catalog_done_sync <= 2'b00;
        catalog_count_pixel <= 5'd0;
        catalog_count_valid <= 1'b0;
    end else begin
        catalog_done_sync <= {catalog_done_sync[0],media_catalog_done};
        if (!catalog_done_sync[1]) begin
            catalog_count_pixel <= 5'd0;
            catalog_count_valid <= 1'b0;
        end else if (!catalog_count_valid) begin
            catalog_count_pixel <= media_asset_count;
            catalog_count_valid <= 1'b1;
        end
    end
end

// This slideshow trial uses only the selected WAV stream. Its volume and mute
// settings are applied in audio_pcm_output before these pixel-domain ports.
wire hdmi_audio_valid = ext_audio_enable && ext_audio_valid;
wire [23:0] hdmi_audio_left_data = ext_audio_left;
wire [23:0] hdmi_audio_right_data = ext_audio_right;
wire hdmi_acr_valid = ext_audio_enable && ext_acr_valid;
wire [19:0] hdmi_acr_cts = ext_acr_cts;
wire [19:0] hdmi_acr_n = ext_acr_n;
// HDMI TX握手信号
wire axis_s_ready;

// HDMI TX输出的4路10位TMDS并行数据
wire [9:0] tmds_ch0_data;
wire [9:0] tmds_ch1_data;
wire [9:0] tmds_ch2_data;
wire [9:0] tmds_clk_data;

// 暂时不用的状态输出
wire       hdmi_video_locked;
// Safety fault detection remains; selectable statistics are removed.
wire [3:0] bc_flow_status;
reg axis_backpressure_fault;
assign axis_crc_diag=4'd0;
assign output_diag=16'd0;
assign display_progress={hdmi_video_locked,3'b000};
wire       edid_read_valid;
wire [7:0] edid_read_data;

assign disp_keep_old = 1'b0;
assign disp_previous_release_req = 1'b0;

// B transaction/FIFO front end.  It supplies frame_rgb for the coordinates
// generated by the original C video_pipe.
bc_frame_fetch_for_video_pipe #(.FRAME_WIDTH(FRAME_WIDTH),
    .FRAME_HEIGHT(FRAME_HEIGHT), .FRAME_HTOTAL(FRAME_WIDTH+H_FRONT+H_SYNC+H_BACK),
    .FRAME_VTOTAL(FRAME_HEIGHT+V_FRONT+V_SYNC+V_BACK),
    .PREFILL_TIMEOUT(FRAME_WIDTH > 640 ? 3750000 : 1250000)) u_bc_frame_fetch_for_video_pipe (
    
    .clk(clk_pixel), .rst(rst_pixel | !catalog_done_sync[1]),
    .h_count(h_count), .v_count(v_count),
    .frame_rgb(frame_rgb), .frame_active(fetched_frame_active),
    .fade_level(transition_fade_level),
    .requested_transition_style(requested_transition_style),
    .active_transition_style(transition_style_active),
    .frame_ready(frame_ready),
    .disp_req(disp_req), .disp_ack(disp_ack), .disp_valid(disp_valid),
    .disp_buffer_sel(disp_buffer_sel), .disp_width(disp_width),
    .disp_height(disp_height), .read_req(read_req), .read_ack(read_ack),
    .read_buffer_sel(read_buffer_sel), .read_start_addr(read_start_addr),
    .read_length(read_length), .read_pixel_valid(read_pixel_valid),
    .read_pixel_ready(read_pixel_ready), .read_pixel_data(read_pixel_data),
    .read_pixel_last(read_pixel_last), .read_done(read_done),
    .read_done_ready(read_done_ready), .read_status(read_status),
    .read_cancel_req(read_cancel_req), .read_cancel_ack(read_cancel_ack),
    .output_fault(fetch_fault), .flow_status(bc_flow_status)
);

// Media-only scan pipeline; original pixel/coordinate/DE latency is retained.
video_pipe #(.FRAME_WIDTH(FRAME_WIDTH), .FRAME_HEIGHT(FRAME_HEIGHT),
    .H_FRONT(H_FRONT), .H_SYNC(H_SYNC), .H_BACK(H_BACK),
    .V_FRONT(V_FRONT), .V_SYNC(V_SYNC), .V_BACK(V_BACK),
    .PIPELINED(FRAME_WIDTH > 640)) u_video_pipe (
    
    .clk(clk_pixel),
    .rst(rst_pixel),
    .frame_rgb(frame_rgb),
    .fade_level(ui_active ? transition_fade_level : 5'd16),
    .transition_style(transition_style_active),
    .h_count(h_count),
    .v_count(v_count),
    .axis_user(axis_s_user),
    .axis_valid(axis_s_valid),
    .axis_last(axis_s_last),
    .axis_x_out(axis_x),.axis_y_out(axis_y),
    .axis_data(axis_s_data)
);

ui_media_compositor #(.FRAME_WIDTH(FRAME_WIDTH),.FRAME_HEIGHT(FRAME_HEIGHT)) u_ui_display (
    
 .clk_pixel(clk_pixel),.rst_pixel(rst_pixel),.enabled(ui_active),.ui_status_payload_pixel(ui_frame),
 .bgm_visualizer_enable(ext_visualizer_enable),
 .bgm_level_left(ext_level_left),.bgm_level_right(ext_level_right),
 .x(axis_x),.y(axis_y),.rgb_in(axis_s_data),.user_in(axis_s_user),.last_in(axis_s_last),.valid_in(axis_s_valid),
 .wallpaper_valid(disp_valid && disp_index==0 && fetched_frame_active),
 .axis_tx_user(axis_ui_user),.axis_tx_last(axis_ui_last),.axis_tx_valid(axis_ui_valid),.axis_tx_data(axis_ui_data));

generate if (ENABLE_RICH_PICTURE_OSD) begin : g_rich_picture_osd
    // Coordinates follow the same delayed SOF/EOL as RGB.
    wire [10:0] osd_axis_x,osd_axis_y;
    wire [23:0] uptime_bcd_pixel;
    wire picture_overlay_show=disp_valid && catalog_done_sync[1] &&
        ui_active && ui_frame[63:60]==4'd2 && ui_frame[56:55]!=2'd2 && ui_frame[15];
    axis_osd_coordinates #(.FRAME_WIDTH(FRAME_WIDTH),
        .FRAME_HEIGHT(FRAME_HEIGHT)) u_osd_coordinates (
        .clk(clk_pixel),.rst(rst_pixel),
        .user_in(axis_ui_user),.last_in(axis_ui_last),.valid_in(axis_ui_valid),
        .x(osd_axis_x),.y(osd_axis_y));
    osd_uptime u_osd_uptime (.clk_sys(clk_sys),.rst_sys(rst_sys),
        .clk_pixel(clk_pixel),.rst_pixel(rst_pixel),.time_bcd_pixel(uptime_bcd_pixel));
    rich_picture_osd #(.FRAME_WIDTH(FRAME_WIDTH),
        .FRAME_HEIGHT(FRAME_HEIGHT)) u_rich_picture_osd (
        .clk(clk_pixel),.rst(rst_pixel),.enabled(picture_overlay_show),
        .x(osd_axis_x),.y(osd_axis_y),.time_bcd(uptime_bcd_pixel),
        .user_in(axis_ui_user),.last_in(axis_ui_last),.valid_in(axis_ui_valid),.rgb_in(axis_ui_data),
        .user_out(axis_tx_user),.last_out(axis_tx_last),.valid_out(axis_tx_valid),.rgb_out(axis_tx_data));
end else begin : g_no_rich_picture_osd
    wire spectrum_show = ui_frame[14] &&  ui_active && ui_frame[63:60] == 4'd2 &&
        ui_frame[56:55] == 2'd1 && ext_audio_enable &&
        !ui_frame[16] && ui_frame[20:17] != 4'd0;
    audio_spectrum_delay4 #(.FRAME_WIDTH(FRAME_WIDTH),
        .FRAME_HEIGHT(FRAME_HEIGHT)) u_audio_spectrum (
        .clk(clk_pixel),.rst(rst_pixel),
        .enabled(spectrum_show),.audio_running(ext_audio_enable),
        .audio_sample_valid(hdmi_audio_valid),
        .audio_left_data(hdmi_audio_left_data),
        .audio_right_data(hdmi_audio_right_data),
        .user_in(axis_ui_user),.last_in(axis_ui_last),.valid_in(axis_ui_valid),.rgb_in(axis_ui_data),
        .user_out(axis_tx_user),.last_out(axis_tx_last),.valid_out(axis_tx_valid),.rgb_out(axis_tx_data),
        .analysis_busy(),.analysis_overrun(),.analysis_update());
end endgenerate

// video_pipe is a fixed-rate source and cannot be stalled.  The official TX
// is expected to keep READY high through each active line; latch a fault if it
// violates that requirement so a lost pixel cannot pass silently.
always @(posedge clk_pixel or posedge rst_pixel) begin
    if (rst_pixel)
        axis_backpressure_fault <= 1'b0;
    else if (axis_tx_valid && !axis_s_ready)
        axis_backpressure_fault <= 1'b1;
end
assign output_fault = fetch_fault | axis_backpressure_fault;

hdmi_resolution_tx #(
    .DEVICE            ("EG"),

    .HTOTAL            (FRAME_WIDTH+H_FRONT+H_SYNC+H_BACK),
    .HSA               (H_SYNC),
    .HFP               (H_FRONT),
    .HBP               (H_BACK),
    .HACTIVE           (FRAME_WIDTH),

    .VTOTAL            (FRAME_HEIGHT+V_FRONT+V_SYNC+V_BACK),
    .VSA               (V_SYNC),
    .VFP               (V_FRONT),
    .VBP               (V_BACK),
    .VACTIVE           (FRAME_HEIGHT),

    .VIDEO_VIC         (VIDEO_VIC),
    .VIDEO_TPG         ("Disable"),
    .VIDEO_FORMAT      ("RGB"),

    // 保留交接版的 48 kHz 音频配置
    .AUDIO_SAMPLE_RATE ("48K"),
    .IIC_SCL_DIV       (250)
) u_hdmi_tx (
    
    // 时钟和复位
    .I_pixel_clk        (clk_pixel),
    .I_rst              (rst_pixel),

    // EDID读取暂时不触发
    .I_edid_read_trig   (1'b0),
    .O_edid_read_valid  (edid_read_valid),
    .O_edid_read_data   (edid_read_data),

    // 接收原始 video_pipe 的固定速率视频流
    .I_axis_s_user      (axis_tx_user),
    .I_axis_s_valid     (axis_tx_valid),
    .I_axis_s_last      (axis_tx_last),
    .I_axis_s_data      (axis_tx_data),
    .O_axis_s_ready     (axis_s_ready),

    // 48 kHz、双声道、24位PCM
    .I_audio_valid      (hdmi_audio_valid),
    .I_audio_left_data  (hdmi_audio_left_data),
    .I_audio_right_data (hdmi_audio_right_data),
    .I_acr_valid        (hdmi_acr_valid),
    .I_acr_cts          (hdmi_acr_cts),
    .I_acr_n            (hdmi_acr_n),

    // HDMI状态与DDC接口
    .O_video_locked     (hdmi_video_locked),
    .O_ddc_scl          (hdmi_ddc_scl),
    .IO_ddc_sda         (hdmi_ddc_sda),

    // 输出4路TMDS并行数据
    .O_ch0_tmds_data    (tmds_ch0_data),
    .O_ch1_tmds_data    (tmds_ch1_data),
    .O_ch2_tmds_data    (tmds_ch2_data),
    .O_clk_tmds_data    (tmds_clk_data)
);

hdmi_phy_wrapper #(
    .DEVICE ("EG")
) u_hdmi_phy (
    
    // 25 MHz像素时钟
    .I_pixel_clk        (clk_pixel),

    // 125 MHz串行时钟
    .I_serial_clk       (clk_hdmi_serial),

    // 高电平复位
    .I_rst              (rst_pixel),
    .I_serial_rst       (rst_hdmi_serial),

    // HDMI TX输出的TMDS数据
    .I_tmds_channel_0   (tmds_ch0_data),
    .I_tmds_channel_1   (tmds_ch1_data),
    .I_tmds_channel_2   (tmds_ch2_data),
    .I_tmds_channel_clk (tmds_clk_data),

    // 连接板子的HDMI输出
    .O_tmds_ch0_p       (hdmi_data_p[0]),
    .O_tmds_ch1_p       (hdmi_data_p[1]),
    .O_tmds_ch2_p       (hdmi_data_p[2]),
    .O_tmds_clk_p       (hdmi_clk_p)
);
endmodule
`default_nettype wire

