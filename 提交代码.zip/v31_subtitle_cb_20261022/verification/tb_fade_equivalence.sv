`timescale 1ns/1ps
module tb_fade_equivalence;
 reg [23:0] rgb_in=0;reg [4:0] level=0;
 wire [23:0] rgb_out,reference_rgb;
 transition_fade dut(.*);
 baseline_transition_fade reference(.rgb_in(rgb_in),.level(level),.rgb_out(reference_rgb));
 integer l,c,k,checks=0,safe_value;
 initial begin
  for(l=0;l<32;l=l+1)for(c=0;c<256;c=c+1)begin
   level=l;rgb_in={8'(c),8'(255-c),8'((c*73+11)%256)};#1;
   if(rgb_out!==reference_rgb)$fatal(1,"fade differs level=%0d rgb=%h got=%h want=%h",l,rgb_in,rgb_out,reference_rgb);
   safe_value=l>16?16:l;
   for(k=0;k<3;k=k+1)
    if(rgb_out[k*8+:8]!==8'((rgb_in[k*8+:8]*safe_value)/16))$fatal(1,"arithmetic mismatch");
   checks=checks+1;
  end
  $display("FADE_EQUIVALENCE_PASS vectors=%0d channels=24576 levels=32 values=256",checks);$finish;
 end
endmodule
