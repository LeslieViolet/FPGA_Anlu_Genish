`default_nettype none

// HX1838 input boundary: synchronize the asynchronous receiver output,
// measure NEC pulse widths, decode a validated frame, then map its command.
module ir_input_subsystem #(
    parameter integer T_LEAD_LOW    = 450_000,
    parameter integer T_LEAD_HIGH   = 225_000,
    parameter integer T_REPEAT_HIGH = 112_500,
    parameter integer T_BIT_LOW     = 28_000,
    parameter integer T_ZERO_HIGH   = 28_000,
    parameter integer T_ONE_HIGH    = 84_500,
    parameter integer TOL_PCT       = 20  // 依据17份实测波形采用±20%脉宽容差
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       ir_rx_async,
    output wire       ir_rx_sync_level,
    output wire       ir_event_valid,
    output wire [3:0] ir_event_code,
    output wire       ir_event_repeat,
    output wire       ir_digit_valid,
    output wire [3:0] ir_digit_code,
    output wire       ir_fault,
    output wire       debug_event_valid,
    output wire [7:0] debug_command,
    output wire       debug_fault,
    output wire       debug_edge_valid
);
    wire pulse_valid;
    wire pulse_level;
    wire level_now;
    wire [19:0] pulse_ticks;
    wire pulse_overflow;
    wire dec_event_valid;
    wire [7:0] dec_command;
    wire dec_repeat;
    wire dec_error;
    wire key_valid;
    wire [4:0] key_code;
    wire key_repeat;
    wire key_is_digit;
    wire repeat_allowed;
    wire [4:0] digit_index;

    // ir_keymap对17个物理键统一编号：0=无键，1..7=功能键，8..17=数字0..9。
    // 当前上层仍使用功能键和数字键两路接口，在此处转换；6=*（返回），7=#（设置）。
    localparam [4:0] KEY_DIGIT_0 = 5'd8;
    localparam [4:0] KEY_DIGIT_9 = 5'd17;
    localparam [4:0] KEY_LEFT    = 5'd3;
    localparam [4:0] KEY_RIGHT   = 5'd4;

    nec_pulse_measure u_measure (
        .clk(clk), .rst(rst), .ir_rx_async(ir_rx_async),
        .edge_valid(pulse_valid), .pulse_level(pulse_level),
        .level_now(level_now),
        .pulse_ticks(pulse_ticks), .overflow(pulse_overflow)
    );

    nec_decoder #(
        .T_LEAD_LOW(T_LEAD_LOW), .T_LEAD_HIGH(T_LEAD_HIGH),
        .T_REPEAT_HIGH(T_REPEAT_HIGH), .T_BIT_LOW(T_BIT_LOW),
        .T_ZERO_HIGH(T_ZERO_HIGH), .T_ONE_HIGH(T_ONE_HIGH),
        .TOL_PCT(TOL_PCT)
    ) u_decoder (
        .clk(clk), .rst(rst), .pulse_valid(pulse_valid),
        .pulse_level(pulse_level), .pulse_ticks(pulse_ticks),
        .pulse_overflow(pulse_overflow), .event_valid(dec_event_valid),
        .event_command(dec_command), .event_repeat(dec_repeat),
        .frame_error(dec_error)
    );

    ir_keymap u_keymap (
        .dec_valid(dec_event_valid), .dec_command(dec_command),
        .dec_repeat(dec_repeat), .key_valid(key_valid),
        .key_code(key_code), .key_repeat(key_repeat)
    );

    assign ir_rx_sync_level = level_now;
    assign key_is_digit     = (key_code >= KEY_DIGIT_0) && (key_code <= KEY_DIGIT_9);
    // 只有左右键的重复帧交给UI；其余按键一次按下只产生一次操作。
    assign repeat_allowed   = !key_repeat || (key_code == KEY_LEFT) || (key_code == KEY_RIGHT);
    assign digit_index      = key_code - KEY_DIGIT_0;
    assign ir_event_valid   = key_valid && !key_is_digit && repeat_allowed;
    assign ir_event_code    = ir_event_valid ? key_code[3:0] : 4'd0;
    assign ir_event_repeat  = ir_event_valid && key_repeat;
    assign ir_digit_valid   = key_valid && key_is_digit && !key_repeat;
    assign ir_digit_code    = ir_digit_valid ? digit_index[3:0] : 4'd0;
    assign ir_fault         = pulse_overflow | dec_error;
    assign debug_event_valid = dec_event_valid;
    assign debug_command     = dec_command;
    assign debug_fault       = pulse_overflow | dec_error;
    assign debug_edge_valid  = pulse_valid;
endmodule

`default_nettype wire
