// SPI mode-0 byte transceiver for the TF/SD-card reader.
// half_period_cycles is the number of clk cycles in one SCLK half-period.
`default_nettype none

module spi_zijie_shoufa (
    input  wire        clk,
    input  wire        rst,
    input  wire        start,
    input  wire [7:0]  tx_data,
    input  wire [15:0] half_period_cycles,
    output reg         busy,
    output reg         done,
    output reg  [7:0]  rx_data,
    output reg         spi_sclk,
    output reg         spi_mosi,
    input  wire        spi_miso
);

    reg [15:0] divider_count;
    reg [7:0]  rx_shift;
    reg [7:0]  tx_shift;
    reg [2:0]  bit_index;

    wire [15:0] selected_half_period;
    assign selected_half_period = (half_period_cycles == 16'd0) ?
                                  16'd1 : half_period_cycles;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            busy          <= 1'b0;
            done          <= 1'b0;
            rx_data       <= 8'hff;
            spi_sclk      <= 1'b0;
            spi_mosi      <= 1'b1;
            divider_count <= 16'd0;
            rx_shift      <= 8'd0;
            tx_shift      <= 8'hff;
            bit_index     <= 3'd7;
        end else begin
            done <= 1'b0;

            if (!busy) begin
                spi_sclk <= 1'b0;
                if (start) begin
                    busy          <= 1'b1;
                    tx_shift      <= tx_data;
                    rx_shift      <= 8'd0;
                    bit_index     <= 3'd7;
                    spi_mosi      <= tx_data[7];
                    divider_count <= selected_half_period - 16'd1;
                end else begin
                    spi_mosi <= 1'b1;
                end
            end else if (divider_count != 16'd0) begin
                divider_count <= divider_count - 16'd1;
            end else if (!spi_sclk) begin
                spi_sclk           <= 1'b1;
                rx_shift[bit_index] <= spi_miso;
                divider_count      <= selected_half_period - 16'd1;
            end else begin
                spi_sclk      <= 1'b0;
                divider_count <= selected_half_period - 16'd1;
                if (bit_index == 3'd0) begin
                    busy     <= 1'b0;
                    done     <= 1'b1;
                    rx_data  <= rx_shift;
                    spi_mosi <= 1'b1;
                end else begin
                    bit_index <= bit_index - 3'd1;
                    spi_mosi  <= tx_shift[bit_index - 3'd1];
                end
            end
        end
    end

endmodule

`default_nettype wire
