// Passive probes only. No diagnostic signal controls functional traffic.
// Offset index: raw, previous 1/2/3 clocks, next 1/2/3 clocks.
// CRC observers see registered paired data/take to isolate native control fanout.
`timescale 1ns/1ps
`default_nettype none
module sdram_duiqi_jiaoyan #(
    parameter FRAME_WIDTH=1280, FRAME_HEIGHT=720,
    parameter [31:0] WRITE_CRC=32'hc9ea9ad9,
    parameter [31:0] READ_CRC=32'hc2338e8b
)(
    input wire clk,rst,write_take,read_take,
    input wire [23:0] write_rgb,raw_rgb,
    input wire [20:0] write_addr,
    output wire [3:0] native_write_crc,
    output wire [6:0] alignment_match,
    output wire [3:0] alignment_status
);
    reg [23:0] history[0:2];
    reg [2:0] delayed_take;
    reg [23:0] sample_rgb[0:6];
    reg [6:0] sample_take;
    reg write_take_pipe;
    reg [23:0] write_rgb_pipe;
    reg [20:0] write_addr_pipe;
    wire [3:0] read_flags[0:6];
    wire [6:0] read_complete;
    integer i;
    always @(posedge clk or posedge rst) begin
        if(rst) begin
            delayed_take<=0; sample_take<=0; write_take_pipe<=0;
            write_rgb_pipe<=0;write_addr_pipe<=0;
            for(i=0;i<3;i=i+1) history[i]<=0;
            for(i=0;i<7;i=i+1) sample_rgb[i]<=0;
        end else begin
            history[0]<=raw_rgb;history[1]<=history[0];history[2]<=history[1];
            delayed_take<={delayed_take[1:0],read_take};
            sample_take<={delayed_take[2],delayed_take[1],delayed_take[0],
                          read_take,read_take,read_take,read_take};
            sample_rgb[0]<=raw_rgb;
            sample_rgb[1]<=history[0];
            sample_rgb[2]<=history[1];
            sample_rgb[3]<=history[2];
            sample_rgb[4]<=raw_rgb;sample_rgb[5]<=raw_rgb;sample_rgb[6]<=raw_rgb;
            write_take_pipe<=write_take;
            write_rgb_pipe<=write_rgb;write_addr_pipe<=write_addr;
        end
    end
    xiangsu_crc_zhenduan #(.EXPECTED_CRC(WRITE_CRC),
        .FRAME_WIDTH(FRAME_WIDTH),.FRAME_HEIGHT(FRAME_HEIGHT),.CHECK_WRITE_ADDR(1))
    u_native_write (
    
        .clk(clk),.rst(rst),.take(write_take_pipe),.rgb(write_rgb_pipe),
        .addr(write_addr_pipe),.last(1'b0),.user(1'b0),.flags(native_write_crc)
    );
    genvar n;
    generate for(n=0;n<7;n=n+1) begin: g_offset
        xiangsu_crc_zhenduan #(.EXPECTED_CRC(READ_CRC),
            .FRAME_WIDTH(FRAME_WIDTH),.FRAME_HEIGHT(FRAME_HEIGHT))
        u_crc (
    .clk(clk),.rst(rst),.take(sample_take[n]),.rgb(sample_rgb[n]),
            .addr(21'd0),.last(1'b0),.user(1'b0),.flags(read_flags[n]));
        assign alignment_match[n]=read_flags[n][2];
        assign read_complete[n]=read_flags[n][1];
    end endgenerate
    assign alignment_status={(&read_complete)&&!(|alignment_match),
                             |alignment_match,&read_complete,native_write_crc[1]};
endmodule
`default_nettype wire
