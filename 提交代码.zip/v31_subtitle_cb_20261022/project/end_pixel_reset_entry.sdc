# The end-of-track toggle owns a two-stage pixel-clock reset-release chain.
# The mapped reset net is audited to drive ONLY these two asynchronous SR inputs.
# Selecting the stable net survives physical cell packing/renaming; D/Q and all
# downstream functional paths remain timed. The separate physical audit must pass.
set_false_path -through [get_nets {u_video_top_core/u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_zhen_xieru_dingceng/u_tuxiang_jiazai_dingceng/u_tf_audio_reader/u_shared_storage/u_player/end_pixel_reset}]
