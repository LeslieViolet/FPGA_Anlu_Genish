"""Repeat only the 65-bit completion-predicate proof, not full RTL equivalence."""
from pathlib import Path
import hashlib,json,sys

root=Path(__file__).resolve().parent.parent
try:
    import z3
except ModuleNotFoundError:
    sys.path.insert(0,'D:/FPGA/work/tools/formal/z3')
    import z3
source=root/'rtl/media_settings_audio_map_20261019/media_audio_720p_20261017/bc_frame_fetch_for_video_pipe.v'
release=json.loads((root/'release_status.json').read_text(encoding='utf-8'))
assert hashlib.sha256(source.read_bytes()).hexdigest()==release['formal_predicate_proof']['source_sha256']
count=z3.BitVec('count',32);words=z3.BitVec('words',32);take=z3.BitVec('take',1)
original=z3.ZeroExt(1,count)+z3.ZeroExt(32,take)==z3.ZeroExt(1,words)
compact=z3.If(take==1,z3.And(words!=0,count==words-1),count==words)
solver=z3.Solver();solver.add(original!=compact)
result=solver.check()
assert result==z3.unsat,str(result)
print('FRAME_COUNT_FORMAL_PASS all_65_input_bits solver='+z3.get_version_string())
