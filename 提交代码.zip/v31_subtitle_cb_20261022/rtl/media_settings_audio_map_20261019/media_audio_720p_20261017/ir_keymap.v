`default_nettype none

// 红外按键映射模块。
// 把nec_decoder输出的8位NEC命令码转换为项目内部4位UI事件或数字键。
// 参数保持8'hFF表示该功能尚未分配，不能把8'hFF当成真实按键。
module ir_keymap (
    input  wire       dec_valid,    // 解码器输出的单周期有效信号
    input  wire [7:0] dec_command,  // 已校验的8位命令码
    input  wire       dec_repeat,   // 1=重复帧

    output wire       key_valid,    // 已识别按键，保持一个事件周期
    output reg  [4:0] key_code,     // 实际按下的物理按键
    output wire       key_repeat    // 该按键事件来自重复帧
);

// 项目内部UI功能事件编号，只在本模块内部使用。
localparam     [4:0] KEY_NONE  = 5'd0,
                     KEY_UP    = 5'd1,
                     KEY_DOWN  = 5'd2,
                     KEY_LEFT  = 5'd3,
                     KEY_RIGHT = 5'd4,
                     KEY_OK    = 5'd5,
                     KEY_STAR  = 5'd6,   // *键
                     KEY_HASH  = 5'd7,   // #键
                     KEY_0     = 5'd8,
                     KEY_1     = 5'd9,
                     KEY_2     = 5'd10,
                     KEY_3     = 5'd11,
                     KEY_4     = 5'd12,
                     KEY_5     = 5'd13,
                     KEY_6     = 5'd14,
                     KEY_7     = 5'd15,
                     KEY_8     = 5'd16,
                     KEY_9     = 5'd17;

// 纯组合映射逻辑：
 always @* begin
        key_code = KEY_NONE;

        // 解码器没有产生新事件时，不输出按键编号。
        // 因此即使dec_command保留着上一次的值，也不会重复按键。
        if (dec_valid) begin
            case (dec_command)
                // 方向键与确认键
                8'h18: key_code = KEY_UP;
                8'h52: key_code = KEY_DOWN;
                8'h08: key_code = KEY_LEFT;
                8'h5A: key_code = KEY_RIGHT;
                8'h1C: key_code = KEY_OK;

                // *与#键
                8'h16: key_code = KEY_STAR;
                8'h0D: key_code = KEY_HASH;

                // 数字键0～9
                8'h19: key_code = KEY_0;
                8'h45: key_code = KEY_1;
                8'h46: key_code = KEY_2;
                8'h47: key_code = KEY_3;
                8'h44: key_code = KEY_4;
                8'h40: key_code = KEY_5;
                8'h43: key_code = KEY_6;
                8'h07: key_code = KEY_7;
                8'h15: key_code = KEY_8;
                8'h09: key_code = KEY_9;

                // 其他命令码不产生按键事件
                default: key_code = KEY_NONE;
            endcase
        end
    end
    
    // 有新事件且命令码在表中，才认为识别到了按键。
    assign key_valid = (key_code != KEY_NONE);

    // 重复属性只在按键事件有效时输出。
    assign key_repeat = key_valid && dec_repeat;

endmodule
`default_nettype wire
