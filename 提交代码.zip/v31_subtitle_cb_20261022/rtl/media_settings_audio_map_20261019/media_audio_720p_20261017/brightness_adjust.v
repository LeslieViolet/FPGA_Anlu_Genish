`default_nettype none
// Brightness level: 0..100, with 50 as the neutral point.
// The offset is 2*(level-50), hence the usable range is -100..+100.
module brightness_adjust (
    input  wire [23:0] rgb_in,
    input  wire [6:0]  level,
    output wire [23:0] rgb_out
);
    function [7:0] adjust;
        input [7:0] channel;
        input [6:0] requested_level;
        reg [6:0] bounded_level;
        reg signed [10:0] value;
        begin
            bounded_level = requested_level > 7'd100 ? 7'd100 : requested_level;
            value = $signed({3'b000,channel}) +
                    $signed({3'b000,bounded_level,1'b0}) - 11'sd100;
            if (value < 0)
                adjust = 8'd0;
            else if (value > 11'sd255)
                adjust = 8'hff;
            else
                adjust = value[7:0];
        end
    endfunction

    assign rgb_out = {adjust(rgb_in[23:16],level),
                      adjust(rgb_in[15:8],level),
                      adjust(rgb_in[7:0],level)};
endmodule
`default_nettype wire
