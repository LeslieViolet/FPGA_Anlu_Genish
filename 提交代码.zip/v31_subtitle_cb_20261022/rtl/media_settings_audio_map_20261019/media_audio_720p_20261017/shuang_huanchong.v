// Part 6: sixteen catalogue entries backed by two 720p SDRAM frame slots.
// The one-bit display selector is a lease token; disp_index is the media ID;
// disp_physical_slot selects the actual SDRAM slot used by the frame reader.
`default_nettype none
module shuang_huanchong (
    input wire clk_write,
    input wire rst_write,
    input wire request_valid,
    output wire request_ready,
    input wire [3:0] request_id,
    input wire [4:0] asset_count,
    input wire request_cancel,
    output wire load_valid,
    input wire load_ready,
    output wire [3:0] load_id,
    output wire load_buffer_sel,
    output wire [1:0] load_physical_slot,
    output wire load_abort,
    input wire write_result_valid,
    output wire write_result_ready,
    input wire [3:0] write_result_code,
    input wire [15:0] write_result_index,
    input wire write_result_buffer_sel,
    input wire write_reset_required,
    output wire request_result_valid,
    input wire request_result_ready,
    output wire [3:0] request_result_code,
    output wire [15:0] request_result_index,
    output wire request_result_buffer_sel,
    output wire write_busy,
    output wire [1:0] slot_busy,

    input wire clk_display,
    input wire rst_display,
    output wire frame_ready,
    input wire disp_req,
    output reg disp_ack,
    input wire disp_keep_old,
    input wire display_reads_idle,
    output reg disp_valid,
    output reg disp_buffer_sel,
    output reg [15:0] disp_width,
    output reg [15:0] disp_height,
    output reg [15:0] disp_index,
    output reg [1:0] disp_physical_slot,
    output reg [31:0] disp_generation,
    output reg disp_previous_valid,
    output reg disp_previous_sel,
    input wire disp_previous_release_req,
    output reg disp_previous_release_ack
);
    localparam [2:0] W_IDLE=0, W_START=1, W_WAIT=2,
                     W_COMMIT=3, W_RESULT=4;
    reg [2:0] wstate;
    reg [1:0] cache_valid;
    reg [3:0] cache_tag [0:1];
    reg [15:0] prefetch_failed;
    reg selected_slot;
    reg [1:0] selected_physical_slot;
    reg foreground;
    reg [3:0] selected_id, result_code_reg;
    reg [15:0] result_index_reg;
    reg result_buffer_reg;
    reg [31:0] generation_counter;
    reg active_valid;
    reg [3:0] active_asset_id;
    reg [1:0] active_physical_slot;

    // Commit payload remains unchanged from one write clock before the toggle
    // until the display actually consumes the pending frame.
    reg commit_toggle;
    reg commit_buffer_payload;
    reg [1:0] commit_physical_payload;
    reg [15:0] commit_index_payload;
    reg [31:0] commit_generation_payload;
    (* async_reg = "true" *) reg [1:0] commit_ack_sync;
    wire commit_mailbox_free = commit_toggle == commit_ack_sync[1];

    // Signals originating in the display domain are declared here because the
    // write-domain synchronizers below consume them.
    reg commit_ack_toggle;
    reg release_toggle, release_slot_payload;

    // Release mailbox crosses one stable slot bit back to the write domain.
    reg release_seen, release_ack_toggle;
    (* async_reg = "true" *) reg [1:0] release_toggle_sync, release_slot_sync;

    function [3:0] next_id;
        input [3:0] current;
        input [2:0] distance;
        input [4:0] count;
        reg [5:0] sum;
        begin
            sum = {2'b00,current} + distance;
            if(count == 0) next_id = 0;
            else if(sum >= count) next_id = sum - count;
            else next_id = sum[3:0];
        end
    endfunction

    wire request_hit0 = cache_valid[0] && cache_tag[0] == request_id;
    wire request_hit1 = cache_valid[1] && cache_tag[1] == request_id;
    wire request_hit = request_hit0 || request_hit1;
    wire [1:0] request_hit_slot = request_hit0 ? 2'd0 : 2'd1;

    // Split wrap arithmetic from cache lookup/replacement. A candidate may
    // only be used while its owning image and catalog count are unchanged.
    reg [3:0] ahead_1, ahead_owner;
    reg [4:0] ahead_count;
    reg ahead_valid;
    always @(posedge clk_write or posedge rst_write) begin
        if(rst_write) begin
            ahead_1<=0; ahead_owner<=0;
            ahead_count<=0; ahead_valid<=0;
        end else begin
            ahead_1<=next_id(active_asset_id,3'd1,asset_count);
            ahead_owner<=active_asset_id;
            ahead_count<=asset_count;
            ahead_valid<=active_valid;
        end
    end
    wire ahead_ready = ahead_valid && ahead_owner==active_asset_id &&
                       ahead_count==asset_count;
    wire ahead_1_cached = (cache_valid[0] && cache_tag[0]==ahead_1) ||
                          (cache_valid[1] && cache_tag[1]==ahead_1);
    wire prefetch_pending = active_valid && ahead_ready && asset_count > 5'd1 &&
                            !ahead_1_cached && !prefetch_failed[ahead_1];
    wire [3:0] prefetch_id = ahead_1;
    wire request_id_ok = {1'b0,request_id} < asset_count;

    wire [1:0] replacement_slot = !active_valid ? (!cache_valid[0] ? 2'd0 : 2'd1) :
                                    (active_physical_slot[0] ? 2'd0 : 2'd1);
    assign request_ready = !rst_write && wstate==W_IDLE &&
        commit_mailbox_free && !write_reset_required;
    assign load_valid = !rst_write && wstate==W_START &&
                        !(foreground && request_cancel);
    assign load_id = selected_id;
    assign load_buffer_sel = selected_slot;
    assign load_physical_slot = selected_physical_slot;
    assign load_abort = !rst_write && wstate==W_WAIT && foreground && request_cancel;
    assign write_result_ready = !rst_write && wstate==W_WAIT;
    assign request_result_valid = !rst_write && wstate==W_RESULT && foreground;
    assign request_result_code = result_code_reg;
    assign request_result_index = result_index_reg;
    assign request_result_buffer_sel = result_buffer_reg;
    assign write_busy = !rst_write && wstate!=W_IDLE;
    assign slot_busy = cache_valid[1:0];

    always @(posedge clk_write or posedge rst_write) begin
        if(rst_write) begin
            wstate<=W_IDLE; cache_valid<=0; prefetch_failed<=0;
            cache_tag[0]<=0; cache_tag[1]<=0;
            selected_slot<=0; selected_physical_slot<=0;
            selected_id<=0; foreground<=0;
            result_code_reg<=0; result_index_reg<=0; result_buffer_reg<=0;
            generation_counter<=0; active_valid<=0; active_asset_id<=0;
            active_physical_slot<=0;
            commit_toggle<=0; commit_buffer_payload<=0; commit_physical_payload<=0;
            commit_index_payload<=0; commit_generation_payload<=0;
            commit_ack_sync<=0; release_toggle_sync<=0; release_slot_sync<=0;
            release_seen<=0; release_ack_toggle<=0;
        end else begin
            commit_ack_sync <= {commit_ack_sync[0], commit_ack_toggle};
            release_toggle_sync <= {release_toggle_sync[0], release_toggle};
            release_slot_sync <= {release_slot_sync[0], release_slot_payload};
            if(release_toggle_sync[1] != release_seen) begin
                release_seen <= release_toggle_sync[1];
                release_ack_toggle <= release_toggle_sync[1];
            end
            case(wstate)
                W_IDLE: begin
                    if(request_valid && request_ready) begin
                        foreground<=1'b1;
                        selected_slot<=generation_counter[0];
                        selected_id<=request_id;
                        result_buffer_reg<=generation_counter[0];
                        result_index_reg<={12'd0,request_id};
                        if(!request_id_ok) begin
                            result_code_reg<=4'd1;
                            wstate<=W_RESULT;
                        end else if(request_hit) begin
                            selected_physical_slot<=request_hit_slot;
                            result_code_reg<=4'd0;
                            commit_buffer_payload<=generation_counter[0];
                            commit_physical_payload<=request_hit_slot;
                            commit_index_payload<={12'd0,request_id};
                            commit_generation_payload<=generation_counter+1'b1;
                            wstate<=W_COMMIT;
                        end else begin
                            selected_physical_slot<=replacement_slot;
                            cache_valid[replacement_slot]<=1'b0;
                            wstate<=W_START;
                        end
                    end else if(active_valid && prefetch_pending &&
                                commit_mailbox_free && !write_reset_required) begin
                        foreground<=1'b0;
                        selected_id<=prefetch_id;
                        selected_slot<=generation_counter[0];
                        selected_physical_slot<=replacement_slot;
                        cache_valid[replacement_slot]<=1'b0;
                        wstate<=W_START;
                    end
                end
                W_START: begin
                    if(foreground && request_cancel) begin
                        result_code_reg<=4'd5; result_index_reg<={12'd0,selected_id};
                        result_buffer_reg<=selected_slot; wstate<=W_RESULT;
                    end else if(load_valid && load_ready) wstate<=W_WAIT;
                end
                W_WAIT: if(write_result_valid && write_result_ready) begin
                    if(write_result_code==0 && write_result_buffer_sel==selected_slot &&
                       write_result_index=={12'd0,selected_id}) begin
                        cache_valid[selected_physical_slot]<=1'b1;
                        cache_tag[selected_physical_slot]<=selected_id;
                        if(foreground) begin
                            result_code_reg<=4'd0;
                            result_index_reg<=write_result_index;
                            result_buffer_reg<=selected_slot;
                            commit_buffer_payload<=selected_slot;
                            commit_physical_payload<=selected_physical_slot;
                            commit_index_payload<=write_result_index;
                            commit_generation_payload<=generation_counter+1'b1;
                            wstate<=W_COMMIT;
                        end else wstate<=W_IDLE;
                    end else begin
                        if(foreground) begin
                            result_code_reg<=write_result_code==0 ? 4'd2 : write_result_code;
                            result_index_reg<=write_result_index;
                            result_buffer_reg<=write_result_buffer_sel;
                            wstate<=W_RESULT;
                        end else begin
                            prefetch_failed[selected_id]<=1'b1;
                            wstate<=W_IDLE;
                        end
                    end
                end
                W_COMMIT: begin
                    // Payload was stable for one full write clock before toggle.
                    if(request_cancel) begin
                        result_code_reg<=4'd5; wstate<=W_RESULT;
                    end else begin
                        generation_counter<=generation_counter+1'b1;
                        active_valid<=1'b1;
                        active_asset_id<=selected_id;
                        active_physical_slot<=selected_physical_slot;
                        prefetch_failed<=16'd0;
                        commit_toggle<=~commit_toggle;
                        wstate<=W_RESULT;
                    end
                end
                W_RESULT: if(request_result_valid && request_result_ready)
                    wstate<=W_IDLE;
                default: wstate<=W_IDLE;
            endcase
        end
    end

    // Display-domain commit synchronizers and stable-payload capture.
    (* async_reg = "true" *) reg [1:0] commit_toggle_sync;
    (* async_reg = "true" *) reg [1:0] commit_buffer_sync;
    (* async_reg = "true" *) reg [1:0] commit_physical_sync1, commit_physical_sync2;
    (* async_reg = "true" *) reg [15:0] commit_index_sync1, commit_index_sync2;
    (* async_reg = "true" *) reg [31:0] commit_generation_sync1, commit_generation_sync2;
    reg commit_seen;
    reg pending_valid, pending_buffer;
    reg [1:0] pending_physical;
    reg [15:0] pending_index;
    reg [31:0] pending_generation;

    reg release_arm;
    (* async_reg = "true" *) reg [1:0] release_ack_sync;
    reg disp_req_seen, previous_req_seen;
    wire release_mailbox_free = !release_arm &&
                                release_toggle==release_ack_sync[1];
    assign frame_ready = !rst_display && pending_valid;

    always @(posedge clk_display or posedge rst_display) begin
        if(rst_display) begin
            commit_toggle_sync<=0; commit_buffer_sync<=0;
            commit_physical_sync1<=0; commit_physical_sync2<=0;
            commit_index_sync1<=0; commit_index_sync2<=0;
            commit_generation_sync1<=0; commit_generation_sync2<=0;
            commit_seen<=0; commit_ack_toggle<=0;
            pending_valid<=0; pending_buffer<=0; pending_physical<=0; pending_index<=0;
            pending_generation<=0; release_toggle<=0;
            release_slot_payload<=0; release_arm<=0; release_ack_sync<=0;
            disp_req_seen<=0; previous_req_seen<=0;
            disp_ack<=0; disp_valid<=0; disp_buffer_sel<=0;
            disp_width<=0; disp_height<=0; disp_index<=0;
            disp_physical_slot<=0; disp_generation<=0;
            disp_previous_valid<=0; disp_previous_sel<=0;
            disp_previous_release_ack<=0;
        end else begin
            commit_toggle_sync <= {commit_toggle_sync[0],commit_toggle};
            commit_buffer_sync <= {commit_buffer_sync[0],commit_buffer_payload};
            commit_physical_sync1<=commit_physical_payload;
            commit_physical_sync2<=commit_physical_sync1;
            commit_index_sync1<=commit_index_payload;
            commit_index_sync2<=commit_index_sync1;
            commit_generation_sync1<=commit_generation_payload;
            commit_generation_sync2<=commit_generation_sync1;
            release_ack_sync <= {release_ack_sync[0],release_ack_toggle};
            disp_ack<=0;
            disp_previous_release_ack<=0;
            if(release_arm) begin
                release_toggle<=~release_toggle;
                release_arm<=0;
            end
            if(commit_toggle_sync[1]!=commit_seen && !pending_valid) begin
                pending_buffer<=commit_buffer_sync[1];
                pending_physical<=commit_physical_sync2;
                pending_index<=commit_index_sync2;
                pending_generation<=commit_generation_sync2;
                pending_valid<=1;
                commit_seen<=commit_toggle_sync[1];
            end
            if(!disp_req) disp_req_seen<=0;
            if(!disp_previous_release_req) previous_req_seen<=0;

            // RELEASE has priority if both requests appear in one cycle.
            if(disp_previous_release_req && !previous_req_seen &&
               display_reads_idle && (!disp_previous_valid || release_mailbox_free)) begin
                previous_req_seen<=1;
                if(disp_previous_valid) begin
                    release_slot_payload<=disp_previous_sel;
                    release_arm<=1;
                    disp_previous_valid<=0;
                end
                disp_previous_release_ack<=1;
            end else if(disp_req && !disp_req_seen && display_reads_idle) begin
                if(!pending_valid) begin
                    disp_ack<=1;
                    disp_req_seen<=1;
                end else if(disp_previous_valid) begin
                    // Two held slots cannot accept another swap; return current view.
                    disp_ack<=1;
                    disp_req_seen<=1;
                end else if(!disp_valid || disp_keep_old || release_mailbox_free) begin
                    if(disp_valid && disp_keep_old) begin
                        disp_previous_valid<=1;
                        disp_previous_sel<=disp_buffer_sel;
                    end else if(disp_valid) begin
                        release_slot_payload<=disp_buffer_sel;
                        release_arm<=1;
                    end
                    disp_valid<=1;
                    disp_buffer_sel<=pending_buffer;
                    disp_width<=16'd1280;
                    disp_height<=16'd720;
                    disp_index<=pending_index;
                    disp_physical_slot<=pending_physical;
                    disp_generation<=pending_generation;
                    pending_valid<=0;
                    commit_ack_toggle<=commit_seen;
                    disp_ack<=1;
                    disp_req_seen<=1;
                end
            end
        end
    end
endmodule
`default_nettype wire
