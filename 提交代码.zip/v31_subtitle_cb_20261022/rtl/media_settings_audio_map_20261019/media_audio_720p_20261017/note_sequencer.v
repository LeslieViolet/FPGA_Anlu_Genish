module note_sequencer  (
    input  wire        clk,
    input  wire        rst,
    input  wire        trigger,
    input  wire [1:0]  sound_id,

    output reg         tone_enable,
    output reg  [31:0] phase_step
);
    localparam active_hd = 1'b1;

    // clk为25 MHz时，5,000,000个周期约为200 ms。
    wire [23:0] TONE_DURATION_CYCLES = 24'd15000000;

    reg        trigger_d;
    reg [23:0] duration_count;

    always @(posedge clk) begin
        if (rst) begin
            trigger_d     <= 1'b0;
            duration_count <= 24'd0;
            tone_enable   <= 1'b0;
            phase_step    <= 32'd45011;
        end
        else begin
            trigger_d <= trigger;

            // trigger上升沿开始一次新的提示音；新触发会重新计时。
            if (trigger && !trigger_d) begin
                duration_count <= 24'd0;
                tone_enable    <= 1'b1;

                // 25 MHz更新时钟下约为262、330、392、523 Hz。
                case (sound_id)
                    2'b00: phase_step <= 32'd15004;
                    2'b01: phase_step <= 32'd18898;
                    2'b10: phase_step <= 32'd22448;
                    2'b11: phase_step <= 32'd29950;
                    default: phase_step <= 32'd45011;
                endcase
            end
            else if (tone_enable) begin
                if (duration_count == TONE_DURATION_CYCLES - 24'd1) begin
                    duration_count <= 24'd0;
                    tone_enable    <= 1'b0;
                end
                else begin
                    duration_count <= duration_count + 23'd1;
                end
            end
        end
    end

endmodule
