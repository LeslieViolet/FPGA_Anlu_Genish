// Explicit same-clock show-ahead FIFO model for this prefetch regression ONLY.
// Not production RTL, not a proof of an asynchronous/vendor FIFO.
`timescale 1ns/1ps
module fangzhen_yibu_fifo #(
 parameter DATA_WIDTH=24,ADDR_WIDTH=10,ALMOST_FULL_LEVEL=1008,ALMOST_EMPTY_LEVEL=4
)(
 input wire rst,wr_clk,wr_en,input wire [DATA_WIDTH-1:0] wr_data,
 output wire full,almost_full,output wire [ADDR_WIDTH:0] wr_usedw,output reg overflow,
 input wire rd_clk,rd_en,output wire [DATA_WIDTH-1:0] rd_data,
 output wire empty,almost_empty,valid,output wire [ADDR_WIDTH:0] rd_usedw,output reg underflow
);
 localparam DEPTH=1<<ADDR_WIDTH;
 reg [DATA_WIDTH-1:0] mem[0:DEPTH-1];reg [ADDR_WIDTH-1:0] wp,rp;reg [ADDR_WIDTH:0] count;
 assign full=count==DEPTH;assign empty=count==0;assign valid=!empty;
 assign almost_full=count>=ALMOST_FULL_LEVEL;assign almost_empty=count<=ALMOST_EMPTY_LEVEL;
 assign wr_usedw=count;assign rd_usedw=count;assign rd_data=mem[rp];
 always @(posedge wr_clk or posedge rst)begin
  if(rst)begin wp<=0;rp<=0;count<=0;overflow<=0;underflow<=0;end
  else begin
   if(rd_clk!==wr_clk)$fatal(1,"same-clock prefetch FIFO model misused");
   overflow<=wr_en && full;underflow<=rd_en && empty;
   if(wr_en && !full)begin mem[wp]<=wr_data;wp<=wp+1'b1;end
   if(rd_en && !empty)rp<=rp+1'b1;
   case({wr_en && !full,rd_en && !empty})2'b10:count<=count+1'b1;2'b01:count<=count-1'b1;default:;endcase
  end
 end
endmodule
