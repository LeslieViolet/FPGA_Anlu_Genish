# Explicitly confirm that adding SR-only exceptions did not remove D/Q timing.
foreach i {0 1 2 4 5 6} {
 set q [get_pins [lindex $pcm_q $i]]
 set d [get_pins [lindex $pcm_d [expr {$i+1}]]]
 set dqfile [file join $run_dir pcm_dq_$i.rpt]
 report_timing_path -from $q -to $d -file $dqfile
 set df [open $dqfile r];set dt [read $df];close $df
 if {![regexp {Check Type\s*:\s*setup} $dt] || ![regexp {Check Type\s*:\s*hold} $dt]} {
  error "PCM_DQ_TIMING_AUDIT_FAIL stage=$i setup_or_hold_path_missing"
 }
}
puts {PCM_DQ_TIMING_AUDIT_PASS SIX_SETUP_HOLD_PATHS_REMAIN_TIMED}
