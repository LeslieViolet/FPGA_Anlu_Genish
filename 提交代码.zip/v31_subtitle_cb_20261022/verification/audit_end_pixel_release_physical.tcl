# TD 6.2 post-route audit only. Does not alter the netlist or constraints.
# Logical release nets survive packing; physical cells may borrow unrelated LUT names.
proc v31_one {objects label} {
    if {[llength $objects] != 1} {error "V31_END_RESET_AUDIT_FAIL $label count=[llength $objects]"}
    return $objects
}
proc v31_prop {key objects} {return [get_property -quiet $key $objects]}
proc v31_require {condition message} {
    if {!$condition} {error "V31_END_RESET_AUDIT_FAIL $message"}
}
proc v31_attr {cell key value} {
    set attrs [v31_prop ATTRIBUTES $cell]
    set found 0
    foreach item [split $attrs {;}] {
        if {[regexp {^\s*([^=]+?)\s*=\s*(.*?)\s*$} $item -> k v]} {
            if {[string trim $k] eq $key && [string trim $v] eq $value} {set found 1}
        }
    }
    v31_require $found "cell=$cell expected_attribute=$key:$value"
}
set v31_player {u_video_top_core/u_b/u_zhen_duqu_dingceng/u_shuang_huanchong_dingceng/u_zhen_xieru_dingceng/u_tuxiang_jiazai_dingceng/u_tf_audio_reader/u_shared_storage/u_player}
set v31_reset [v31_one [get_nets $v31_player/end_pixel_reset] reset_net]
set v31_pixel_clock [v31_one [get_nets {u_video_top_core/u_c/u_hdmi_phy/I_pixel_clk}] pixel_clock]
set v31_sr_pins {}
set v31_q_pins {}
set v31_d_pins {}
set v31_stage_nets {}
set v31_driver_cells {}
for {set stage 0} {$stage < 2} {incr stage} {
    set stage_name [format {%s/end_pixel_release[%d]} $v31_player $stage]
    set n [v31_one [get_nets $stage_name] stage_net]
    v31_require [v31_prop ASYNC_REG $n] "stage=$stage missing_ASYNC_REG"
    v31_require [expr {[v31_prop BUS_WIDTH $n] == 2}] "stage=$stage wrong_bus_width"
    set drivers {}
    foreach pin_name [get_pins -of $n] {
        set pin [get_pins $pin_name]
        if {[v31_prop DIRECTION $pin] == 1} {lappend drivers $pin_name}
    }
    set q [v31_one $drivers stage_q_driver]
    v31_require [regexp {^(.*)\.q\[([01])\]$} [lindex $q 0] -> cell_name q_index] "stage=$stage nonphysical_Q_driver=$q"
    set cell [v31_one [get_cells $cell_name] stage_cell]
    set sr [v31_one [get_pins $cell_name.sr] stage_sr]
    set clk [v31_one [get_pins $cell_name.clk] stage_clk]
    set d [v31_one [get_pins [format {%s.mi[%d]} $cell_name $q_index]] stage_d]
    v31_require [expr {[v31_prop NET_NAME $sr] eq [v31_prop NAME $v31_reset]}] "stage=$stage wrong_SR_net"
    v31_require [expr {[v31_prop NET_NAME $clk] eq [v31_prop NAME $v31_pixel_clock]}] "stage=$stage wrong_clock"
    foreach {key value} {DFFMODE :FF CEMUX :1 CLKMUX :CLK SRMODE :ASYNC SRMUX :SR} {v31_attr $cell $key $value}
    v31_attr $cell REG${q_index}_REGSET :SET
    v31_attr $cell REG${q_index}_SD :MI
    lappend v31_sr_pins [lindex $sr 0]
    lappend v31_q_pins [lindex $q 0]
    lappend v31_d_pins [lindex $d 0]
    lappend v31_stage_nets [lindex $n 0]
    lappend v31_driver_cells [lindex $cell 0]
    puts "V31_END_RESET_STAGE stage=$stage Q=$q D=$d SR=$sr"
    report_cells $cell -attributes -connection
}
# Packing may put the two audited release FFs in one dual-FF slice.
# Require the connected Q set of every used cell to be EXACTLY the audited
# stage Q set. No third/functional FF is admitted to the reset exception.
v31_require [expr {[llength [lsort -unique $v31_q_pins]] == 2}] {expected_two_distinct_logical_Q_pins}
foreach cell_name [lsort -unique $v31_driver_cells] {
    set expected_q {}
    for {set i 0} {$i<2} {incr i} {
        if {[lindex $v31_driver_cells $i] eq $cell_name} {lappend expected_q [lindex $v31_q_pins $i]}
    }
    set connected_q {}
    foreach pn [get_pins -of [get_cells $cell_name]] {
        if {[regexp {\.q\[[01]\]$} $pn] && [v31_prop IS_CONNECTED [get_pins $pn]]} {lappend connected_q $pn}
    }
    v31_require [expr {[lsort $connected_q] eq [lsort $expected_q]}] {shared_SR_has_nonrelease_Q}
}
v31_require [expr {[v31_prop CONST_VALUE [get_pins [lindex $v31_d_pins 0]]] eq "0"}] {stage0_D_is_not_constant_zero}
v31_require [expr {[v31_prop NET_NAME [get_pins [lindex $v31_d_pins 1]]] eq [lindex $v31_stage_nets 0]}] {stage1_D_is_not_stage0_Q}
set v31_stage0_pins [lsort [get_pins -of [get_nets [lindex $v31_stage_nets 0]]]]
v31_require [expr {$v31_stage0_pins eq [lsort [list [lindex $v31_q_pins 0] [lindex $v31_d_pins 1]]]}] {stage0_has_nonchain_fanout}
set v31_reset_drivers {}
set v31_reset_sinks {}
foreach pin_name [get_pins -of $v31_reset] {
    set pin [get_pins $pin_name]
    if {[v31_prop DIRECTION $pin] == 1} {lappend v31_reset_drivers $pin_name} else {lappend v31_reset_sinks $pin_name}
}
v31_require [expr {[llength $v31_reset_drivers] == 1}] {reset_net_must_have_one_driver}
v31_require [expr {[lsort $v31_reset_sinks] eq [lsort -unique $v31_sr_pins]}] {reset_net_has_unverified_nonSR_or_extra_fanout}
puts "V31_END_RESET_AUDIT_PASS ENTRY_FF_ONLY=2 PHYSICAL_SR=[llength [lsort -unique $v31_sr_pins]] STAGE0_D=0 STAGE1_D=STAGE0_Q DQ_TIMED=true"
puts "V31_END_RESET_SR_WHITELIST=$v31_sr_pins"
