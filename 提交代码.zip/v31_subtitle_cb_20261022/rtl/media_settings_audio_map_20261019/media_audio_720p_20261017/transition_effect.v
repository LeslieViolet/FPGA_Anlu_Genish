// Single-frame image transition. No second SDRAM read is needed.
// Style 0 preserves the verified 16-step fade-to-black behavior.
`default_nettype none
module transition_effect #(
    parameter FRAME_WIDTH = 1280,
    parameter FRAME_HEIGHT = 720
) (
    input  wire [10:0] x,
    input  wire [10:0] y,
    input  wire [23:0] rgb_in,
    input  wire [4:0] level,
    input  wire [1:0] style,
    output reg  [23:0] rgb_out
);
    wire [11:0] active_height = FRAME_HEIGHT;
    wire [11:0] active_width = FRAME_WIDTH;
    wire active_hd = (FRAME_WIDTH>640);
    wire [4:0] safe_level = level > 5'd16 ? 5'd16 : level;
    wire [23:0] faded_rgb;
    transition_fade u_original_fade (
        .rgb_in(rgb_in), .level(safe_level), .rgb_out(faded_rgb)
    );

    // Both supported display widths/heights divide exactly by 16. The
    // multipliers have compile-time constant operands (40/80 and 30/45).
    wire [7:0] H_STEP = active_width / 16;
    wire [7:0] V_STEP = active_height / 16;
    wire [15:0] h_limit = safe_level * H_STEP;
    wire [15:0] v_limit = safe_level * V_STEP;

    // 4x4 Bayer order, repeated in 32x32-pixel blocks. A pixel becomes
    // visible exactly once as level rises from 0 to 16.
    reg [3:0] tile_order;
    always @* begin
        case ({y[6:5],x[6:5]})
            4'h0: tile_order=4'd0;
            4'h1: tile_order=4'd8;
            4'h2: tile_order=4'd2;
            4'h3: tile_order=4'd10;
            4'h4: tile_order=4'd12;
            4'h5: tile_order=4'd4;
            4'h6: tile_order=4'd14;
            4'h7: tile_order=4'd6;
            4'h8: tile_order=4'd3;
            4'h9: tile_order=4'd11;
            4'ha: tile_order=4'd1;
            4'hb: tile_order=4'd9;
            4'hc: tile_order=4'd15;
            4'hd: tile_order=4'd7;
            4'he: tile_order=4'd13;
            default: tile_order=4'd5;
        endcase
    end

    always @* begin
        case (style)
            2'd1: rgb_out = (x < h_limit) ? rgb_in : 24'h000000;
            2'd2: rgb_out = (y < v_limit) ? rgb_in : 24'h000000;
            2'd3: rgb_out = (safe_level > {1'b0,tile_order}) ?
                              rgb_in : 24'h000000;
            default: rgb_out = faded_rgb;
        endcase
    end
endmodule
`default_nettype wire
