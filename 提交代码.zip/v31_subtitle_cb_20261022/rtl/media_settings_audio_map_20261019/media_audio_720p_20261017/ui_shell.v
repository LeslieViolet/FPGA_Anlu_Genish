`default_nettype none
// 设置控制器：只在50MHz系统域保存参数，跨域由上层快照邮箱承担。
// 数值先写草稿，OK才提交；*或#取消未提交内容，重复帧不能重复确认。
module ui_shell #(
 parameter integer DEMO_IMAGES=0, CLK_HZ=50_000_000, SETTINGS_HOLD_STEP_MS=150
)(
 input wire media_offline,clk,rst,event_valid,input wire [3:0] event_code,
 input wire event_repeat,event_source,digit_valid,input wire [3:0] digit_code,
 input wire hold_start,hold_release,input wire [3:0] hold_code,input wire [4:0] asset_count,
 input wire [3:0] current_picture,input wire media_busy,
 output reg [3:0] ui_state,output reg [1:0] home_focus,launch_mode,
 output reg media_open_req,media_next_req,media_prev_req,media_play_toggle,
 output reg settings_enter,transform_enter,pip_select_req,pip_move_mode,
 output reg brightness_inc,brightness_dec,zoom_inc,zoom_dec,rotate_cw,rotate_ccw,
 output reg file_select_digit_valid,output reg [3:0] file_select_digit,
 output reg settings_digit_valid,output reg [3:0] settings_digit,
 output reg [15:0] browser_index,output reg [3:0] brightness_level,zoom_level,
 output reg [1:0] rotation_mode,output wire playback_rate_valid,output wire [1:0] playback_rate_code,
 output reg [2:0] settings_page,settings_focus,output reg [3:0] volume_level,
 output reg mute_enabled,output reg [3:0] contrast_level,
 output reg [3:0] auto_interval_code, // 兼容端口名；现在存真正的1..9秒
 output reg [1:0] transition_mode,output reg osd_enabled,audio_visualizer_enabled,subtitle_enabled,
 output reg [3:0] bgm_map_picture,output reg [1:0] bgm_map_track,current_bgm_track,
 output reg slideshow_auto,audio_enabled,player_playing,settings_numeric_edit,ui_fault,
 output reg [3:0] edit_value,output reg [1:0] settings_feedback,
 output reg confirm_active,confirm_yes,software_reset_req
);
 localparam [3:0] UI_BOOT=0,UI_PLAYER=2,UI_OSD=9;
 localparam [3:0] UP=1,DOWN=2,LEFT=3,RIGHT=4,OK=5,BACK=6,HASH=7,PLAY=9;
 localparam [2:0] ROOT=0,PLAYBACK=1,SOUND=2,DISPLAY=3,SYSTEM=4,MUSIC_MAP=5;
 localparam integer HOLD_TICKS=(CLK_HZ/1000)*SETTINGS_HOLD_STEP_MS;
 localparam integer FEEDBACK_TICKS=CLK_HZ;
 reg [3:0] return_state;
 // 长按计数与提示计数分时使用，计数器取两者中的较大范围。
 localparam integer TIMER_TICKS=(HOLD_TICKS>FEEDBACK_TICKS)?HOLD_TICKS:FEEDBACK_TICKS;
 localparam integer TIMER_WIDTH=TIMER_TICKS>1?$clog2(TIMER_TICKS):1;
 reg [TIMER_WIDTH-1:0] settings_timer_count;
 reg hold_active,hold_right;
 reg [17:0] bgm_picture_map;
 wire settings_context=(ui_state==UI_OSD);
 wire dispatch=(event_valid&&!event_repeat)||hold_start;
 wire [3:0] action=(event_valid&&!event_repeat)?event_code:hold_code;
 wire [3:0] picture_count=asset_count>9?4'd9:asset_count[3:0];
 reg [2:0] last_focus;
 reg [3:0] selected_value,minimum,maximum;
 function [1:0] picture_track;
  input [3:0] picture;
  input [17:0] mapping;
  begin
   if(picture>=1 && picture<=9)
    picture_track=mapping[(picture-4'd1)*2 +: 2];
   else picture_track=2'd0;
  end
 endfunction
 always @* begin
  last_focus=0;selected_value=0;minimum=0;maximum=9;
  bgm_map_track=picture_track(bgm_map_picture,bgm_picture_map);
  // The media adapter reports a zero-based index; the user-facing map is 1..9.
  current_bgm_track=picture_track(current_picture+4'd1,bgm_picture_map);
  case(settings_page)
   PLAYBACK:begin
    last_focus=3;
    case(settings_focus)
     0:begin selected_value=(current_picture<picture_count)?current_picture+4'd1:4'd1;
       minimum=1;maximum=(picture_count==0)?4'd1:picture_count;end
     1:begin selected_value=auto_interval_code;minimum=1;end
     2:begin selected_value={3'b000,slideshow_auto};maximum=1;end
     default:begin selected_value={2'b00,transition_mode};maximum=3;end
    endcase
   end
   SOUND:begin
    last_focus=3;
    case(settings_focus)
     0:selected_value=volume_level;
     1:begin selected_value={3'b000,mute_enabled};maximum=1;end
     2:begin selected_value={3'b000,audio_enabled};maximum=1;end
      default:begin selected_value=0;maximum=0;end
    endcase
   end
   DISPLAY:begin
     last_focus=4;
    case(settings_focus)
     0:selected_value=brightness_level;
     1:selected_value=contrast_level;
      2:begin selected_value={3'b000,osd_enabled};maximum=1;end
      3:begin selected_value={3'b000,audio_visualizer_enabled};maximum=1;end
      default:begin selected_value={3'b000,subtitle_enabled};maximum=1;end
    endcase
   end
   SYSTEM:begin last_focus=1;maximum=1;end
    MUSIC_MAP:begin
     last_focus=1;
     if(settings_focus==0)begin
      selected_value=bgm_map_picture;minimum=1;
      maximum=(picture_count==0)?4'd1:picture_count;
     end else begin
      selected_value={2'b00,bgm_map_track};maximum=3;
     end
    end
   default:begin end
  endcase
 end
 wire timed_step=hold_active&&(settings_timer_count>=HOLD_TICKS-1);
 wire direct_step=dispatch&&(action==LEFT||action==RIGHT);
 wire step_right=direct_step?(action==RIGHT):hold_right;
 wire restore_defaults_commit=dispatch&&(action==OK)&&settings_context&&confirm_active&&confirm_yes&&(settings_focus==0);
 wire bgm_map_commit=dispatch&&(action==OK)&&settings_context&&!confirm_active&&settings_numeric_edit&&
                     (settings_page==MUSIC_MAP)&&(settings_focus==1)&&
                     (edit_value>=minimum)&&(edit_value<=maximum);
 assign playback_rate_valid=1'b0;
 assign playback_rate_code=0;
 always @(posedge clk or posedge rst) begin
  if(rst)bgm_picture_map<=18'h00000;
  else if(restore_defaults_commit)bgm_picture_map<=18'h00000;
  else if(bgm_map_commit)begin
   case(bgm_map_picture)
    1:bgm_picture_map[1:0]<=edit_value[1:0];
    2:bgm_picture_map[3:2]<=edit_value[1:0];
    3:bgm_picture_map[5:4]<=edit_value[1:0];
    4:bgm_picture_map[7:6]<=edit_value[1:0];
    5:bgm_picture_map[9:8]<=edit_value[1:0];
    6:bgm_picture_map[11:10]<=edit_value[1:0];
    7:bgm_picture_map[13:12]<=edit_value[1:0];
    8:bgm_picture_map[15:14]<=edit_value[1:0];
    9:bgm_picture_map[17:16]<=edit_value[1:0];
    default:begin end
   endcase
  end
 end
 always @(posedge clk or posedge rst) begin
  if(rst)begin
   ui_state<=UI_BOOT;home_focus<=0;launch_mode<=1;browser_index<=0;
   media_open_req<=0;media_next_req<=0;media_prev_req<=0;media_play_toggle<=0;
   settings_enter<=0;transform_enter<=0;pip_select_req<=0;pip_move_mode<=0;
   brightness_inc<=0;brightness_dec<=0;zoom_inc<=0;zoom_dec<=0;rotate_cw<=0;rotate_ccw<=0;
   file_select_digit_valid<=0;file_select_digit<=0;settings_digit_valid<=0;settings_digit<=0;
   brightness_level<=5;contrast_level<=5;volume_level<=7;mute_enabled<=0;
   zoom_level<=2;rotation_mode<=0;auto_interval_code<=5;transition_mode<=0;
   osd_enabled<=1;audio_visualizer_enabled<=1;subtitle_enabled<=1;slideshow_auto<=1;audio_enabled<=1;
    bgm_map_picture<=4'd1;
   player_playing<=0;settings_numeric_edit<=0;settings_page<=ROOT;settings_focus<=0;
   ui_fault<=0;edit_value<=0;settings_feedback<=0;confirm_active<=0;confirm_yes<=0;
   software_reset_req<=0;return_state<=UI_BOOT;
   hold_active<=0;hold_right<=0;settings_timer_count<=0;
  end else begin
   media_open_req<=0;media_next_req<=0;media_prev_req<=0;media_play_toggle<=0;
   settings_enter<=0;transform_enter<=0;pip_select_req<=0;
   brightness_inc<=0;brightness_dec<=0;zoom_inc<=0;zoom_dec<=0;rotate_cw<=0;rotate_ccw<=0;
   file_select_digit_valid<=0;settings_digit_valid<=0;software_reset_req<=0;
   // 反馈保持约一秒，之后返回正常操作提示。
   // 长按步进和一秒提示互斥，共用同一计数器，减少寄存器资源。
   if(settings_feedback!=0&&!hold_active)begin
    if(settings_timer_count>=FEEDBACK_TICKS-1)begin settings_feedback<=0;settings_timer_count<=0;end
    else settings_timer_count<=settings_timer_count+1'b1;
   end
   if(hold_release||!settings_context||!settings_numeric_edit)begin
    hold_active<=0;
    if(hold_active)settings_timer_count<=0;
   end
   else if(hold_start&&(hold_code==LEFT||hold_code==RIGHT))begin
    hold_active<=1;hold_right<=(hold_code==RIGHT);settings_timer_count<=0;settings_feedback<=0;
   end else if(hold_active)begin
    if(timed_step)settings_timer_count<=0;else settings_timer_count<=settings_timer_count+1'b1;
   end
   if(ui_state==UI_BOOT&&!media_offline&&picture_count!=0)begin
    ui_state<=UI_PLAYER;launch_mode<=1;browser_index<=0;media_open_req<=!DEMO_IMAGES;player_playing<=1;
   end
   // 数字只替换当前草稿的一个数位，范围外保持旧值并提示。
   if(digit_valid&&digit_code<=9)begin
    if(settings_context&&settings_numeric_edit&&!confirm_active)begin
     if(digit_code>=minimum&&digit_code<=maximum)begin
      edit_value<=digit_code;settings_digit_valid<=1;settings_digit<=digit_code;settings_feedback<=0;
     end else begin settings_feedback<=3;settings_timer_count<=0;end
    end else if(ui_state==UI_PLAYER&&digit_code>=1&&digit_code<=picture_count&&!media_busy)begin
     browser_index<={12'd0,digit_code}-16'd1;media_open_req<=!DEMO_IMAGES;
    end
   end
   if(settings_context&&settings_numeric_edit&&!confirm_active&&(direct_step||timed_step))begin
    settings_feedback<=0;
    if(settings_page==PLAYBACK&&settings_focus==0)begin
     // 图片为封闭环，最后一张再按右是第一张；反方向也一样。
     edit_value<=step_right?((edit_value>=maximum)?minimum:edit_value+4'd1):
                           ((edit_value<=minimum)?maximum:edit_value-4'd1);
    end else if(maximum==1)edit_value<=step_right?4'd1:4'd0;
    else if(step_right&&edit_value<maximum)edit_value<=edit_value+4'd1;
    else if(!step_right&&edit_value>minimum)edit_value<=edit_value-4'd1;
   end
   if(dispatch)begin
    if(action==HASH)begin
     settings_numeric_edit<=0;confirm_active<=0;confirm_yes<=0;hold_active<=0;
     settings_page<=ROOT;settings_focus<=0;home_focus<=0;settings_feedback<=0;
     if(settings_context)ui_state<=return_state;
     else begin return_state<=ui_state;ui_state<=UI_OSD;settings_enter<=1;end
    end else if(ui_state==UI_PLAYER)begin
     case(action)
      OK,PLAY:if(slideshow_auto)player_playing<=~player_playing;
      LEFT:if(!media_busy)media_prev_req<=!DEMO_IMAGES;
      RIGHT:if(!media_busy)media_next_req<=!DEMO_IMAGES;
      default:begin end
     endcase
    end else if(settings_context)begin
     if(confirm_active)begin
      case(action)
       LEFT:confirm_yes<=0;
       RIGHT:confirm_yes<=1;
       BACK:begin confirm_active<=0;confirm_yes<=0;settings_feedback<=2;settings_timer_count<=0;end
       OK:begin
        confirm_active<=0;confirm_yes<=0;settings_timer_count<=0;
        if(!confirm_yes)settings_feedback<=2;
        else if(settings_focus==0)begin
         // 恢复参数不复位媒体，也不覆盖用户的手动暂停状态。
         brightness_level<=5;contrast_level<=5;volume_level<=7;mute_enabled<=0;
         auto_interval_code<=5;transition_mode<=0;osd_enabled<=1;audio_visualizer_enabled<=1;subtitle_enabled<=1;
         slideshow_auto<=1;audio_enabled<=1;settings_feedback<=1;
        end else begin software_reset_req<=1;settings_feedback<=1;end
       end
       default:begin end
      endcase
     end else if(settings_numeric_edit)begin
      if(action==BACK)begin
       settings_numeric_edit<=0;hold_active<=0;settings_feedback<=2;settings_timer_count<=0;
      end else if(action==OK)begin
       if(edit_value<minimum||edit_value>maximum||
          (settings_page==PLAYBACK&&settings_focus==0&&(media_busy||picture_count==0)))begin
        settings_feedback<=3;settings_timer_count<=0;
       end else begin
        settings_numeric_edit<=0;hold_active<=0;settings_feedback<=1;settings_timer_count<=0;
        case(settings_page)
         PLAYBACK:case(settings_focus)
          0:begin
           browser_index<={12'd0,edit_value}-16'd1;
           media_open_req<=!DEMO_IMAGES;
           ui_state<=return_state;
           settings_page<=ROOT;settings_focus<=0;settings_feedback<=0;
           confirm_active<=0;confirm_yes<=0;hold_active<=0;
          end
          1:auto_interval_code<=edit_value;
          2:slideshow_auto<=edit_value[0];
          3:transition_mode<=edit_value[1:0];
          default:begin end
         endcase
         SOUND:case(settings_focus)
          0:volume_level<=edit_value;
          1:mute_enabled<=edit_value[0];
          2:audio_enabled<=edit_value[0];
          default:begin end
         endcase
         DISPLAY:case(settings_focus)
          0:brightness_level<=edit_value;
          1:contrast_level<=edit_value;
          2:osd_enabled<=edit_value[0];
          3:audio_visualizer_enabled<=edit_value[0];
          4:subtitle_enabled<=edit_value[0];
           default:begin end
          endcase
          MUSIC_MAP:case(settings_focus)
           0:bgm_map_picture<=edit_value;
          1:begin end
          default:begin end
         endcase
         default:begin end
        endcase
       end
      end
     end else if(settings_page==ROOT)begin
      case(action)
       LEFT:home_focus<=home_focus-2'd1;
       RIGHT:home_focus<=home_focus+2'd1;
       OK:begin settings_page<={1'b0,home_focus}+3'd1;settings_focus<=0;settings_feedback<=0;end
       BACK:ui_state<=return_state;
       default:begin end
      endcase
     end else begin
      case(action)
       UP:settings_focus<=(settings_focus==0)?last_focus:settings_focus-3'd1;
       DOWN:settings_focus<=(settings_focus>=last_focus)?3'd0:settings_focus+3'd1;
        BACK:begin
         if(settings_page==MUSIC_MAP)begin settings_page<=SOUND;settings_focus<=3;end
         else begin settings_page<=ROOT;settings_focus<=0;end
         settings_feedback<=0;
        end
       OK:begin
        settings_feedback<=0;
         if(settings_page==SOUND&&settings_focus==3)begin
          if(picture_count==0)begin settings_feedback<=3;settings_timer_count<=0;end
          else begin
           settings_page<=MUSIC_MAP;settings_focus<=0;
           bgm_map_picture<=(current_picture<picture_count)?current_picture+4'd1:4'd1;
          end
         end else if(settings_page==SYSTEM)begin confirm_active<=1;confirm_yes<=0;end
        else begin settings_numeric_edit<=1;edit_value<=selected_value;hold_active<=0;end
       end
       default:begin end
      endcase
     end
    end
   end
   // 掉卡优先于按键提交：不把请求发往已经失效的会话。
   if(!DEMO_IMAGES&&media_offline&&(ui_state==UI_PLAYER||(settings_context&&return_state==UI_PLAYER)))begin
    ui_state<=UI_BOOT;browser_index<=0;player_playing<=0;settings_numeric_edit<=0;
    confirm_active<=0;confirm_yes<=0;hold_active<=0;software_reset_req<=0;
    media_open_req<=0;media_next_req<=0;media_prev_req<=0;
   end
  end
 end
endmodule
`default_nettype wire
