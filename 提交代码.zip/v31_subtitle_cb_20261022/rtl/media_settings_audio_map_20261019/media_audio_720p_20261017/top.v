// Original board project: teammate remote/UI front-end and existing B/C backend.
`default_nettype none
module video_top_core #(
    // Production output is fixed at 1280x720; no runtime clock switching.
    parameter DIAGNOSTICS=0,
    parameter ENABLE_RICH_PICTURE_OSD=0
)(
    // Board mapping: docs/BOARD_PIN_MAP.md; constraints/hx4s20_board.adc.
    // Pin names below are FPGA BGA balls, not connector pin numbers.
    input wire clk_50m,             // R7: onboard 50 MHz oscillator
    input wire reset_n,             // A2: KEY1, pressed=0, system reset
    input wire key_next_n,          // B2: KEY2, unused compatibility input
    input wire key_aux_n,           // B1: KEY3, unused compatibility input
    input wire key_auto_n,          // C1: KEY4, unused compatibility input
    input wire ir_rx, // J1 pin 5, GPIOA_4 / H13
    input wire [3:0] switches,      // SW1..4 compatibility inputs; ignored
    input wire tf_miso,             // B14: TF pin 7 DAT0/DO, card -> FPGA
    output wire tf_sclk,            // A14: TF pin 5 CLK, FPGA -> card
    output wire tf_mosi,            // A13: TF pin 3 CMD/DI, FPGA -> card
    output wire tf_cs_n,            // A12: TF pin 2 DAT3/CS, selected=0
    output wire hdmi_clk_p,         // HDMI B: P=C3, paired N=C2 via vendor PHY
    output wire [2:0] hdmi_data_p,  // B D0/D1/D2: P=G5/F1/E1; N=G6/F2/D1
    output wire hdmi_ddc_scl,       // P2: HDMI B SCL, connector pin 15
    inout wire hdmi_ddc_sda,        // R2: HDMI B SDA, connector pin 16
    output wire [3:0] led_status    // [0..3]=LED1..4: A4,A3,C10,B12; on=1
);
wire clk_sys;
wire clk_sd;
wire clk_mem;
wire clk_mem_sft;
wire clk_pixel;
wire clk_hdmi_serial;
wire rst_sys;
wire rst_sd;
wire rst_mem;
wire rst_pixel;
wire rst_hdmi_serial;
wire clocks_ready;
wire software_reset_req;
wire img_frame_start;
wire img_start_ready;
wire [15:0] img_width;
wire [15:0] img_height;
wire img_bottom_up;
wire [15:0] img_index;
wire img_pixel_valid;
wire img_pixel_ready;
wire [23:0] img_pixel_data;
wire img_frame_end;
wire img_end_ready;
wire img_abort;
wire img_abort_ready;
wire img_result_valid;
wire img_result_ready;
wire [3:0] img_result_code;
wire [15:0] img_result_index;
wire frame_ready;
wire disp_req;
wire disp_ack;
wire disp_keep_old;
wire disp_valid;
wire disp_buffer_sel;
wire [15:0] disp_width;
wire [15:0] disp_height;
wire [15:0] disp_index;
wire [1:0] disp_physical_slot;
wire [31:0] disp_generation;
wire disp_previous_valid;
wire disp_previous_sel;
wire disp_previous_release_req;
wire disp_previous_release_ack;
wire read_req;
wire read_ack;
wire read_buffer_sel;
wire [31:0] read_start_addr;
wire [31:0] read_length;
wire read_pixel_valid;
wire read_pixel_ready;
wire [23:0] read_pixel_data;
wire read_pixel_last;
wire read_done;
wire read_done_ready;
wire [3:0] read_status;
wire read_cancel_req;
wire read_cancel_ack;
wire input_fault;
wire memory_fault;
wire tf_load_fault;
wire output_fault;
wire media_catalog_done;wire media_card_offline;
wire media_catalog_ok;
wire [4:0] media_asset_count;
wire media_storage_ready;
wire media_request_valid;
wire media_request_ready;
wire [3:0] media_request_id;
wire media_request_cancel;
wire media_result_valid;
wire [3:0] media_result_code;
wire media_request_started;
wire [95:0] ui_status_payload_pixel;
wire ui_status_valid_pixel;
wire bgm_selected, bgm_audio_valid, bgm_acr_valid, bgm_meter_valid;
wire bgm_visualizer_enable;
wire [23:0] bgm_audio_left, bgm_audio_right;
wire [19:0] bgm_acr_cts, bgm_acr_n;
wire [3:0] bgm_level_left, bgm_level_right;

clock_reset_subsystem u_k (
    .clk_50m(clk_50m),
    .reset_n(reset_n), .software_reset_req(software_reset_req),
    .clk_sys(clk_sys),
    .clk_sd(clk_sd),
    .clk_mem(clk_mem),
    .clk_mem_sft(clk_mem_sft),
    .clk_pixel(clk_pixel),
    .clk_hdmi_serial(clk_hdmi_serial),
    .rst_sys(rst_sys),
    .rst_sd(rst_sd),
    .rst_mem(rst_mem),
    .rst_pixel(rst_pixel),
    .rst_hdmi_serial(rst_hdmi_serial),
    .clocks_ready(clocks_ready)
);

ui_media_input_subsystem u_a (
    .software_reset_req(software_reset_req),
    .key_aux_n(1'b1),.ir_rx_async(ir_rx),
    .clk_pixel(clk_pixel),.rst_pixel(rst_pixel),
    .ui_status_payload_pixel(ui_status_payload_pixel),.ui_status_valid_pixel(ui_status_valid_pixel),
    .key_next_n(1'b1),
    .key_auto_n(1'b1),
    .clk_sys(clk_sys),
    .clk_sd(clk_sd),
    .rst_sys(rst_sys),
    .rst_sd(rst_sd),
    .img_frame_start(img_frame_start),
    .img_start_ready(img_start_ready),
    .img_width(img_width),
    .img_height(img_height),
    .img_bottom_up(img_bottom_up),
    .img_index(img_index),
    .img_pixel_valid(img_pixel_valid),
    .img_pixel_ready(img_pixel_ready),
    .img_pixel_data(img_pixel_data),
    .img_frame_end(img_frame_end),
    .img_end_ready(img_end_ready),
    .img_abort(img_abort),
    .img_abort_ready(img_abort_ready),
    .img_result_valid(img_result_valid),
    .img_result_ready(img_result_ready),
    .img_result_code(img_result_code),
    .img_result_index(img_result_index),
    .media_card_offline(media_card_offline),.media_catalog_done(media_catalog_done),
    .media_catalog_ok(media_catalog_ok),
    .media_asset_count(media_asset_count),
    .media_storage_ready(media_storage_ready),
    .media_request_valid(media_request_valid),
    .media_request_ready(media_request_ready),
    .media_request_id(media_request_id),
    .media_request_cancel(media_request_cancel),
    .media_result_valid(media_result_valid),
    .media_result_code(media_result_code),
    .media_request_started(media_request_started),
    .input_fault(input_fault)
);

framebuffer_subsystem #(.DIAGNOSTICS(DIAGNOSTICS)) u_b (
    .rst_catalog(rst_sd),
    .media_card_offline(media_card_offline),.media_catalog_done(media_catalog_done),
    .media_catalog_ok(media_catalog_ok),
    .media_asset_count(media_asset_count),
    .media_storage_ready(media_storage_ready),
    .media_request_valid(media_request_valid),
    .media_request_ready(media_request_ready),
    .media_request_id(media_request_id),
    .media_request_cancel(media_request_cancel),
    .media_result_valid(media_result_valid),
    .media_result_code(media_result_code),
    .media_request_started(media_request_started),
    .tf_miso(tf_miso),
    .tf_sclk(tf_sclk),
    .tf_mosi(tf_mosi),
    .tf_cs_n(tf_cs_n),
    .clk_sys(clk_sys),
    .clk_sd(clk_sd),
    .clk_mem(clk_mem),
    .clk_mem_sft(clk_mem_sft),
    .clk_pixel(clk_pixel),
    .rst_sys(rst_sd),
    .rst_sd(rst_sd),
    .rst_mem(rst_mem),
    .rst_pixel(rst_pixel),
    .img_frame_start(img_frame_start),
    .img_start_ready(img_start_ready),
    .img_width(img_width),
    .img_height(img_height),
    .img_bottom_up(img_bottom_up),
    .img_index(img_index),
    .img_pixel_valid(img_pixel_valid),
    .img_pixel_ready(img_pixel_ready),
    .img_pixel_data(img_pixel_data),
    .img_frame_end(img_frame_end),
    .img_end_ready(img_end_ready),
    .img_abort(img_abort),
    .img_abort_ready(img_abort_ready),
    .img_result_valid(img_result_valid),
    .img_result_ready(img_result_ready),
    .img_result_code(img_result_code),
    .img_result_index(img_result_index),
    .frame_ready(frame_ready),
    .disp_req(disp_req),
    .disp_ack(disp_ack),
    .disp_keep_old(disp_keep_old),
    .disp_valid(disp_valid),
    .disp_buffer_sel(disp_buffer_sel),
    .disp_width(disp_width),
    .disp_height(disp_height),
    .disp_index(disp_index),
    .disp_physical_slot(disp_physical_slot),
    .disp_generation(disp_generation),
    .disp_previous_valid(disp_previous_valid),
    .disp_previous_sel(disp_previous_sel),
    .disp_previous_release_req(disp_previous_release_req),
    .disp_previous_release_ack(disp_previous_release_ack),
    .read_req(read_req),
    .read_ack(read_ack),
    .read_buffer_sel(read_buffer_sel),
    .read_start_addr(read_start_addr),
    .read_length(read_length),
    .read_pixel_valid(read_pixel_valid),
    .read_pixel_ready(read_pixel_ready),
    .read_pixel_data(read_pixel_data),
    .read_pixel_last(read_pixel_last),
    .read_done(read_done),
    .read_done_ready(read_done_ready),
    .read_status(read_status),
    .read_cancel_req(read_cancel_req),
    .read_cancel_ack(read_cancel_ack),
    .memory_fault(memory_fault),
    .tf_load_fault(tf_load_fault),
    .tf_scan_status(),
    .tf_reader_error_code(),
    .boot_progress(),
    .memory_diag(),
    .read_request_diag(),
    .pixel_crc_diag(),
    .native_write_crc(),.alignment_match(),
    .alignment_status(),
    .native_read_addr_diag(),.native_access_diag(),
    .ui_status_payload_pixel(ui_status_payload_pixel),
    .bgm_selected(bgm_selected),.bgm_audio_valid(bgm_audio_valid),
    .bgm_audio_left(bgm_audio_left),.bgm_audio_right(bgm_audio_right),
    .bgm_acr_valid(bgm_acr_valid),.bgm_acr_cts(bgm_acr_cts),.bgm_acr_n(bgm_acr_n),
    .bgm_meter_valid(bgm_meter_valid),.bgm_visualizer_enable(bgm_visualizer_enable),
    .bgm_level_left(bgm_level_left),.bgm_level_right(bgm_level_right)
);

av_output_subsystem #(
    .DIAGNOSTICS(DIAGNOSTICS),
    .ENABLE_RICH_PICTURE_OSD(ENABLE_RICH_PICTURE_OSD),
    .FRAME_WIDTH(1280),
    .FRAME_HEIGHT(720),
    .H_FRONT(110),
    .H_SYNC(40),
    .H_BACK(220),
    .V_FRONT(5),
    .V_SYNC(5),
    .V_BACK(20),
    .VIDEO_VIC(4)
) u_c (
    .frame_boundary(),
    .ui_status_payload_pixel(ui_status_payload_pixel),.ui_status_valid_pixel(ui_status_valid_pixel),
    .media_catalog_done(media_catalog_done),
    .media_asset_count(media_asset_count),
    .ext_audio_enable(bgm_selected),.ext_audio_valid(bgm_audio_valid),
    .ext_audio_left(bgm_audio_left),.ext_audio_right(bgm_audio_right),
    .ext_acr_valid(bgm_acr_valid),.ext_acr_cts(bgm_acr_cts),.ext_acr_n(bgm_acr_n),
    .ext_meter_valid(bgm_meter_valid),.ext_level_left(bgm_level_left),.ext_level_right(bgm_level_right),
    .ext_visualizer_enable(bgm_visualizer_enable),
    .key_aux_n(1'b1),
    .switches(4'b0000),
    .hdmi_clk_p(hdmi_clk_p),
    .hdmi_data_p(hdmi_data_p),
    .hdmi_ddc_scl(hdmi_ddc_scl),
    .hdmi_ddc_sda(hdmi_ddc_sda),
    .clk_sys(clk_sys),
    .clk_pixel(clk_pixel),
    .clk_hdmi_serial(clk_hdmi_serial),
    .rst_sys(rst_sys),
    .rst_pixel(rst_pixel),
    .rst_hdmi_serial(rst_hdmi_serial),
    .frame_ready(frame_ready),
    .disp_req(disp_req),
    .disp_ack(disp_ack),
    .disp_keep_old(disp_keep_old),
    .disp_valid(disp_valid),
    .disp_buffer_sel(disp_buffer_sel),
    .disp_width(disp_width),
    .disp_height(disp_height),
    .disp_index(disp_index),
    .disp_generation(disp_generation),
    .disp_previous_valid(disp_previous_valid),
    .disp_previous_sel(disp_previous_sel),
    .disp_previous_release_req(disp_previous_release_req),
    .disp_previous_release_ack(disp_previous_release_ack),
    .read_req(read_req),
    .read_ack(read_ack),
    .read_buffer_sel(read_buffer_sel),
    .read_start_addr(read_start_addr),
    .read_length(read_length),
    .read_pixel_valid(read_pixel_valid),
    .read_pixel_ready(read_pixel_ready),
    .read_pixel_data(read_pixel_data),
    .read_pixel_last(read_pixel_last),
    .read_done(read_done),
    .read_done_ready(read_done_ready),
    .read_status(read_status),
    .read_cancel_req(read_cancel_req),
    .read_cancel_ack(read_cancel_ack),
    .output_fault(output_fault),
    .display_progress(),
    .output_diag(),
    .axis_crc_diag()
);

// Basic fault indicators only; no selectable diagnostic banks.
assign led_status={output_fault,memory_fault,input_fault | tf_load_fault,clocks_ready};
endmodule

`default_nettype wire
