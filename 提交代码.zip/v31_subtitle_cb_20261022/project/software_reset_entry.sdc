# The five clock-domain release chains have asynchronous assertion and
# synchronous release. Cut only the verified root reset net entering their
# asynchronous SR pins; D/Q functional paths remain timed.
set_units -time ns
set_false_path -through [get_nets {*u_video_top_core/u_k/reset_async}]
