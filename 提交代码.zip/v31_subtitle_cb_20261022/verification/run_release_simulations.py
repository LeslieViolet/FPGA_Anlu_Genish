from pathlib import Path
import argparse,shutil,os,json,subprocess
root=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--iverilog');ap.add_argument('--vvp');ap.add_argument('--list',action='store_true');args=ap.parse_args()
A=root/'rtl/media_settings_audio_map_20261019/media_audio_720p_20261017';V=root/'verification'
O=root/'simulation_output'
tests=[('tb_fade_equivalence',[V/'reference/baseline_transition_fade.v',A/'transition_fade.v',V/'tb_fade_equivalence.sv'],'FADE_EQUIVALENCE_PASS'),
('tb_subtitle_font',[A/'promo_subtitle_font_rom.v',V/'tb_subtitle_font.sv'],'SUBTITLE_FONT_PASS'),
('tb_subtitle_motion',[A/'promo_marquee_renderer.v',V/'tb_subtitle_motion.sv'],'SUBTITLE_MOTION_PASS'),
('tb_subtitle_pixels',[V/'reference/baseline_ui_media_compositor.v',V/'reference/baseline_promo_marquee_renderer.v',*[A/(n+'.v') for n in ['ui_media_compositor','promo_marquee_renderer','promo_subtitle_font_rom','ui_settings_renderer','ui_font16_sync_rom','ui_color_lut']],V/'tb_subtitle_pixels.sv'],'SUBTITLE_PIXELS_PASS')]
tests.append(('tb_frame_fetch_equivalence',[V/'reference/baseline_bc_frame_fetch_for_video_pipe.v',A/'bc_frame_fetch_for_video_pipe.v',A/'guanfang_yibu_fifo.v',V/'media_prefetch_fifo_model.sv',V/'tb_frame_fetch_equivalence.sv'],'FRAME_FETCH_EQUIVALENCE_PASS'))
for _,files,_ in tests:
    for p in files:assert p.is_file(),p
if args.list:
    print('SIMULATION_PATHS_VALID 5 tests');raise SystemExit(0)
known=Path('D:/FPGA/work/tools/simulation/msys2-iverilog-13.0/ucrt64/bin')
iverilog=args.iverilog or shutil.which('iverilog') or (str(known/'iverilog.exe') if known.exists() else None)
assert iverilog,'Pass --iverilog with the full path to iverilog'
vvp=args.vvp or str(Path(iverilog).with_name('vvp.exe' if str(iverilog).endswith('.exe') else 'vvp'))
env=os.environ.copy();env['PATH']=str(Path(iverilog).parent)+os.pathsep+env.get('PATH','')
O.mkdir(exist_ok=True);shutil.copy2(V/'subtitle_ink.hex',O/'subtitle_ink.hex')
for top,files,marker in tests:
    extra=['-DB_FANGZHEN'] if top=='tb_frame_fetch_equivalence' else []
    commands=[[iverilog,'-g2012','-s',top,'-o',str(O/(top+'.vvp')),*extra,*map(str,files)],[vvp,str(O/(top+'.vvp'))]]
    for i,cmd in enumerate(commands):
        p=subprocess.run(cmd,env=env,cwd=O,capture_output=True)
        (O/f'{top}.{i}.log').write_bytes(p.stdout+p.stderr)
        assert p.returncode==0,(top,i,p.returncode)
        if i:assert marker.encode() in p.stdout
    (O/(top+'.commands.json')).write_text(json.dumps(commands,indent=2))
    print(marker,flush=True)
