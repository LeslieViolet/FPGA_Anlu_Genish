# 透明居中字幕 C+B：冻结规格

## 0. 目标与验收

用户选择 C+B：三条短句依次滚入、居中停留、滚出，配白字、金色和珊瑚色重点及细描边。透明底，只修改字及其紧邻的轮廓像素；关闭字幕后视频逐像素等价。基线为已交付 v31_audio3_subtitle_20261021，原目录不改。

固定文案：①夏日清凉好滋味；②全场9.5折，买一送一；③欢迎光临，清凉一夏。第二句“全场9.5折”为金色、“买一送一”为珊瑚色，逗号及第一、三句为暖白。描边为深紫灰色，不是矩形底板。

720p 字幕可视窗口 x=320..959，中心 x=640；文字 y=24..55，16×16字模放大2倍。窗口与右上状态栏 x>=1008、底部频谱 y>=622 不重叠。状态栏开关不改变字幕位置。滚动4像素/有效SOF，约242.4像素/秒，居中停留120帧约1.98秒。三条短句分别7、11、9个全宽字位。

## 1. 模块及端口契约

工作目录：work/rtl/v31_subtitle_cb_20261022/media_settings_audio_map_20261019。

- promo_marquee_renderer：同一75MHz像素域，异步断言/原像素复位释放；输入 clk/rst/enabled、x/y[10:0]、user_in/valid_in。输出 font_valid、font_address[8:0]（{global_character[4:0],row[3:0]}）、font_col[3:0]、font_palette[1:0]。原 panel_hit 删除，禁止产生字幕底板。无物理端口或新CDC。
- promo_subtitle_font_rom：输入 clk、address[8:0]，同步一拍输出 bits[31:0]，低16bit为文字，高16bit为轮廓。最终固定512×32bit共16384bit，即2048byte；不访问TF或SDRAM。三句基址0/7/18，填充空位为0。
- ui_media_compositor：UI原文字表及字体不变；字幕地址/列/颜色在描述符拍登记，新字库与原UI字库同拍读取，最终优先合成文字、轮廓、原UI/图片。RGB/valid/SOF/EOL仍严格四拍。
- UI 96bit快照[77]、PLAYER状态[63:60]==2、其余字段和邮箱不改；设置页面隐藏字幕并冻结状态，重新进入恢复当前位置。

## 2. 状态与不变式

ENTER：字串从x=960向左滚动，达到整句居中坐标后转HOLD。HOLD计120个有效帧后转EXIT。EXIT向左移动到整句离开x=320，下一句重新ENTER。句号编号0→1→2→0。只有enabled&&valid_in&&user_in推进，普通像素、无效周期、设置期间或字幕关掉时均不推进；状态仅在帧边界改变，禁止字串中途跳变。

轮廓在构建时由原始16×16字模做3×3邻域扩张后减去笔画生成，实机约2像素宽；不使用逐像素浮点、alpha乘法或动态邻域读取。

## 3. 资源及带宽预算

新字库最终16384bit，TD实测映射为2块BRAM9K；原版本BRAM32K=2/16、BRAM9K=54/64、LUT=17722/19600。本版最终BRAM9K=56/64、BRAM32K仍2/16。旧共享字库不改，避免新文案占用UI字位。帧缓存仍为两张1280×720×32bit，共7372800byte，外部8MiB余1015808byte。75MHz/1650/750=60.606Hz，平均帧读223.4MB/s，48kHz双声道16bit音频192000byte/s；本改动不增加这两条带宽。最终资源与时序见SUBTITLE_CB_STATUS_20261022.json。

## 4. 验证顺序和边界

先生成/检查字库模块并自动比对所有地址的笔画与轮廓，再实现并测试滚动状态、三句、暂停/循环/区域/颜色；随后接合成器，逐像素验证透明、关闭等价、描边、颜色及四拍数据边界。编译通过后才运行仿真。全部通过后检查AL路径、UsedInSyn/UsedInP&R、CompileOrder和TOP；使用原已通过工程模板及原ADC/SDC进行TD综合布局布线。复用已审计的复位SR例外，不新增功能路径例外。未通过物理检查不发布新BIT。

板测仍需确认字幕可读性、三句节奏、字幕开关、状态栏开关、图片切换和三首配乐。资料依据：ARCHITECTURE.md、INTERFACE_CONTRACT.md、BOARD_PIN_MAP.md、原ADC/SDC、fpga_board.al、20261021交付的真实源码、AL与签核流程；无新增引脚、IP端口或外部协议参数。

## v2 紧凑字库与固定宽度滚动契约

v1的3组功能仿真通过，但多个物理布局存在MSlice超限、布线冲突或负setup余量，不能生成交付位流。v1源码和测试备份在work/backups/subtitle_cb_v1_20261022。

v2不改变RGB/SOF/EOL/valid四拍、文字内容、样式和UI快照。字库按27个实际字符连续排列，ROM缩为512×32bit=16384bit（2048byte），font_address端口改为9bit，高5bit为全局字符索引，低4bit为行。三句全局字符基址0/7/18。描边计算和字形位图仍相同。

滚动采用统一的352像素宽字位框，三句分别在左侧填2/0/1个透明字位，因此三句笔画的中心仍为x640。透明填充不产生font_valid；全局索引由相对字位加常量得到。ENTER/HOLD/EXIT的居中及结束偏移均变成常数，消除原先三路宽度/目标坐标选择。窗口、每帧步进和120帧停留不变。先验证512字库地址、运动状态和像素比对，再对v2重新综合；禁止复用v1门级数据库生成v2位流。

## v3 渐变运算等价精简

物理报告定位到 fade_level→transition_fade乘法→rgb3 的75MHz长路径。transition_fade端口、组合延迟拍数和全部输入语义保持：level[4]=1表示16..31，原先均限幅到16并原样输出rgb；level[4]=0时使用低4位做RGB×level/16。因此以4bit乘法和满亮直通替换5bit乘法前的限幅，不引入寄存器或新时钟。先穷举全部32级×256通道值，并与原真实模块比较每个RGB通道，再重新综合；图片解码、SDRAM、读卡仲裁、帧提交和音频不改。保护清单允许额外一份transition_fade.v，禁止仅靠改变时序例外通过检查。

## v4 完整帧计数比较等价精简

v3最接近通过的布局仅有received_count到failed_frame的setup=-0.006ns。具体组合逻辑为33bit received_count+input_take再与32bit active_words比较。将完成谓词改为input_take ? (active_words!=0 && received_count==active_words-1) : received_count==active_words，并复用末像素判断。对所有32bit计数、32bit目标和1bit取数，共65bit任意输入，先用SAT证明该谓词等价；不改变计数器本身、状态机、FIFO、握手、错误周期、帧租约或切图策略。仅放行bc_frame_fetch_for_video_pipe.v这一额外源的组合表达式修改，随后重新综合；不得复用v3门级数据库生成v4位流。
