// Four registered pixel stages. RGB and SOF/EOL/VALID always take the
// same path, including bypass/blank pixels. There is no backpressure.
// Layer order: source picture -> translucent plate -> glyph/logo.
`default_nettype none
module rich_picture_osd #(
    parameter FRAME_WIDTH = 1280,
    parameter FRAME_HEIGHT = 720
) (
    input wire clk,
    input wire rst,
    input wire enabled,
    input wire [10:0] x,
    input wire [10:0] y,
    input wire user_in,
    input wire last_in,
    input wire valid_in,
    input wire [23:0] rgb_in,
    input wire [23:0] time_bcd,
    output reg user_out,
    output reg last_out,
    output reg valid_out,
    output reg [23:0] rgb_out
);
    localparam [23:0] NAVY = 24'h102848;
    localparam [23:0] LOGO_NAVY = 24'h18283F;
    localparam [23:0] LOGO_RED = 24'hCB333B;
    localparam SD_HEIGHT = FRAME_HEIGHT;
    wire active_hd = (FRAME_WIDTH>640);
    wire [10:0] norm_x = active_hd ? {1'b0,x[10:1]} : x;
    wire [10:0] norm_y = active_hd ? {1'b0,y[10:1]} : y;
    wire [10:0] strip_top = active_hd ? 11'd320 : SD_HEIGHT-40;
    wire [10:0] strip_bottom = active_hd ? 11'd348 : SD_HEIGHT-12;
    wire [10:0] text_top = active_hd ? 11'd326 : SD_HEIGHT-34;
    reg [9:0] phase;
    reg [23:0] frame_time;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            phase <= 10'd192;
            frame_time <= 24'd0;
        end else if (valid_in && user_in) begin
            frame_time <= time_bcd;
            if (enabled) phase <= phase==10'd831 ? 10'd0 : phase+10'd1;
        end
    end

    wire [11:0] text_scan = {1'b0,norm_x}+{2'b0,phase};
    wire [7:0] text_offset = text_scan-12'd640;
    wire [6:0] logo_x = norm_x-11'd16;
    wire [4:0] logo_y = norm_y-11'd16;
    wire [6:0] clock_x = norm_x-11'd16;
    wire [10:0] text_y = norm_y-text_top;
    reg [4:0] glyph_now;
    reg [3:0] row_now, col_now;
    reg [1:0] plate_now;
    reg [23:0] foreground_now;
    reg glyph_enable_now;
    reg [3:0] digit_now;
    // plate: 0 bypass; 1 navy at 25%; 2 white at 50%.
    always @* begin
        glyph_now=5'd31; row_now=4'd0; col_now=4'd0;
        plate_now=2'd0; foreground_now=24'hFFFFFF;
        glyph_enable_now=1'b0; digit_now=4'd0;
        if (enabled && valid_in) begin
            if (norm_x>=11'd12 && norm_x<11'd132 &&
                norm_y>=11'd12 && norm_y<11'd52) plate_now=2'd2;
            else if ((norm_x>=11'd12 && norm_x<11'd148 &&
                      norm_y>=11'd54 && norm_y<11'd76) ||
                     (norm_y>=strip_top && norm_y<strip_bottom)) plate_now=2'd1;
            if (norm_x>=11'd16 && norm_x<11'd128 &&
                norm_y>=11'd16 && norm_y<11'd48) begin
                glyph_enable_now=1'b1;
                glyph_now=5'd17+{2'd0,logo_x[6:4]}+(logo_y[4] ? 5'd7 : 5'd0);
                row_now=logo_y[3:0]; col_now=logo_x[3:0];
                foreground_now=(logo_x<7'd38 && logo_y<5'd23 &&
                                logo_x>=7'd16+{3'd0,logo_y[4:1]}) ? LOGO_RED : LOGO_NAVY;
            end else if (norm_x>=11'd16 && norm_x<11'd144 &&
                         norm_y>=11'd56 && norm_y<11'd72) begin
                glyph_enable_now=1'b1;
                row_now=norm_y-11'd56; col_now=clock_x[3:0];
                case (clock_x[6:4])
                    3'd0: digit_now=frame_time[23:20];
                    3'd1: digit_now=frame_time[19:16];
                    3'd3: digit_now=frame_time[15:12];
                    3'd4: digit_now=frame_time[11:8];
                    3'd6: digit_now=frame_time[7:4];
                    3'd7: digit_now=frame_time[3:0];
                    default: digit_now=4'd0;
                endcase
                glyph_now=(clock_x[6:4]==3'd2 || clock_x[6:4]==3'd5) ?
                          5'd16 : (digit_now<4'd10 ? 5'd6+{1'b0,digit_now} : 5'd31);
            end else if (norm_y>=text_top && text_y<11'd16 &&
                         text_scan>=12'd640 && text_scan<12'd832) begin
                glyph_enable_now=1'b1;
                row_now=text_y[3:0]; col_now=text_offset[3:0];
                // guan zhu ta fei miao guan zhu ta fei xie xie miao.
                case (text_offset[7:4])
                    4'd0,4'd5: glyph_now=5'd0;
                    4'd1,4'd6: glyph_now=5'd1;
                    4'd2,4'd7: glyph_now=5'd2;
                    4'd3,4'd8: glyph_now=5'd3;
                    4'd4,4'd11: glyph_now=5'd4;
                    4'd9,4'd10: glyph_now=5'd5;
                    default: glyph_now=5'd31;
                endcase
            end
        end
    end

    // Stage 1: geometry and glyph address.
    reg [4:0] glyph_s1;
    reg [3:0] row_s1, col_s1;
    reg [1:0] plate_s1;
    reg glyph_enable_s1, user_s1, last_s1, valid_s1;
    reg [23:0] rgb_s1, foreground_s1;
    // Stage 2: the dedicated ROM's synchronous read plus matching metadata.
    wire [15:0] mask_bits_s2;
    rich_osd_mask_rom u_mask_rom (.clk(clk), .glyph(glyph_s1),
                                .row(row_s1), .bits(mask_bits_s2));
    reg [3:0] col_s2;
    reg [1:0] plate_s2;
    reg glyph_enable_s2, user_s2, last_s2, valid_s2;
    reg [23:0] rgb_s2, foreground_s2;
    wire [23:0] navy_background, white_background;
    alpha_blend_quarters #(.ALPHA(1)) u_plate_navy (
        .background_rgb(rgb_s2), .foreground_rgb(NAVY), .mixed_rgb(navy_background));
    alpha_blend_quarters #(.ALPHA(2)) u_plate_white (
        .background_rgb(rgb_s2), .foreground_rgb(24'hFFFFFF), .mixed_rgb(white_background));
    // Stage 3: the bottom blend is registered before the foreground blend.
    reg [23:0] background_s3, foreground_s3;
    reg glyph_pixel_s3, user_s3, last_s3, valid_s3;
    wire [23:0] foreground_mixed;
    alpha_blend_quarters #(.ALPHA(3)) u_glyph_blend (
        .background_rgb(background_s3), .foreground_rgb(foreground_s3),
        .mixed_rgb(foreground_mixed));
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            glyph_s1<=5'd31; row_s1<=0; col_s1<=0; plate_s1<=0;
            glyph_enable_s1<=0; user_s1<=0; last_s1<=0; valid_s1<=0;
            rgb_s1<=0; foreground_s1<=0;
            col_s2<=0; plate_s2<=0; glyph_enable_s2<=0;
            user_s2<=0; last_s2<=0; valid_s2<=0; rgb_s2<=0; foreground_s2<=0;
            background_s3<=0; foreground_s3<=0; glyph_pixel_s3<=0;
            user_s3<=0; last_s3<=0; valid_s3<=0;
            user_out<=0; last_out<=0; valid_out<=0; rgb_out<=0;
        end else begin
            glyph_s1<=glyph_now; row_s1<=row_now; col_s1<=col_now;
            plate_s1<=plate_now; glyph_enable_s1<=glyph_enable_now;
            user_s1<=user_in; last_s1<=last_in; valid_s1<=valid_in;
            rgb_s1<=rgb_in; foreground_s1<=foreground_now;
            col_s2<=col_s1; plate_s2<=plate_s1; glyph_enable_s2<=glyph_enable_s1;
            user_s2<=user_s1; last_s2<=last_s1; valid_s2<=valid_s1;
            rgb_s2<=rgb_s1; foreground_s2<=foreground_s1;
            background_s3<=plate_s2==2'd2 ? white_background :
                           plate_s2==2'd1 ? navy_background : rgb_s2;
            foreground_s3<=foreground_s2;
            glyph_pixel_s3<=glyph_enable_s2 && mask_bits_s2[4'd15-col_s2];
            user_s3<=user_s2; last_s3<=last_s2; valid_s3<=valid_s2;
            user_out<=user_s3; last_out<=last_s3; valid_out<=valid_s3;
            rgb_out<=glyph_pixel_s3 ? foreground_mixed : background_s3;
        end
    end
endmodule
`default_nettype wire
