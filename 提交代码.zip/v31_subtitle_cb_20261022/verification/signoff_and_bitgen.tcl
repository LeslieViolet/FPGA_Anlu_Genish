set root [file normalize [file join [file dirname [info script]] ..]]
set run_dir [file join $root rebuild_output]
import_device eagle_s20.db -package EG4S20BG256
import_db [file join $run_dir implementation.db]
clear_user_sdc
read_sdc [file join $root project shizhong_static_720p.sdc]
read_sdc [file join $root project software_reset_entry.sdc]
read_sdc [file join $root project end_pixel_reset_entry.sdc]
source [file join $root verification audit_end_pixel_release_physical.tcl]
source [file join $root verification apply_pcm_rd_reset_physical.tcl]
report_route_status -drc
update_timing -mode final
source [file join $root verification audit_pcm_dq_timing.tcl]
report_timing_status -file "$run_dir/final.ts"
report_timing_summary -file "$run_dir/final_timing.rpt"
report_area -io_info -file "$run_dir/physical.area"
check_timing -verbose -file "$run_dir/timing_check.txt"
set f [open "$run_dir/final.ts" r];set t [read $f];close $f
if {![regexp {SWNS:\s*([-+]?[0-9.]+)ns,\s*STNS:\s*([-+]?[0-9.]+)ns} $t -> sw st] ||
 ![regexp {HWNS:\s*([-+]?[0-9.]+)ns,\s*HTNS:\s*([-+]?[0-9.]+)ns} $t -> hw ht]} {error TIMING_PARSE_FAIL}
if {$sw<0 || $st<0 || $hw<0 || $ht<0} {error "TIMING_FAIL $t"}
set f [open "$run_dir/timing_check.txt" r];set t [read $f];close $f
if {![regexp {There are 0 invalid constraints} $t]} {error INVALID_CONSTRAINTS}
set f [open "$run_dir/final_timing.rpt" r];set t [read $f];close $f
if {![regexp {STA coverage\s*:\s*99\.98%} $t] || ![regexp {clk0\s+local\s+\S+\s+\S+\s+20\.000\s+50\.000} $t]} {error CLOCK_COVERAGE_INVALID}
export_db "$run_dir/final.db"
bitgen -bit "$run_dir/v31_subtitle_cb_20261022.bit"
puts SUBTITLE_CB_SIGNOFF_BITGEN_PASS
exit
